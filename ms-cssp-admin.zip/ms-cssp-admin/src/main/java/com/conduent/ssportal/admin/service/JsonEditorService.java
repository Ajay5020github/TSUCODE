/**
 * 
 */
package com.conduent.ssportal.admin.service;

import com.conduent.ssportal.admin.exception.JsonEditException;
import com.conduent.ssportal.admin.exception.JsonNotFoundException;
import com.conduent.ssportal.admin.model.*;

/**
 * @author C5109952
 *
 */
public interface JsonEditorService {
	
	public JsonResponseBean fetchJson(JsonRequestBean request) throws JsonEditException;

	public JsonResponseBean saveChanges(JsonRequestBean request) throws JsonEditException;

	public JsonResponseBean revertChanges(JsonRequestBean request) throws JsonEditException;

	public JsonResponseBean publishJson(JsonRequestBean request) throws JsonEditException;

	public JsonResponseBean fetchLog(JsonRequestBean request) throws JsonEditException;
	
	public JSONContentResponseBean readJson(String fileName) throws JsonNotFoundException;

    JSONLockedResponseBean fetchLockedFiles(String userId) throws JsonEditException;
}
