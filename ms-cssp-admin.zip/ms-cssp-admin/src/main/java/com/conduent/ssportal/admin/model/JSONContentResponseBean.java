package com.conduent.ssportal.admin.model;

import org.json.simple.JSONObject;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class JSONContentResponseBean {
	
	private int statusCode;
	private String message;
	private JSONObject data;

}