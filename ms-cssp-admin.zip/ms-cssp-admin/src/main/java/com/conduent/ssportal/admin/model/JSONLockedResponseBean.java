package com.conduent.ssportal.admin.model;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Setter
@Getter
public class JSONLockedResponseBean {

    private String message;
    private List<LockedFile> lockedFiles;


    @Setter
    @Getter
    public static class LockedFile{
        public String screenName;
        public String language;
        public Date lastSavedDateTime;
        private String comments;
    }
}
