/**
 * create account 25-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 * Licensed under the CONDUENT License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * Software is the copyrighted work of Conduent and/or its licensors. Copying or reproducing
 * the Software to any other server or location for further reproduction or redistribution is
 * prohibited,  unless such reproduction or redistribution is permitted by a license agreement
 * accompanying  such Software. You may not create derivative works of the Software, or attempt to
 * decompile or reverse-engineer the Software unless otherwise permitted by law. Use of the Software
 * is subject to the license terms of any license agreement that may accompany or is provided
 * with the Software.
 */
/*
 * @author C5100105 Description: This package is used for bean creation
 *
 *
 *
 */

package com.conduent.ssportal.admin.entity;

import java.util.Date;
import java.util.Set;

import com.conduent.ssportal.admin.util.ColumnAttributeConverter;
import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Entity
@Data
@Table(name = "ADMIN_USER_DETAILS_TB")
public class AdminUser {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long accountUserSeq;

	@Size(max = 50)
	private String firstName;

	@Size(max = 50)
	private String lastName;

	@Size(max = 15)
	private String phoneNumber;

	@Size(max = 5)
	private String zipCode;

	@Size(max = 50)
	private String emailAddress;

	@Size(max = 1)
	private String mobileContactInd;

	@Size(max = 1)
	private String emailContactInd;

	@NotNull
	@Size(max = 50)
	private String userName;

	@Size(max = 1)
	private String accountActiveInd;

	
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	private Date accountCreatedDate;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastLoginDateTime;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastLogoutDateTime;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updateDateTime;

	@Size(max = 50)
	private String userTitle;

	@Size(max = 50)
	private String department;

	@Size(max = 50)
	private String location;

	@Size(max = 50)
	private String organizationName;

	@Convert(converter = ColumnAttributeConverter.class)
	private String password;

	
	@ManyToMany(targetEntity=AdminUserRoles.class,cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private Set<AdminUserRoles> roles;

	

}
