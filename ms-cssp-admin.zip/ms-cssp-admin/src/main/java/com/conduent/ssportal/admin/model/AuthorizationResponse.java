/**
 * 
 */
package com.conduent.ssportal.admin.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

/**
 * @author C5109952
 *
 */
@Setter
@Getter
@ToString
@JsonInclude(value = Include.NON_NULL)
@NoArgsConstructor
public class AuthorizationResponse {
	
	private String userId;
	private String firstName;
	private String lastName;


	private int statusCode;
	private String message;

	private List<String> roles = new ArrayList<>();


	public AuthorizationResponse(int statusCode, String message) {
		this.statusCode = statusCode;
		this.message = message;
	}
}
