package com.conduent.ssportal.admin.model;

import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class JsonRequestBean {
	
	
	private JsonNode json;
	@NotNull
	private String jsonScreenName;
	@NotNull
	private String language;
	private String jsonFileName;
	private String comments;
	private String authToken;
	@NotNull
	private String userId;
	
	
	
}
