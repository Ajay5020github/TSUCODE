package com.conduent.ssportal.admin.util;

public class AdminServiceConstants {

    public static final String U_IND = "U";
	public static final String R_IND = "R";
	public static final String X_IND = "X";
	public static final String STATUS_CODE = "statusCode";
	public static final String MESSAGE = "message";
	public static final String ERROR_FIELDS = "errorFields";
	public static final Integer BAD_REQUEST_CODE = 400;
	public static final String STRING_SPLIT = "\\s*,\\s*";
    public static final int UNAUTHORIZED_CODE = 401;

    private AdminServiceConstants() {
	  }

	
	/**
	 * description: variables declaration for constants.
	 */
	public static final String SUCCESS = "Success";
	public static final String ERROR = "Error while processing the request";
	public static final String UNAUTHORIZED = "User not available in our system";
	public static final String BAD_REQUEST = "Bad Request";
	
	public static final String SUCCESS_API_CODE = "200";
	public static final String ERROR_API_CODE = "500";
	public static final String UNAUTHORIZED_API_CODE = "401";
	public static final String BAD_REQUEST_API_CODE = "400";
	public static final String LOCK_API_CODE = "423";

	public static final String JSON_FETCHED_SUCCESS = "Json has been fetched successfully";
	public static final String JSON_SAVED_SUCCESS = "Json saved successfully";
	public static final String JSON_REVERT_SUCCESS = "Json has been reverted successfully";
	public static final String JSON_REVERT_FAILURE = "Error while reverting the JSON";
	public static final String JSON_PUBLISH_SUCCESS = "Json has been published successfully";
	public static final String JSON_CHANGE_LOG = "Change log has been fetched successfully";

	public static final String JSON_PUBLISH = "Published";

	
	public static final String JSON_BAD_REQUEST = "Insufficient data to process the request";
	
	public static final String JSON_LOCKED_MESSAGE = "This file is locked by";
	
	public static final String JSON_FETCH_ERROR = "Error occurred while fetching JSON details";
	
	public static final String JSON_SAVED_ERRO = "Error while saving the JSON";
	
	public static final String JSON_PUBLISHED_ERROR = "Error while publishing the JSON"; 
	public static final String JSON_CHANGE_LOG_ERROR = "Error while fetching the change log";
	public static final String JSON_NOT_FOUND = "Requested Json Not found in the blob";
	


	public static final String USER_UNAUTH = "Unauthorized";
	// Response Code



	public static final int SUCCESS_CODE = 200;

	public static final int INTERNAL_ERROR_CODE = 500;

	public static final String USER_LOGOUT_SUCCESS = "User logged out successfully";
	public static final String USER_LOGOUT_ERROR = "Error while logged out the user";
	public static final String ERROR_RESPONSE = "Error while processing the request";
	
	public static final String MODIFIED ="Modified";
	
	public static final String MASTER_COPY = "MasterCopy";
	public static final String SUCCESS_RESPONSE = "Success";

	public static final String Y_IND = "Y";

	public static final String ACTION_NAME = "actionName";
	public static final String SERVICE_ID = "serviceId";
	public static final String RESPONSE_CODE = "responseCode";
	public static final String ERROR_CODE = "errorCode";
	public static final String CONSUMER_ID = "consumerId";
	public static final String TRANSACTION_ID = "transactionId";
	public static final String SERVICE_TYPE = "serviceType";
	public static final String SOURCE_LAYER = "sourceLayer";
	public static final String TRANSACTION_STATUS = "transactionStatus";
	public static final String ERROR_MESSAGE = "errorMessage";
	public static final String ERROR_TRACE = "errorTrace";
	public static final String ACCOUNT = "account";
	public static final String SERVICE_SB = "Service-SB";

	public static final String DEPARTMENT = "internal";

	public static final String F_IND = "F";


}
