package com.conduent.ssportal.admin.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class RoleMatrixResponse implements Serializable {

    private int statusCode;
    private String message;

    private Object rolesMatrix;
}
