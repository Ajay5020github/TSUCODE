package com.conduent.ssportal.admin.repository;

import java.util.List;

import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.conduent.ssportal.admin.entity.JsonEditor;

public interface JsonEditorRepository extends JpaRepository<JsonEditor, Integer> {

	@Transactional
	@Modifying
	@Query("Delete from JsonEditor where userId=?1 and jsonScreenName=?2 and language=?3 and type=?4")
	int deletechangedjson(String userId, String screename, String language, String type);

	JsonEditor findByLanguageAndJsonScreenNameAndType(String language, String jsonScreenName, String type);
	
	List<JsonEditor> findByTypeAndJsonScreenNameAndLanguageOrderByUpdatedTimestampDesc(String type,String language, String jsonScreenName);
	
	boolean existsByLanguageAndJsonScreenNameAndType(String language, String jsonScreenName, String type);

	@Query("select json.jsonScreenName,json.language, json.comments, json.updatedTimestamp from JsonEditor json where json.userId = ?1 and json.type = ?2 order by json.updatedTimestamp desc")
	List<Object[]> findLockedFilesByUserIdAndType(String userId, String type);


}
