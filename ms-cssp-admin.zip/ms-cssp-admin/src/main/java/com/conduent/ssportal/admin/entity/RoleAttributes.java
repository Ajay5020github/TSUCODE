/**
 * 
 */
package com.conduent.ssportal.admin.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * @author C5109952
 *
 */
@Entity
@Data
@Table(name = "ADMIN_ROLE_MATRIX_TB")
public class RoleAttributes {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long attributeSeq;

	@Size(max = 1)
	private String activeInd;

	@Size(max = 50)
	private String roleAttribute;

	private String permissionInd;


	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdTimestamp;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedTimeStamp;

}
