package com.conduent.ssportal.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.conduent.ssportal.admin.entity.AdminUser;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AdminRepository extends JpaRepository<AdminUser, Long> {

	AdminUser findByUserName(String UserId);


	AdminUser	findByUserNameAndPassword(@Param("userId") String userId, @Param("password") String password);


}

