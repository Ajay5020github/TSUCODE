/**
 * 
 */
package com.conduent.ssportal.admin.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

import com.conduent.ssportal.admin.model.*;
import com.conduent.ssportal.admin.repository.ReferenceDataRepository;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.conduent.ssportal.admin.entity.AdminUser;
import com.conduent.ssportal.admin.entity.JsonEditor;
import com.conduent.ssportal.admin.exception.JsonEditException;
import com.conduent.ssportal.admin.exception.JsonNotFoundException;
import com.conduent.ssportal.admin.exception.JsonLockedException;
import com.conduent.ssportal.admin.repository.AdminRepository;
import com.conduent.ssportal.admin.repository.JsonEditorRepository;
import com.conduent.ssportal.admin.util.AdminServiceConstants;
import com.conduent.ssportal.admin.util.AdminUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;

/**
 * @author C5109952
 *
 */

@Service
public class JsonModifierServiceImpl implements JsonEditorService {

	@Autowired
	private JsonEditorRepository jsonEditorRepository;

	@Autowired
	private ReferenceDataRepository dataRepository;
	
	private final CloudBlobContainer container;


	@Autowired
	public JsonModifierServiceImpl(CloudBlobContainer container) {
		this.container = container;
	}

	
	@Value("${azure.storage.container-directory}")
	private String fileDirectory;
	
	static final String CONFIG_JSON_NAME = "configJsonMapping" + ".json";
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired private AdminRepository adminRepo;
	
	@Autowired
	private EntityManager em;

	private static final Logger log = LoggerFactory.getLogger(JsonModifierServiceImpl.class);

	@Override
	@Transactional
	public JsonResponseBean fetchJson(JsonRequestBean jsonRequestBean) throws JsonEditException, JsonLockedException {
		JsonResponseBean response = new JsonResponseBean();
		log.info("Entering into fetchJson in JsonModifierServiceImpl =====>");
		try {

			JsonEditor jsonEntity = getJsonEntity(jsonRequestBean.getLanguage(), jsonRequestBean.getJsonScreenName(),
					AdminServiceConstants.MODIFIED);
			response = jsonResBean(jsonRequestBean.getJsonScreenName(), jsonRequestBean.getLanguage(),
					AdminServiceConstants.JSON_FETCHED_SUCCESS);
			if (jsonEntity != null) {

				if (jsonEntity.getUserId().equals(jsonRequestBean.getUserId())) {
					log.info("JSON has been taken from DB");
					Object data = AdminUtil.getJSon(jsonEntity.getJson());
					response.setJson(data);
					response.setFileName(jsonEntity.getJsonFileName());
				} else {
					throw new JsonLockedException(AdminServiceConstants.JSON_LOCKED_MESSAGE+" "+jsonEntity.getUserId()+"!!!");
				}

			} else {
				log.info("<<<START>> fetching from blob");
				CloudBlockBlob blob = container.getBlockBlobReference(CONFIG_JSON_NAME);
				String responseBlobConfigScreenJson = blob.downloadText();

				JSONParser readJsonParser = new JSONParser();
				JSONObject configJson;
				configJson = (JSONObject) readJsonParser.parse(responseBlobConfigScreenJson);
				JSONObject screenObject = (JSONObject) configJson.get(jsonRequestBean.getJsonScreenName());
				JSONObject languageObject = null;
				String responseConfigJson = null;
				String fileName = null;
				if (screenObject != null) {
					languageObject = (JSONObject) screenObject.get(jsonRequestBean.getLanguage());
					if (languageObject != null) {
						 fileName = languageObject.get("json_file_name").toString() + ".json";
						String file_path = languageObject.get("json_file_path").toString();
						log.info("fetching file from blob {} {}", file_path, fileName);
						blob = container.getBlockBlobReference(file_path+"/"+fileName);
						responseConfigJson = blob.downloadText();
					}
				}
				
				if(screenObject==null || languageObject==null) {
					log.error(" === Json not found ===");
					throw new JsonNotFoundException(AdminServiceConstants.JSON_NOT_FOUND);
				}

				ObjectMapper mapper = new ObjectMapper();
				JsonNode node = mapper.readTree(responseConfigJson);
				jsonRequestBean.setJson(node);
				jsonRequestBean.setJsonFileName(fileName);

				if (!checkJsonExist(jsonRequestBean.getLanguage(), jsonRequestBean.getJsonScreenName(),
						AdminServiceConstants.MASTER_COPY)) {
					log.error(" === saving master json===");
					saveJson(jsonRequestBean, AdminServiceConstants.MASTER_COPY);
				}

				saveJson(jsonRequestBean, AdminServiceConstants.MODIFIED);

				response.setJson(node);
				response.setFileName(fileName);

			}

		} catch (DataAccessException | URISyntaxException | StorageException | IOException
				| ParseException | JsonNotFoundException e) {
			log.error(" Exception had occurred while downloading the file");
			throw new JsonEditException(500,"fetchJson",jsonRequestBean.getUserId(),e.getMessage(),e.getCause());
		}
		log.info("Exit from fetchJson in JsonModifierServiceImpl =====>");
		return response;
	}

	private boolean checkJsonExist(String language, String jsonScreenName, String type) {
		 return jsonEditorRepository.existsByLanguageAndJsonScreenNameAndType(language, jsonScreenName, type);
	}

	@Override
	public JsonResponseBean saveChanges(JsonRequestBean request) throws JsonEditException {
		JsonResponseBean response = new JsonResponseBean();
		log.info("Entering into saveChanges in JsonModifierServiceImpl =====>");
		try {
			JsonEditor jsonentity = getJsonEntity(request.getLanguage(), request.getJsonScreenName(), AdminServiceConstants.MODIFIED);

			response = jsonResBean(request.getJsonScreenName(), request.getLanguage(),
					AdminServiceConstants.JSON_SAVED_SUCCESS);

			if (jsonentity == null) {
				jsonentity = new JsonEditor();
				log.info("Entered if block in save-changes in JsonModifierServiceImpl ->");
				jsonentity.setUserId(request.getUserId());
				jsonentity.setJsonScreenName(request.getJsonScreenName());
				jsonentity.setJson(request.getJson().toString());
				jsonentity.setLanguage(request.getLanguage());
				jsonentity.setCreatedTimestamp(AdminUtil.getCurrentTimeStamp());
				jsonentity.setUpdatedTimestamp(AdminUtil.getCurrentTimeStamp());
				jsonentity.setType(AdminServiceConstants.MODIFIED);
				jsonentity.setComments(request.getComments());
				if (request.getJsonFileName() != null)
					jsonentity.setJsonFileName(request.getJsonFileName());
			} else if (jsonentity.getUserId() != null
					&& jsonentity.getUserId().equals(request.getUserId())) {
				log.info("Entered else if block in save-changes in JsonModifierServiceImpl ->");
				jsonentity.setJsonScreenName(request.getJsonScreenName());
				jsonentity.setJson(request.getJson().toString());
				jsonentity.setLanguage(request.getLanguage());
				jsonentity.setUpdatedTimestamp(AdminUtil.getCurrentTimeStamp());
				jsonentity.setType(AdminServiceConstants.MODIFIED);
				jsonentity.setComments(request.getComments());
			}

			jsonEditorRepository.save(jsonentity);
			response.setJson(request.getJson());
		} catch (DataAccessException e) {
			log.error(" Exception had occurred while saving : {} " , e.getMessage());
			throw new JsonEditException(500,"saveChanges",request.getUserId(),e.getMessage(),e.getCause());
		}
		log.info("Exit from saveChanges in JsonModifierServiceImpl =====>");
		return response;
	}

	@Override
	public JsonResponseBean revertChanges(JsonRequestBean request) throws JsonEditException {
		JsonResponseBean response = null;
		log.info("Entering into revert-changes in JsonModifierServiceImpl =====>");
		try {
			int deletechangedjson = jsonEditorRepository.deletechangedjson(request.getUserId(),
					request.getJsonScreenName(), request.getLanguage(), AdminServiceConstants.MODIFIED);
			log.info("After delete these many rows has been affected {} " , deletechangedjson);
			if (deletechangedjson != 0)
				response = jsonResBean(request.getJsonScreenName(), request.getLanguage(),
						AdminServiceConstants.JSON_REVERT_SUCCESS);
			else
				response = jsonResBean(request.getJsonScreenName(), request.getLanguage(),
						AdminServiceConstants.JSON_REVERT_FAILURE);
		} catch (DataAccessException jpa) {
			log.error(" Exception occurred in revertChanges : {}" , jpa.getMessage());
			throw new JsonEditException(500,"revertChanges",request.getUserId(),jpa.getMessage(),jpa.getCause());
		}
		log.info("Exit from revert-changes in JsonModifierServiceImpl =====>");
		return response;
	}

	@Override
	public JsonResponseBean publishJson(JsonRequestBean jsonRequestBean) throws JsonEditException {
		JsonResponseBean response = new JsonResponseBean();
		String responseBlobConfigScreenJson = "";
		String fileName = "";
		log.info("Entering into publishJson in JsonModifierServiceImpl =====>");
		try {

			CloudBlockBlob blob = container.getBlockBlobReference(CONFIG_JSON_NAME);
			responseBlobConfigScreenJson = blob.downloadText();

			JSONParser readJsonParser = new JSONParser();
			JSONObject configJson;
			configJson = (JSONObject) readJsonParser.parse(responseBlobConfigScreenJson);
			JSONObject screenObject = (JSONObject) configJson.get(jsonRequestBean.getJsonScreenName());

			if (screenObject != null) {
				JSONObject languageObject = (JSONObject) screenObject.get(jsonRequestBean.getLanguage());
				if (languageObject != null) {
					fileName = languageObject.get("json_file_name").toString();
					String file_path = languageObject.get("json_file_path").toString();
					log.info(file_path+"/"+fileName);
					blob = container.getBlockBlobReference(file_path+"/"+fileName+ ".json");
					blob.getProperties().setContentType("application/json");
					blob.uploadText(jsonRequestBean.getJson().toString());
				}
			}

			JsonEditor jsonEntity = getJsonEntity(jsonRequestBean.getLanguage(), jsonRequestBean.getJsonScreenName(),
					AdminServiceConstants.MODIFIED);

			if (jsonEntity != null) {
				jsonEntity.setComments(jsonRequestBean.getComments());
				jsonEntity.setType(AdminServiceConstants.JSON_PUBLISH);
				jsonEntity.setJsonFileName(fileName);
				jsonEntity.setUpdatedTimestamp(AdminUtil.getCurrentTimeStamp());
				jsonEditorRepository.save(jsonEntity);
			}


			response = jsonResBean(jsonRequestBean.getJsonScreenName(), jsonRequestBean.getLanguage(),
					AdminServiceConstants.JSON_PUBLISH_SUCCESS);
			response.setFileName(fileName);
			response.setJson(jsonRequestBean.getJson());
		} catch (Exception e) {
			log.error(" Exception had occurred while uploading the file");
			throw new JsonEditException(500,"publishJson",jsonRequestBean.getUserId(),e.getMessage(),e.getCause());

		}
		log.info("Exit from publishJson in JsonModifierServiceImpl =====>");
		return response;
	}

	@Override
	public JsonResponseBean fetchLog(JsonRequestBean jsonRequestBean) throws JsonEditException {
		JsonResponseBean response = new JsonResponseBean();
		log.info("Entering into fetchLog in JsonModifierServiceImpl =====>");
		try {
			List<JsonEditor> listofPublishedJson = jsonEditorRepository.findByTypeAndJsonScreenNameAndLanguageOrderByUpdatedTimestampDesc(
					AdminServiceConstants.JSON_PUBLISH, jsonRequestBean.getJsonScreenName(),
					jsonRequestBean.getLanguage());

			response = jsonResBean(jsonRequestBean.getJsonScreenName(), jsonRequestBean.getLanguage(),
					AdminServiceConstants.JSON_CHANGE_LOG);
			List<ChangeLog> logs = new ArrayList<>();
			ChangeLog changeLog = null;
			for (JsonEditor jsonEditor : listofPublishedJson) {
				changeLog = new ChangeLog();
				modelMapper.map(jsonEditor, changeLog);
				AdminUser user = fetchAdminUserDetails(jsonEditor.getUserId());
				modelMapper.map(user, changeLog);
				logs.add(changeLog);
			}
			
			response.setLog(logs);
			
		} catch (DataAccessException es) {
			log.error(" Exception occurred in fetchLog : {}" , es.getMessage());
			throw new JsonEditException(500,"fetchLog",jsonRequestBean.getUserId(),es.getMessage(),es.getCause());
		}
		log.info("Exit from fetchLog in JsonModifierServiceImpl =====>");
		return response;
	}

	private AdminUser fetchAdminUserDetails(String userId) {
		return adminRepo.findByUserName(userId);
	}

	@Transactional
	public void saveJson(JsonRequestBean request, String message) {
		JsonEditor jsonEntity = new JsonEditor();
		log.debug("Entered saveJson in AdminService ->");
		jsonEntity.setUserId(request.getUserId());
		jsonEntity.setJsonScreenName(request.getJsonScreenName());
		jsonEntity.setJson(request.getJson().toString());
		jsonEntity.setLanguage(request.getLanguage());
		jsonEntity.setCreatedTimestamp(AdminUtil.getCurrentTimeStamp());
		jsonEntity.setUpdatedTimestamp(AdminUtil.getCurrentTimeStamp());
		jsonEntity.setType(message);
		jsonEntity.setComments(request.getComments());
		jsonEntity.setJsonFileName(request.getJsonFileName());
		jsonEditorRepository.save(jsonEntity);
		em.flush();
		em.clear();

	}

	//@Async
	public JsonEditor getJsonEntity(String language, String jsonScreenName, String type) {
		return jsonEditorRepository.findByLanguageAndJsonScreenNameAndType(language, jsonScreenName, type);
	}

	public JsonResponseBean jsonResBean(String jsonScreenName, String language, String message) {
		JsonResponseBean response = new JsonResponseBean();
		response.setScreenName(jsonScreenName);
		response.setLanguageId(language);
		response.setMessage(message);
		return response;
	}
	


	@Override
	public JSONContentResponseBean readJson(String fileName) throws JsonNotFoundException {
		JSONContentResponseBean responseBean = null ;
		log.info("Entering into readJson in JsonModifierServiceImpl =====>");
		try {
		
		CloudBlockBlob blockBlobReference = container.getBlockBlobReference(fileDirectory + fileName+".json");
		
		 String downloadText = blockBlobReference.downloadText();

		JSONParser readJsonParser = new JSONParser();
		JSONObject configJson = (JSONObject) readJsonParser.parse(downloadText);
		responseBean = new JSONContentResponseBean();
		responseBean.setData(configJson);
		responseBean.setMessage(AdminServiceConstants.JSON_FETCHED_SUCCESS);
		responseBean.setStatusCode(AdminServiceConstants.SUCCESS_CODE);
		}catch (URISyntaxException | StorageException | IOException | ParseException e) {
			log.error(" Exception occurred in readJson : {} " , e.getMessage());
			throw new JsonNotFoundException(AdminServiceConstants.JSON_NOT_FOUND,e.getCause());
		}
		log.info("Exit from readJson in JsonModifierServiceImpl =====>");
		return responseBean;
	}

	@Override
	public JSONLockedResponseBean fetchLockedFiles(String userId) throws JsonEditException {

		JSONLockedResponseBean response = null;
		log.info("Entering into fetchLockedFiles in JsonModifierServiceImpl =====>");
		try {
			List<Object[]> lockedFiles = jsonEditorRepository.findLockedFilesByUserIdAndType(userId, AdminServiceConstants.MODIFIED);
			List<JSONLockedResponseBean.LockedFile> fileList = new ArrayList<>();
			if (lockedFiles != null) {
				Map<String, String> language =  dataRepository.findByCategoryData("Language");
				response = new JSONLockedResponseBean();
				for (Object[] files : lockedFiles) {
					JSONLockedResponseBean.LockedFile lockedFile = new JSONLockedResponseBean.LockedFile();
					lockedFile.setScreenName((String) files[0]);
					lockedFile.setLanguage((String) files[1]);
					lockedFile.setComments((String) files[2]);
					lockedFile.setLastSavedDateTime((Date) files[3]);
					fileList.add(lockedFile);
				}

			}
			response.setLockedFiles(fileList);
			response.setMessage(AdminServiceConstants.SUCCESS_RESPONSE);
		} catch (DataAccessException es) {
			log.error(" Exception occurred in fetchLockedFiles : {} " , es.getMessage());
			throw new JsonEditException(500,"fetchLockedFiles",userId,es.getMessage(),es.getCause());
		}
		log.info("Exit from fetchLockedFiles in JsonModifierServiceImpl =====>");
		return response;
	}

}
