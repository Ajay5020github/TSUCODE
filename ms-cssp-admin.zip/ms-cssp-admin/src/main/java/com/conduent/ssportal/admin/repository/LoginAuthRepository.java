package com.conduent.ssportal.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.conduent.ssportal.admin.entity.LoginAuthentication;

public interface LoginAuthRepository extends JpaRepository<LoginAuthentication, Integer> {

	@Query("SELECT u FROM LoginAuthentication u WHERE u.userId = ?1")
	LoginAuthentication getByUserId(String userId);

}