package com.conduent.ssportal.admin.service;

import com.conduent.ssportal.admin.exception.LoginAuthenticateError;
import com.conduent.ssportal.admin.exception.AdminException;
import com.conduent.ssportal.admin.model.AuthorizationResponse;
import com.conduent.ssportal.admin.model.LoginRequestBean;

public interface  LoginAuthenticateService {
	
	public AuthorizationResponse tokenAuthenticate(LoginRequestBean loginRequestBean) throws LoginAuthenticateError;

	/*
	 * public boolean authorizelogin(LoginRequestBean loginRequestBean) throws
	 * UserException;
	 */
}
