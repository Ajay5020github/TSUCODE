package com.conduent.ssportal.admin.controller;

import com.conduent.ssportal.admin.exception.LoginAuthenticateError;
import com.conduent.ssportal.admin.model.AuthorizationResponse;
import com.conduent.ssportal.admin.model.LoginRequestBean;
import com.conduent.ssportal.admin.service.LoginAuthenticateService;
import com.conduent.ssportal.admin.util.AdminServiceConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
public class LoginAuthenticateController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginAuthenticateController.class);

	private  LoginAuthenticateService loginAuthService;

	@Autowired
	public LoginAuthenticateController(LoginAuthenticateService loginAuthService) {
		this.loginAuthService = loginAuthService;
	}


	@PostMapping(value = "/authorizeUser")
	public ResponseEntity<AuthorizationResponse> authenticateAuthToken(
			@RequestBody(required = true) @Valid LoginRequestBean loginReqBean) {

		LOGGER.info("Entering authenticateAuthToken in LoginAuthenticateController");

		return new ResponseEntity<>(loginAuthService.tokenAuthenticate(loginReqBean), HttpStatus.OK);
	}

}
