package com.conduent.ssportal.admin.exception;

import org.springframework.core.NestedCheckedException;

public class LoginAuthenticateError extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LoginAuthenticateError(String msg) {
		super(msg);
	}


}
