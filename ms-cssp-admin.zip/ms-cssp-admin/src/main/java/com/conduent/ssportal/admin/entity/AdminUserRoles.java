/**
 * 
 */
package com.conduent.ssportal.admin.entity;

import java.util.Date;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * @author C5109952
 *
 */
@Entity
@Data
@Table(name = "ADMIN_USER_ROLES_TB")
public class AdminUserRoles {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long roleSeq;

	@Size(max = 50)
	private String userRole;

	@Size(max = 1)
	private String activeInd;

	@Size(max = 25)
	private String agency;

	private Long adminRank;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdTimestamp;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private String updatedTimeStamp;

	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "role_matrix_id",nullable = false)
	private Set<RoleAttributes> roleMatrix;


}
