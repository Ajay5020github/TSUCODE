package com.conduent.ssportal.admin.exception;

public class JsonLockedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	public JsonLockedException(String message) {
		super(message);
	}


}