package com.conduent.ssportal.admin.repository;

import org.springframework.data.repository.CrudRepository;

import com.conduent.ssportal.admin.entity.AdminUserRoles;

public interface AdminUserRolesRepository extends CrudRepository<AdminUserRoles, Long> {




   AdminUserRoles findByUserRoleAndActiveInd(String userRole, String activeInd);
}