package com.conduent.ssportal.admin.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.conduent.ssportal.admin.exception.JsonEditException;
import com.conduent.ssportal.admin.exception.JsonLockedException;
import com.conduent.ssportal.admin.model.JSONLockedRequestBean;
import com.conduent.ssportal.admin.model.JSONLockedResponseBean;
import com.conduent.ssportal.admin.model.JsonRequestBean;
import com.conduent.ssportal.admin.model.JsonResponseBean;
import com.conduent.ssportal.admin.service.JsonEditorService;
import com.conduent.ssportal.admin.util.AdminServiceConstants;
import com.conduent.ssportal.admin.util.AdminUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;

@RestController
public class JsonModifierController {

	private static final Logger log = LoggerFactory.getLogger(JsonModifierController.class);

	@Autowired
	private JsonEditorService jsonEditor;

	@Operation(summary  = " This method is used to  save content JSON in database")
	@ApiResponses(value = { @ApiResponse(responseCode = AdminServiceConstants.SUCCESS_API_CODE, description = AdminServiceConstants.JSON_SAVED_SUCCESS),
			@ApiResponse(responseCode = AdminServiceConstants.BAD_REQUEST_API_CODE, description = AdminServiceConstants.JSON_BAD_REQUEST),
			@ApiResponse(responseCode = AdminServiceConstants.ERROR_API_CODE, description = AdminServiceConstants.JSON_SAVED_ERRO) })
	@PostMapping(value = "/saveJson",produces = "application/json")
	public ResponseEntity<JsonResponseBean> saveJson(@RequestBody @Valid JsonRequestBean request) {
		log.info("=== start saveJson ===");

		JsonResponseBean response = new JsonResponseBean();

		try {

			response = jsonEditor.saveChanges(request);
		} catch (JsonEditException ex) {
			log.error("Error while saving the json :: {} {}" , ex.getMessage(), ex.getCause());
			response.setMessage(ex.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.info("=== exit saveJson ===");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Operation(summary  = " This method is used to  revert modified JSON from database")
	@ApiResponses(value = { @ApiResponse(responseCode = AdminServiceConstants.SUCCESS_API_CODE, description = AdminServiceConstants.JSON_REVERT_SUCCESS),
			@ApiResponse(responseCode = AdminServiceConstants.BAD_REQUEST_API_CODE, description = AdminServiceConstants.JSON_BAD_REQUEST),
			@ApiResponse(responseCode = AdminServiceConstants.ERROR_API_CODE, description = AdminServiceConstants.JSON_REVERT_FAILURE) })
	@PostMapping(value = "/revertJson",produces = "application/json")
	public ResponseEntity<JsonResponseBean> revertJson(@RequestBody @Valid JsonRequestBean request) {
		log.info("=== start revertJson ===");
		JsonResponseBean response = new JsonResponseBean();

		try {
			log.info("Entered revertJson");
			response = jsonEditor.revertChanges(request);
		} catch (JsonEditException ex) {
			log.error("Error while reverting the json :: {} {}" , ex.getMessage(), ex.getCause());
			response.setMessage(ex.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.info("=== exit revertJson ===");
		return new ResponseEntity<>(response, HttpStatus.ACCEPTED);
	}

	@Operation(summary  = "This method is used to publish the JSON in azure blob")
	@ApiResponses(value = { @ApiResponse(responseCode = AdminServiceConstants.SUCCESS_API_CODE, description = AdminServiceConstants.JSON_PUBLISH_SUCCESS),
			@ApiResponse(responseCode = AdminServiceConstants.BAD_REQUEST_API_CODE, description = AdminServiceConstants.JSON_BAD_REQUEST),
			@ApiResponse(responseCode = AdminServiceConstants.ERROR_API_CODE, description = AdminServiceConstants.JSON_PUBLISHED_ERROR) })
	@PostMapping(value="/publishJson",produces = "application/json")
	public ResponseEntity<JsonResponseBean> publishJson(@RequestBody @Valid JsonRequestBean json) {
		log.info("=== Start publishJson... ===");

		JsonResponseBean response = new JsonResponseBean();

		try {
			response = jsonEditor.publishJson(json);
		} catch (JsonEditException ex) {
			log.error("Error while publishing the json :: {} {}" , ex.getMessage(), ex.getCause());
			response.setMessage(ex.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.info("=== exit publishJson... ===");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Operation(summary  = "This method is used to fetch the JSON")
	@ApiResponses(value = { @ApiResponse(responseCode = AdminServiceConstants.SUCCESS_API_CODE, description = AdminServiceConstants.JSON_FETCHED_SUCCESS),
			@ApiResponse(responseCode = AdminServiceConstants.BAD_REQUEST_API_CODE, description  = AdminServiceConstants.JSON_BAD_REQUEST),
			@ApiResponse(responseCode = AdminServiceConstants.ERROR_API_CODE, description = AdminServiceConstants.JSON_FETCH_ERROR),
			@ApiResponse(responseCode = AdminServiceConstants.LOCK_API_CODE, description = AdminServiceConstants.JSON_LOCKED_MESSAGE) })
	@PostMapping(value="/fetchJson",produces = "application/json")
	public ResponseEntity<JsonResponseBean> fetchJson(@RequestBody @Valid JsonRequestBean jsonRequestBean) {
		log.info("=== start fetchJson... ===");
		JsonResponseBean response = new JsonResponseBean();

		try {

			response = jsonEditor.fetchJson(jsonRequestBean);
			
		} catch (JsonEditException e) {
			log.error("Error while fetching the json :: {} {}" , e.getMessage(), e.getCause());
			response.setMessage(e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (JsonLockedException ex) {
			log.error("Json locked  :: {} {}" , ex.getMessage(), ex.getCause());
			response.setMessage(ex.getMessage());
			return new ResponseEntity<>(response, HttpStatus.LOCKED);
		}
		log.info("=== exit fetchJson... ===");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Operation(summary  = "This method is used to fetch JSON change log")
	@ApiResponses(value = { @ApiResponse(responseCode = AdminServiceConstants.SUCCESS_API_CODE, description = AdminServiceConstants.JSON_CHANGE_LOG),
			@ApiResponse(responseCode = AdminServiceConstants.BAD_REQUEST_API_CODE, description = AdminServiceConstants.JSON_BAD_REQUEST),
			@ApiResponse(responseCode = AdminServiceConstants.ERROR_API_CODE, description = AdminServiceConstants.JSON_CHANGE_LOG_ERROR) })
	@PostMapping(value="/fetchLog",produces = "application/json")
	public ResponseEntity<JsonResponseBean> fetchLog(@RequestBody @Valid JsonRequestBean json) {
		log.info("=== start fetchLog... ===");
		JsonResponseBean response = new JsonResponseBean();

		try {
			response = jsonEditor.fetchLog(json);

		} catch (JsonEditException e) {
			log.error("Error while fetching the json log :: {} {}" , e.getMessage(), e.getCause());
			response.setMessage(e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.info("=== exit fetchLog... ===");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}



	@Operation(summary  = "This method is used to fetch locked files for the logged-in user")
	@ApiResponses(value = { @ApiResponse(responseCode = AdminServiceConstants.SUCCESS_API_CODE, description  = AdminServiceConstants.SUCCESS_RESPONSE),
			@ApiResponse(responseCode = AdminServiceConstants.BAD_REQUEST_API_CODE, description = AdminServiceConstants.JSON_BAD_REQUEST),
			@ApiResponse(responseCode = AdminServiceConstants.ERROR_API_CODE, description = AdminServiceConstants.ERROR_RESPONSE) })
	@PostMapping(value="/fetchLockedFiles",produces = "application/json")
	public ResponseEntity<JSONLockedResponseBean> fetchLockedFiles(@RequestBody @Valid JSONLockedRequestBean json) {
		log.info("=== start fetchLockedFiles... ===");
		JSONLockedResponseBean response = new JSONLockedResponseBean();

		try {
			if(json.getUserId().equals(AdminUtil.getUserId(json.getAuthToken()))){
				response = jsonEditor.fetchLockedFiles(json.getUserId());
			}else{
				response.setMessage(AdminServiceConstants.ERROR);
				return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

			}



		} catch (JsonEditException e) {
			log.error("Error while fetching the json log :: {} {}", e.getMessage(), e.getCause());
			response.setMessage(e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.info("=== exit fetchLockedFiles... ===");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
}
