package com.conduent.ssportal.admin.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;


@Entity
@Data
@JsonInclude(value = Include.NON_NULL)
@Table(name = "JSON_EDITOR_TB", indexes = {@Index(name = "LanguageAndJsonScreenNameAndType", columnList = "json_screen_name,language,type"),
	      @Index(name = "userIdAndType", columnList = "user_id,type"),
	      @Index(name = "userIdAndLanguageAndJsonScreenNameAndType", columnList = "user_id,json_screen_name,language,type")})
public class JsonEditor {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@JsonIgnore
	private Long jsonSeq;

	@NotNull
	@Column(name = "user_id")
	private String userId;

	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdTimestamp;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd HH:mm:ss", timezone = JsonFormat.DEFAULT_LOCALE)
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedTimestamp;

	
	@Lob
	@JsonIgnore
	private String json;

	@NotNull
	@JsonProperty("screenName")
	@Column(name = "json_screen_name")
	private String jsonScreenName;

	@NotNull
	@JsonProperty("languageId")
	@Column(name = "language")
	private String language;

	@JsonProperty("fileName")
	private String jsonFileName;

	@JsonIgnore
	@Column(name = "type")
	private String type;

	private String comments;

}
