package com.conduent.ssportal.admin.service;

import com.conduent.ssportal.admin.entity.AdminUser;
import com.conduent.ssportal.admin.entity.AdminUserRoles;
import com.conduent.ssportal.admin.entity.LoginAuthentication;
import com.conduent.ssportal.admin.entity.RoleAttributes;
import com.conduent.ssportal.admin.exception.AdminException;
import com.conduent.ssportal.admin.model.AuthorizationResponse;
import com.conduent.ssportal.admin.model.LoginRequestBean;
import com.conduent.ssportal.admin.model.RoleMatrixRequest;
import com.conduent.ssportal.admin.model.RoleMatrixResponse;
import com.conduent.ssportal.admin.repository.AdminRepository;
import com.conduent.ssportal.admin.repository.AdminUserRolesRepository;
import com.conduent.ssportal.admin.repository.LoginAuthRepository;
import com.conduent.ssportal.admin.util.AdminServiceConstants;
import com.conduent.ssportal.admin.util.AdminUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.SerializationUtils;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {

	private static final Logger log = LoggerFactory.getLogger(AdminServiceImpl.class);

	private final AdminRepository adminRepository;

	private final LoginAuthRepository authRepo;

	private final AdminUserRolesRepository rolesRepository;

	@Autowired
	public AdminServiceImpl(AdminRepository adminRepository, LoginAuthRepository authRepo, AdminUserRolesRepository rolesRepository) {
		this.adminRepository = adminRepository;
		this.authRepo = authRepo;
		this.rolesRepository = rolesRepository;
	}

	@Override
	public AuthorizationResponse authorizeUser(LoginRequestBean request) throws AdminException{
		log.info("<<<START>>> authorizeUser in AdminServiceImpl");
		AuthorizationResponse response = new AuthorizationResponse();
		try {
			if(ObjectUtils.isEmpty(request.getPassword())){
				throw new AdminException(HttpStatus.BAD_REQUEST.value(),"authorizeUser",request.getUserId(),HttpStatus.BAD_REQUEST.toString(), null);
			}

			AdminUser user = adminRepository.findByUserNameAndPassword(request.getUserId(),request.getPassword());
              if(null != user) {

				  if(AdminServiceConstants.Y_IND.equals(user.getAccountActiveInd())) {

					  if(!CollectionUtils.isEmpty(user.getRoles())){
						  for (AdminUserRoles roles: user.getRoles()) {
							  if(AdminServiceConstants.Y_IND.equals(roles.getActiveInd())){
								  response.getRoles().add(roles.getUserRole());
							  }
						  }
					  }
					  response.setMessage(AdminServiceConstants.SUCCESS);
					  response.setUserId(request.getUserId());
					  response.setFirstName(user.getFirstName());
					  response.setLastName(user.getLastName());
					  user.setLastLoginDateTime(AdminUtil.getCurrentTimeStamp());

					  adminRepository.save(user);
					  saveAuthentication(request.getAuthToken(), request.getUserId(), AdminUtil.getCurrentTimeStamp());
				  }else{
					  response.setMessage(HttpStatus.LOCKED.toString());
					  response.setStatusCode(HttpStatus.LOCKED.value());
					  return response;
				  }
			  }else{
				  throw new AdminException(HttpStatus.UNAUTHORIZED.value(),"authorizeUser",request.getUserId(),HttpStatus.UNAUTHORIZED.toString(), null);
			  }

		} catch (DataAccessException exception) {
			log.error("<<<EXCEPTION>>> in authorizeUser AdminServiceImpl {} " + exception.getMessage(), exception);
			throw new AdminException(HttpStatus.INTERNAL_SERVER_ERROR.value(),"authorizeUser",request.getUserId(), exception.getMessage(), exception.getCause());
		}
		response.setMessage(HttpStatus.OK.toString());
		response.setStatusCode(HttpStatus.OK.value());
		log.info("<<<EXIT>>> authorizeUser in AdminServiceImpl");
		return response;
	}
	
	private void saveAuthentication(String authToken, String userId, Timestamp currentTimeStamp) throws DataAccessException{
		log.info("<<<START>>> saveAuthentication in AdminServiceImpl");
		LoginAuthentication byConsumerAccountId = authRepo.getByUserId(userId);
		if(byConsumerAccountId==null) {
			byConsumerAccountId = new LoginAuthentication();
		}
			byte[] data = SerializationUtils.serialize(authToken);
			byConsumerAccountId.setAuthtoken(data);
			byConsumerAccountId.setLastLoginDateTime(currentTimeStamp);
			byConsumerAccountId.setUserId(userId);
			byConsumerAccountId.setLastLogoutDateTime(null);
			authRepo.save(byConsumerAccountId);

		log.info("<<<EXIT>>> saveAuthentication in AdminServiceImpl");
	}


	@Override
	public AuthorizationResponse logoutUser(LoginRequestBean request) throws AdminException {

		log.info("<<<START>>> logoutUser in AdminServiceImpl");
		AuthorizationResponse response = new AuthorizationResponse();

		try {

			AdminUser user = adminRepository.findByUserName(request.getUserId());
			if (user != null) {

				user.setLastLogoutDateTime(AdminUtil.getCurrentTimeStamp());

				adminRepository.save(user);
				
				LoginAuthentication loginAuthentication = authRepo.getByUserId(request.getUserId());
				if(loginAuthentication!=null) {
					loginAuthentication.setLastLogoutDateTime(AdminUtil.getCurrentTimeStamp());
					authRepo.save(loginAuthentication);
				}
				response.setStatusCode(HttpStatus.OK.value());
				response.setMessage(AdminServiceConstants.USER_LOGOUT_SUCCESS);

			}
		} catch (DataAccessException exception) {
			log.error("<<<EXCEPTION>>> in logoutUser AdminServiceImpl: {} " + exception.getMessage());
			throw new AdminException(HttpStatus.INTERNAL_SERVER_ERROR.value(),"logoutUser",request.getUserId(), exception.getMessage(), exception.getCause());
		}

		log.info("<<<EXIT>>> logoutUser in AdminServiceImpl");
		return response;

	}

	@Override
	public RoleMatrixResponse fetchRoleMatrix(RoleMatrixRequest request) throws AdminException {
		log.info("<<<START>>> fetchRoleMatrix in AdminServiceImpl");
		RoleMatrixResponse response = new RoleMatrixResponse();

		try{
			AdminUser byUserName = adminRepository.findByUserName(request.getUserId());
			List<String> rolesList = new ArrayList<>();
			if(null != byUserName ) {
				Set<AdminUserRoles> roles = byUserName.getRoles();

				for (AdminUserRoles role :
						roles) {
					if (AdminServiceConstants.Y_IND.equals(role.getActiveInd())) {
						rolesList.add(role.getUserRole());

					}

				}
			}
			Map<String, String> matrix = new HashMap<>();
			String[] split = request.getUserRoles().trim().split(AdminServiceConstants.STRING_SPLIT);
			Set<String> roles = Arrays.stream(split).collect(Collectors.toSet());

			for (String role: roles) {
				if(byUserName ==null || rolesList.contains(role)) {
					AdminUserRoles userRole = rolesRepository.findByUserRoleAndActiveInd(role, AdminServiceConstants.Y_IND);
                   if(userRole != null) {
					   Map<String, String> results = userRole.getRoleMatrix().stream().collect(Collectors.toMap(RoleAttributes::getRoleAttribute, RoleAttributes::getPermissionInd));
					   matrix = Stream.of(results, matrix).flatMap(m -> m.entrySet().stream())
							   .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (source, target) -> merge(source, target)));
				   }
				}

			}

			response.setRolesMatrix(matrix);
			response.setStatusCode(HttpStatus.OK.value());
			response.setMessage(HttpStatus.OK.toString());

		}catch (DataAccessException exception){
			log.info("<<<EXCEPTION>>> in fetchRoleMatrix AdminServiceImpl: ",exception.getCause());
			throw new AdminException(HttpStatus.INTERNAL_SERVER_ERROR.value(),"fetchRoleMatrix",null, exception.getMessage(), exception.getCause());
		}
		log.info("<<<EXIT>>> fetchRoleMatrix in AdminServiceImpl");
		return response;
	}


	private static String merge(String source, String target) {

		if (AdminServiceConstants.U_IND.equals(source)) {
			return source;
		} else if (AdminServiceConstants.R_IND.equals(source) && AdminServiceConstants.U_IND.equals(target)) {
			return target;

		} else if (AdminServiceConstants.R_IND.equals(source) && AdminServiceConstants.X_IND.equals(target)) {
			return source;
		}

		return target;
	}


}
