package com.conduent.ssportal.admin.service;

import com.conduent.ssportal.admin.exception.AdminException;
import com.conduent.ssportal.admin.model.*;

public interface AdminService {



	 AuthorizationResponse authorizeUser(LoginRequestBean request) throws AdminException;


	 AuthorizationResponse logoutUser(LoginRequestBean request) throws AdminException;


	RoleMatrixResponse fetchRoleMatrix(RoleMatrixRequest request) throws AdminException;
}