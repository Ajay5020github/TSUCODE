package com.conduent.ssportal.admin.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.conduent.ssportal.admin.exception.JsonNotFoundException;
import com.conduent.ssportal.admin.model.AuthorizationResponse;
import com.conduent.ssportal.admin.model.JSONContentResponseBean;
import com.conduent.ssportal.admin.model.LoginRequestBean;
import com.conduent.ssportal.admin.model.RoleMatrixRequest;
import com.conduent.ssportal.admin.model.RoleMatrixResponse;
import com.conduent.ssportal.admin.service.AdminService;
import com.conduent.ssportal.admin.service.JsonEditorService;
import com.conduent.ssportal.admin.util.AdminServiceConstants;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;

@RestController
public class AdminPortalController {

	private static final Logger log = LoggerFactory.getLogger(AdminPortalController.class);

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private JsonEditorService jsonService;

	@PostMapping(value = "/login",produces = "application/json")
	@Operation(summary  = "This method is used to  authorize the admin user")
	@ApiResponses(value = { @ApiResponse(responseCode  = AdminServiceConstants.SUCCESS_API_CODE, description  = AdminServiceConstants.SUCCESS),
			@ApiResponse(responseCode = AdminServiceConstants.BAD_REQUEST_API_CODE, description = AdminServiceConstants.BAD_REQUEST),
			@ApiResponse(responseCode = AdminServiceConstants.UNAUTHORIZED_API_CODE, description = AdminServiceConstants.UNAUTHORIZED),
			@ApiResponse(responseCode = AdminServiceConstants.ERROR_API_CODE, description = AdminServiceConstants.ERROR) })
	public ResponseEntity<AuthorizationResponse> login(@RequestBody @Valid LoginRequestBean request) {
		log.info("<<<START>>>  Entering into Login ====>");

		return new ResponseEntity<>(adminService.authorizeUser(request), HttpStatus.OK);
	}



	@PostMapping(value = "/fetchRoleMatrix",produces = "application/json")
	@Operation(summary  = "This method is used to  fetch admin role matrix")
	@ApiResponses(value = { @ApiResponse(responseCode  = AdminServiceConstants.SUCCESS_API_CODE, description  = AdminServiceConstants.SUCCESS),
			@ApiResponse(responseCode = AdminServiceConstants.BAD_REQUEST_API_CODE, description = AdminServiceConstants.BAD_REQUEST),
			@ApiResponse(responseCode = AdminServiceConstants.UNAUTHORIZED_API_CODE, description = AdminServiceConstants.UNAUTHORIZED),
			@ApiResponse(responseCode = AdminServiceConstants.ERROR_API_CODE, description = AdminServiceConstants.ERROR) })
	public ResponseEntity<RoleMatrixResponse> fetchRoleMatrix(@RequestBody @Valid RoleMatrixRequest request) {
		log.info("<<<START>>>  Entering into Login ====>");

		return new ResponseEntity<>(adminService.fetchRoleMatrix(request), HttpStatus.OK);
	}



	@PostMapping(value = "/logout",produces = "application/json")
	@Operation(summary  = "This method is used to  logout the admin user")
	@ApiResponses(value = { @ApiResponse(responseCode = AdminServiceConstants.SUCCESS_API_CODE, description = AdminServiceConstants.SUCCESS),
			@ApiResponse(responseCode = AdminServiceConstants.BAD_REQUEST_API_CODE, description = AdminServiceConstants.BAD_REQUEST),
			@ApiResponse(responseCode = AdminServiceConstants.ERROR_API_CODE, description = AdminServiceConstants.USER_LOGOUT_ERROR) })
	public ResponseEntity<AuthorizationResponse> logout(@RequestBody @Valid LoginRequestBean request) {
		log.info("<<<START>>> Entering into logout ====>");


		return new ResponseEntity<>(adminService.logoutUser(request), HttpStatus.INTERNAL_SERVER_ERROR);


	}
	
	
	@GetMapping(value = "/readContentJson/{fileName}", produces = "application/json")
	@Operation(summary  = "This method is used to get the all the LanguageServiceResponseBean data ")
	@ApiResponses(value = { @ApiResponse(responseCode = AdminServiceConstants.SUCCESS_API_CODE, description = AdminServiceConstants.JSON_FETCHED_SUCCESS),
			@ApiResponse(responseCode = AdminServiceConstants.ERROR_API_CODE, description = AdminServiceConstants.JSON_NOT_FOUND) })
	@ExceptionHandler(value = JsonNotFoundException.class)
	public ResponseEntity<JSONContentResponseBean> readContentJson(@PathVariable("fileName") String fileName){
		log.info(" == Starting of readContentJson == ");
		JSONContentResponseBean responseBean = null;
		try {
			responseBean = jsonService.readJson(fileName);
		} catch (JsonNotFoundException e) {
			responseBean = new JSONContentResponseBean();
			responseBean.setMessage(e.getMessage());
			responseBean.setStatusCode(AdminServiceConstants.INTERNAL_ERROR_CODE);
			log.error("Error occurred in readContentJson :: {}" , e.getMessage());
			return new ResponseEntity<>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.info("== Ending of readContentJson ==");
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}


}