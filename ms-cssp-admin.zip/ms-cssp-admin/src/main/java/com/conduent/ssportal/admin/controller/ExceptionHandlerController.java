package com.conduent.ssportal.admin.controller;

import com.conduent.ssportal.admin.exception.AdminException;
import com.conduent.ssportal.admin.exception.JsonEditException;
import com.conduent.ssportal.admin.exception.LoginAuthenticateError;
import com.conduent.ssportal.admin.util.AdminServiceConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.*;
import java.util.stream.Collectors;

@RestControllerAdvice
public class ExceptionHandlerController {


	
	@ExceptionHandler(value = { DataIntegrityViolationException.class })
	public ResponseEntity<?> DataIntegrityViolationException(DataIntegrityViolationException ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.CONFLICT);
	}



	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {

		Map<String, Object> body = new LinkedHashMap<>();
		body.put(AdminServiceConstants.STATUS_CODE, 400);
		body.put(AdminServiceConstants.MESSAGE, AdminServiceConstants.BAD_REQUEST);

		// Get all errors
		List<String> errors = ex.getBindingResult().getFieldErrors().stream().map(x -> x.getField())
				.collect(Collectors.toList());
		body.put(AdminServiceConstants.ERROR_FIELDS, errors);

		// Error log
		transactionLog(ex);



		return new ResponseEntity<>(body, HttpStatus.OK);
	}



	@ExceptionHandler(AdminException.class)
	public ResponseEntity<Object> accountServiceException(AdminException ex) {

		Map<String, Object> body = new LinkedHashMap<>();
		body.put(AdminServiceConstants.STATUS_CODE, ex.getErrorCode() != 0 ?ex.getErrorCode():500);
		body.put(AdminServiceConstants.MESSAGE, ex.getMessage());


		// Error log
		if(500 == ex.getErrorCode()) transactionLog(ex);

		return new ResponseEntity<>(body, HttpStatus.OK);
	}


	@ExceptionHandler(LoginAuthenticateError.class)
	public ResponseEntity<Object> unAuthorized(LoginAuthenticateError ex) {

		Map<String, Object> body = new LinkedHashMap<>();
		body.put(AdminServiceConstants.STATUS_CODE, AdminServiceConstants.UNAUTHORIZED_CODE);
		body.put(AdminServiceConstants.MESSAGE, ex.getMessage());

		return new ResponseEntity<>(body, HttpStatus.UNAUTHORIZED);
	}




	@Autowired
	private ErrorLogHandler handler;


	@ExceptionHandler(JsonEditException.class)
	public ResponseEntity<Object> accountServiceException(JsonEditException ex) {


		Map<String, Object> body = new LinkedHashMap<>();

		body.put(AdminServiceConstants.STATUS_CODE, ex.getErrorCode() != 0 ?ex.getErrorCode():500);
		body.put(AdminServiceConstants.MESSAGE, ex.getMessage());

		// Error log
		if(500 == ex.getErrorCode()) transactionLog(ex);


		return new ResponseEntity<>(body, HttpStatus.OK);
	}

	private void transactionLog(Exception ex){
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> childObj = new HashMap<>();

		if(ex instanceof MethodArgumentNotValidException){
			MethodArgumentNotValidException methodEx = (MethodArgumentNotValidException) ex;
			map.put(AdminServiceConstants.ACTION_NAME, methodEx.getParameter().getMethod().getName());
			map.put(AdminServiceConstants.SERVICE_ID,methodEx.getParameter().getMethod().getName());
			childObj.put(AdminServiceConstants.RESPONSE_CODE, AdminServiceConstants.BAD_REQUEST_CODE);
			childObj.put(AdminServiceConstants.ERROR_CODE, AdminServiceConstants.BAD_REQUEST_CODE);
		}else if (ex instanceof AdminException || ex instanceof JsonEditException){
			JsonEditException aex = (JsonEditException) ex;
			map.put(AdminServiceConstants.ACTION_NAME, aex.getAction());
			map.put(AdminServiceConstants.SERVICE_ID,aex.getAction());
			map.put(AdminServiceConstants.CONSUMER_ID,aex.getConsumerId() != null ?aex.getConsumerId().toString():null);
			childObj.put(AdminServiceConstants.RESPONSE_CODE, aex.getErrorCode());
			childObj.put(AdminServiceConstants.ERROR_CODE, aex.getErrorCode());
		}

		map.put(AdminServiceConstants.TRANSACTION_ID, null);
		map.put(AdminServiceConstants.SERVICE_TYPE, AdminServiceConstants.ACCOUNT);
		map.put(AdminServiceConstants.SOURCE_LAYER, AdminServiceConstants.SERVICE_SB);
		map.put(AdminServiceConstants.TRANSACTION_STATUS, AdminServiceConstants.F_IND);
		childObj.put(AdminServiceConstants.ERROR_MESSAGE, ex.getMessage());
		childObj.put(AdminServiceConstants.ERROR_TRACE, Arrays.toString(ex.getStackTrace()));
		map.put(AdminServiceConstants.MESSAGE, childObj);
		handler.invokeExceptionLogging(map);

	}
	
}
