/**
 * 
 */
package com.conduent.ssportal.admin.model;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

/**
 * @author C5109952
 *
 */

@Setter
@Getter
public class ChangeLog {

	
	private String userId;
	
	private String comments;
	
	private String jsonFileName;
	
	private Date updatedTimestamp;
	
	private String userName;
	
	private String userTitle;
	
	private String phoneNumber;
	
	private String department;
	
	private String location;
	
	private String emailAddress;
	
	private String organizationName;
	
	
}
