package com.conduent.ssportal.admin.configuration;

import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.conduent.ssportal.admin.AdminPortalApplication;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.XXssProtectionHeaderWriter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;


import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

@Configuration
@EnableWebMvc
public class AdminPortalConfig {
	
	private static final Logger log = LoggerFactory.getLogger(AdminPortalConfig.class);

	/*
	 * @Bean public Docket api() { return new
	 * Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select()
	 * .apis(RequestHandlerSelectors.basePackage("com.conduent.ssportal.admin")).
	 * paths(PathSelectors.any()) .build(); }
	 */

	/*
	 * private ApiInfo apiInfo() { return new
	 * ApiInfoBuilder().title("Admin Login and Dashboard")
	 * .description("Admin Login and Dashboard restAPI Info").build();
	 * 
	 * }
	 */
	
	@Bean
	public OpenAPI openApiInformation() {
	 
	  Info info = new Info()
	              .description("Benepath - SSP Application Service restAPI Info")
	              .title("Admin Login and Dashboard restAPI Info")
	              .version("V1.0.0");
	  return new OpenAPI().info(info);
	 }
	
	@Value("${azure.storage.connection-string}")
	private String accountName;
	
	@Value("${azure.storage.container-name}")
	private String containerName;
	
	@Bean
	public CloudBlobContainer getContainer() {
			CloudStorageAccount storageAccount;
			CloudBlobClient blobClient = null;
			CloudBlobContainer container = null;
			try {
				storageAccount = CloudStorageAccount.parse(accountName);
				blobClient = storageAccount.createCloudBlobClient();
				container = blobClient.getContainerReference(containerName);
				
			} catch (InvalidKeyException | StorageException | URISyntaxException io) {
				log.error("Error while getting blob container",io.getCause());
			}
			return container;
		
	}

	@Bean
	public WebSecurityCustomizer webSecurityCustomizer() {
		return (web) -> web.ignoring()
				.requestMatchers("/**");
	}

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.headers(headers -> headers
                .xssProtection(xss -> xss.headerValue(XXssProtectionHeaderWriter.HeaderValue.ENABLED_MODE_BLOCK))
                        .contentSecurityPolicy(csp -> csp
                            .policyDirectives("script-src 'self'")
                        ));
		return http.build();
	}


	@Value("${encryption.key}")
	private String encryptionKey;

	private static final String AES = "AES";

	@Bean(name = "encrypt")
	public Cipher encrypt(){

		Cipher cipher = null;
		try {
			cipher = Cipher.getInstance(AES);
			cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(encryptionKey.getBytes(), AES));

		} catch (InvalidKeyException | NoSuchPaddingException | NoSuchAlgorithmException e ) {
			log.error("Error while generating AES Cipher");
			throw new BeanCreationException(e.getMessage());
		}


		return cipher;
	}


	@Bean(name = "decrypt")
	public Cipher decrypt(){

		Cipher cipher = null;
		try {
			cipher = Cipher.getInstance(AES);
			cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(encryptionKey.getBytes(), AES));

		} catch (InvalidKeyException | NoSuchPaddingException | NoSuchAlgorithmException e ) {
			log.error("Error while generating AES Cipher");
			throw new BeanCreationException(e.getMessage());
		}


		return cipher;
	}
	
}