package com.conduent.ssportal.admin.repository;

import com.conduent.ssportal.admin.entity.ReferenceData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public interface ReferenceDataRepository extends JpaRepository<ReferenceData, Long> {

    List<ReferenceData> findByCategory(String category);

    default Map<String, String> findByCategoryData(String category) {
        return findByCategory(category).stream().collect(Collectors.toMap(ReferenceData::getCode, ReferenceData::getDescription));
    }
}