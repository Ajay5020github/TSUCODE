package com.conduent.ssportal.admin.exception;

public class JsonNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public JsonNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public JsonNotFoundException(String message) {
		super(message);
	}


}