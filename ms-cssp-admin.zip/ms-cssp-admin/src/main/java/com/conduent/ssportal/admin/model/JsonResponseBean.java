/**
 * 
 */
package com.conduent.ssportal.admin.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * @author C5109952
 *
 */
@Setter
@Getter
@JsonInclude(value = Include.NON_NULL)
public class JsonResponseBean {
	
	private transient Object json;
	//private String authToken;
	//private int statusCode;
	private String message;
	private String screenName;
	private String languageId;
	private String fileName;
	
	private List<ChangeLog> log;

}
