package com.conduent.ssportal.admin.model;

import lombok.Getter;
import lombok.Setter;

import jakarta.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@Setter
@Getter
public class RoleMatrixRequest implements Serializable {

    @NotNull
    private String userId;
    @NotNull
    private String userRoles;
}
