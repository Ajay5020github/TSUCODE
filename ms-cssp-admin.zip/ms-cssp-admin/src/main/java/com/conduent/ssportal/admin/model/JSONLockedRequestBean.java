package com.conduent.ssportal.admin.model;

import lombok.Getter;
import lombok.Setter;

import jakarta.validation.constraints.NotNull;

@Setter
@Getter
public class JSONLockedRequestBean {
	
    private String authToken;

    @NotNull
    private String userId;
}
