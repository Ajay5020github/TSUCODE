package com.conduent.ssportal.admin.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;



@Data
@Entity
public class ReferenceData {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

   private String code;
   private String description;
   private String category;
}
