/**
 * 
 */
package com.conduent.ssportal.admin.exception;

/**
 * @author C5109952
 *
 */
public class AdminException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7175584735429892235L;



	/**
	 * @param msg
	 */


	private final int errorCode;

	public String getAction() {
		return action;
	}

	private final String action;

	public Object getConsumerId() {
		return consumerId;
	}

	private final Object consumerId;



	public int getErrorCode() {
		return errorCode;
	}

	public AdminException(int errorCode, String action, Object consumerId, String errorMsg, Throwable cause) {
		super(errorMsg, cause);
		this.errorCode = errorCode;
		this.action = action;
		this.consumerId = consumerId;
	}


}
