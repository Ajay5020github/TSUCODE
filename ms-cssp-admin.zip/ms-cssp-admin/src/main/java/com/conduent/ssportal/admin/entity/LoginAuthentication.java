package com.conduent.ssportal.admin.entity;


import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.Date;

@Setter
@Getter
@Entity
@Table(name = "Admin_Authentication")
public class LoginAuthentication {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer Id;
	@Lob
	private byte[] authtoken;
	private String userId;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastLoginDateTime;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastLogoutDateTime;
}
	