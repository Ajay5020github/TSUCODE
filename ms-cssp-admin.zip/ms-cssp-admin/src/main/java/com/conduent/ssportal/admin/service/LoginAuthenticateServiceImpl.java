package com.conduent.ssportal.admin.service;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Date;

import com.conduent.ssportal.admin.model.AuthorizationResponse;
import com.conduent.ssportal.admin.util.AdminServiceConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.SerializationUtils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.conduent.ssportal.admin.entity.LoginAuthentication;
import com.conduent.ssportal.admin.exception.LoginAuthenticateError;
import com.conduent.ssportal.admin.exception.AdminException;
import com.conduent.ssportal.admin.model.LoginRequestBean;
import com.conduent.ssportal.admin.repository.LoginAuthRepository;

@Service
public class LoginAuthenticateServiceImpl implements LoginAuthenticateService {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginAuthenticateServiceImpl.class);

	@Autowired
	private LoginAuthRepository authrepo;


	// If the Combination Exist throw error orElse persist the combination in DB
	public AuthorizationResponse tokenAuthenticate(LoginRequestBean loginRequestBean) throws LoginAuthenticateError{
		LOGGER.info("Starting of the tokenAuthenticate in LoginAuthenticateServiceImpl");
		if (!isValidateToken(loginRequestBean)) {
			LOGGER.error("Consumer details are not matching");
			throw new LoginAuthenticateError("Invalid Request tokenAuthenticate Fail in isValidateToken() method");
		}

		if(AdminServiceConstants.DEPARTMENT.equals(loginRequestBean.getDepartment())) {
			LoginAuthentication byConsumerAccountId = authrepo.getByUserId(loginRequestBean.getUserId());
			if (byConsumerAccountId == null) {
				throw new LoginAuthenticateError("Request not authorized");
			}
		}

		return new AuthorizationResponse(AdminServiceConstants.SUCCESS_CODE, AdminServiceConstants.SUCCESS);
	}

	// Find the requested userId,consumerAccountId and the same present in authToken are same or not
	private boolean isValidateToken(LoginRequestBean loginRequestBean) throws LoginAuthenticateError {

		DecodedJWT jwt = null;
		var instant = Instant.now();
		var dateNow = instant.toEpochMilli();
		var timeStamp = new Timestamp(dateNow);
		try {
			jwt = JWT.decode(loginRequestBean.getAuthToken());
		} catch (JWTDecodeException exception) {
			LOGGER.error("Exception in isValidateToken: {} {}", exception.getMessage(), exception.getCause());
			throw new LoginAuthenticateError("Exception in isValidateToken: ");
		}
		String userId = "";

		if(AdminServiceConstants.DEPARTMENT.equals(loginRequestBean.getDepartment())) {
			userId = jwt.getClaim("userId").asString();
		}else{
			userId = jwt.getClaim("email").asString();
		}

		var expiresAt = jwt.getExpiresAt();
		var expire = expiresAt.after(timeStamp);
		LOGGER.info(" Compare two time {} ",expire);
		return userId.equals(loginRequestBean.getUserId()) && expire;
	}



}
