/**
 * 
 */
package com.conduent.ssportal.admin.util;

import java.sql.Timestamp;
import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.gson.Gson;

/**
 * @author C5109952
 *
 */
public class AdminUtil {
	

	private static final Logger log = LoggerFactory.getLogger(AdminUtil.class);

	public static String getUserId(String authToken) {

		String userId = null;
		DecodedJWT jwt = null;
		try {
			jwt = JWT.decode(authToken);
			userId = jwt.getClaim("userId").asString();
		} catch (JWTDecodeException exception) {
			log.error("Exception in decoding jwtToken ");
		}

		return userId;
	}


	
	/**
	 * desc:getCurrentTimeStamp() method used to get the date
	 * 
	 * @return dateNow
	 */
	public static Timestamp getCurrentTimeStamp() {
		Instant instant = Instant.now();
		long dateNow = instant.toEpochMilli();
		return new Timestamp(dateNow);
	}
	
	
	public static Object getJSon(String jsonString) {

		Gson gson = new Gson();
		return gson.fromJson(jsonString, Object.class);

	}
	
	

}
