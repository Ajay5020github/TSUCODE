package com.conduent.ssportal.admin.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import java.nio.charset.Charset;
import java.util.Base64;

@Component
@Converter
public class ColumnAttributeConverter implements AttributeConverter<String, String> {

    private static final Logger logger = LoggerFactory.getLogger(ColumnAttributeConverter.class);


    @Autowired
    @Qualifier("encrypt")
    private  Cipher encrypt;


    @Autowired
    @Qualifier("decrypt")
    private  Cipher decrypt;



    @Override
    public String convertToDatabaseColumn(String attribute) {
        try {

            if(attribute != null) {

                return Base64.getEncoder().encodeToString(encrypt.doFinal(attribute.getBytes(Charset.forName("UTF-8"))));
            }
        } catch (IllegalBlockSizeException | BadPaddingException | IllegalArgumentException e) {
            logger.error("Error while encrypting the column");
        }
        return attribute;
    }

    @Override
    public String convertToEntityAttribute(String dbData) {
        try {
            if(dbData != null) {
                return new String(decrypt.doFinal(Base64.getDecoder().decode(dbData)),Charset.forName("UTF-8"));
            }
        } catch (IllegalBlockSizeException | BadPaddingException  | IllegalArgumentException e) {
            logger.error("Error while decrypting the column");
        }
        return dbData;
    }
}
