package com.conduent.ssportal.admin;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@SpringBootApplication
@EnableWebSecurity
public class AdminPortalApplication {

	private static final Logger log = LoggerFactory.getLogger(AdminPortalApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(AdminPortalApplication.class, args);

		log.debug("AdminPortalApplication has Started");
	}

	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
}
