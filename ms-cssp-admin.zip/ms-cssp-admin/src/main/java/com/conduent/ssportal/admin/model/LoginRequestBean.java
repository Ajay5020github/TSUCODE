package com.conduent.ssportal.admin.model;

import jakarta.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class LoginRequestBean {
	@NotNull
	private String authToken;
	@NotNull
	private String userId;

	private String password;

	@NotNull
	private Boolean authenticationStatus;


	private String department;
	

}
