// middleware.js
import { NextResponse } from 'next/server';
import { isAuthenticated } from './utils/authenticate';

export function middleware(request) {
  const { pathname } = request.nextUrl;
  const isPublicPath = pathname.startsWith('/login') || pathname === '/';
  const isProtectedPath = !isPublicPath && pathname.startsWith('/admin');

  if (isProtectedPath && !isAuthenticated()) {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  if (isPublicPath && isAuthenticated()) {
    return NextResponse.redirect(new URL('/admin/dashboard', request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*', '/'],
};
