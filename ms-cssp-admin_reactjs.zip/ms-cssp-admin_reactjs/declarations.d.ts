declare module 'next-with-less';
declare module 'less-loader';
