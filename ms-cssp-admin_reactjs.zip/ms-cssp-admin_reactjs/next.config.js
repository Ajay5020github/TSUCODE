// next.config.js
module.exports = {
  //basePath: '/admin',
  assetPrefix: '/admin/',
   // trailingSlash: true,
  output: 'export', // Enable static export
  productionBrowserSourceMaps: false,
  async redirects() {
    return [
      {
        source: '/',
        destination: '/admin/login',
        permanent: true,
      },
    ];
  }
};
