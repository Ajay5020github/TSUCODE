// invalidUserIdValidations types for reset password.
export const INVALID_USER = 'INVALID_USER';
