/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
export const ADD_MORE = 'ADD_MORE';
export const ADD_MORE_SECTION = 'ADD_MORE_SECTION';
export const BUTTON = 'BUTTON';
export const CHECKBOX = 'CHECKBOX';
export const DATE = 'DATE';
export const DATE_LABEL = 'DATE_LABEL';
export const DISCLAIMER = 'DISCLAIMER';
export const E_SIGNATURE = 'E_SIGNATURE';
export const IMAGE = 'IMAGE';
export const INPUT = 'INPUT';
export const LABEL = 'LABEL';
export const LEGAL = 'LEGAL';
export const MULTI_SELECT = 'MULTI_SELECT';
export const PARAGRAPH = 'PARAGRAPH';
export const PROGRESS_BAR = 'PROGRESS_BAR';
export const RADIO = 'RADIO';
export const SECTION_BUTTON = 'SECTION_BUTTON';
export const SECTION_DIVIDER = 'SECTION_DIVIDER';
export const SELECT = 'SELECT';
export const TABLE = 'TABLE';
