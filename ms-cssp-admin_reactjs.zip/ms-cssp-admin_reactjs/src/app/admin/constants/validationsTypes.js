/*
 * Contains all the validations types used
 * throughout the application
 */

// Validations types for reset password.
export const EMPTY_FIELD = 'empty';
export const PASSWORD_MISMATCH = 'passwordMatch';
export const CHARACTER_MISMATCH = 'characterMismatch';
export const EMAIL_FIELD = 'email';

