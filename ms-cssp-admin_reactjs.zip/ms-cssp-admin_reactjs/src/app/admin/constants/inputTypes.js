/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
export const INPUT = 'INPUT';
export const CHECKBOX = 'CHECKBOX';
export const RADIO = 'RADIO';
export const SELECT = 'SELECT';
export const PARAGRAPH = 'PARAGRAPH';
export const PROGRESSBAR = 'PROGRESSBAR';
export const IMAGE = 'IMAGE';
export const LABEL = 'LABEL';
export const LINK = 'LINK';
export const MULTISELECT = "MULTISELECT";
//adding type for DISCLAIMER
export const DISCLAIMER = 'DISCLAIMER';
export const DATE = 'DATE';
export const TEXTFIELD = 'TEXTFIELD';
