import CONFIG  from  '../config/index';
import axios from 'axios';
import https  from 'https';
import Storage from '../utils/storage';


const serviceURL = `${CONFIG.api.nodeUrl.replace("adminbackend", "nodebackend")}/cache`;

export const deleteCacheItem = (cacheItem) => {
    
    const agent = new https.Agent({
        rejectUnauthorized: true
    });

    const headers = {
        contentType: "application/json"
    };
    
    const endPoint = `${serviceURL}/deleteCacheItem`;
        
    return axios
        .post(
            endPoint, cacheItem, { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error =>  error );
};
