import CONFIG  from  '../config/index';
import axios from 'axios';
import https  from 'https';
import Storage from '../utils/storage';

const invalidateCacheURL = `${CONFIG.api.nodeUrl.replace("adminbackend", "nodebackend")}/fetchConfigJson`;

export const invalidateCache = () => {
    
    const headers = {
        contentType: "application/json"
    };
    
    const endPoint = `${invalidateCacheURL}/invalidateCache`;
    
    
    return axios
        .get(endPoint, 
            { httpsAgent: headers }
        )
        .then(response => response.data)
        .catch(error => error);
};
