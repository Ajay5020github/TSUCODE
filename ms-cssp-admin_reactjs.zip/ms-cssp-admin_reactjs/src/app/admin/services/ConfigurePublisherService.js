import CONFIG  from  '../config/index';
import axios from 'axios';
import https  from 'https';
import Storage from '../utils/storage';

// fetchjson => fetch the content JSON based on screen name and language code
/* Input {
    "comments": "string",
    "json": {},
    "jsonFileName": "string",
    "jsonScreenName": "string",
    "language": "string"
} */

const getAuthToken = () => {
    return Storage.getItem('authToken');
}

const getUserId = () => {
    return Storage.getItem('adminUserId');
}

const serviceURL = `${CONFIG.api.nodeUrl}/jsonModifierService`;
const reportServiceURL = `${CONFIG.api.nodeUrl}/reportService`;
const environmentServiceURL = `${CONFIG.api.nodeUrl}`;


const readContentURL = `${CONFIG.api.nodeUrl}`;

export const fetchJson = (publisherJsonData) => {
    const agent = new https.Agent({
		rejectUnauthorized: true
    });
    
    const headers = {
        contentType: "application/json",
        authToken: Storage.getItem('authToken')
    };

    // publisherJsonData['authToken'] = getAuthToken();
    // publisherJsonData['userId'] =  getUserId();

    publisherJsonData['authToken'] = Storage.getItem('authToken');
    publisherJsonData['userId'] = Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email");
    publisherJsonData['department'] = Storage.getItem("loginType");
    publisherJsonData['id'] = Storage.getItem("sid");

    const endPoint = `${serviceURL}/fetchJson`;

    return axios
        .post(endPoint , publisherJsonData, 
            { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error => error);
};

// SaveJson => service will update the InProgress record with modified JSON based on screenName , language ID and userID.
export const saveJson = (savePublisherJsonData) => {

    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        contentType: "application/json",
        authToken: Storage.getItem('authToken')
    };

    // savePublisherJsonData['authToken'] = getAuthToken();
    // savePublisherJsonData['userId'] =  getUserId();

    savePublisherJsonData['authToken'] = Storage.getItem('authToken');
    savePublisherJsonData['userId'] = Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email");
    savePublisherJsonData['department'] = Storage.getItem("loginType");
    savePublisherJsonData['id'] = Storage.getItem("sid");

    const endPoint = `${serviceURL}/saveJson`;
    return axios
    .post(
        endPoint, savePublisherJsonData, { httpsAgent: agent, headers }
    )
    .then(response => response.data)
    .catch(error => error);
}


// revertJson =>  service will delete the InProgress copy based on screenName , language ID and userID.
export const revertJson = (revertPublisherJsonData) => {
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        contentType: "application/json",
        authToken: Storage.getItem('authToken')
    };

    // revertPublisherJsonData['authToken'] = getAuthToken();
    // revertPublisherJsonData['userId'] =  getUserId();

    revertPublisherJsonData['authToken'] = Storage.getItem('authToken');
    revertPublisherJsonData['userId'] = Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email");
    revertPublisherJsonData['department'] = Storage.getItem("loginType");
    revertPublisherJsonData['id'] = Storage.getItem("sid");
    
    const endPoint = `${serviceURL}/revertJson`;

    return axios
    .post(
        endPoint, revertPublisherJsonData, { httpsAgent: agent, headers }
    )
    .then(response => response.data)
    .catch(error => error);
}

// publishJson => service will update the modified content JSON in Azure blob and also 
// update the database with publishTimeStsmp, changeComments and status to published.
export const publishJson = (publishJSONData) => {
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        contentType: "application/json",
        authToken: Storage.getItem('authToken')
    };

    // publishJSONData['authToken'] = getAuthToken();
    // publishJSONData['userId'] = getUserId();

    publishJSONData['authToken'] = Storage.getItem('authToken');
    publishJSONData['userId'] = Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email");
    publishJSONData['department'] = Storage.getItem("loginType");
    publishJSONData['id'] = Storage.getItem("sid");

    const endPoint = `${serviceURL}/publishJson`;
    
    return axios
    .post(
        endPoint, publishJSONData, { httpsAgent: agent, headers }
    )
    .then(response => response.data)
    .catch(error => error);
}

// fetchLog => service will fetch log a JSON file
export const fetchLog = (jsonLogData) => {
    
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        contentType: "application/json",
        authToken: Storage.getItem('authToken')
    };

    // jsonLogData['authToken'] = getAuthToken();
    // jsonLogData['userId'] = getUserId();

    jsonLogData['authToken'] = Storage.getItem('authToken');
    jsonLogData['userId'] = Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email");
    jsonLogData['department'] = Storage.getItem("loginType");
    jsonLogData['id'] = Storage.getItem("sid");

    const endPoint = `${serviceURL}/fetchLog`;
    
    return axios
    .post(
        endPoint, jsonLogData, { httpsAgent: agent, headers }
    )
    .then(response => response.data)
    .catch(error => error);
}

export const readContentJson = (jsonFile) => {

    let readContent = {};

    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    
    const headers = {
        contentType: "application/json",
        authToken: Storage.getItem('authToken')
    };
    
    const endPoint = `${serviceURL}/readContentJson`;
    
    readContent['authToken'] = Storage.getItem('authToken');
    readContent['userId'] = Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email");
    readContent['department'] = Storage.getItem("loginType");  
    readContent['filename'] = jsonFile; 
    readContent['id'] = Storage.getItem("sid");

    return axios
        .post(endPoint, readContent,
            { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error => error);
};

export const fetchLockedFiles = (lockedJsonFiles) => {
    
    const agent = new https.Agent({
        rejectUnauthorized: true
    });

    const headers = {
        contentType: "application/json",
        authToken: Storage.getItem('authToken')
    };
    
    // lockedJsonFiles['authToken'] = getAuthToken();
    // lockedJsonFiles['userId'] = getUserId();

    lockedJsonFiles['authToken'] = Storage.getItem('authToken');
    lockedJsonFiles['userId'] = Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email");
    lockedJsonFiles['department'] = Storage.getItem("loginType");
    lockedJsonFiles['id'] = Storage.getItem("sid");

    const endPoint = `${serviceURL}/fetchLockedFiles`;   
        
        return axios
        .post(
            endPoint, lockedJsonFiles, { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error =>  error );
};

export const getEmbedToken = (adminReports) => {
    
    const agent = new https.Agent({
        rejectUnauthorized: true
    });

    const headers = {
        contentType: "application/json",
        authToken: Storage.getItem('authToken')
    };
    
    // adminReports['authToken'] = getAuthToken();
    // adminReports['userId'] = getUserId();

    adminReports['authToken'] = Storage.getItem('authToken');
    adminReports['userId'] = Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email");
    adminReports['department'] = Storage.getItem("loginType");
    adminReports['id'] = Storage.getItem("sid");

    const endPoint = `${reportServiceURL}/getEmbedToken`;
        
    return axios
        .post(
            endPoint, adminReports, { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error =>  error );
};

export const getEnvironment = (adminReportEnvironment) => {
    
    const agent = new https.Agent({
        rejectUnauthorized: true
    });

    const headers = {
        contentType: "application/json",
        authToken: Storage.getItem('authToken')
    };
    
    adminReportEnvironment['authToken'] = Storage.getItem('authToken');
    adminReportEnvironment['userId'] = Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email");
    adminReportEnvironment['department'] = Storage.getItem("loginType");
    adminReportEnvironment['id'] = Storage.getItem("sid");

    const endPoint = `${environmentServiceURL}/getEnvironment`;
        
    return axios
        .post(
            endPoint, adminReportEnvironment, { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error =>  error );
};

