"use client"
import axios from 'axios';
import https from 'https';
import { formatSSN } from '../components/userManagementComponents/myBenefitUtil';
import CONFIG from '../config/index';
import Storage from '../utils/storage';


const getAuthToken = () => {
    return Storage.getItem('authToken');
}

const getUserId = () => {
    return Storage.getItem('adminUserId');
}

// viewUserDetail() service will fetch the complete user information from database based on 
// userID selected. Response includes Complete User information along with Security 
// Questions and Answers.
export const viewUserService = (userData) => {
    /* istanbul ignore next */
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        'Content-Type': "application/json",
        authToken: Storage.getItem('authToken')
    };
    userData['authToken'] = getAuthToken();
    // userData['userId'] = getUserId();
    // userData['emailAddress'] = "hariprasadqa55@gmail.com";

    const endPoint = `${CONFIG.api.nodeUrl}/adminService/viewUserDetail`;
    const requestBody = {
		userId:  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		consumerUserID: userData.consumerUserID || userData.consumerAccountId || null,
		email: userData.emailAddress || null,
        authToken: Storage.getItem('authToken'),
        department: Storage.getItem("loginType"),
        id: Storage.getItem("sid")
	};

    return axios
        .post(endPoint , requestBody, { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error => {
        });
}

// unlockUserAccount() service will update the user account status as unlocked, also its 
// stores the audit information (ConsumerUserId, adminUserID, requestType, 
// requestTimeStamp) in UserManagentLog table. 

export const unlockUserAccount = (userData) => {
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    
    const headers = {
        'Content-Type': "application/json",
        authToken: Storage.getItem('authToken')
    };

    userData['authToken'] = getAuthToken();
    userData['userId'] = getUserId();

    const endPoint = `${CONFIG.api.nodeUrl}/adminService/unlockAccount`;
    const requestBody = {
		userId:  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		consumerAccountId: userData.consumerAccountId || null,
        email: userData.emailAddress || null,
        department: Storage.getItem("loginType"),
        authToken: Storage.getItem('authToken'),
        id: Storage.getItem("sid")
	};
    return axios
        .post(endPoint, requestBody, 
            { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error => {
        });
}

// resetPassword

// export const resetPassword = (userData) => {
//     const agent = new https.Agent({
//         rejectUnauthorized: true
//     });
//     const headers = {
//         'Content-Type': "application/json",
//         authToken: Storage.getItem('authToken')
//     };

//     //userData['authToken'] = getAuthToken();
//     //userData['userId'] = getUserId();

//     const endPoint = `${CONFIG.api.nodeUrl}/adminService/resetAccountPassword`;
//     const requestBody = {
// 		userId:  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
// 		consumerAccountId: userData.consumerAccountId || null,
//         email: userData.emailAddress || null,
//         department: Storage.getItem("loginType"),
//         authToken: Storage.getItem('authToken'),
//         id: Storage.getItem("sid")
// 	};
//     return axios
//         .post(endPoint , requestBody, 
//             { httpsAgent: agent, headers }
//         )
//         .then(response => response.data)
//         .catch(error => {
//         });
// }

// kunal converted to async
// Async function to reset the password
export const resetPassword = async (userData) => {
    const agent = new https.Agent({
        rejectUnauthorized: true
    });

    const headers = {
        'Content-Type': "application/json",
        authToken: Storage.getItem('authToken')
    };

    const requestBody = {
        userId: Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
        consumerAccountId: userData.consumerAccountId || null,
        email: userData.emailAddress || null,
        department: Storage.getItem("loginType"),
        authToken: Storage.getItem('authToken'),
        id: Storage.getItem("sid")
    };

    const endPoint = `${CONFIG.api.nodeUrl}/adminService/resetAccountPassword`;

    try {
        const response = await axios.post(endPoint, requestBody, { httpsAgent: agent, headers });
        return response.data;
    } catch (error) {
        // Handle error appropriately here
        // throw error; // Re-throw the error to handle it higher up if needed
    }
};




export const lockAccountService = (userData) => {
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        'Content-Type': "application/json",
        authToken: Storage.getItem('authToken')
    };

    //userData['authToken'] = getAuthToken();
    //userData['userId'] = getUserId();

    const endPoint = `${CONFIG.api.nodeUrl}/adminService/lockAccount`;
    const requestBody = {
		userId:  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		consumerAccountId: userData.consumerAccountId || null,
        email: userData.emailAddress || null,
        department: Storage.getItem("loginType"),
        authToken: Storage.getItem('authToken'),
        id: Storage.getItem("sid")
	};
    return axios
        .post(endPoint , requestBody, 
            { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error => {
        });
}

export const authenticateAccountService = (userData) => {
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        'Content-Type': "application/json",
        authToken: Storage.getItem('authToken')
    };

    //userData['authToken'] = getAuthToken();
    //userData['userId'] = getUserId();

    const endPoint = `${CONFIG.api.nodeUrl}/adminService/authenticateAccount`;
    const requestBody = {
		userId:  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		consumerAccountId: userData.consumerAccountId || null,
        email: userData.emailAddress || null,
        department: Storage.getItem("loginType"),
        dateOfBirth: userData.dateOfBirth && userData.dateOfBirth,
        socialSecurityNumber: userData.socialSecurityNumber && userData.socialSecurityNumber.replaceAll("-", ""),
        authToken: Storage.getItem('authToken'),
        id: Storage.getItem("sid")
	};
    return axios
        .post(endPoint , requestBody, 
            { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error => {
        });
}

export const activateAccountService = (userData) => {
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        'Content-Type': "application/json",
        authToken: Storage.getItem('authToken')
    };

    //userData['authToken'] = getAuthToken();
    //userData['userId'] = getUserId();

    const endPoint = `${CONFIG.api.nodeUrl}/adminService/activateAccount`;
    const requestBody = {
		userId:  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		consumerAccountId: userData.consumerAccountId || null,
        email: userData.emailAddress || null,
        department: Storage.getItem("loginType"),
        authToken: Storage.getItem('authToken'),
        id: Storage.getItem("sid")
	};
    return axios
        .post(endPoint , requestBody, 
            { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error => {
        });
}


export const deactivateAccountService = (userData) => {
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        'Content-Type': "application/json",
        authToken: Storage.getItem('authToken')
    };

    //userData['authToken'] = getAuthToken();
    //userData['userId'] = getUserId();

    const endPoint = `${CONFIG.api.nodeUrl}/adminService/deactivateAccount`;
    const requestBody = {
		userId:  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		consumerAccountId: userData.consumerAccountId || null,
        email: userData.emailAddress || null,
        department: Storage.getItem("loginType"),
        authToken: Storage.getItem('authToken'),
        id: Storage.getItem("sid")
	};
    return axios
        .post(endPoint , requestBody, 
            { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error => {
        });
}

export const telephoneAssistorService = (userData) => {
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        'Content-Type': "application/json",
        authToken: Storage.getItem('authToken')
    };

    //userData['authToken'] = getAuthToken();
    //userData['userId'] = getUserId();

    const endPoint = `${CONFIG.api.nodeUrl}/adminService/telephoneAssistor`;
    const requestBody = {
		userId:  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		consumerAccountId: userData.consumerAccountId || null,
        email: userData.emailAddress || null,
        department: Storage.getItem("loginType"),
        assistorInd: userData.assistorInd,
        authToken: Storage.getItem('authToken'),
        id: Storage.getItem("sid")
    };

    return axios
        .post(endPoint , requestBody, 
            { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error => {
        });
}

export const enableProgramService = (mdhsVerifyCase) => {
    const agent = new https.Agent({
        rejectUnauthorized: true
    });
    const headers = {
        'Content-Type': "application/json",
        authToken: Storage.getItem('authToken')
    };

    mdhsVerifyCase["id"] = Storage.getItem("sid");
    
    const endPoint = `${CONFIG.api.nodeUrl}/adminService/verifyCase`;
    const requestBody = mdhsVerifyCase;

    return axios
        .post(endPoint , requestBody, 
            { httpsAgent: agent, headers }
        )
        .then(response => response.data)
        .catch(error => {
        });
}
