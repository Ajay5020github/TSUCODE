"use client"
import React, { useEffect } from 'react';
import RootLayout from '../layout';
import Login from '../components/login/login';
import Layout from '../components/layout';
import GetBuildVersion from "../ChunkReload";

const LoginComponent = (props) => {
    // kunal calling getbuildversion to reload the chunks
    useEffect(() => {
        GetBuildVersion(); // Call function on mount
    }, []);

  return (
    <div className='login-container'>

      <RootLayout>
        <Login />
      </RootLayout>
    </div>
  );
};

export default LoginComponent;
