import React from 'react';
import RootLayout from '../layout';
import UserManagement from '../containers/userManagement/userManagement';
const AdminReportDetailComponentpage = (props) => {
 
  return (
    <div className='login-container'>

      <RootLayout>
        <UserManagement />
             </RootLayout>
    </div>
  );
};

export default AdminReportDetailComponentpage;
