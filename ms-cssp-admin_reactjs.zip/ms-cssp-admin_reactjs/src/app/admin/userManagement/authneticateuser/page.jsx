import React from 'react';
import RootLayout from '../../layout';
import UserAuthenticationContainer from '../../containers/userAuthentication/userAuthenticationContainer';
import withAuth from '../../components/withAuth';
import '../../components/userManagementComponents/userdetails.css';
import '../../containers/custom.css'

const UserDetailContainerPage = (props) => { 
  return (
    <div className='login-container'>

      <RootLayout>
        <UserAuthenticationContainer />
      </RootLayout>
      
    </div>
  );
};

export default UserDetailContainerPage;
