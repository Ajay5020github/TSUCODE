import React from 'react';
import RootLayout from '../../layout';
import UserDetailContainer from '../../containers/userDetails/UserDetailContainer';
import withAuth from '../../components/withAuth';

// import UserDetailContainer from '/containers/userDetails/UserDetailContainer';

const UserDetailContainerPage = (props) => {

  return (
    <div className='login-container'>

      <RootLayout>
        <UserDetailContainer />
      </RootLayout>
    </div>
  );
};

export default UserDetailContainerPage;
