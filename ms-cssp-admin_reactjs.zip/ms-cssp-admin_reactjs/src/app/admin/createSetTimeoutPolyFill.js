/* export default function createSetTimeoutPolyFill(fn,n){
    (async()=>{
      n=n||0; var time=Date.now()+n
      await new Promise(r=>r()) //asynchronous even if n is 0
      while(Date.now()<time){
        await new Promise(r=>r())
      }
      fn()
    })()
    return true
  } */
const setTimeouts = [];  

 export default function createSetTimeoutPolyFill(cb, ms) {
    var now = performance.now();
    window.addEventListener('message', handleMessage);
    let num = Math.random()
    postMessage('timeout'+num, '*');
    function handleMessage(evt) {
     if(evt.data === 'timeout'+num) {
        if(performance.now() - now >= ms) {
          window.removeEventListener('message', handleMessage);
          cb();
        }
        else {
          postMessage('timeout'+num, '*');
        }
      }
    }
  
  }

  export function customClearTimeout(setTimeoutId) {
    if (setTimeouts[setTimeoutId]) {
      setTimeouts[setTimeoutId].active = false;
    }
  }