
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 
 */
const logger = () => next => action => {
	const result = next(action);
	return result;
};

export default logger;
