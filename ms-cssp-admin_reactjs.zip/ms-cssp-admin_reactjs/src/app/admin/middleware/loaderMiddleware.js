
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 
 */
/*
 * Sets the loader text page wise.
 */

import { setLoaderText } from '../actions/loader/loaderActions';
import * as types from '../actions/actionTypes';

export const loaderMiddleware = function ({ dispatch }) {
	return function (next) {
		return function (action) {
			if (
				action.type === types.FETCH_ELIGIBILITY_QUESTIONS_DATA_SUCCESS
			) {
				let loaderText = '';
				if (
					action.payload.data.content &&
					action.payload.data.content.loader &&
					action.payload.data.content.loader.text
				) {
					loaderText = action.payload.data.content.loader.text;
				}

				dispatch(setLoaderText(loaderText));
			}
			return next(action);
		};
	};
};
