"use client";
import React, { useEffect, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import UserDashboard from '../containers/userDashboard/userDashboard';

const DashboardPage = () => {
  const searchParams = useSearchParams();
  const router = useRouter();
  const [paramsReady, setParamsReady] = useState(false);

  useEffect(() => {
    // ✅ Capture params HERE using Next.js hook — window.location.search is unreliable
    const mail = searchParams.get("mail");
    const id   = searchParams.get("id");

    console.log("DashboardPage - mail param:", mail);
    console.log("DashboardPage - id param:", id);

    if (mail && id) {
      // ✅ Save to sessionStorage BEFORE cleaning URL
      sessionStorage.setItem("externalMail", mail);
      sessionStorage.setItem("externalId", id);
      console.log("DashboardPage - Saved params to sessionStorage");

      // ✅ Clean the URL without losing the page, THEN render UserDashboard
      router.replace("/admin/dashboard");
    }

    // ✅ Signal that params have been handled — safe to mount UserDashboard
    setParamsReady(true);
  }, [searchParams]);

  // ✅ Don't render UserDashboard until params are saved to sessionStorage
  if (!paramsReady) return null;

  return (
    <div className="login-container">
      <UserDashboard />
    </div>
  );
};

export default DashboardPage;
