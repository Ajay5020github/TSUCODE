
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 
 */
/*
 * Wrapper around browser storage.
 * Currently it uses localStorage
 */
export default class Storage {
	// Determine the storage based on environment
	static get storage() {
	  if (typeof window !== 'undefined') {
		return sessionStorage;
	  }
	  // Return a dummy object in non-browser environments to avoid errors
	  return {
		setItem: () => {},
		getItem: () => null,
		removeItem: () => {},
		clear: () => {},
	  };
	}
  
	static setItem(key, value) {
	  this.storage.setItem(key, value);
	}
  
	static getItem(key) {
	  return this.storage.getItem(key);
	}
  
	static removeItem(key) {
	  this.storage.removeItem(key);
	}
  
	static clear() {
	  this.storage.clear();
	}
  }
  