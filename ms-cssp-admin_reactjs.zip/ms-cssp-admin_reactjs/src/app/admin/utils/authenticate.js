/*
 * Manage the authentication and authorization
 * logic of the application
 */


import Storage from './storage';

export const isAuthenticated = () => {

	if ((Storage.getItem('authToken') === null || Storage.getItem('authToken') === undefined)) {
			return false;		
	}
	else {
		return true;
	}	
};
export const getTokenValue = (email, id) => {
    return new Promise((resolve, reject) => {
        try {
            Storage.setItem('email', email);
            Storage.setItem('sid', id);
            resolve();  // Resolves the promise if successful
        } catch (error) {
            reject(error);  // Rejects if there's an error
        }
    });
};

 











