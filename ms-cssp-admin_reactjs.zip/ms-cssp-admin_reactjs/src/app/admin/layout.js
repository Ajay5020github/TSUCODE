"use client";

import React, { useEffect } from "react";
import { useRouter } from "next/navigation";
import "bootstrap/dist/css/bootstrap.min.css";
import { Provider } from "react-redux";
import { configureAppStore } from "./store/configureStore";
import "../admin/styles/global.scss";
import "../admin/components/componentStyle.css";
import { PersistGate } from "redux-persist/integration/react";
import { AuthProvider } from "./components/AuthContext";
import Head from "next/head";

import "@fontsource/open-sans/300.css";
import "@fontsource/open-sans/400.css";
import "@fontsource/open-sans/700.css";
import "@fontsource/source-sans-pro/400.css";
import "@fontsource/source-sans-pro/700.css";
import "@fontsource/dancing-script/700.css";

const { store, persistor } = configureAppStore();

export default function RootLayout({ children }) {
  const router = useRouter();

  // Redirect from "/" to "/admin/login"
  useEffect(() => {
    if (router.pathname === "/") {
      console.log("Redirect triggered:", window.location.href);
      router.replace("/admin/login");
    }
  }, [router]);

  // Log every URL change
  useEffect(() => {
    console.log("Initial URL:", window.location.href);

    const handleRouteChange = (url) => {
      console.log("Navigated to:", url);
    };

    // Subscribe to router events
    router.events?.on("routeChangeComplete", handleRouteChange);

    return () => {
      router.events?.off("routeChangeComplete", handleRouteChange);
    };
  }, [router]);

  useEffect(() => {
    document.title = "Conduent Admin Portal";
  }, []);

  return (
    <html lang="en">
      <Head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#000000" />
        <meta name="description" content="Conduent Admin Portal" />
        <link rel="apple-touch-icon" href="logo192.png" />
      </Head>
      <body>
        <Provider store={store}>
          <PersistGate loading={null} persistor={persistor}>
            <AuthProvider>
              {children}
            </AuthProvider>
          </PersistGate>
        </Provider>
      </body>
    </html>
  );
}
