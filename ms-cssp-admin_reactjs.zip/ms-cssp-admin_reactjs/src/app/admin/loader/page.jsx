import React from 'react';
import RootLayout from '../layout';
import Loader from '../components/loader/loader';
import withAuth from '../components/withAuth';

const LoginComponent = (props) => {
 
  return (
    <div className='login-container'>

      <RootLayout>
        <Loader />
      </RootLayout>
    </div>
  );
};

export default (LoginComponent);
