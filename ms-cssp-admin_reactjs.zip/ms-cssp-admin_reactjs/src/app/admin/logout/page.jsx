import React from 'react';
import RootLayout from '../layout';
import Layout from '../components/layout';
import Logout from '../containers/logout/logout';
import withAuth from '../components/withAuth';

const LoginComponent = (props) => {
 
  return (
    <div className='login-container'>

      <RootLayout>
        <Logout />
      </RootLayout>
    </div>
  );
};

export default (LoginComponent);
