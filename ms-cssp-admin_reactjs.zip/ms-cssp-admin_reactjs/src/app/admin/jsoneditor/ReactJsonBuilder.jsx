"use client";
import React from 'react';
import { useDispatch } from 'react-redux';
import { CssBaseline, ThemeProvider } from '@mui/material';
import { Provider } from 'react-redux';
import { jsonBuilderTheme } from './themes/JsonBuilderTheme';
import Home from './components/Home';
import allReducers from './reducers';
import ErrorBoundary from '../ErrorBoundary';
import { configureStore } from '@reduxjs/toolkit';
import '../../admin/styles/global.scss'

const store = configureStore({
    reducer: allReducers
});

const ReactJsonBuilder = (props) => {
    return (
        <ErrorBoundary>
            <Provider store={store}>
                <ThemeProvider theme={jsonBuilderTheme}>
                    <CssBaseline />
                    <Home publishLabelData={props.publishLabelData} />
                </ThemeProvider>
            </Provider>
        </ErrorBoundary>
    );
};

export default ReactJsonBuilder;
