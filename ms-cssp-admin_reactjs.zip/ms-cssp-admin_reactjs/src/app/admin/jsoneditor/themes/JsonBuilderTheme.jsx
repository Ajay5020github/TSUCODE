import { createTheme } from '@mui/material/styles';

const colorCode = {
    appBackground: '#f4f5fd',
    headerToolbar: '#147120',
    sectionBackground: '#B7BEBB',
    paperBackground: '#0000008a',
    errorMessage: '#E2231A',
    pageContent: '#ffffff',
    editorPaper: '#ffffff',
    /*********Property Tree */
    textboxPropertyTreeColor: '#fafbff',
    propertyTreeRoot: '#57a3eb',
    /**********Node update tree */
    paperBorderNodeUpdateTree: '#E7EFEB',
    paperBackgroundNodeUpdateTree: 'rgba(0, 0, 0, 0)',
    searchedValueNodeUpdateTree: '#e4eb31',
    searchedTextNodeUpdateTree: '#ffffff',
    listIconNodeUpdateTree: '#ff6464'
};

export const jsonBuilderTheme = createTheme({
    palette: {
        primary: { main: colorCode.appBackground },
        secondary: { main: colorCode.headerToolbar },
        error: { main: colorCode.errorMessage },
        background: {
            default: colorCode.pageContent,
            paper: colorCode.editorPaper
        },
        text: {
            primary: '#000',
            secondary: '#808080'
        },
        /**********************Text Color */
        contentColor: {
            white: '#fff',
            black: '#000',
            grey: '#808080'
        },
        /*********Header */
        header: { main: colorCode.headerToolbar, contrastText: '#fff' },
        pageContent: { main: colorCode.pageContent, contrastText: '#000' },
        /****************View Section */
        tabBgViewSection: { main: '#585b5f' },
        /*******Editor */
        editorPaper: { main: colorCode.editorPaper },
        /**********Property Tree */
        textboxPropertyTree: { main: colorCode.textboxPropertyTreeColor },
        propertyTreeRoot: { main: colorCode.propertyTreeRoot },
        searchInputPropertyTree: { main: 'rgb(211, 211, 211)' },
        /***************Property Update */
        accordionSectionPropertyUpdate: { main: '#e1e6e6' },
        /********************* Node Update Tree */
        paperBorderNodeUpdateTree: { main: '#E7EFEB' },
        paperBackgroundNodeUpdateTree: { main: 'rgba(0, 0, 0, 0)' },
        searchedValueNodeUpdateTree: { main: '#e4eb31' },
        searchedTextNodeUpdateTree: { main: 'rgb(211, 211, 211)' },
        listIconNodeUpdateTree: { main: '#ff6464' },
        /***************JSON Schema Window */
        buttonStyleJsonSchemaWindow: { main: '#545A61' },
        tabBottomJsonSchemaWindow: { main: '#e8e8e8' },
        /*******************View Section */
        viewSectiontab: { main: '#55585A', boxshadow: '#484747' },
        gridSectiontab: { main: '#2596be'}
    },
    typography: {
        fontFamily: ['Roboto', 'Helvetica', 'Arial', 'sans-serif'].join(',')
    },
    shape: {
        borderRadius: 12
    },
    components: {
        MuiButtonBase: {
            defaultProps: {
                disableRipple: true // No more ripple, on the whole application!
            }
        },
        MuiCssBaseline: {
            styleOverrides: {
                '*': {
                    'scrollbar-width': 'thin'
                },
                '*::-webkit-scrollbar': {
                    width: '12px',
                    height: '6px',
                },
                /* Track */
                '::-webkit-scrollbar-track': {
                    background: '#f1f1f1'
                },
                /* Handle */
                '::-webkit-scrollbar-thumb': {
                    background: '#c1c1c1',
                    borderRadius: '0px'
                },
                /* Handle on hover */
                '*::-webkit-scrollbar-thumb:hover': {
                    background: '#b5b3b3',
                    width: '12px',
                }
            }
        }
    }
});
