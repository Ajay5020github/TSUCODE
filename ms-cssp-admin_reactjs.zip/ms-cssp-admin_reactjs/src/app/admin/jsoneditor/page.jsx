import React from 'react';
import RootLayout from '../layout';
import Layout from '../components/layout';
import Home from './components/Home';
import ReactJsonBuilder from './ReactJsonBuilder';
import JSONEditorContainers from '../containers/JSONEditor/JSONEditorContainers';

const LoginComponent = (props) => {
 
  return (
    <div className='login-container'>

      <RootLayout>
        <JSONEditorContainers />
      </RootLayout>
    </div>
  );
};

// LoginComponent.displayName = "Login"

export default LoginComponent;
