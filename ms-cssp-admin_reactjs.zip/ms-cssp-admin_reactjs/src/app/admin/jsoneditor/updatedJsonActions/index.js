const UPDATE_JSON = 'UPDATE_JSON';
const SAVE_CODE_JSON = 'SAVE_CODE_JSON';
const CLEAR_UPDATED_JSON_DATA = 'CLEAR_UPDATED_JSON_DATA';
const SAVE_JSON_SUCCESSFUL = 'SAVE_JSON_SUCCESSFUL';
const SAVE_JSON_FAILED = 'SAVE_JSON_FAILED';
const UPDATE_COMPLETE = 'UPDATE_COMPLETE'

export const update_json = (data, path, key, json) => {
	return {
		type: UPDATE_JSON,
		payload: data,
		path: path,
		key: key,
		json: json
	};
};

export const save_code_json = data => {
	return {
		type: SAVE_CODE_JSON,
		payload: data
	};
};

export const update_complete = () => {
	return {
		type: UPDATE_COMPLETE
	};
};

export const clear_updated_json = () => {	
	return {
		type: CLEAR_UPDATED_JSON_DATA
	};
};

export const json_file_save_successful = () => {
	return {
		type: SAVE_JSON_SUCCESSFUL
	};
};

export const json_file_save_failed = () => {
	return {
		type: SAVE_JSON_FAILED
	};
};
