const SELECTED_NODE_JSON = 'SELECTED_NODE_JSON';
const CLEAR_SELECTED_NODE = 'CLEAR_SELECTED_NODE';

export const selected_node_json = (selectedNodeData, nodeSelected) => {
    return {
        type: SELECTED_NODE_JSON,
        selectedNodeData: selectedNodeData,
        nodeSelected: nodeSelected
    };
};

export const clear_selected_node = () => {
    return {
        type: CLEAR_SELECTED_NODE
    };
};