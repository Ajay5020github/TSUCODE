export const validateJson = (jsonData) => {
	let message = '';
	try {
		JSON.parse(jsonData);
		return [true, message];
	} catch (error) {
		message = error.message;
		return [false, message];
	}
};

export const convertToJson = function (obj) {

	// Generate a random value structured as a GUID
	const guid = function () {
		const s4 = () => {
			return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
		};
		return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
	};

	

	// Check if a value is an object
	const isObject = function (value) {
		return (typeof value === 'object');
	};

	// Check if an object is an array
	const isArray = function (obj) {
		return (Object.prototype.toString.call(obj) === '[object Array]');
	};

	const setParent = function (o, key, parentid) {
		if (o === null) {
			return;
		}

		if (Object.isFrozen(o)) {			
			o = { ...o }; // Clone the object to make it mutable
		}
		
		o['$ID'] = guid();
		if (!parentid) {
			parentid = o['$ID'];
		}
		o['$PID'] = parentid;
		parentid = o['$ID'];
		
		for (const n in o) {

			if (o.hasOwnProperty(n) && isObject(o[n]) && (!isArray(o[n]))) {
				setParent(o[n], key, parentid);
			}
			if (isObject(o[n]) && (isArray(o[n]))) {
				const objchild = o[n];
				for (let i = 0; i < objchild.length; i++) {
					if (objchild.hasOwnProperty(i) && isObject(objchild[i])) {
						const obj = objchild[i];
						setParent(obj, key, parentid);
					}
				}
			}
		}
		return o;
		
	};
	return setParent(obj, '$ID', 'ROOT');

};

// Check if a value is an object
export const RemoveParentId = function (o, id, pid) {

    // Check if a value is a plain object

    const isObject = function (value) {
        return value !== null && typeof value === 'object' && !Array.isArray(value);
    };
 
    // Check if value is an array

    const isArray = function (value) {
        return Array.isArray(value);
    };
 
    // Recursive function to deeply clone and remove id/pid

    const removeKeys = (obj) => {
        
		if (!isObject(obj) && !isArray(obj)) return obj;

        if (isArray(obj)) {
            return obj.map(item => removeKeys(item));
        }
 
        const newObj = {};

        for (const key in obj) {

            if (key === id || key === pid) continue; // skip $ID and $PID
 
            const value = obj[key];
            newObj[key] = removeKeys(value);

        }

        return newObj;

    };
 
    return removeKeys(o);

};

export const searchObject = function (object, matchCallback, currentPath, result, searched) {
	currentPath = currentPath || '';
	result = result || [];
	searched = searched || [];
	if (searched.indexOf(object) !== -1 && object === Object(object)) {
		return;
	}
	searched.push(object);
	if (matchCallback(object)) {
		result.push({ path: currentPath, value: object });
	}
	try {
		if (object === Object(object)) {
			for (const property in object) {
				if (property.indexOf('$') !== 0) {
					searchObject(object[property], matchCallback, currentPath + '.' + property, result, searched);
				}
			}
		}
	}
	catch (e) {
	}
	return result;
};

export const uuidv4 = () => {
	return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
		(c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
	);
};

export const handleSaveToPC = jsonData => {
	const newDate = new Date();
	jsonData.version = '1.0.0';
	const fileData = JSON.stringify(jsonData, null, 2);
	const blob = new Blob([fileData], { type: 'application/json' });
	const url = URL.createObjectURL(blob);
	const link = document.createElement('a');
	link.download = 'json- ' + newDate.toLocaleString() + '.json';
	link.href = url;
	link.click();
};
