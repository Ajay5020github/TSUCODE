// /* eslint-disable react/prop-types */
// import React from 'react';
// import Alert from '@mui/material/Alert';
// import Snackbar from '@mui/material/Snackbar';

// export const handleFileValidation = (inputFile) => {
// 	const inputFileName = inputFile.target.files[0].name;
// 	const result = checkInputFileExtension(inputFileName);
// 	return result;
// };

// export const handleDropFileValidation = (inputFile) => {
// 	const inputFileName = inputFile.path;
// 	const result = checkInputFileExtension(inputFileName);
// 	return result;
// };

// export const handleCloudFileValidation = (fileUrl) => {
// 	const inputFileName = fileUrl.substring(fileUrl.lastIndexOf('/') + 1);
// 	const result = checkInputFileExtension(inputFileName);
// 	return result;
// };

// const checkInputFileExtension = (fileName) => {
// 	if (!fileName.match(/\.(json)$/)) {
// 		return false;
// 	} else {
// 		return true;
// 	}
// };

// export const FileErrorComponent = (props) => {	
// 	return (
// 		<Snackbar open={isValid} autoHideDuration={6000}  anchorOrigin={{ vertical: 'top', horizontal: 'center' }}>
// 			<Alert variant='filled' severity='error' onClose={() => handleClose()}>
// 				<strong>{errorMessage}</strong>
// 			</Alert>
// 		</Snackbar>
// 	);
// };


/* eslint-disable react/prop-types */
import React from 'react';
import Alert from '@mui/material/Alert';
import Snackbar from '@mui/material/Snackbar';

export const handleFileValidation = (inputFile) => {
    const inputFileName = inputFile.target.files[0].name;
    const result = checkInputFileExtension(inputFileName);
    return result;
};

export const handleDropFileValidation = (inputFile) => {
    const inputFileName = inputFile.path;
    const result = checkInputFileExtension(inputFileName);
    return result;
};

export const handleCloudFileValidation = (fileUrl) => {
    const inputFileName = fileUrl.substring(fileUrl.lastIndexOf('/') + 1);
    const result = checkInputFileExtension(inputFileName);
    return result;
};

const checkInputFileExtension = (fileName) => {
    if (!fileName.match(/\.(json)$/)) {
        return false;
    } else {
        return true;
    }
};

export const FileErrorComponent = ({ isValid, errorMessage, handleClose }) => { 
    return (
        <Snackbar open={!isValid} autoHideDuration={6000}  anchorOrigin={{ vertical: 'top', horizontal: 'center' }}>
            <Alert variant='filled' severity='error' onClose={handleClose}>
                <strong>{errorMessage}</strong>
            </Alert>
        </Snackbar>
    );
};
