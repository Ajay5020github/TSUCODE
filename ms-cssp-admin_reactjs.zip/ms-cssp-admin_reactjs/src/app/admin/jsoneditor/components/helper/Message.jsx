/* eslint-disable react/prop-types */
import React from 'react';
import makeStyles from '@mui/styles/makeStyles';
import MuiAlert from '@mui/material/Alert';
import Snackbar from '@mui/material/Snackbar';
const useStyles = makeStyles((theme) => ({
	root: {
		'width': '100%',
		'& > * + *': {
			marginTop: theme.spacing(2)
		}
	},
	alertRadius: {
		'borderRadius': 0,
		'backgroundColor': '#f23f2e',
		'color': '#ffffff',
		'& .MuiAlert-icon': {
			color: '#ffffff'
		}
	}
}));
export const ErrorMessage = ({ errorMessage }) => {
	const classes = useStyles();
	return (
		<Alert severity="error" className={classes.alertRadius}>
			{errorMessage}
		</Alert>
	);
};

const Alert = (props) => {
	return <MuiAlert elevation={6} variant='filled' {...props} />;
};

export const SuccessMessage = ({ openAlertbar, successMessage, vertical, horizontal, handleCloseSuccess }) => {

	return (
		<Snackbar
			anchorOrigin={{ vertical, horizontal }}
			open={openAlertbar}
			autoHideDuration={1000}
			key={vertical + horizontal}
			onClose={() => handleCloseSuccess()}
		>
			<Alert severity="info" onClose={() => handleCloseSuccess()}>
				{successMessage}
			</Alert>
		</Snackbar>
	);
};
