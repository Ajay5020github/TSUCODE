import React from 'react';
// import { makeStyles } from '@mui/material/styles';
import { makeStyles } from 'tss-react/mui';
// import { Alert, AlertTitle } from '@mui/lab';
import Alert from '@mui/material/Alert';

const useStyles = makeStyles((theme) => ({
	root: {
		'width': '100%',
		'& > * + *': {
			marginTop: theme.spacing(2)
		}
	},
	alertRadius: {
		'borderRadius': 0,
		'backgroundColor': '#fff',
		'color': '#C92500',
		'border': '1px solid #C92500',
		'marginBottom': '30px',
		'fontSize' : '15px',
		'fontWeight':'bold',
	}
}));

/* istanbul ignore next */
export const ErrorMessage = ({ errorMessage }) => {
	const classes = useStyles();
	return (
		<Alert severity="error" icon={false} className={classes.alertRadius}>
			{errorMessage}
		</Alert>
	);
};
