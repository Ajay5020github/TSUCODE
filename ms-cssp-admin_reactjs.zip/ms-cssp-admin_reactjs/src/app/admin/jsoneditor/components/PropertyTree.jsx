"use client"

import React, {useState} from 'react';

import { Grid2, Paper } from '@mui/material';
import { makeStyles } from '@mui/styles';
import { alpha } from '@mui/material/styles';
import { ThemeProvider } from '@mui/system';
// import makeStyles


import NodeUpdate from './NodeUpdate';

import { jsonBuilderTheme } from '../themes/JsonBuilderTheme';

const useStyles = makeStyles({
	root: {
		width: '100%',
		backgroundColor: jsonBuilderTheme.palette.propertyTreeRoot.main,
		minHeight:'50px'
	},
	paper: {
		marginRight: jsonBuilderTheme.spacing(0),
		width: 'auto',
		minHeight: '200px',
		backgroundColor: jsonBuilderTheme.palette.editorPaper.main,
		borderRadius: '0px'
	},
	textbox: {
		backgroundColor: jsonBuilderTheme.palette.textboxPropertyTree.main,
		disableRipple: true
	},
	file: {
		display: 'none'
	},
	searchInput: {
		'opacity': '0.6',
		'padding': '0px 8px',
		'fontSize': '0.8rem',
		'&:hover': {
			backgroundColor: jsonBuilderTheme.palette.searchInputPropertyTree.main
		},
		'& .MuiSvgIcon-root' : {
			marginLeft: '5px'
		}
	},
	disableSave : {
		cursor: 'not-allowed',
		pointerEvents: 'none'
	},
	search: {
		'position': 'relative',
		'borderRadius': jsonBuilderTheme.shape.borderRadius,
		'backgroundColor': alpha(jsonBuilderTheme.palette.common.white, 0.15),
		'&:hover': {
			backgroundColor: alpha(jsonBuilderTheme.palette.common.white, 0.25)
		},
		'marginRight': jsonBuilderTheme.spacing(2),
		'marginLeft': 0,
		'width': '100%',
		[jsonBuilderTheme.breakpoints.up('sm')]: {
			marginLeft: jsonBuilderTheme.spacing(3),
			width: 'auto'
		}
	},
	searchIcon: {
		padding: jsonBuilderTheme.spacing(0, 2),
		height: '100%',
		position: 'absolute',
		pointerEvents: 'none',
		display: 'flex',
		alignItems: 'center',
		justifyContent: 'center'
	},
	inputRoot: {
		color: 'inherit'
	},
	inputInput: {
		padding: jsonBuilderTheme.spacing(1, 1, 1, 0),
		// vertical padding + font size from searchIcon
		paddingLeft: `calc(1em + ${jsonBuilderTheme.spacing(4)}px)`,
		transition: jsonBuilderTheme.transitions.create('width'),
		width: '100%',
		[jsonBuilderTheme.breakpoints.up('md')]: {
			width: '20ch'
		}
	},
	customWidth: {
		width: '100%'
	}
});

const PropertyTree = ({selectedJSON}) => {

	const classes = useStyles();
	const [expand, setExpand] = useState(true);
	const [searchTerm, setSearchTerm] = useState();

	const [sortJSON, setSortJSON] = useState(true);
	const [sortDirection, setSortDirection] = useState('');

	const handleExpand = () => {
		if (expand === false){
			setExpand(!expand);
		}else if (expand === true){
			setExpand(false);
		}
	};

	const sortBykey = () => {

		if (sortJSON === true)
		{
			setSortDirection('Ascending');
			setSortJSON(false);
		}
		else if (sortJSON === false)
		{
			setSortJSON(true);
			setSortDirection('Descending');
		}
	};

	const searchData = e => {
		setSearchTerm(e.target.value);
	};

	return (

		<ThemeProvider theme={jsonBuilderTheme}>
			<div >
				<Paper variant='elevation' className={classes.paper}>
					<Grid2 container alignItems='center'>
						<Grid2 item xs={12} >
							
							<NodeUpdate data={selectedJSON} expand={expand} searchTerm={searchTerm} sortDirection={sortDirection}></NodeUpdate>
						</Grid2>
					</Grid2>
				</Paper>
			</div>
		</ThemeProvider>
	);
};

export default PropertyTree;
