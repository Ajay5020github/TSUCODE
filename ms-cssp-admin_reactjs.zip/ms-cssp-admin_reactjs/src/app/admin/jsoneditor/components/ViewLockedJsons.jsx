"use client"

import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import makeStyles from '@mui/styles/makeStyles';
import withStyles from '@mui/styles/withStyles';
import IconButton from '@mui/material/IconButton';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import MuiDialogTitle from '@mui/material/DialogTitle';
import MuiDialogContent from '@mui/material/DialogContent';
import MuiDialogActions from '@mui/material/DialogActions';
import CloseIcon from '@mui/icons-material/Close';
import { fetchLockedFiles } from '../../services/ConfigurePublisherService';
import Storage from '../../utils/storage';


const useStyles = makeStyles({
	table: {
		width: '100%',
		backgroundColor: '#FFFFFF',
		boxShadow: '0px 3px 15px #00000029',
		opacity: 1,
		margin: '0px',
		//tableLayout: 'fixed'
	},
	tableHead: {
		backgroundColor: '#00837b',
		boxShadow: '0px 3px 6px #00000029',
		opacity: 1
	},
	tableWrap: {
		minWidth: 600,
		border: '1px solid #AAAFB9'
	},
	tableContainerClass: {
		width: '100%',
		overflowX: 'hidden',
		maxHeight: '400px'
	},
	cellRow: {
		border: '1px solid #AAAFB9',
	},
	cellDisplayProperty: {
		textAlign: 'left',
		font: 'normal 18px Open Sans',
		letterSpacing: '0px'
	},
	headerTableCell: {
		color: '#F4F4F4',
		fontWeight: 'bold',
		backgroundColor: '#147120'
	},
	rowTableCell: {
		color: '#000000',
		borderBottom: '1px solid #AAAFB9',
		wordBreak: 'break-word'
	},
	dialogTitleClass: {
		textAlign: 'left',
		font: 'bold 30px Open Sans',
		letterSpacing: '0px',
		color: '#274463',
		opacity: 1
	},
	bottomCloseButtonClass: {
		margin: '10px 15px 11px 11px',
		backgroundColor: '#FFFFFF',
		border: '1px solid #274463',
		borderRadius: '3px',
		textAlign: 'center',
		font: 'bold 16px Open Sans',
		letterSpacing: '0px',
		color: '#274463',
	},
	svnExport: {
		width: '30px',
		height: '30px',
	},
	dialogBox: {
		minWidth: '85%',
		borderRadius: '3px',
		fontFamily: 'Open Sans',
		boxShadow: '0px 0px 18px #00000036',
	},
	notDataText: {
		textAlign: "center",
		fontSize: "23px",
		fontFamily: 'Open Sans',
	},
	historyWrap: {
		display: 'flex',
		flexDirection: 'column',
		paddingTop: 10,
		paddingBottom: 10,
		marginBottom: '5px',
	},
	historyRowWrap: {
		display: 'flex',
		fontSize: '15px',
		fontFamily: 'Open Sans',
		marginLeft: '15px',
	},
	historyRow: {
		width: '30%',
	},
	rowFirstSpan: {
		marginRight: 5
	},
	historyRowTitle: {
		width: '27%'
	},
	historyRowAlias: {
		width: '20%'
	},
	historyRowUser: {
		width: '26%'
	},
	historyRowDept: {
		width: '15%'
	},
	historyRowEmail: {
		width: '45%'
	}
});
//dialog
const styles = (theme) => ({
	root: {
		margin: 0,
		padding: '27px  10px 10px 17px'
	},
	closeButton: {
		position: 'absolute',
		right: '10px',
		top: '20px',
		color: '#274463',
		padding: '15px'		
	},
});

const DialogTitle = withStyles(styles)((props) => {
	const { children, classes, onClose, ...other } = props;
	return (
        (<MuiDialogTitle disableTypography sx = {{ margin: 0, padding: '27px  10px 10px 17px' }} {...other}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
				<IconButton
                    aria-label="close"
                    sx = {{ position: 'absolute', right: '10px', top: '20px', color: '#274463', padding: '15px' }}
                    onClick={onClose}
                    size="large">
					<CloseIcon />
				</IconButton>
			) : null}
        </MuiDialogTitle>)
    );
});

const DialogContent = withStyles((theme) => ({
	root: {
		padding: '15px'
	},
}))(MuiDialogContent);


function Row(props) {
	const { row, srno} = props;
	const classes = useStyles();

	return (

		<React.Fragment>
			<TableRow sx = {{ border: '1px solid #AAAFB9' }}>
				<TableCell sx = {{ color: '#000000', borderBottom: '1px solid #AAAFB9', wordBreak: 'break-word', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} component="th" scope="row">
					{srno}
				</TableCell>
				<TableCell sx = {{ color: '#000000', borderBottom: '1px solid #AAAFB9', wordBreak: 'break-word', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} component="th" scope="row">
					{row.screenName}
				</TableCell>
				<TableCell sx = {{ color: '#000000', borderBottom: '1px solid #AAAFB9', wordBreak: 'break-word', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} align="right">{row.language}</TableCell>
				<TableCell sx = {{ color: '#000000', borderBottom: '1px solid #AAAFB9', wordBreak: 'break-word', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} align="right">{row.time}</TableCell>
			</TableRow>
		</React.Fragment>
	);
}

Row.propTypes = {
	row: PropTypes.shape({
		fileName: PropTypes.string.fileName,
		language: PropTypes.string.language,
		date: PropTypes.string.isRequired,
		time: PropTypes.string.isRequired,
		screenName: PropTypes.string.screenName,
		comments: PropTypes.string.comments,
		lastSavedDateTime: PropTypes.string.lastSavedDateTime,
	}).isRequired,
};

const ViewLockedJsonFiles = ({ lockedJsonFilesDialog, handleCloseLockedJsonFiles, messages, viewLockedJsons }) => {
	
	const classes = useStyles();
	const [open, setOpen] = React.useState(lockedJsonFilesDialog);
	const [noData, setNoData] = useState(false);
	const [message, setMessage] = useState("");
	const [tableRowData, setTableRowData] = useState([]);
	const userName = Storage.getItem('adminUserId'); 

	/* istanbul ignore next */
	const handleClose = () => {
		handleCloseLockedJsonFiles(false)
		setOpen(false);
	};

	/* istanbul ignore next */
	const DialogActions = withStyles((theme) => ({
		root: {
			margin: 0,
			padding: theme.spacing(1),
		},
	}))(MuiDialogActions);

	/* istanbul ignore next */
	const submitfetchLockedJsonsInput = () => {
		const fetchInput = {
			"userId": userName
		}
		fetchViewLockedJsonsAPI(fetchInput);
	}

	/* istanbul ignore next */
	const convertToDateTime = (timeStamp) => {
		let dateTime = new Date(timeStamp);
		//let date = dateTime.toLocaleDateString();
		//let time = dateTime.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', });
		let time = dateTime.toLocaleTimeString('en-US', { timeZone: 'America/New_York', month: '2-digit', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });		
		return time;
	}

	/* istanbul ignore next */
	const fetchViewLockedJsonsAPI = (fetchViewLockedInput) => {
		
		fetchLockedFiles(fetchViewLockedInput).then(response => {
			
			if (response.statusCode !== undefined && response.statusCode == 200 && response.success === true) {

				if (Object.keys(response.body.lockedFiles).length !== 0) {
					setTableRowData(response.body.lockedFiles);
				} else {
					setNoData(true);
					setMessage(messages && messages.MSG013)
				}

				// try { window.appInsights.trackEvent('Admin - View Locked JSON', { 'pageName': "Configuration Publisher" }, { 'adminUserId': Storage.getItem('adminUserId')  }); }
				// catch { }
				
			} else {
				setNoData(true);
				setMessage(messages && messages.MSG013)
			}
		})
	}

	useEffect(() => {
		if (lockedJsonFilesDialog) {
			submitfetchLockedJsonsInput();
		}
	}, [lockedJsonFilesDialog]);

	return (
		<div>
			<Dialog fullWidth onClose={handleClose} open={open}
				classes={{ paperWidthSm: classes.dialogBox }}
				className='Lockedjsonpopup'
			>
				<DialogTitle id="customized-dialog-title" onClose={handleClose}>
					<span className={classes.dialogTitleClass}>{viewLockedJsons.labels && viewLockedJsons.labels.viewLockedJson}</span>
				</DialogTitle>
				<>
					<DialogContent className={classes.dialogContainerClass}					
						sx={{
							maxHeight: "80vh", // Prevents height restriction
							overflow: "hidden", // Prevents double scrolling issues
						}}>
						{!noData && Object.keys(tableRowData).length > 0 && 
						<TableContainer className={classes.tableContainerClass}
							sx={{
								overflow: "auto", // Prevents vertical scrollbar
								maxHeight: "60vh",  // Ensures it does not limit height artificially
							}}>						
							<Table style={{ width: '100%' }} 
								sx={{ minWidth: 600, border: '1px solid #AAAFB9', tableLayout: "fixed" }} 
								aria-label="collapsible table sticky table" stickyHeader>
									<TableHead sx = {{ backgroundColor: '#00837b', boxShadow: '0px 3px 6px #00000029', opacity: 1 }} >
										<TableRow className={classes.tableRow}>
											<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }}>{viewLockedJsons.labels && viewLockedJsons.labels.srNo}</TableCell>
											<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }}>{viewLockedJsons.labels && viewLockedJsons.labels.screenName}</TableCell>
											<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }}>{viewLockedJsons.labels && viewLockedJsons.labels.language}</TableCell>
											<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }}>{viewLockedJsons.labels && viewLockedJsons.labels.lastSavedTime}</TableCell>
										</TableRow>
									</TableHead>
									<TableBody className={classes.tableBody}>
										{tableRowData.map((row, index) => {
											let lockedJsonTime = convertToDateTime(row.lastSavedDateTime);
											row['time'] = lockedJsonTime;
											return <Row key={index} row={row} srno={index+1} />
										})}
									</TableBody>
							</Table>							
						</TableContainer>
						}
						{noData && message && <div className={classes.notDataText}>{message}</div>}
					</DialogContent>
					<DialogActions style={{ margin: '0 10px 0 0' }}>
						<Button sx={{
								margin: '10px 15px 11px 11px',
								backgroundColor: '#FFFFFF',
								border: '1px solid #274463',
								borderRadius: '3px',
								textAlign: 'center',
								font: 'bold 16px Open Sans',
								letterSpacing: '0px',
								color: '#274463',
							}} autoFocus onClick={handleClose} >
							{viewLockedJsons.buttons && viewLockedJsons.buttons.config && viewLockedJsons.buttons.config.close}
						</Button>
					</DialogActions>
				</>
			</Dialog>
		</div>
	);
}
export default ViewLockedJsonFiles
