"use client"
import React, { useState, useEffect, useCallback } from 'react';
import { useSelector, useDispatch, useStore } from 'react-redux';
import { AppBar, Toolbar, IconButton, Grid2, Typography } from '@mui/material';

// Sub-components for each menu items
import OpenFromCloud from './OpenFromCloud';
import SaveToDatabase from '../components/SaveToDatabase';
import RevertFromDatabase from './RevertFromDatabase';
import Publish from './Publish';
import ViewLog from './ViewLog';
import ViewLockedJsons from './ViewLockedJsons';
/* eslint-disable react/prop-types */
import { jsonBuilderTheme } from '../themes/JsonBuilderTheme';
import { ThemeProvider } from '@mui/system';
import makeStyles from '@mui/styles/makeStyles';

// Helper
import { FileErrorComponent } from './helper/InputFileValidationHelper';
import { fetch_json_success, save_temp_json, save_json_schema_status } from '../actions';
import { ValidateJsonSchema } from '../utility/index';
import Storage from '../../utils/storage';

const useStyles = makeStyles({
    root: {
        transform: 'translateZ(0)',
        background: jsonBuilderTheme.palette.header.main,
        color: jsonBuilderTheme.palette.header.contrastText   // 454749    // 325C05
    },
    toolbar: {
        minHeight: '40px'
    },
    paper: {
        marginRight: jsonBuilderTheme.spacing(2)
    },
    file: {
        display: 'none'
    },
    iconButtonHeader: {
        padding: '3px 8px 3px 0',
        borderRadius: 0,
    },
    fontSizeHeader: { fontSize: '18px' },
    searchInput: {
        'opacity': '0.6',
        'padding': '0px 8px',
        'fontSize': '0.8rem',
        '&:hover': {
            backgroundColor: 'lightgrey'
        },
        '& .MuiSvgIcon-root': {
            marginLeft: '5px'
        }
    },
    disableSave: {
        cursor: 'not-allowed',
        pointerEvents: 'none'
    },
    SnackbarDiv: {
        maxWidth: '600px'
    },
    open: {
        width: '54px',
        height: '45px'
    },
    Save: {
        width: '48px',
        height: '42px'
    },
    Revert: {
        width: '45px',
        height: '38px'
    },
    Logs: {
        width: '28px',
        height: '32px',
        marginLeft: '5px'
    },
    LockOpen: {
        width: 25,
        marginTop: 2,
        marginRight: 5,
    },
    LogOpen: {
        width: '41px',
        height: '39px',
        marginLeft: '5px'
    },
    Publish: {
        width: '51px',
        height: '42px'
    }
});

export default function Header(props) {
    const classes = useStyles();
    const dispatch = useDispatch();
    const store = useStore();
    
    const currentState = useSelector(state => state?.jsonReducer?.present);
    const currentNodeState = useSelector(state => state.selectedNodeReducer);
    const currentStateJsonData = useSelector(state => state?.jsonReducer?.present?.jsonData);
    const currentUpdatedState = useSelector(state => state?.updatedJsonReducer);

    const [openFileDialog, setOpenFileDialog] = useState(false);
    const [saveFileDialog, setSaveFileDialog] = useState(false);
    const [revertFileDialog, setRevertFileDialog] = useState(false);
    const [publishDialog, setPublishDialog] = useState(false);
    const [jsonLogDialog, setJSONLogDialog] = useState(false);
    const [lockedJsonFilesDialog, setLockedJsonFilesDialog] = useState(false);

    const fileName = Storage.getItem('fileName');

    const handleOpenDialog = () => setOpenFileDialog(true);
    const handleCloseFileDialog = () => setOpenFileDialog(false);
    const handleSaveFileToDatabase = () => setSaveFileDialog(true);
    const handleCloseSaveFile = () => setSaveFileDialog(false);
    const handleRevertFromDatabase = () => setRevertFileDialog(true);
    const handleCloseRevertFile = () => setRevertFileDialog(false);
    const handlePublish = () => setPublishDialog(true);
    const handleClosePublish = () => setPublishDialog(false);
    const handleJSONLog = () => setJSONLogDialog(true);
    const handleCloseJSONLog = () => setJSONLogDialog(false);
    const handleLockedJsonFiles = () => setLockedJsonFilesDialog(true);
    const handleCloseLockedJsonFiles = () => setLockedJsonFilesDialog(false);

    return (  
        <ThemeProvider theme={jsonBuilderTheme}>
            <AppBar position='static' sx = {{ transform: 'translateZ(0)', background: jsonBuilderTheme.palette.header.main, color: jsonBuilderTheme.palette.header.contrastText }}>
                <Toolbar sx={{ width: "100vw", maxWidth: "100%", backgroundColor: jsonBuilderTheme.palette.secondary.main }}>                    
                    <Grid2 container alignItems='center' 
                        justifyContent={"flex-end"}
                        sx={{ width: "100vw", maxWidth: "100%",  backgroundColor: jsonBuilderTheme.palette.secondary.main }}>
                        <Grid2 item xs={3} sx={{ marginRight: 'auto' }}>{fileName}</Grid2>
                        <Grid2 item>
                            <IconButton style={{ padding: '3px 8px 3px 0', borderRadius: 0, }} size="large">
                                <img src='/src/assets/images/iconslock.png' title={props.publishLabelData && props.publishLabelData.formMessages && props.publishLabelData.formMessages.MSG001} style = {{ width: 25, marginTop: 2, marginRight: 5 }} onClick={handleLockedJsonFiles} />
                                {lockedJsonFilesDialog && <ViewLockedJsons
                                    lockedJsonFilesDialog={lockedJsonFilesDialog}
                                    handleCloseLockedJsonFiles={handleCloseLockedJsonFiles}
                                    messages={props.publishLabelData && props.publishLabelData.formMessages}
                                    viewLockedJsons={props.publishLabelData && props.publishLabelData.content && props.publishLabelData.content.viewlockedjson.config}

                                />}
                            </IconButton>
                        </Grid2>
                        <Grid2 item>
                            
                            <IconButton style={{ padding: '3px 8px 3px 0', borderRadius: 0, }} size="large">
                                <img src="/src/assets/images/open_from_blob.png" title={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config.openButton} style={{ width: '54px', height: '45px' }}         onClick={handleOpenDialog} />
                                {openFileDialog && <OpenFromCloud
                                    openFileDialog={openFileDialog}
                                    handleCloseFileDialog={handleCloseFileDialog}
                                    labels={props.publishLabelData.content && props.publishLabelData.content.labels && props.publishLabelData.content.labels.config}
                                    messages={props.publishLabelData && props.publishLabelData.formMessages}
                                    errors={props.publishLabelData && props.publishLabelData.errorMessages}
                                    buttons={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config}
                                />}
                            </IconButton>
                        </Grid2>
                        <Grid2 item>
                            <IconButton style={{ padding: '3px 8px 3px 0', borderRadius: 0, }} size="large">
                                {(currentNodeState.nodeSelected || currentUpdatedState.updated || currentState.jsonView === true) ? <img src="/src/assets/images/save_db_active.png" title={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config.saveButton} style = {{ width: '48px',height: '42px' }} onClick={handleSaveFileToDatabase} />
                                    : <img src="/src/assets/images/save_db.png" title={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config.saveButton} style = {{ width: '48px',height: '42px' }} />}
                                {saveFileDialog && <SaveToDatabase
                                    saveFileDialog={saveFileDialog}
                                    handleCloseSaveFile={handleCloseSaveFile}
                                    labels={props.publishLabelData.content && props.publishLabelData.content.labels && props.publishLabelData.content.labels.config}

                                    buttons={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config}
                                />}

                            </IconButton>
                        </Grid2>
                        <Grid2 item>
                            <IconButton style={{ padding: '3px 8px 3px 0', borderRadius: 0, }} size="large">
                                {Object.keys(currentState.jsonData).length > 2 || currentUpdatedState.updated || currentState.jsonView ?
                                    <img src="/src/assets/images/revert_active.png" title={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config.revertButton} style = {{ width: '45px', height: '38px' }} onClick={handleRevertFromDatabase} />
                                    : <img src="/src/assets/images/revert.png" title={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config.revertButton} style = {{ width: '45px', height: '38px' }} />
                                }
                                {revertFileDialog && <RevertFromDatabase
                                    revertFileDialog={revertFileDialog}
                                    handleCloseRevertFile={handleCloseRevertFile}
                                    labels={props.publishLabelData.content && props.publishLabelData.content.labels && props.publishLabelData.content.labels.config}
                                    messages={props.publishLabelData && props.publishLabelData.formMessages}
                                    errors={props.publishLabelData && props.publishLabelData.errorMessages}
                                    buttons={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config}
                                />}
                            </IconButton>
                        </Grid2>
                        <Grid2 item>
                            <IconButton style={{ padding: '3px 8px 3px 0', borderRadius: 0, }} size="large">
                                {currentUpdatedState.jsonSaved ? <img src="/src/assets/images/publish_to_blob_active.png" title={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config.publishButton} style = {{ width: '51px',height: '42px' }} onClick={handlePublish} />
                                    : <img src="/src/assets/images/publish_to_blob.png" title={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config.publishButton} style = {{ width: '51px',height: '42px' }} />}
                                {publishDialog && <Publish
                                    publishDialog={publishDialog}
                                    handleClosePublish={handleClosePublish}
                                    labels={props.publishLabelData.content && props.publishLabelData.content.labels && props.publishLabelData.content.labels.config}
                                    configPublishTitle={props.publishLabelData && props.publishLabelData.pageName}
                                    buttons={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config}
                                />}
                            </IconButton>
                        </Grid2>
                        <Grid2 item>
                            <IconButton style={{ padding: '3px 8px 3px 0', borderRadius: 0, }} size="large">
                                {Object.keys(currentState.jsonData).length > 2 || currentState.jsonView === true ?
                                    <img src="/src/assets/images/view_log_active.png" title={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config.logsButton} style = {{ width: '41px', height: '39px', marginLeft: '5px' }} onClick={handleJSONLog} />
                                    : <img src="/src/assets/images/view_log.png" title={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config.logsButton} style = {{ width: '28px', height: '32px', marginLeft: '5px' }}
                                         />
                                }
                                {jsonLogDialog && <ViewLog
                                    jsonLogDialog={jsonLogDialog}
                                    handleCloseJSONLog={handleCloseJSONLog}
                                    labels={props.publishLabelData.content && props.publishLabelData.content.labels && props.publishLabelData.content.labels.config}
                                    messages={props.publishLabelData && props.publishLabelData.formMessages}
                                    viewLogs={props.publishLabelData && props.publishLabelData.content && props.publishLabelData.content.logview.config}
                                    buttons={props.publishLabelData.content && props.publishLabelData.content.buttons && props.publishLabelData.content.buttons.config}
                                />}
                            </IconButton>
                        </Grid2>
                    </Grid2>
                </Toolbar>
            </AppBar>
        </ThemeProvider>       
    );
}
