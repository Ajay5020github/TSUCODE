"use client"

import React, { useState , useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { simplify, desimplify } from '../../utils/simplifr';

import makeStyles from '@mui/styles/makeStyles';
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Collapse from "@mui/material/Collapse";

import ChevronRight from "@mui/icons-material/ChevronRight";
import { Typography } from "@mui/material";

import { RemoveParentId, searchObject, uuidv4 } from '../components/helper/helper';
// import { setSelectedNode } from '../reducers/selectedNodeReducer';
import { selected_node_json } from '../selectedNodeActions';

import { jsonBuilderTheme } from '../themes/JsonBuilderTheme';
import { ThemeProvider } from '@mui/system';

const useStyles = makeStyles({
	root: {
		width: '100%',
		maxWidth: 360,
		backgroundColor: jsonBuilderTheme.palette.background.paper
	},
	nested: {
		padding: `0px ${jsonBuilderTheme.spacing(3)}`
	},
	listItem: {
		padding: 0
	},
	listItemText: {
		flex: '0 1 auto'
	},
	body1: {
		fontWeight: 'bold'
	},
	listIcon: {
		minWidth: 'unset',
		color: '#ff6464'
	},
	paper: {
		borderColor: 'E7EFEB !important',
		backgroundColor: 'transparent'
	},
	paper2: {
		textAlign: 'center',
		backgroundColor: 'transparent'
	},
	bold: {
		fontWeight: 600
	},
	selectedNode: {
		color: 'blue',
		[jsonBuilderTheme.breakpoints.down(1000)]: {
			fontSize: '11px'
		}
	},
	normalKey: {
		color: '',
		backgroundColor: ''
	},
	selectedKey: {
		color: '#fff',
		backgroundColor: '#55585A'
	},
	treeList:{
		[jsonBuilderTheme.breakpoints.down(1000)]: {
			'& span': { fontSize: '15px'}
		}
	},
	treeIcon:{
		[jsonBuilderTheme.breakpoints.down(1000)]: {
			fontSize: '20px'
		}
	},
	treeCollapse: {
		paddingLeft: '30px',
		[jsonBuilderTheme.breakpoints.down(1000)]: {
			paddingLeft: '15px'
		}
	},
	editedNode: {
		color: 'red'
	}
});

const ShowNodes = ({ data, parentName, selectedId , parentID}) => {
	return (
		<TreeOther
			key={Math.random()}
			data={data}
			parentName={parentName}
			selectedId={selectedId}
			parentID={parentID}
		/>
	);
};

export const initialMenuState = {
	mouseX: null,
	mouseY: null,
};

const TreeOther = (({
	data,
	parentName = 'Root: []',
	selectedId = null,
	parentID = null
}) => {
	const classes = useStyles();
	const dispatch = useDispatch();

	const [open, setOpen] = useState(false);
	const [clickedObject, setClickedObject] = useState('');
	const currentState = useSelector(state => state.jsonReducer.present);

	

	const handleClick = () => {
		
		var Clickedelement = document.getElementById(data.$ID);
		
		
		// document.querySelectorAll('.MuiListItemText-root').forEach((node) =>
		// {
		// 	if (Clickedelement != null) {
		// 		if (node === Clickedelement.querySelector('.MuiListItemText-root'))
		// 		{
		// 			node.style.color = '#fff';
		// 			node.style.backgroundColor = '#55585A';
		// 		}
		// 		else
		// 		{
		// 			node.style.color = '';
		// 			node.style.backgroundColor = '';
		// 		}
		// 	}
		// });

		setClickedObject(data.$ID);
		let returnedData = undefined;
		let childObjectExists = false;
		if (parentName !== 'Root: []')
		{
			// Loads Right side panel on every click
			returnedData = dispatch(selected_node_json(data), false);

						
			Object.keys(returnedData).some(function (k) {				
				if (typeof returnedData[k] === 'object') {
					
					try {
						returnedData[k].map(function (innerKey) {
							childObjectExists = true;							
							setOpen(!open);
						});
					}
					catch (err) {
						// Do Nothing						
						Object.keys(returnedData).some(function (k) {
							childObjectExists = true;
							setOpen(!open);
						});
						
					}
				}
			});

			if (childObjectExists === false)
			{ 
				setOpen(true);
			}
			
		}
		else if (parentName === 'Root: []')
		{
			if (Object.keys(data).length > 2)
			{
				returnedData = dispatch(selected_node_json(data), false);				

				Object.keys(returnedData).some(function (k) {				
					if (typeof returnedData[k] === 'object') {
						try {
							returnedData[k].some(function (innerKey) {
								childObjectExists = true;							
								setOpen(!open);
							});
						}
						catch {							
							// Do Nothing						
							Object.keys(returnedData).some(function (k) {		
								childObjectExists = true;
								setOpen(!open);
							});
						}
					}
				});				

				if (childObjectExists === false)
				{ 
					setOpen(true);
				}
			}
		}
	};

	useEffect(() => {
		if (parentName === 'Root: []')
		{
			handleClick();			
		}		
	}, []);
	
	return (
	  <>
	  	<ThemeProvider theme={jsonBuilderTheme}>
			{data && (
			
					<ListItem
						button
						onClick={handleClick}
						id={selectedId}
						classes={{ root: classes.listItem }}
					>
						<ListItemIcon
						key={Math.random() * 10}
						classes={{ root: classes.listIcon }}
						>
							{parentName !== 'Root: []' && Object.keys(data).length > 0 ? 
								open ? 
								<img src='/src/assets/images/minus.png' alt='mins' width="18" height="18" /> 
								: <img src='/src/assets/images/plus.png' alt='plus' width="18" height="18" />	
								: parentName === 'Root: []' && Object.keys(data).length > 2 ?
								open ? <img src='/src/assets/images/minus.png' alt='mins' width="18" height="18" /> : <img src='/src/assets/images/plus.png' alt='plus' width="18" height="18" /> : null }
								
						</ListItemIcon>
						&nbsp;
						{/* className={clickedObject === selectedId ? classes.selectedKey : classes.normalKey} */}
						<ListItemText key={Math.random() * 10}>
							<Typography>					
								<b>{parentName !== 'Root: []' && Object.keys(data).length > 0 ? parentName : Object.keys(data).length > 2 ? 'Root: []': null}</b>
							</Typography>
						</ListItemText>
					</ListItem>
				
			)}
			<Collapse
			in={open}
			timeout="auto"
			unmountOnExit
			style={{ paddingLeft: "30px" }}
			>
			<List component="div" style={{ padding: 0 }}>
				{data &&
				Object.keys(data).map((k, i) => {
					return data[k] != null && typeof data[k] === "object" ? (
						(Array.isArray(data[k]) ?
						<>
							{Array.from(data[k]).map((item, index) => (
								<>
									{/* Flow: This is for Array Objects
										1. If there are id, name - concatenate id, name values
										2. If there is a no id, name, check for title value and display it
										3. If there are no id, name, title fields, display node name
									*/}
									{
										data[k][index]['$ID'] && 
										<ShowNodes key={index} item={item} data={data[k][index]} parentID={data[k][index]['id']} parentName={data[k][index]['id'] ? (data[k][index]['name'] ? data[k][index]['name'] +  ' - ' : (k + ' - ')) + data[k][index]['id'] : (data[k][index]['title'] ? k + ' - ' + data[k][index]['title'] : k)} selectedId={data[k][index]['$ID']} />
									
									}
									
								</>
							))}
						</>
						:
						<>
							
							{/* Flow: This is for non-array Objects */}
								
							<TreeOther
								key={Math.random()}
								data={data[k]}
								parentName={Array.isArray(data) ? "" : k}
								length={Object.keys(data[k]).length}
								selectedId={data[k]['$ID']}
							/>
					</>
					)
					) : ''
				})}
			</List>
			</Collapse>
		</ThemeProvider>
	  </>
	);
  })

  export default TreeOther;