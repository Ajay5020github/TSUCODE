"use client"

import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import withStyles from '@mui/styles/withStyles';
import { Box, Button, FormHelperText } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Grid from '@mui/material/Grid';
// import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandMore  from '@mui/icons-material/ExpandMore';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';

import FormGroup from '@mui/material/FormGroup';
// import { fetchJsonSuccess } from '../reducers/jsonReducer';
// import { clearSelectedNode } from '../reducers/selectedNodeReducer';

import { fetch_json_success } from '../actions';
import { clear_selected_node } from '../selectedNodeActions';
import { FileErrorComponent, handleCloudFileValidation } from './helper/InputFileValidationHelper';

import { ErrorMessage } from '../components/helper/ErrorMessage'
// Configure Publiher Service
import { fetchJson, revertJson, readContentJson } from '../../services/ConfigurePublisherService';
import Storage from '../../utils/storage';
import Loader from '../../components/loader/loader';
import { borderColor } from '@mui/system';
const validURL = (str) => {
	const pattern = new RegExp(
		'^(https?:\\/\\/)?' + // protocol
		'((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
		'((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
		'(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
		'(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
		'(\\#[-a-z\\d_]*)?$',
		'i'
	); // fragment locator
	return !!pattern.test(str);
};
const useStyles = makeStyles({
	root: {
		width: '450px',
		//minHeight: '450px',
		borderRadius: '0.3rem',
		fontFamily: 'Open Sans',
		boxShadow: '0px 0px 18px #00000036',
		border: '1px solid rgba(0,0,0,.2)'
	},
	closeButton: {
		position: 'absolute',
		right: '10px',
		top: '10px',
		color: '#274463',
	},
	dialogTitle: {
		color: '#274463',
		fontSize: '30px',
		fontWeight: 'bold',
	},
	formControl: {
		minWidth: 130,
	},
	labelAsterisk: {
		color: '#c92500'
	},
	labelColor: {
		color: '#000',
		'&.Mui-focused': {
			color: '#000 !important'
		}
	},
	btnCancel: {
		backgroundColor: '#fff',
		border: '1px solid #274463',
		marginRight: '20px',
		padding: '10px 18px',
		borderRadius: '3px',
		color: '#274463',
		fontWeight: 'bold',
		textTransform: 'none',
		'&:hover': {
			border: '1px solid #274463'
		},
	},
	btnOK: {
		backgroundColor: '#274463',
		border: '1px solid #274463',
		padding: '10px 48px',
		borderRadius: '3px',
		fontWeight: 'bold',
		textTransform: 'none',
		'&:hover': {
			backgroundColor: '#274463',
			border: '1px solid #274463',
			color: '#fff'
		},
		'&:disabled' : {
			backgroundColor: '#ccc',
    	border: '1px solid transparent',
    	color: '#fff'
		}
	},
	formControlWrap: {
		display: 'flex',
		justifyContent: 'space-between',
		marginTop: '40px'
	},
	formOpen: {
		display: 'flex',
		flexDirection: 'column',
	},
	btnWrap: {
		display: 'flex',
		justifyContent: 'flex-end',
		fontSize: '21px',
		marginTop: '70px',
		fontFamily: 'Open Sans',
		marginBottom: '20px'
	},
	selected: {
		color: '#000',
		backgroundColor: 'transparent',
		'&:focus': {
			color: '#000',
			backgroundColor: 'transparent'
		},
		'&::after': {
			borderBottom: 'red'
		}
	},
	formDemoLanguage: {
		'& div' : {
			'&::after': {
				borderBottom: '1px solid #000'
			}
		}
	},
	dropdownStyle: {
		borderRadius: 0,
		maxHeight: 280,
		'&::-webkit-scrollbar' : {
			width: '8px'
		},
		/* "& ul": {
			  
		}, */
		"& li": {
			fontSize: 14,
		},
	},
	formSelect: {
		fontSize: 14
	}
});

const OpenFromCloud = ({ openFileDialog, handleCloseFileDialog, labels, messages, errors, buttons }) => {

	const dispatch = useDispatch();
	const classes = useStyles();
	const [openDialog, setOpenDialog] = useState(openFileDialog);
	const [value, setValue] = useState(null);
	const [jsonScreenName, setJsonScreenName] = useState('');
	const [jsonScreeNameSelected, setjsonScreeNameSelected] = useState(true);
	const [language, setLanguage] = useState('');
	const [languageSelected, setLanguageSelected] = useState(true);
	const [btnDisabled, setBtnDisabled] = useState(false);
	const [screenName, setScreenName] = useState([]);
	const [screenLanguage, setScreenLanguage] = useState([]);
	// Error State
	const [isValid, setIsValid] = useState(false);
	const [errorMessage, setErrorMessage] = useState('');
	const [screenErrorMessage, setScreenErrorMessage] = useState('');
	const [languageErrorMessage, setLanguageErrorMessage] = useState('');
	const [loading, setLoading] = useState(false);

	// ScreenName and Language
	
	/* let screenName = screenandlanguage.screenName;
	let screenLanguage = screenandlanguage.language; */
	// Handle Error
	/* istanbul ignore next */
	const handleError = (status, errorMsg = '') => {
		setIsValid(status);
		setErrorMessage(errorMsg);
	};

	/* istanbul ignore next */
	const handleClose = (reason) => {
		if (reason === 'clickaway') {
			return;
		}

		setIsValid(false);
	};
	
	// Set Selected Screen Name onchange
	/* istanbul ignore next */
	const handleScreenChange = (event) => {
		if (event.target.value !== '') {
			setBtnDisabled(false);
			handleError(false);
			setJsonScreenName(event.target.value);
			setjsonScreeNameSelected(true);
		}
	}

	// Set Selected language
	/* istanbul ignore next */
	const handleLanguageChange = (event) => {
		if (event.target.value !== '') {
			handleError(false);
			setBtnDisabled(false);
			setLanguage(event.target.value);
			setLanguageSelected(true);
		}
	}

	// Submit Form Data
	/* istanbul ignore next */
	const submitFormData = (event) => {
		event.preventDefault();
	
	
		if (jsonScreenName === '') {
			setjsonScreeNameSelected(false);
			setScreenErrorMessage(errors && errors.EM006);
		}

		if (language === '') {
			setLanguageSelected(false);
			setLanguageErrorMessage(errors && errors.EM007);
		}

		if (jsonScreenName !== '' && language !== '') {
			const fetchJsonData = {
				"jsonScreenName": jsonScreenName,
				"language": language
			};
			fetchJsonFromAPI(fetchJsonData);
		}
	}
	
	/* istanbul ignore next */
	const fetchJsonFromAPI = (fetchJsonInput) => {
		setLoading(true)
	
		fetchJson(fetchJsonInput)
			.then(data => {
				if (data.statusCode === 200 && data.success === true) {

					Storage.setItem('fileName', data.body.fileName);
					Storage.setItem('languageId', data.body.languageId);
					Storage.setItem('screenName', data.body.screenName);

					dispatch(fetch_json_success(data.body.json));
					dispatch(clear_selected_node());
					setLoading(false)
					handleDialogClose();

					// try { window.appInsights.trackEvent('Admin - Open JSON', { 'pageName': "Configuration Publisher" }, { 'adminUserId': Storage.getItem('adminUserId')  }); }
					// catch { }
					
				} else {
					setLoading(false);
					
					if (data.statusCode === 423 && !data.success) {
						
						if(data.body && data.body.message) {
							var lockedMessage = data.body.message.replace('!!!', '');
							lockedMessage = data.body.message.replace('This file', jsonScreenName)
							// var lockedMessage = data.body.message;
							handleError(true, lockedMessage);
						}
						setBtnDisabled(true);
					} 
					else if (data.statusCode === 500) {						
						handleError(true, errors && errors.EM009);
					}
					else 
					{
						handleError(true, data.message);
					}
				}

			})
			.catch((error) =>  { 				
			});
	}

	/* istanbul ignore next */
	const handleDialogClose = () => {
		setOpenDialog(false);
		handleCloseFileDialog(false)
	};

/* 	const handleDialogGo = () => {
		getJsonData(value);
	}; */

	/* istanbul ignore next */
	const handleChange = (e) => {
		setValue(e.target.value);
	};

	useEffect(() => {

		if (openDialog) {
			const fetchLanguageScreen = {
				"jsonScreenName": "enScreenAndLanguage",
				"language": "en"
			};
			readContentJson(fetchLanguageScreen.jsonScreenName).then(response =>  {
				if (response && response.statusCode && response.statusCode === 200) {
					if(response.bodyJSON && response.bodyJSON.data) {
						setScreenLanguage(response.bodyJSON.data.language);
						setScreenName(response.bodyJSON.data.screenName);						
					}
				}
			});
		}	
	}, [openDialog])
	return (
        (<div>
				{openDialog ?
					<>
						<Dialog fullWidth={false}
							id='dialogURL'
							open={openDialog} onClose={handleDialogClose}
							sx = {{ paperWidthSm: { width: '850px', borderRadius: '0.3rem', fontFamily: 'Open Sans', boxShadow: '0px 0px 18px #00000036',border: '1px solid rgba(0,0,0,.2)'} }}
							className='openJsonPopup'
						>
							<DialogTitle id="customized-dialog-title">
								<h6 sx = {{ color: '#274463', fontSize: '30px', fontWeight: 'bold' }}>{labels.openJSONLabel}</h6>
								<IconButton
									aria-label="close"
									sx = {{ position: 'absolute', right: '10px', top: '10px', color: '#274463' }}
									onClick={handleDialogClose}
									size="large">
									<CloseIcon />
								</IconButton>
							</DialogTitle>

							<DialogContent className="open-cloud-dialog">
							
								{errorMessage && <ErrorMessage errorMessage={errorMessage} />}

								<form onSubmit={submitFormData} >
									<FormGroup>
										<FormControl 
											fullWidth 
											sx = {{root: {'& div' : {
															'&::after': {
																borderBottom: '1px solid #000'
															}
														}}}}
											className="formInput" 
											error={!jsonScreeNameSelected} >

											<InputLabel
												required
												sx = {{
													asterisk: {color: '#c92500'},
													root: {color: '#000',
													'&.Mui-focused': {
														color: '#000 !important'
													}}
												}}
												disableAnimation
												htmlFor="demo-scree-name-select" id="demo-scree-name" label="true" 	>{labels.screenNameDropdown}</InputLabel>
											<Select
												labelId="demo-scree-name"
												value={jsonScreenName}
												onChange={handleScreenChange}
												IconComponent={ExpandMore}
												sx = {{ 
													selectMenu: {
														color: '#000',
														backgroundColor: 'transparent',
														'&:focus': {
															color: '#000',
															backgroundColor: 'transparent'
														},
														'&::after': {
															borderBottom: 'red'
														}
													}
												}}
												
												inputProps={{
													name: 'demo-scree-name-select',
													id: 'demo-scree-name-select'
												}}												
												MenuProps={{
													sx: { paper: {
														borderRadius: 0,
														maxHeight: 280,
														'&::-webkit-scrollbar' : {
															width: '8px'
														},
														"& li": {
															fontSize: 14,
														},
													} },
													anchorOrigin: {
														vertical: 'bottom',
														horizontal: 'left'
													},
													transformOrigin: { vertical: 'top', horizontal: 'left' },
													getContentAnchorEl: null
												}}
											>
												{ screenName.length && screenName.map((item) => {													
														return <MenuItem
															value={item.jsonFile.actualName} key={item.jsonFile.displayName} >{item.jsonFile.displayName}</MenuItem>
													})
												}
												
												
											</Select>
											{!jsonScreeNameSelected && 
											<FormHelperText>
												{screenErrorMessage}												
											</FormHelperText>}
										</FormControl>
										<FormControl 
											sx = {{root: {
												'& div' : {
													'&::after': {
														borderBottom: '1px solid #000'
													}
												}
											}}}
											fullWidth className="formInput" error={!languageSelected}>
											<InputLabel
												required
												sx = {{
													asterisk: {
														color: '#c92500'
													},
													root: {
														color: '#000',
														'&.Mui-focused': {
															color: '#000 !important'
														}
													}
												}}
												htmlFor='demo-language-select' id="demo-language" >{labels.languageDropdown}</InputLabel>
											<Select
												labelId="demo-language"
												value={language}
												sx = {{ selectMenu: {
													color: '#000',
													backgroundColor: 'transparent',
													'&:focus': {
														color: '#000',
														backgroundColor: 'transparent'
													},
													'&::after': {
														borderBottom: 'red'
													}
												} }}
												onChange={handleLanguageChange}
												IconComponent={ExpandMore}
												inputProps={{
													name: 'demo-language-select',
													id: 'demo-language-select',
												}}
												MenuProps={{
													sx: { 
														paper: {
															borderRadius: 0,
															maxHeight: 280,
															'&::-webkit-scrollbar' : {
																width: '8px'
															},															
															"& li": {
																fontSize: 14,
															},
														},
													},
													anchorOrigin: {
														vertical: 'bottom',
														horizontal: 'left'
													},
													transformOrigin: { vertical: 'top', horizontal: 'left' },
													getContentAnchorEl: null
												}}
											>
												{
													screenLanguage.map((item) => {
														let languageKey = Object.keys(item)[0];
														let languageVal = item[Object.keys(item)[0]];
														return <MenuItem value={languageVal} key={languageKey}>{languageKey}</MenuItem>
													}) 
												}
											</Select>
											{!languageSelected && 
												<FormHelperText>
													{languageErrorMessage}													
												</FormHelperText>}
										</FormControl>
									</FormGroup>
									<div sx = {{ display: 'flex', justifyContent: 'flex-end', fontSize: '21px', marginTop: '70px', fontFamily: 'Open Sans', marginBottom: '20px' }} className='buttonComp_uploaddoc'>
																											<Button onClick={handleDialogClose} variant='outlined' color="primary" sx = {{
																			backgroundColor: '#fff',
																			border: '1px solid #274463',
																			marginRight: '20px',
																			padding: '10px 18px',
																			borderRadius: '3px',
																			color: '#274463',
																			fontWeight: 'bold',
																			textTransform: 'none',
																			'&:hover': {
																				border: '1px solid #274463'
																			},
																		}}>
											{buttons.cancelButton}
										</Button>
										<Button 
											variant='outlined' 
											color="primary" 
											type="submit" 
											sx = {{
												backgroundColor: '#274463',
												border: '1px solid #274463',
												padding: '10px 48px',
												borderRadius: '3px',
												fontWeight: 'bold',
												textTransform: 'none',
												'&:hover': {
													backgroundColor: '#274463',
													border: '1px solid #274463',
													color: '#fff'
												},
												'&:disabled' : {
													backgroundColor: '#ccc',
												border: '1px solid transparent',
												color: '#fff'
												}
											}} 
											disabled = {btnDisabled}  >
											{buttons.okButton}
										</Button>
									</div>
								</form>

							</DialogContent>
						</Dialog>
					</>
					: null}
        </div>)
    );
};

export default OpenFromCloud;
