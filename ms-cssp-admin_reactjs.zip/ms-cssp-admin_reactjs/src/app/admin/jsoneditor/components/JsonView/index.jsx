"use client"
import React, { useEffect, useState, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid2';
import FormatAlignLeftOutlinedIcon from '@mui/icons-material/FormatAlignLeftOutlined';
import SaveOutlinedIcon from '@mui/icons-material/SaveOutlined';
import makeStyles from '@mui/styles/makeStyles';
import { Tooltip } from '@mui/material';
import { FileErrorComponent } from '../helper/InputFileValidationHelper';
import { SuccessMessage } from '../helper/Message';
import { validateJson, RemoveParentId } from '../helper/helper';
import { not_proper_json, set_temp_json, save_temp_json, json_view_updated_value, set_json_view_value } from '../../actions';
import { save_code_json } from '../../updatedJsonActions';
import { clear_selected_node } from '../../selectedNodeActions';
import { jsonBuilderTheme } from '../../themes/JsonBuilderTheme';
import { ThemeProvider } from '@mui/system';

const useStyles = makeStyles({
    root: {
        flexGrow: 1
    },
    pageContent: {
        margin: jsonBuilderTheme.spacing(1),
        padding: jsonBuilderTheme.spacing(1),
        backgroundColor: jsonBuilderTheme.palette.pageContent.main,
        borderRadius: '0px',
        height: 'calc(100vh - 100px)',
        minHeight: '80px'
    },
    paper: {
        padding: jsonBuilderTheme.spacing(0),
        textAlign: 'center',
        color: jsonBuilderTheme.palette.text.secondary,
        overflow: 'hidden',
        height: 'calc(100vh - 116px)',
        minHeight: '64px',
        elevation: 1,
        backgroundColor: jsonBuilderTheme.palette.editorPaper.main,
        borderRadius: '0px'
    },
    paperHeight: {
        height: '100vh'
    },
    resizeTextArea: {
        width: '100%',
        border: 'none',
        height: 'calc(100vh - 152px)',
        minHeight: '150px',
        resize: 'vertical',
        overflowY: 'auto',
        fontSize: '14px',
        padding: '8px',
        boxSizing: 'border-box'
    },
    toolbar: {
        textAlign: 'left',
        padding: '4px 8px',
        background: '#545454',
        color: '#fff',
        marginBottom: '0px'
    },
    tooltip: {
        marginRight: jsonBuilderTheme.spacing(1),
        cursor: 'pointer'
    }
});

export const JsonView = ({ JsonData }) => {
    const classes = useStyles();

    return (
        <>
            <Paper className={`${classes.pageContent} jsonview_table`} >
                <Grid container spacing={1} className="MuiPaper-root MuiAppBar-root MuiAppBar-positionStatic MuiAppBar-colorPrimary jss7 MuiPaper-elevation4">
                    <Grid item xs={12}>
                        <Paper variant="elevation" className={classes.paper}>
                            <CodeView treeData={JsonData} />
                        </Paper>
                    </Grid>
                </Grid>
            </Paper>
        </>
    );
};

export const CodeView = ({ treeData, replacer = null, space = 2 }) => {
    const classes = useStyles();
    const currentState = useSelector(state => state.jsonReducer.present);
    const currentUpdatedState = useSelector(state => state.updatedJsonReducer);

    const dispatch = useDispatch();

    const [codeView, setCodeView] = useState("");
    const [isInValid, setIsInValid] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    const [state, setState] = useState({
        openSnackbar: false,
        vertical: 'top',
        horizontal: 'center'
    });

    const textAreaRef = useRef(null); // Ref for textarea

    const { vertical, horizontal, openSnackbar } = state;

    const handleTextChange = (e) => {
        const { selectionStart, selectionEnd } = e.target; // Save cursor position
        setCodeView(e.target.value); // Update state

        setTimeout(() => {
            if (textAreaRef.current) {
                textAreaRef.current.selectionStart = selectionStart;
                textAreaRef.current.selectionEnd = selectionEnd;
            }
        }, 0);
    };

    const prettyJson = () => {
        try {
            setCodeView(JSON.stringify(JSON.parse(codeView), replacer, space));
            setIsInValid(false);
            dispatch(json_view_updated_value());
        } catch (error) {
            setIsInValid(true);
            setErrorMessage("Invalid JSON");
        }
    };

    const saveJSON = () => {
        try {
            const jsonData = JSON.parse(codeView);
            dispatch(save_code_json(jsonData));
            dispatch(set_temp_json());
            dispatch(clear_selected_node());
            setState({ openSnackbar: true, vertical: 'top', horizontal: 'center' });
            setSuccessMessage('JSON is saved');
        } catch {
            dispatch(save_temp_json(codeView));
            dispatch(not_proper_json(false));
        }
    };

    useEffect(() => {
        let formattedJson = '';
        const [message] = validateJson(treeData);

        if (currentState.properJSON && currentUpdatedState.updated) {
            treeData = RemoveParentId(JSON.parse(JSON.stringify(currentUpdatedState.updatedJsonData)), '$ID', '$PID');
            formattedJson = JSON.stringify(treeData, null, space);
        } else if (currentState.properJSON) {
            treeData = RemoveParentId(JSON.parse(JSON.stringify(currentState.jsonData)), '$ID', '$PID');
            formattedJson = JSON.stringify(treeData, null, space);
        } else {
            setIsInValid(true);
            setErrorMessage(message);
            formattedJson = treeData;
        }

        setCodeView(formattedJson);
    }, [treeData, currentState, currentUpdatedState, space]);

    return (
        <ThemeProvider theme={jsonBuilderTheme}>
            <>
                <div className={classes.toolbar}>
                    <Tooltip className={classes.tooltip} title="Save JSON">
                        <SaveOutlinedIcon fontSize="small" onClick={saveJSON} />
                    </Tooltip>
                    <Tooltip className={classes.tooltip} title="Format JSON">
                        <FormatAlignLeftOutlinedIcon fontSize="small" onClick={prettyJson} />
                    </Tooltip>
                </div>
                <textarea
                    ref={textAreaRef}
                    value={codeView}
                    onChange={handleTextChange}
                    className={classes.resizeTextArea}
                    placeholder="Upload The File"
                />
                {isInValid && <FileErrorComponent isValid={!isInValid} errorMessage={errorMessage} />}
            </>
        </ThemeProvider>
    );
};
