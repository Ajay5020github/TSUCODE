"use client"

import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, Button } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';

// import { fetchJsonSuccess, clearJsonData } from '../reducers/jsonReducer';
import { fetch_json_success, clear_json } from '../actions';
import { ErrorMessage } from '../components/helper/ErrorMessage'
// Configure Publiher Service
import { revertJson } from '../../services/ConfigurePublisherService';
import Storage from '../../utils/storage';
import MessageFromAPI from './MessageFromAPI';
// import { clearSelectedNode } from '../reducers/selectedNodeReducer';
// import { clearUpdatedJsonData } from '../reducers/updatedJsonReducer';

import { clear_selected_node } from '../selectedNodeActions';
import { clear_updated_json } from '../updatedJsonActions';

// Clear Redux Store after successful revert

const useStyles = makeStyles({
    root: {
        width: '450px',
        //minHeight: '450px',
        borderRadius: '3px',
        fontFamily: 'Open Sans',
        boxShadow: '0px 0px 18px #00000036',
        border: '1px solid rgba(0,0,0,.2)'
    },
    messageDialog : {
        width: '430px',
        borderRadius: '3px',
        minHeight: '330px',
        fontFamily: 'Open Sans',
        boxShadow: '0px 0px 18px #00000036',
    },
    closeButton: {
        position: 'absolute',
        right: '10px',
        top: '10px',
        color: '#274463'
    },
    dialogTitle: {
        color: '#274463',
        fontSize: '30px',
        fontWeight: 'bold',
    },
    btnCancel: {
        backgroundColor: '#fff',
        border: '1px solid #274463',
        marginRight: '20px',
        padding: '10px 18px',
        borderRadius: '3px',
        color: '#274463',
        fontWeight: 'bold',
        textTransform: 'none',
        '&:hover': {
            border: '1px solid #274463'
        },
    },
    btnOK: {
        backgroundColor: '#274463',
        border: '1px solid #274463',
        padding: '10px 48px',
        borderRadius: '3px',
        fontWeight: 'bold',
        textTransform: 'none',
        '&:hover': {
            backgroundColor: '#274463',
            border: '1px solid #274463',
            color: '#fff'
        },
    },
    formControlWrap: {
        display: 'flex',
        justifyContent: 'space-between',
        marginTop: '40px'
    },
    formOpen: {
        display: 'flex',
        flexDirection: 'column',
    },
    btnWrap: {
        display: 'flex',
        justifyContent: 'flex-end',
        fontSize: '21px',
        marginTop: '70px',
        fontFamily: 'Open Sans',
        marginBottom: '20px'
    },
    ContentText: {
        fontSize: '20px',
        color: '#000000',
        margin: '50px auto',
        textAlign: 'left',
        fontWeight: 600
    }
});

const RevertFromDatabase = ({ revertFileDialog, handleCloseRevertFile, labels, messages, errors, buttons}) => {

    const classes = useStyles();
    const currentState = useSelector(state => state.jsonReducer.present);

    const dispatch = useDispatch();

    const [title, setTitle] = useState(labels.revertChangesText);
    const [dialogClasss, setDialogClass] = useState('root')
    const [openDialog, setOpenDialog] = useState(revertFileDialog);

    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [fileName, setFileName] = useState('');
    // ScreenName and Language
    // fetch STorage Items
    //const fileName = Storage.getItem('fileName');
    const languageId = Storage.getItem('languageId');
    const screenName = Storage.getItem('screenName');

    // Handle Error
    /* istanbul ignore next */
    const handleError = (status, errorMsg) => {
        
        setErrorMessage(errorMsg);
    };

    
    const handleDialogClose = () => {
        setOpenDialog(false);
        handleCloseRevertFile(false)
    };

    // Submit Form Data
    /* istanbul ignore next */
    const revertFromDatabase = () => {
        let revertFromDB = {
            "jsonScreenName": screenName,
            "language": languageId
        };

        revertFromDatabaseAPI(revertFromDB);

    }

    /* istanbul ignore next */
    const revertFromDatabaseAPI = (revertFromDB) => {
        revertJson(revertFromDB)
            .then(response => {
                if (response.statusCode === 200 || response.statusCode === 202) {
                    
                    setDialogClass('messageDialog')
                    setTitle(labels.revertChangesText);                    
                    setSuccessMessage(`${messages.MSG0051} ${Storage.getItem('fileName')} ${messages.MSG0052}`);
                    setFileName(Storage.getItem('fileName'));
                    Storage.removeItem('fileName');
                    dispatch(clear_updated_json());
                    dispatch(clear_json());
                    dispatch(clear_selected_node());
                    dispatch(fetch_json_success([]));

                    // try { window.appInsights.trackEvent('Admin - Revert JSON', { 'pageName': "Configuration Publisher" }, { 'adminUserId': Storage.getItem('adminUserId')  }); }
				    // catch { }

                } else {
                    if(response.statusCode == 404) {
                        handleError(true, "Error in updating the JSON");
                    }                    
                }
            });
    }

    return (<>
        <>
            {openDialog ?
                <> <Dialog fullWidth={false}
                    id='dialogURL'
                    open={openDialog} onClose={handleDialogClose}
                    
                    // classes = { dialogClasss === 'root' ? { paperWidthSm: classes.root }  : { paperWidthSm: classes.messageDialog } }  

                    sx={{
                        "& .MuiDialog-paper": { 
                        //   width: "500px", // Set width
                        //   height: "320px", // Set height
                          maxWidth: "none" // Prevent default max-width behavior
                        }
                      }}
                      className='RevertJsonPopup'
                >

                    <DialogTitle id="customized-dialog-title">
                        <h6 sx={{
                            color: '#274463',
                            fontSize: '30px',
                            fontWeight: 'bold',
                        }}>{title}</h6>
                        <IconButton
                            aria-label="close"
                            sx={{
                                position: 'absolute',
                                right: '10px',
                                top: '10px',
                                color: '#274463'
                            }}
                            onClick={handleDialogClose}
                            size="large">
                            <CloseIcon />
                        </IconButton>
                    </DialogTitle>

                    <DialogContent className="open-cloud-dialog">
                        {errorMessage && <ErrorMessage errorMessage={errorMessage} />}
                        {successMessage !== '' ?
                            <MessageFromAPI filename={fileName} message={successMessage} handleDialogClose={handleDialogClose} />
                            :
                            <>
                                <div sx={{
                                        fontSize: '20px',
                                        color: '#000000',
                                        margin: '50px auto',
                                        textAlign: 'left',
                                        fontWeight: 600
                                    }}
                                    className='reverPopupContent'
                                    ><div>{messages.MSG0041}</div><br /><div>{messages.MSG0042}</div></div>
                                
                                
                                <Box sx = {{ display: 'flex', 
                                            justifyContent: 'flex-end', 
                                            fontSize: '21px', 
                                            marginTop: '70px', 
                                            fontFamily: 'Open Sans', 
                                            marginBottom: '20px' }}>

                                            <Button onClick={handleDialogClose} variant='outlined' color="primary" 
                                                    sx={{
                                                        backgroundColor: '#fff',
                                                        border: '1px solid #274463',
                                                        marginRight: '20px',
                                                        padding: '10px 18px',
                                                        borderRadius: '3px',
                                                        color: '#274463',
                                                        fontWeight: 'bold',
                                                        textTransform: 'none',
                                                    }}>
                                            {buttons.cancelButton}
                                        </Button>
                                        <Button variant='outlined' color="primary" onClick={revertFromDatabase} 
                                                sx={{
                                                    backgroundColor: '#274463',
                                                    border: '1px solid #274463',
                                                    padding: '10px 48px',
                                                    borderRadius: '3px',
                                                    fontWeight: 'bold',
                                                    textTransform: 'none',
                                                    '&:hover': {
                                                        backgroundColor: '#274463',
                                                        border: '1px solid #274463',
                                                        color: '#fff'
                                                    },
                                                }} >
                                            {buttons.revertButton}
                                        </Button>
                                </Box>
                            </>
                        }
                    </DialogContent>

                </Dialog>
                </>

                : null}
        </>
    </>);
};

export default RevertFromDatabase;