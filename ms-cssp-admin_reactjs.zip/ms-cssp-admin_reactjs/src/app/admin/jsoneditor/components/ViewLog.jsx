"use client"

import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import makeStyles from '@mui/styles/makeStyles';
import withStyles from '@mui/styles/withStyles';
import Box from '@mui/material/Box';
import Collapse from '@mui/material/Collapse';
import IconButton from '@mui/material/IconButton';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import MuiDialogTitle from '@mui/material/DialogTitle';
import MuiDialogContent from '@mui/material/DialogContent';
import MuiDialogActions from '@mui/material/DialogActions';
import CloseIcon from '@mui/icons-material/Close';
import Checkbox from '@mui/material/Checkbox';
import { fetchLog } from '../../services/ConfigurePublisherService';
import Storage from '../../utils/storage';
import Loader from '../../components/loader/loader';


const useStyles = makeStyles({
	table: {
		width: '100%',
		backgroundColor: '#FFFFFF',
		boxShadow: '0px 3px 15px #00000029',
		opacity: 1,
		margin: '0px',
		//tableLayout: 'fixed'
	},
	tableHead: {
		backgroundColor: '#00837BCC',
		boxShadow: '0px 3px 6px #00000029',
		opacity: 1
	},
	tableRow: {

	},
	tableContainerClass: {
		width: '99%',
		maxHeight: '400px'
	},
	tableWrap: {
		borderLeft: '1px solid #AAAFB9',
		borderRight: '1px solid #AAAFB9'
	},
	cellRow: {
		border: '1px solid #AAAFB9',
	},
	cellDisplayProperty: {
		textAlign: 'left',
		font: 'normal 18px Open Sans',
		letterSpacing: '0px'
	},
	headerTableCell: {
		color: '#F4F4F4',
		fontWeight: 'bold',
		backgroundColor: '#147120'
	},
	rowTableCell: {
		color: '#000000',
		borderBottom: '1px solid #AAAFB9',
		wordBreak: 'break-word'
	},
	dialogTitleClass: {
		textAlign: 'left',
		font: 'bold 30px Open Sans',
		letterSpacing: '0px',
		color: '#274463',
		opacity: 1
	},
	bottomCloseButtonClass: {
		margin: '10px 15px 11px 11px',
		backgroundColor: '#FFFFFF',
		border: '1px solid #274463',
		borderRadius: '3px',
		textAlign: 'center',
		font: 'bold 16px Open Sans',
		letterSpacing: '0px',
		color: '#274463',
	},
	svnExport: {
		width: '30px',
		height: '30px',
	},
	dialogBox: {
		minWidth: '85%',
		borderRadius: '3px',
		fontFamily: 'Open Sans',
		boxShadow: '0px 0px 18px #00000036',
	},
	notDataText: {
		textAlign: "center",
		fontSize: "23px",
		fontFamily: 'Open Sans',
	},
	historyWrap: {
		display: 'flex',
		flexDirection: 'column',
		paddingTop: 10,
		paddingBottom: 10,
		marginBottom: '5px',
	},
	historyRowWrap: {
		display: 'flex',
		fontSize: '15px',
		fontFamily: 'Open Sans',
		marginLeft: '15px',
	},
	historyRow: {
		width: '30%',
	},
	rowFirstSpan: {
		marginRight: 5
	},
	historyRowTitle: {
		width: '27%'
	},
	historyRowAlias: {
		width: '20%'
	},
	historyRowUser: {
		width: '26%'
	},
	historyRowDept: {
		width: '15%'
	},
	historyRowEmail: {
		width: '45%'
	}
});
//dialog
const styles = (theme) => ({
	root: {
		margin: 0,
		padding: '27px  10px 10px 17px'
	},
	closeButton: {
		position: 'absolute',
		right: '10px',
		top: '20px',
		color: '#274463',
		padding: '15px'		
	},
});

/* istanbul ignore next */
const GreenCheckbox = withStyles({
	root: {
		color: '#274463',
		'&$checked': {
			color: '#274463',
		},
	},
	checked: {},
})((props) => <Checkbox color="default" {...props} />);


/* istanbul ignore next */
const DialogTitle = withStyles(styles)((props) => {
	const { children, classes, onClose, ...other } = props;
	return (
        (<MuiDialogTitle disableTypography sx={{
			margin: 0,
			padding: '27px  10px 10px 17px'
		}} {...other}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
				<IconButton
                    aria-label="close"
                    sx={{
						position: 'absolute',
						right: '10px',
						top: '20px',
						color: '#274463',
						padding: '15px'		
					}}
                    onClick={onClose}
                    size="large">
					<CloseIcon />
				</IconButton>
			) : null}
        </MuiDialogTitle>)
    );
});

/* istanbul ignore next */
const DialogTitleExport = withStyles(styles)((props) => {
	const checkStatus = (setExportStatusMethod) => {
		setExportStatusMethod(true);
	}
	return (
		<div style={{ textAlign: 'right', padding: '0px 30px 5px 10px', font: 'normal 18px Open Sans', color: '#274463' }}>
			<div style={{ display: 'inline-block', width: '95%' }}><img src="/src/resources/images/csv-file.svg" alt="banner image" title="" className={props.classes.svnExport} /></div>
			<div onClick={() => checkStatus(props.setExportStatusMethod)} style={{ textAlign: 'left', display: 'inline-block', width: '5%', margin: '0px, 0px, 5px, 0px', fontSize: '16px', font: 'normal normal 18px Open Sans' }}>Export</div>
		</div>
	);
});

/* istanbul ignore next */
const DialogContent = withStyles((theme) => ({
	root: {
		padding: '15px'
	},
}))(MuiDialogContent);


function Row(props) {
	const { row, exportStatusValue, checkAllExportValue, viewLogs } = props;
	const [open, setOpen] = React.useState(false);
	const classes = useStyles();

	return (

		<React.Fragment>
			<TableRow sx={{ border: '1px solid #AAAFB9' }}>
				<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }}>

					{!exportStatusValue ?
						<IconButton aria-label="expand row" size="small" onClick={() => setOpen(!open)}>
							{open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
						</IconButton>
						:
						<GreenCheckbox checked={checkAllExportValue.checkAllExportValue} color="primary" inputProps={{ 'aria-label': 'checkbox with default color' }} />
					}
				</TableCell>
				<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} component="th" scope="row">
					{row.userId}
				</TableCell>
				<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} style={{ width: '30%' }} align="right">{row.comments}</TableCell>
				<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} align="right">{row.jsonFileName}</TableCell>
				<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} align="right">{row.date}</TableCell>
				<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} align="right">{row.time}</TableCell>
			</TableRow>
			<TableRow sx={{ border: '1px solid #AAAFB9' }}>
				<TableCell style={{ paddingBottom: 0, paddingTop: 0, margin: 0 }} colSpan={6}>
				<Collapse in={open} timeout="auto" unmountOnExit>
      {row.history.map((historyRow) => (
        <div
          key={historyRow.emailAddress}
          style={{
            display: 'flex',
            flexDirection: 'column',
            paddingTop: 10,
            paddingBottom: 10,
            marginBottom: '5px',
          }}
        >
          <div
            style={{
              display: 'flex',
              fontSize: '15px',
              fontFamily: 'Open Sans',
              marginLeft: '15px',
            }}
          >
            <div style={{ width: '26%' }}>
              <span style={{ marginRight: 5 }}>
                {viewLogs && viewLogs.labels.userName}:{' '}
              </span>
              <span>{historyRow.userName}</span>
            </div>
            <div style={{ width: '27%' }}>
              <span style={{ marginRight: 5 }}>
                {viewLogs && viewLogs.labels.title}:{' '}
              </span>
              <span>{historyRow.userTitle}</span>
            </div>
            <div style={{ width: '30%' }}>
              <span style={{ marginRight: 5 }}>
                {viewLogs && viewLogs.labels.mobileNumber}:{' '}
              </span>
              <span>{historyRow.phoneNumber}</span>
            </div>
            <div style={{ width: '15%' }}>
              <span style={{ marginRight: 5 }}>
                {viewLogs && viewLogs.labels.dept}:{' '}
              </span>
              <span>{historyRow.department}</span>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              fontSize: '15px',
              fontFamily: 'Open Sans',
              marginLeft: '15px',
            }}
          >
            <div style={{ width: '26%' }}>
              <span style={{ marginRight: 5 }}>
                {viewLogs && viewLogs.labels.location}:{' '}
              </span>
              <span>{historyRow.location}</span>
            </div>
            <div style={{ width: '27%' }}>
              <span style={{ marginRight: 5 }}>
                {viewLogs && viewLogs.labels.organization}:{' '}
              </span>
              <span>{historyRow.organizationName}</span>
            </div>
            <div style={{ width: '45%' }}>
              <span style={{ marginRight: 5 }}>
                {viewLogs && viewLogs.labels.emailAddress}:{' '}
              </span>
              <span>{historyRow.emailAddress}</span>
            </div>
          </div>
        </div>
      ))}
    </Collapse>
				</TableCell>
			</TableRow>
			</React.Fragment>
	);
}

Row.propTypes = {
	row: PropTypes.shape({
		comments: PropTypes.string.isRequired,
		date: PropTypes.string.isRequired,
		time: PropTypes.string.isRequired,
		history: PropTypes.arrayOf(
			PropTypes.shape({
				userName: PropTypes.string.isRequired,
				phoneNumber: PropTypes.string.isRequired,
				department: PropTypes.string.isRequired,
				userTitle: PropTypes.string.isRequired,
				location: PropTypes.string.isRequired,
				organizationName: PropTypes.string.isRequired,
				emailAddress: PropTypes.string.isRequired,
			}),
		).isRequired,
		jsonFileName: PropTypes.string.isRequired,
		userId: PropTypes.string.isRequired,
	}).isRequired,
};

const ViewLog = ({ jsonLogDialog, handleCloseJSONLog, labels, messages, viewLogs, buttons }) => {
	const classes = useStyles();
	const [open, setOpen] = React.useState(jsonLogDialog);
	const [noData, setNoData] = useState(false);
	const [message, setMessage] = useState("");
	const [tableRowData, setTableRowData] = useState([]);
	const [exportStatusValue, setExportStatusValue] = React.useState(false);
	const [checkAllExportValue, setCheckAllExportValue] = React.useState(false);
	const [loading, setLoading] = useState(false);

	let dateTime;
	// fetch STorage Items
	const fileName = Storage.getItem('fileName');
	const languageId = Storage.getItem('languageId');
	const screenName = Storage.getItem('screenName');

	/* istanbul ignore next */
	const handleClickOpen = () => {
		setOpen(true);
	};

	/* istanbul ignore next */
	const handleClose = () => {
		handleCloseJSONLog(false)
		setOpen(false);
		setExportStatusValue(false);
	};

	/* istanbul ignore next */
	const DialogActions = withStyles((theme) => ({
		root: {
			margin: 0,
			padding: theme.spacing(1),
		},
	}))(MuiDialogActions);

	/* istanbul ignore next */
	const setExportStatusMethod = (exportStatus) => {

		setExportStatusValue(exportStatus);
	}

	/* istanbul ignore next */
	const setCheckAllExportMethod = (checkValue) => {

		setCheckAllExportValue(checkValue);
	}

	/* istanbul ignore next */
	const submitFetchLogInput = () => {
		const fetchInput = {
			"jsonScreenName": screenName,
			"language": languageId
		}
		fetchLogAPI(fetchInput);
	}

	/* istanbul ignore next */
	const convertToDateTime = (timeStamp) => {
		let dateTime = new Date(timeStamp);
		let date = dateTime.toLocaleDateString();
		//let time = dateTime.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', });
		let time = dateTime.toLocaleTimeString('en-US', { timeZone: 'America/New_York', hour: '2-digit', minute: '2-digit' });
		return [date, time];
	}

	/* istanbul ignore next */
	const fetchLogAPI = (fetchLogInput) => {
		setLoading(true);
		fetchLog(fetchLogInput).then(response => {
			if (response.statusCode !== undefined && response.statusCode == 200 && response.success === true) {

				if (Object.keys(response.body.log).length !== 0) {
					setTableRowData(response.body.log);
					setLoading(false);
				} else {
					setLoading(false);
					setNoData(true);
					setMessage("NO LOGS AVAILABLE FOR NOW!")
				}

				// try { window.appInsights.trackEvent('Admin - View Log', { 'pageName': "Configuration Publisher" }, { 'adminUserId': Storage.getItem('adminUserId')  }); }
				// catch { }
				
			} else {
				setNoData(true);
				setMessage("NO LOGS AVAILABLE FOR NOW!")
			}
		})
	}

	useEffect(() => {
		if (jsonLogDialog) {
			submitFetchLogInput();
		}
	}, [jsonLogDialog])
		return (

		<>
			<Dialog fullWidth onClose={handleClose} open={open}
				classes={{ paperWidthSm: classes.dialogBox }}
				className='ViewPublishLogs'
			>
				<DialogTitle id="customized-dialog-title" onClose={handleClose}>
					<span sx={{
							textAlign: 'left',
							font: 'bold 30px Open Sans',
							letterSpacing: '0px',
							color: '#274463',
							opacity: 1
						}}>{labels.viewLogsText}</span>
				</DialogTitle>
				{/*!exportStatusValue?
        <DialogTitleExport classes={classes} exportStatusValue={exportStatusValue} setExportStatusMethod={setExportStatusMethod}></DialogTitleExport>
        :null */}
				<>
					<DialogContent className={classes.dialogContainerClass} >
						{!noData && Object.keys(tableRowData).length > 0 && <TableContainer sx={{ width: '99%', maxHeight: '400px' }}>
							<Table style={{ width: '100%' }} sx={{ borderLeft: '1px solid #AAAFB9',
																	borderRight: '1px solid #AAAFB9'
																}} aria-label="collapsible table sticky table" stickyHeader  >
								{/* header */}
								<TableHead sx={{
												backgroundColor: '#00837BCC',
												boxShadow: '0px 3px 6px #00000029',
												opacity: 1
											}} >
									<TableRow className={classes.tableRow}>
										<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120' }} ><label style={{ color: "#00837BCC" }}>.</label></TableCell>
										<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }}>{viewLogs.labels.userId}</TableCell>
										<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} align="center">{viewLogs.labels.chnageComments}</TableCell>
										<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} align="center">{viewLogs.labels.fileName}</TableCell>
										<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} align="center">{viewLogs.labels.date}&nbsp;</TableCell>
										<TableCell sx={{ color: '#F4F4F4', fontWeight: 'bold', backgroundColor: '#147120', textAlign: 'left', font: 'normal 18px Open Sans', letterSpacing: '0px' }} align="center">{viewLogs.labels.time}&nbsp;</TableCell>
									</TableRow>
								</TableHead>
								<TableBody className={classes.tableBody}>
									{tableRowData.map((row, index) => {
										let [logDate, logTime] = convertToDateTime(row.updatedTimestamp);
										row['date'] = logDate;
										row['time'] = logTime;
										row['history'] = [
											{
												userName: row.userName,
												phoneNumber: row.phoneNumber,
												department: row.department,
												userTitle: row.userTitle,
												location: row.location,
												organizationName: row.organizationName,
												emailAddress: row.emailAddress,
											}
										];
										return <Row exportStatusValue={exportStatusValue} checkAllExportValue={checkAllExportValue} key={index} row={row} viewLogs={viewLogs} />
									})}
								</TableBody>
							</Table>
						</TableContainer>
						}
						{noData && message && <div sx={{
														textAlign: "center",
														fontSize: "23px",
														fontFamily: 'Open Sans',
													 }}
													 className="no_content"
													 >{message}</div>}
					</DialogContent>
					{!exportStatusValue ?
						<DialogActions><Button sx={{
							margin: '10px 15px 11px 11px',
							backgroundColor: '#FFFFFF',
							border: '1px solid #274463',
							borderRadius: '3px',
							textAlign: 'center',
							font: 'bold 16px Open Sans',
							letterSpacing: '0px',
							color: '#274463',
						}} autoFocus onClick={handleClose} >
							{viewLogs.buttons.config.close}
						</Button></DialogActions>
						:
						<DialogActions style={{ margin: '0 10px 0 0' }}><Button sx={{
							margin: '10px 15px 11px 11px',
							backgroundColor: '#FFFFFF',
							border: '1px solid #274463',
							borderRadius: '3px',
							textAlign: 'center',
							font: 'bold 16px Open Sans',
							letterSpacing: '0px',
							color: '#274463',
						}} autoFocus onClick={() => setExportStatusMethod(false)} >
							{viewLogs.buttons.config.back}
						</Button>
							<Button sx={{
									margin: '10px 15px 11px 11px',
									backgroundColor: '#FFFFFF',
									border: '1px solid #274463',
									borderRadius: '3px',
									textAlign: 'center',
									font: 'bold 16px Open Sans',
									letterSpacing: '0px',
									color: '#274463',
								}} autoFocus onClick={handleClose} >
								{viewLogs.buttons.config.export}
							</Button>
						</DialogActions>
					}
				</>
			</Dialog>
		</>
	);
}
export default ViewLog
