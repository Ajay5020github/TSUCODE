"use client"

import React, { useState, useEffect } from 'react';
import makeStyles from '@mui/styles/makeStyles';
import Button from '@mui/material/Button';
const useStyles = makeStyles({
    root: {
        width: '450px',
        minHeight: '450px',
        borderRadius: '3px',
        fontFamily: 'Open Sans'
    },
    closeButton: {
        position: 'absolute',
        right: '10px',
        top: '10px',
        color: '#274463'
    },
    dialogTitle: {
        color: '#274463',
        fontSize: '41px',
        fontWeight: 'bold',
    },
    formControl: {
        minWidth: 130,
    },
    btnCancel: {
        backgroundColor: '#fff',
        border: '1px solid #274463',
        marginRight: '20px',
        padding: '10px 18px',
        borderRadius: '3px',
        color: '#274463'
    },
    btnOK: {
        backgroundColor: '#274463',
        border: '1px solid #274463',
        padding: '10px 48px',
        borderRadius: '3px',
        '&:hover': {
            backgroundColor: '#fff',
            border: '1px solid #274463',
            color: '#274463'
        },
    },
    formControlWrap: {
        display: 'flex',
        justifyContent: 'space-between',
        marginTop: '40px'
    },
    formOpen: {
        display: 'flex',
        flexDirection: 'column',
    },
    btnWrap: {
        display: 'flex',
        justifyContent: 'flex-end',
        fontSize: '21px',
        marginTop: '100px'
    },
    dropdownStyle: {
        borderRadius: 0,
        /* "& ul": {
            
        }, */
        "& li": {
            fontSize: 14,
        },
    },
    formSelect: {
        fontSize: 14
    },
    inputRad: {
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
              borderRadius: `4px 0 0 4px`,
            },
          },
        
    },
    btnOK: {
        backgroundColor: '#274463',
        border: '1px solid #274463',
        padding: '10px 48px',
        borderRadius: '3px',
        textTransform: 'none',
        '&:hover': {
            backgroundColor: '#fff',
            border: '1px solid #274463',
            color: '#274463'
        },
    },
});

const SaveMessage = ({ message, title, handleDialogClose }) => {

    
    const classes = useStyles(); 
    

    return (
        <>
            {message && title &&
                <>
                <div></div>
                <div>{message}</div>
                <Button variant='outlined' color="primary" onClick={handleDialogClose} 
                    sx={{
                        backgroundColor: '#274463',
                        border: '1px solid #274463',
                        padding: '10px 48px',
                        borderRadius: '3px',
                        textTransform: 'none',
                        '&:hover': {
                            backgroundColor: '#fff',
                            border: '1px solid #274463',
                            color: '#274463'
                        }
                    }} >
                        Ok
                </Button>
                </>        
            }
        </>
    );
};

export default SaveMessage;