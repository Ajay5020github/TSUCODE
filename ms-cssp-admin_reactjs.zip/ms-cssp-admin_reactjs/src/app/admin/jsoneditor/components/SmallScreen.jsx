"use client"

import React from 'react';
import makeStyles from '@mui/styles/makeStyles';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';

const useStyles = makeStyles({
	root: {
		minWidth: 275,
		margin: '8% auto 0',
		width: 275
	},
	title: {
		fontSize: 14,
		textAlign: 'center'
	}
});

const SmallScreen = () => {
	const classes = useStyles();

	return (
		<Card className={classes.root}>
			<CardContent>
				<Typography className={classes.title} color="textSecondary">
            View in large screen
				</Typography>
			</CardContent>
		</Card>
	);
};

export default SmallScreen;
