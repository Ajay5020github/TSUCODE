"use client"

import React, { useState, useEffect, useContext } from 'react';
import { useSelector, useDispatch, useStore } from 'react-redux';
import { simplify, desimplify } from '../../utils/simplifr';
import { Typography, Collapse, List, ListItem, ListItemText } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import MuiAlert from '@mui/material/Alert';
import { searchObject } from '../components/helper/helper';
// import { fetchJsonSuccess, removeNodeJson, addNodeJson } from '../reducers/jsonReducer';
import { fetch_json_request, remove_node_json, add_node_json, update_json_data, set_updated_json_data } from '../actions';
import { update_json, update_complete } from '../updatedJsonActions';
// import { updateJson } from '../reducers/updatedJsonReducer';

import { jsonBuilderTheme } from '../themes/JsonBuilderTheme';
import { ThemeProvider } from '@mui/system';
import editableKeys from '../../editableKeys.json';
import Grid from '@mui/material/Grid2'

import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Input from '@mui/material/Input';

import { fetchJson, revertJson, readContentJson } from '../../services/ConfigurePublisherService';


import { EditableKeyConext } from './Home';
import "./customJson.css"
/* istanbul ignore next */
const Alert = (props) => {
	return <MuiAlert elevation={6} variant='filled' {...props} />;
};

const useStyles = makeStyles({
	root: {
		width: '100%',
		backgroundColor: jsonBuilderTheme.palette.background.paper
	},
	nested: {
		'padding': '0px 8px 2px',
		'margin': '0px 0px 2px'
	},
	hoverIcon: {
		'fontSize': '1.56rem',
		'color': '#353434',
		'margin': '0 2px',
		'background': '#615b5b8a',
		'padding': '3px',
		'cursor': 'pointer',
		[jsonBuilderTheme.breakpoints.down(780)]: {
			fontSize: '16px'
		},
		[jsonBuilderTheme.breakpoints.down(1025)]: {
			fontSize: '26px'
		}
	},
	hoverIconGrid: {
		display: 'flex',
		marginRight: '8px'
	},
	listItem: {
		padding: 0
	},

	listItemText: {
		flex: '0 1 auto',
		color: 'black',
		[jsonBuilderTheme.breakpoints.down(1150)]: {
			marginLeft: '19%',
			width: '238px'
		},
		'&  .MuiInput-formControl': {
			marginTop: '0',
		}
	},
	body1: {
		fontWeight: 'bold'
	},
	listIcon: {
		minWidth: 'unset',
		color: jsonBuilderTheme.palette.listIconNodeUpdateTree.main
	},
	paper: {
		borderColor: jsonBuilderTheme.palette.paperBorderNodeUpdateTree.main
	},
	paper2: {
		textAlign: 'center'
	},
	bold: {
		fontWeight: 600
	},
	searchedValue: {
		fontWeight: '200',
		backgroundColor: jsonBuilderTheme.palette.searchedValueNodeUpdateTree.main
	},
	searchedText: {
		color: jsonBuilderTheme.palette.searchedTextNodeUpdateTree.main,
		fontWeight: '200'
	},
	buttonsSection: {
		textAlign: 'right'
	},
	addSection: {
		margin: '2px 0 2px',
		background: '#ccc',
		padding: '4px 0',
		width: '100%'
	},
	addForm: {
		display: 'flex'
	},
	addButtonsSection: {
		display: 'flex',
		maxWidth: 'fit-content'
	},
	addButtonsSectionButtons: {
		'minWidth': 'auto',
		'background': 'rgb(123 119 119 / 76%)',
		'margin': '1px',
		'padding': '0px 5px',
		'minHeight': 'auto',
		'height': '27px'
	},
	inputRad: {
		color: '#000'
	},
	nodeUpdateCollapse: {
		'& br': {
			display: 'none',
		}
	},
	addkeyValue: {
		[jsonBuilderTheme.breakpoints.down(800)]: {
			maxWidth: '43%'
		}
	},
	collapseNodeUpdate: {
		paddingLeft: '30px',
		[jsonBuilderTheme.breakpoints.down(1000)]: {
			paddingLeft: '0px'
		}
	},
	readOnly: {
		color: '#584e4e',
		wordBreak: 'break-word'
	},
	listItemDisplayNot: {
		display: 'none'
	}
});

export default function NodeUpdate({
	data,
	expand,
	searchTerm,
	sortDirection,
	parentName = ' ',
	ref
}) {

	const classes = useStyles();
	const store = useStore();
	const dispatch = useDispatch();

	const [open, setOpen] = useState(false);
	const [appear, setAppear] = useState(false);
	const [addNewValue, setAddNewValue] = useState(false);
	const [checkkey, setCheckKey] = useState();
	const [checkIndex, setCheckIndex] = useState();
	const [checkKeyOfNode, setCheckKeyOfNode] = useState();
	const [checkIndexOfNode, setCheckIndexOfNode] = useState();
	const [searchKey, setSearchKey] = useState();
	const [json, setJson] = useState({});
	const [newKey, setNewKey] = useState('');
	const [newValue, setNewValue] = useState('');
	const [keyChanged, setKeyChanged] = useState('');
	const [editableKey, setEditableKey] = useState('');
	const [state, setState] = useState({
		openSnackbar: false,
		vertical: 'top',
		horizontal: 'center'
	});

	const [editableKeyList, setEditableKeyList] = useState([]);
	const [stateChanged, setStateChanged] = useState(false);

	const { vertical, horizontal, openSnackbar } = state;

	const handleSnackbar = () => {
		setState({ openSnackbar: true, vertical: 'top', horizontal: 'center' });
	};

	const currentState = useSelector(state => state.jsonReducer.present);
	const currentUpdatedState = useSelector(state => state.updatedJsonReducer);

	/* istanbul ignore next */
	const handleChange = (event) => {
		// setKeyChanged('');
		const name = event.target.name;
		const value = event.target.value;

		setJson((prevState) => ({
			...prevState,
			[name]: value
		}));		

		setKeyChanged(name);
		setStateChanged(true);
	};

	/* istanbul ignore next */
	useEffect(() => {

		if (keyChanged !== '') {
			handleUpdate(keyChanged);
			setStateChanged(false);
		}

	}, [stateChanged === true]);

	/* istanbul ignore next */
	const setChangedKey = () => {

		setKeyChanged('');
	};

	/* istanbul ignore next */
	const handleUpdate = (changedKey) => {		
		confirmChange(changedKey);
		setChangedKey();
	};

	/* istanbul ignore next */
	const confirmChange = keyChanged => {

		const jsonData = simplify(currentState.jsonData);
		const getPathResult = searchObject(currentState.jsonData,
			function (value) { return value !== null && value !== undefined && value.$ID === data.$ID; });

		if (getPathResult && Object.keys(getPathResult).length > 0) {
			updateJSONData(jsonData, getPathResult[0].path, keyChanged, json);
		}
	};

	/* istanbul ignore next */
	const cancelChange = () => {

		const jsonData = simplify(currentState.jsonData);
		const getPathResult = searchObject(jsonData,
			function (value) { return value !== null && value !== undefined && value.$ID === data.$ID; });

		if (getPathResult && Object.keys(getPathResult).length > 0) {
			setJson(getPathResult[0].value);
			// setJsonChanged(false);
			setKeyChanged('');
		}
	};

	/* istanbul ignore next */
	const updateJSONData = (jsonData, path, name, json) => {
		dispatch(update_json(jsonData, path, name, json));
		dispatch(set_updated_json_data(jsonData, path, name, json))
		// dispatch(update_complete())
	};

	/* istanbul ignore next */
	const handleClick = () => {
		setUpdatedJSON(desimplify(currentState.jsonData));
		setOpen(!open);
	};

	/* istanbul ignore next */
	const searchData = () => {

		Object.keys(json).map((k) => {
			if (k === searchTerm || (json[k].toString() !== '' && json[k].toString().includes(searchTerm))) {
				setSearchKey(k);
			}
		});
	};

	/* istanbul ignore next */
	const cancelAdd = () => {
		setAddNewValue(false);
	};

	// Check if a value is an object
	/* istanbul ignore next */
	const isObject = function (value) {
		return (typeof value === 'object');
	};

	/* istanbul ignore next */
	// Check if an object is an array
	const isArray = function (obj) {
		return (Object.prototype.toString.call(obj) === '[object Array]');
	};

	/* istanbul ignore next */
	// This function helps in adding a Node
	const addNode = () => {
		if (newKey === '' || newValue === '') {
			return false;
		} else {
			let getPathResult = '';
			let objectPath = '';

			// Form a JSON Object with new Key, new Value

			const jsonNodeToAdd = {
				newJSON:
					{ jsonKey: newKey, jsonValue: newValue }
			};

			// Check if json is an array
			if (isObject(json) && (isArray(json))) {
				getPathResult = searchObject(currentState.jsonData,
					function (value) { return value !== null && value !== undefined && value.$ID === json[0].$ID; });

				if (getPathResult !== null && getPathResult.length > 0) {
					// Get the Node Path by checking the first node of an Object
					objectPath = getPathResult[0].path.substr(0, getPathResult[0].path.lastIndexOf('.'));
				}
			}
			else {
				// Get the Node Path
				getPathResult = searchObject(currentState.jsonData,
					function (value) { return value !== null && value !== undefined && value.$ID === json.$ID; });

				if (getPathResult !== null && getPathResult.length > 0) {
					objectPath = getPathResult[0].path;
				}
			}
			// Simplify the current state's jsonData
			const jsonData = simplify(currentState.jsonData);
			if (objectPath !== null && objectPath.length > 0) {
				// run dispatch method in jsonReducer to add the node
				addJSON(jsonData, objectPath, jsonNodeToAdd);
			}

			handleSnackbar();
			setAddNewValue(false);
			setAppear(false);
		}
	};

	/* istanbul ignore next */
	const addJSON = (jsonData, path, jsonNodeToAdd) => {

		dispatch(add_node_json(jsonData, path, jsonNodeToAdd));
		dispatch(fetch_json_request());

		// Pass to setUpdatedJSON to set the json state
		setUpdatedJSON(desimplify(currentState.jsonData));  //jsonUpdatedData.payload
		setNewKey('');
		setNewValue('');
	};

	/* istanbul ignore next */
	// This function helps in removing a json node
	const removeNode = (key) => {

		let jsonData = '';
		let getPathResult = '';

		// Get the path of the selected node
		getPathResult = searchObject(currentState.jsonData,
			function (value) { return value !== null && value !== undefined && value.$ID === json.$ID; });

		jsonData = simplify(currentState.jsonData);
		if (getPathResult !== null && getPathResult.length > 0) {
			// run dispatch method in jsonReducer to remove the node
			removeJSON(jsonData, getPathResult[0].path + '.' + key);
		}
	};

	/* istanbul ignore next */
	// Runs dispatch method of jsonReducer
	const removeJSON = (jsonData, path) => {

		let jsonUpdatedData = '';

		// Run dispatch method and get the updated JSON (of all objects)
		jsonUpdatedData = dispatch(remove_node_json(jsonData, path));

		// Pass to setUpdatedJSON to set the json state
		setUpdatedJSON(desimplify(jsonUpdatedData.payload));
	};

	/* istanbul ignore next */
	// Set the json State
	const setUpdatedJSON = (jsonData) => {
		let getPathResult = '';

		// get updated JSON from the current State of updated JSON (of all objects)
		getPathResult = searchObject(jsonData,
			function (value) { return value !== null && value !== undefined && value.$ID === json.$ID; });
		if (getPathResult !== null && getPathResult.length > 0) {
			// Invoke setJson React Hook
			setJson(getPathResult[0].value);
		}
	};

	/* istanbul ignore next */
	const handleMouseEnter = (key, index) => {
		Object.keys(json).map((k, i) => {
			if (k === key && i === index) {
				setAppear(true);
				setCheckIndex(index);
				setCheckKey(key);
			}
		});
	};

	/* istanbul ignore next */
	const handleMouseLeave = () => {
		setAppear(false);
		setCheckIndex(null);
	};

	/* istanbul ignore next */
	const filterItems = (arr, query) => {
		return arr && arr.filter((el) => {
			return el.toLowerCase() === query.toLowerCase()
		})
	}

	/* istanbul ignore next */
	const checkReadOnlyNodes = jsonKey => {

		let nodeKey = filterItems(editableKeyList, jsonKey);

		if (nodeKey && nodeKey.length === 0) {
			return true;
		}
		else {
			return false;
		}
	};

	/* istanbul ignore next */
	const sortBykey = () => {
		const sorted = {};

		if (sortDirection === 'Ascending') {
			Object.keys(json).sort().map((k) => {
				sorted[k] = json[k];
			});
			setJson(sorted);
		}
		else if (sortDirection === 'Descending') {
			Object.keys(json).sort().reverse().map((k) => {
				sorted[k] = json[k];
			});
			setJson(sorted);
		}
	};

	/* istanbul ignore next */
	useEffect(() => {
		setUpdatedJSON(currentState.jsonData);
	}, [currentState.jsonData]);

	// Initial Loading
	/* istanbul ignore next */
	useEffect(() => {
		setJson(data);
		setOpen(expand);
	}, [expand, searchTerm, data]);

	// This is for Sorting....
	/* istanbul ignore next */
	useEffect(() => {
		sortBykey();
	}, [sortDirection]);


	var editableKeyContext = useContext(EditableKeyConext);

	if (editableKeyList && editableKeyList.length === 0) {
		setEditableKeyList(editableKeyContext);
	}

	return (
		<ThemeProvider theme={jsonBuilderTheme}>
			<>

				<div className={classes.nodeUpdateCollapse}>
					<Collapse
						in={open}
						timeout='auto'
						unmountOnExit
						style={{ paddingLeft: '30px' }}
					>
						<List component={'div'} style={{ padding: 0 }} onMouseOver={() => setAppear(true)}
							onMouseLeave={() => setAppear(false)} >
							{json &&
								Object.keys(json).map((k, i) => {
									return json[k] !== null && typeof json[k] === 'object' && k !== 'sections' && k !== 'fields' ? (
										<NodeUpdate
											key={Math.random()}
											data={json[k]}
											parentName={Array.isArray(json) ? '' : k}
											length={Object.keys(json[k]).length}
										/>
									) : (
										<>
											{(k !== '$ID' && k !== '$PID' && k !== 'sections' && k !== 'fields' && k !== '') ?
												<Grid >
													<ListItem button onMouseOver={() => handleMouseEnter(k, i)} onMouseLeave={() => handleMouseLeave()}>
														<Grid item xs={1} className="text_display">
															<>
																{appear && checkIndex === i && checkkey === k && <>
																</>}
															</>
														</Grid>
														{!Array.isArray(json) ? (
															<>
																<Grid item xs={5} className="text_display">
																	{(k !== '$ID' && k !== '$PID' && k !== 'sections' && k !== 'fields') ?
																		(checkReadOnlyNodes(k)) ?
																			<ListItemText className={`${classes.listItemText} json_text_align`}>
																				<Typography className={`${classes.readOnly} json_text_align`}>{k}</Typography>
																			</ListItemText>
																			: k
																		: null}
																</Grid>
															</>
														) : (
															null
														)}
														<Grid item xs={7} className="text_display">
															{(k !== '$ID' && k !== '$PID' && k !== 'sections' && k !== 'fields' && json[k] !== null) ?
																(checkReadOnlyNodes(k)) ?
																	<ListItemText className={`${classes.listItemText}  json_text_align`} >
																		<Typography className={`${classes.readOnly} json_text_align`}>{json[k] !== null && json[k].toString()}</Typography>
																	</ListItemText>
																	:
																	<>

																		<div className='enterable_json_text_align' >
																			<FormControl fullWidth>
																				<InputLabel style={{ "display": "none", paddingRight: '10px' }} htmlFor={k}>InputLabel</InputLabel>
																				<Input sx={{ maxWidth: 'auto', flexBasis: 'auto', paddingRight: '10px', width: '600px', whiteSpace: 'nomral', wordWrap: 'break-wordf' }} name={k} id={k} fullWidth
																					value={json[k]} multiline onChange={handleChange}
																					inputProps={{ className: classes.inputRad }} />
																			</FormControl>
																		</div>
																	</>
																: null}
														</Grid>
													</ListItem>
												</Grid>
												: <Grid className={classes.listItemDisplayNot} ></Grid>}
										</>
									);
								})
							}

						</List>
					</Collapse></div>
			</>
		</ThemeProvider>
	);
}
