"use client"

import React from 'react';
import { Box, Button } from '@mui/material';

import makeStyles from '@mui/styles/makeStyles';

const useStyles = makeStyles({
    btnOK: {
        backgroundColor: '#274463',
        border: '1px solid #274463',
        padding: '10px 48px',
        borderRadius: '3px',
        float: 'right',
        fontWeight: 'bold',
        fontFamily: 'Open Sans',
        textTransform: 'none',
        '&:hover': {
            backgroundColor: '#274463',
            border: '1px solid #274463',
            color: '#fff'
        },
    },
    ContentText: {
        color: '#000000',
        margin: '50px auto',
        fontSize: '17px',
        fontWeight: 600,
        fontFamily: 'Open Sans',
    }
});

const MessageFromAPI = ({ message, filename, handleDialogClose }) => {

    const classes = useStyles();   

    return (
        <>
            {message && filename &&
                <>
                    <Box sx={{
                        color: '#000000',
                        margin: '50px auto',
                        fontSize: '17px',
                        fontWeight: 600,
                        fontFamily: 'Open Sans',
                    }}>{message}</Box>
                    <Button variant='outlined' color="primary" type="submit" 
                        sx={{
                            backgroundColor: '#274463',
                            border: '1px solid #274463',
                            padding: '10px 48px',
                            borderRadius: '3px',
                            float: 'right',
                            fontWeight: 'bold',
                            fontFamily: 'Open Sans',
                            textTransform: 'none',
                            '&:hover': {
                                backgroundColor: '#274463',
                                border: '1px solid #274463',
                                color: '#fff'
                            },
                        }} 
                    onClick={handleDialogClose} >
                        OK
					</Button>
                </>        
            }

        </>
    );
};

export default MessageFromAPI;