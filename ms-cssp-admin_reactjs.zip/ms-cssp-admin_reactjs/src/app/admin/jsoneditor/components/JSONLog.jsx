"use client"

import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import makeStyles from '@mui/styles/makeStyles';

// Configure Publiher Service
import { fetchLog } from '../../services/ConfigurePublisherService';
import Storage from '../../utils/storage';

import MessageFromAPI from './MessageFromAPI';
const useStyles = makeStyles({
    root: {
        width: '450px',
        minHeight: '450px',
        borderRadius: '3px',
        fontFamily: 'Open Sans'
    },
    closeButton: {
        position: 'absolute',
        right: '10px',
        top: '10px',
        color: '#274463'
    },
    dialogTitle: {
        color: '#274463',
        fontSize: '41px',
        fontWeight: 'bold',
    },
    formControl: {
        minWidth: 130,
    },
    btnCancel: {
        backgroundColor: '#fff',
        border: '1px solid #274463',
        marginRight: '20px',
        padding: '10px 18px',
        borderRadius: '3px',
        color: '#274463'
    },
    btnOK: {
        backgroundColor: '#274463',
        border: '1px solid #274463',
        padding: '10px 48px',
        borderRadius: '3px',
        '&:hover': {
            backgroundColor: '#fff',
            border: '1px solid #274463',
            color: '#274463'
        },
    },
    formControlWrap: {
        display: 'flex',
        justifyContent: 'space-between',
        marginTop: '40px'
    },
    formOpen: {
        display: 'flex',
        flexDirection: 'column',
    },
    btnWrap: {
        display: 'flex',
        justifyContent: 'flex-end',
        fontSize: '21px',
        marginTop: '100px'
    },
    dropdownStyle: {
        borderRadius: 0,
        /* "& ul": {
            
        }, */
        "& li": {
            fontSize: 14,
        },
    },
    formSelect: {
        fontSize: 14
    },
    inputRad: {
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
              borderRadius: `4px 0 0 4px`,
            },
          },
        
    }
});

const JSONLog = ({ jsonLogDialog, handleCloseJSONLog }) => {

    const dispatch = useDispatch();
    const classes = useStyles();
    const currentState = useSelector(state => state.jsonReducer.present);
    const jsonData = currentState.jsonData;
    const [openDialog, setOpenDialog] = useState(jsonLogDialog);
    const [value, setValue] = useState(null);
    const [jsonComments, setJsonComments] = useState('');
    const [jsonLogInvoked, setJSONLogInvoked] = useState(false);

    // Error State
    const [isValid, setIsValid] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    // ScreenName and Language
    // fetch STorage Items
    const fileName = Storage.getItem('fileName');
    const languageId = Storage.getItem('languageId');
    const screenName = Storage.getItem('screenName');

    // Handle Error
    const handleError = (status, errorMsg) => {
        setIsValid(status);
        setErrorMessage(errorMsg);
    };

    // Set Selected Screen Name onchange
    const handleCommentsChange = (event) => {
        setJsonComments(event.target.value);
    }

    // Submit Form Data
    const openJSONLog = () => {        
            let jsonLogData = {
                "jsonScreenName": screenName,
                "language": languageId
            };

            jsonLogAPI(jsonLogData);
            setJSONLogInvoked(true);
    }

    const jsonLogAPI = (jsonLogData) => {        
        fetchLog(jsonLogData)
            .then(response => {
               if (response.statusCode === 200 && response.success === true) {
                    
                    handleDialogClose();
                    // Call JSON Log component
                    
                } else {

                    // Call MessageFromAPI component with filename, message, title
                    {/* <MessageFromAPI filename={fileName} message={response.message} title={'View Logs'} /> */}
                    handleError(true, response.message);
                }
                handleDialogClose();
            });

            setJSONLogInvoked(false);    
    }


    const handleDialogClose = () => {
        setOpenDialog(false);
        handleCloseJSONLog(false);
    };

    useEffect(() => {
        openJSONLog();
    }, [jsonLogInvoked === false])

    return (
        <></>
    );
};

export default JSONLog;
