
"use client"
import React, {useState, useEffect} from 'react';
import {useSelector, useDispatch} from 'react-redux';

import makeStyles from '@mui/styles/makeStyles';
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import Typography from '@mui/material/Typography';

import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Grid2 from '@mui/material/Grid2';
import { fetch_json_request, update_json_data, get_updated_json_data, fetch_json_success } from '../actions';
import { update_complete } from '../updatedJsonActions';

import PropertyTree from './PropertyTree';
import { searchObject } from '../components/helper/helper';

import { jsonBuilderTheme } from '../themes/JsonBuilderTheme';
import { ThemeProvider } from '@mui/system';
import "../../containers/custom.css"


import { RemoveParentId } from '../components/helper/helper';

const useStyles = makeStyles({
	root: {
		width: '100%'
	},
	heading: {
		fontSize: jsonBuilderTheme.typography.pxToRem(15),
		flexBasis: '33.33%',
		flexShrink: 0
	},
	secondaryHeading: {
		fontSize: jsonBuilderTheme.typography.pxToRem(15),
		color: jsonBuilderTheme.palette.text.secondary
	},
	paper: {
		padding: jsonBuilderTheme.spacing(2),
		textAlign: 'left',
		//elevation: 1
	},
	accordionDetailsSection: {
		// display: 'block'
	},
	accordionSection: {
		background: '#147120',
		margin: '2px 0px 2px 0px',
		position: 'inherit'
	},
	accordionSectionDisabled: {
		background: '#F4F4F4',
		margin: '2px 0px 2px 0px',
		position: 'inherit'
	}
});

const PropertyUpdateNew = () => {

	const classes = useStyles();
	const [expanded, setExpanded] = useState('');
	const dispatch = useDispatch();

	const [jsonFifthNode, setFifthNode] = useState({});
	const [jsonFourthNode, setFourthNode] = useState({});
	const [jsonThirdNode, setThirdNode] = useState({});
	const [jsonSecondNode, setSecondNode] = useState({});
	const [jsonFirstNode, setFirstNode] = useState({});


	const [jsonFirstNodeObjectName, setJsonFirstNodeObjectName] = useState('');
	const [jsonSecondNodeObjectName, setJsonSecondNodeObjectName] = useState('');
	const [jsonThirdNodeObjectName, setJsonThirdNodeObjectName] = useState('');
	const [jsonFourthNodeObjectName, setJsonFourthNodeObjectName] = useState('');
	const [jsonFifthNodeObjectName, setJsonFifthNodeObjectName] = useState('');
	const [trigger, setTrigger] = useState(false);

	let currentState = useSelector(state => state.jsonReducer.present);
	const currentNodeState = useSelector(state => state.selectedNodeReducer);
	const currentUpdatedState = useSelector(state => state.updatedJsonReducer);
	

	/* istanbul ignore next */
	const handleChange = (panel) => () => {
		setExpanded(expanded !== panel ? panel : '');
	};

	/* istanbul ignore next */
	useEffect(() => {
		
		setFifthNode({});
		setFourthNode({});
		setThirdNode({});
		setSecondNode({});
		setFirstNode({});

		// setJsonFirstNodeObjectName('');
		// setSecondNodeObjectName('');
		// setThirdNodeObjectName('');
		// setFourthNodeObjectName('');
		// setFifthNodeObjectName('');

		let getCurrentNodeResult = '';

		let getFifthNodeResult = '';
		let getFourthNodeResult = '';
		let getThirdNodeResult = '';
		let getSecondNodeResult = '';
		let getFirstNodeResult = '';

		
		if (currentUpdatedState.updated === true) {
			const parsedJSON = JSON.parse(JSON.stringify(currentUpdatedState.updatedJsonData))			
			dispatch(update_json_data(parsedJSON))
			// dispatch(update_complete())
		}

		if (currentNodeState.selectedNodeData && currentNodeState.selectedNodeData.$PID !== 'ROOT')
			{
				if (currentNodeState && currentNodeState.selectedNodeData && Object.keys(currentNodeState.selectedNodeData).length > 0)
				{
					
					getCurrentNodeResult = searchObject(currentState.jsonData,
							function (value) { return value !== null && value !== undefined && value.$ID === currentNodeState.selectedNodeData.$ID; });
					
					if (getCurrentNodeResult !== null && getCurrentNodeResult !== undefined)
					{
						if (Object.keys(getCurrentNodeResult).length > 0 && getCurrentNodeResult[0].value.$PID !== 'ROOT')
						{
							if (Object.keys(getCurrentNodeResult).length > 0)
							{
								getFirstNodeResult = searchObject(currentState.jsonData,
									function (value) { return value !== null && value !== undefined && value.$ID === currentNodeState.selectedNodeData.$ID; });
			
								if (Object.keys(getFirstNodeResult).length > 0)
								{
									Object.keys(getFirstNodeResult[0].value).map((k, i) => {
										if (getFirstNodeResult[0].value[k] != null && typeof getFirstNodeResult[0].value[k] !== "object" && k !== '$ID' && k !== '$PID') {
											 
											let nodeFirstName = getFirstNodeResult[0].path.substr(getFirstNodeResult[0].path.lastIndexOf('.') + 1);
											
											if (isNaN(parseInt(nodeFirstName)))
											{
												setJsonFirstNodeObjectName(nodeFirstName);		
											}
											else
											{
												nodeFirstName = getFirstNodeResult[0].path.substr(0, getFirstNodeResult[0].path.lastIndexOf('.'));
												nodeFirstName = nodeFirstName.substr(nodeFirstName.lastIndexOf('.') + 1);
		
												if (isNaN(parseInt(nodeFirstName)))
												{
													setJsonFirstNodeObjectName(nodeFirstName);				
												}
											}
		
											// Loads Right side panel on every click
											setFirstNode(getFirstNodeResult[0].value);
											setExpanded('panel1');
										}
									});
											
									getSecondNodeResult = searchObject(currentState.jsonData,
										function (value) { return value !== null && value !== undefined && value.$PID !== 'ROOT' && value.$ID === getFirstNodeResult[0].value.$PID});
			
										if (Object.keys(getSecondNodeResult).length > 0)
										{
											Object.keys(getSecondNodeResult[0].value).map((k, i) => {
												if (getSecondNodeResult[0].value[k] != null && typeof getSecondNodeResult[0].value[k] !== "object" && k !== '$ID' && k !== '$PID') {
		
													let nodeSecondName = getSecondNodeResult[0].path.substr(getSecondNodeResult[0].path.lastIndexOf('.') + 1);
											
													if (isNaN(parseInt(nodeSecondName)))
													{
														setJsonSecondNodeObjectName(nodeSecondName);		
													}
													else
													{
														nodeSecondName = getSecondNodeResult[0].path.substr(0, getSecondNodeResult[0].path.lastIndexOf('.'));
														nodeSecondName = nodeSecondName.substr(nodeSecondName.lastIndexOf('.') + 1);
				
														if (isNaN(parseInt(nodeSecondName)))
														{
															setJsonSecondNodeObjectName(nodeSecondName);	
														}
													}
													// Loads Right side panel on every click
													setSecondNode(getSecondNodeResult[0].value);
													setExpanded('panel1');
												}
											});									
			
											getThirdNodeResult = searchObject(currentState.jsonData,
												function (value) { return value !== null && value !== undefined && value.$ID === getSecondNodeResult[0].value.$PID && value.$PID !== 'ROOT'});
			
												if (Object.keys(getThirdNodeResult).length > 0)
												{
													Object.keys(getThirdNodeResult[0].value).map((k, i) => {
														if (getThirdNodeResult[0].value[k] != null && typeof getThirdNodeResult[0].value[k] !== "object" && k !== '$ID' && k !== '$PID') {
													
															let nodeThirdName = getThirdNodeResult[0].path.substr(getThirdNodeResult[0].path.lastIndexOf('.') + 1);
											
															if (isNaN(parseInt(nodeThirdName)))
															{
																setJsonThirdNodeObjectName(nodeThirdName);		
															}
															else
															{
																nodeThirdName = getThirdNodeResult[0].path.substr(0, getThirdNodeResult[0].path.lastIndexOf('.'));
																nodeThirdName = nodeThirdName.substr(nodeThirdName.lastIndexOf('.') + 1);
						
																if (isNaN(parseInt(nodeThirdName)))
																{
																	setJsonThirdNodeObjectName(nodeThirdName);	
																}
															}
															
															// Loads Right side panel on every click
															setThirdNode(getThirdNodeResult[0].value);
															setExpanded('panel1');
														}										
													});
												}
										}
								}
							}					
						}	
					}
					
				} // PID is ROOT
				else
				{
						getCurrentNodeResult = searchObject(currentState.jsonData,
							function (value) { return value !== null && value !== undefined && value.$PID === 'ROOT'; });
	
							if (Object.keys(getCurrentNodeResult).length > 0)
							{
								getFirstNodeResult = searchObject(currentState.jsonData,
									function (value) { return value !== null && value !== undefined && value.$PID === 'ROOT'; });
									
			
								if (Object.keys(getFirstNodeResult).length > 0)
								{
									Object.keys(getFirstNodeResult[0].value).map((k, i) => {
										if (getFirstNodeResult[0].value[k] != null && typeof getFirstNodeResult[0].value[k] !== "object" && k !== '$ID' && k !== '$PID') {
											
											setJsonFirstNodeObjectName('Root');
											// Loads Right side panel on every click
											setFirstNode(getFirstNodeResult[0].value);
											setExpanded('panel1');
										}
									});
								}
							}
				}
			}
			else
			{
	
						getCurrentNodeResult = searchObject(currentState.jsonData,
							function (value) { return value !== null && value !== undefined && value.$PID === 'ROOT'; });
	
							if (Object.keys(getCurrentNodeResult).length > 0)
							{
								getFirstNodeResult = searchObject(currentState.jsonData,
									function (value) { return value !== null && value !== undefined && value.$PID === 'ROOT'; });
									
			
								if (Object.keys(getFirstNodeResult).length > 0)
								{
									Object.keys(getFirstNodeResult[0].value).map((k, i) => {
										if (getFirstNodeResult[0].value[k] != null && typeof getFirstNodeResult[0].value[k] !== "object" && k !== '$ID' && k !== '$PID') {
		
											setJsonFirstNodeObjectName('Root');
											// Loads Right side panel on every click
											setFirstNode(getFirstNodeResult[0].value);
											setExpanded('panel1');
										}
									});
								}
							}
			}
		
		
	}, [currentNodeState.selectedNodeData]);

	useEffect(() => {

		const parsedJSON = JSON.parse(JSON.stringify(currentUpdatedState.updatedJsonData))
		dispatch(update_complete())
		// dispatch(fetch_json_success(parsedJSON))

		
	}, [currentUpdatedState.updated === true])	

	return (
		<ThemeProvider theme={jsonBuilderTheme}>
			<div className={classes.root}>
				<>
					{currentNodeState.selectedNodeData && currentNodeState.selectedNodeData.$ID !== null ?
						<>
							<Typography color='textSecondary' align='left'></Typography>
							<Grid2 container>
								<Grid2 item xs={12} className="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12"></Grid2>
								{jsonFifthNode && Object.keys(jsonFifthNode).length > 0 ?
									<>
											<Grid2 item xs={12} classname="display_container" >
												<Accordion expanded={expanded === 'panel5'} onChange={handleChange('panel5')}
													className={expanded === 'panel5' ? classes.accordionSection : classes.accordionSectionDisabled}>
													<AccordionSummary
														expandIcon={<ExpandMoreIcon />}
														aria-controls='panel1bh-content'
														id='panel1bh-header'
														className={classes.accordionDetailsSection}>
														<Typography>{(jsonFifthNode.name !== undefined) ? jsonFifthNode.name : jsonFifthNodeObjectName} Properties</Typography>
													</AccordionSummary>
													<AccordionDetails>
														{Object.keys(jsonFifthNode).length > 0 ? <PropertyTree selectedJSON={jsonFifthNode} /> : null}
													</AccordionDetails>
												</Accordion>
											</Grid2>
									</>
									: null}

								{jsonFourthNode && Object.keys(jsonFourthNode).length > 0 ?
									<>
											<Grid2 item xs={12} className="display_container">
												<Accordion expanded={expanded === 'panel4'} onChange={handleChange('panel4')}
													className={expanded === 'panel4' ? classes.accordionSection : classes.accordionSectionDisabled}>
													<AccordionSummary
														expandIcon={<ExpandMoreIcon />}
														aria-controls='panel2bh-content'
														id='panel2bh-header'
														className={classes.accordionDetailsSection}>
														<Typography>{(jsonFourthNode.name !== undefined) ? jsonFourthNode.name : jsonFourthNodeObjectName} Properties</Typography>
													</AccordionSummary>
													<AccordionDetails>
														{Object.keys(jsonFourthNode).length > 0 ? <PropertyTree selectedJSON={jsonFourthNode} /> : null}
													</AccordionDetails>
												</Accordion>
											</Grid2>
									</>
									: null}  

								{jsonThirdNode && Object.keys(jsonThirdNode).length > 0 ?
									<>
											<Grid2 item xs={12} className="display_container">
												<Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}
													className={expanded === 'panel3' ? classes.accordionSection : classes.accordionSectionDisabled}>
													<AccordionSummary
														expandIcon={<ExpandMoreIcon />}
														aria-controls='panel3bh-content'
														id='panel3bh-header'
														className={classes.accordionDetailsSection}>
														<Typography>{(jsonThirdNode.name !== undefined) ? jsonThirdNode.name : jsonThirdNodeObjectName} Properties</Typography>
													</AccordionSummary>
													<AccordionDetails>
														{Object.keys(jsonThirdNode).length > 0 ? <PropertyTree selectedJSON={jsonThirdNode} /> : null}
													</AccordionDetails>
												</Accordion>
											</Grid2>
									</>
									: null}

								{jsonSecondNode && Object.keys(jsonSecondNode).length > 0 ?
									<>
											<Grid2 item xs={12} className="display_container">
												<Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')}
													className={expanded === 'panel2' ? classes.accordionSection : classes.accordionSectionDisabled}>
													<AccordionSummary
														expandIcon={<ExpandMoreIcon />}
														aria-controls='panel4bh-content'
														id='panel4bh-header'
														className={classes.accordionDetailsSection}>
														<Typography>{(jsonSecondNode.name !== undefined) ? jsonSecondNode.name : jsonSecondNodeObjectName} Properties</Typography>
													</AccordionSummary>
													<AccordionDetails>
														{Object.keys(jsonSecondNode).length > 0 ? <PropertyTree selectedJSON={jsonSecondNode} /> : null}
													</AccordionDetails>
												</Accordion>
											</Grid2>
									</>
									: null}

								{jsonFirstNode && Object.keys(jsonFirstNode).length > 0 ?
									<>
											<Grid2 item xs={12} className="display_container">
												<Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}
													className={expanded === 'panel1' ? classes.accordionSection : classes.accordionSectionDisabled}>
													<AccordionSummary
														expandIcon={<ExpandMoreIcon />}
														aria-controls='panel5bh-content'
														id='panel5bh-header'
														className={classes.accordionDetailsSection}>
														<Typography>{jsonFirstNode.name !== undefined ? jsonFirstNode.name : jsonFirstNodeObjectName} Properties</Typography>
														
													</AccordionSummary>
													<AccordionDetails>
														{Object.keys(jsonFirstNode).length > 0 ? <PropertyTree selectedJSON={jsonFirstNode} /> : null}
													</AccordionDetails>
												</Accordion>
											</Grid2>
									</>
									: null} 
							</Grid2>
						</>
						: ''}
				</>
			</div>
		</ThemeProvider>
	);
};

export default PropertyUpdateNew;
