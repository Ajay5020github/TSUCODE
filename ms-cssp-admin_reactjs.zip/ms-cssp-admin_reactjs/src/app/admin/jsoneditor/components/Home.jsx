"use client"
import React, { useState, useEffect, useContext } from 'react';
import { useDispatch } from 'react-redux';
import ViewSection from './ViewSection';
import SmallScreen from './SmallScreen';
import { useStore } from 'react-redux';
// // import { clearJsonData } from '../reducers/jsonReducer';
// // import { clearSelectedNode } from '../reducers/selectedNodeReducer';

import { clear_json } from '../actions';
import { clear_selected_node } from '../selectedNodeActions';
import { clear_updated_json } from '../updatedJsonActions';

import Storage from '../../utils/storage';
export const EditableKeyConext = React.createContext(null);


import { readContentJson } from '../../services/ConfigurePublisherService';

const Home = (props) => {
	const store = useStore();
	const [width, setWidth] = useState(window.innerWidth);
	const breakpoint = 700;
	const dispatch = useDispatch();
	const [editableKeyList, setEditableKeyList] = React.useState([]);
	

	useEffect(() => {		
		dispatch(clear_updated_json());
		dispatch(clear_json());
		dispatch(clear_selected_node());
		
		Storage.removeItem('fileName');

		const handleWindowResize = () => setWidth(window.innerWidth);
		window.addEventListener('resize', handleWindowResize);

		// Return a function from the effect that removes the event listener
		return () => window.removeEventListener('resize', handleWindowResize);
	}, []);

	useEffect(() => {
		const fetchEditableScreen = {
			"jsonScreenName": "enEditableKeys",
			"language": "en"
		};
		/* istanbul ignore next */
		readContentJson(fetchEditableScreen.jsonScreenName).then(response =>  {
			let editableList = [];
			if(response && response.statusCode && response.statusCode === 200) {
				if(response.bodyJSON && response.bodyJSON.data && response.bodyJSON.data.editableKeys) {
					
					response.bodyJSON.data.editableKeys.length && 
					response.bodyJSON.data.editableKeys.forEach(element => {
						editableList.push(element.key);						
					});

					setEditableKeyList(editableList);
				}
			}
		});

		
	}, [editableKeyList.length === 0]);

	return width < breakpoint ?
		<SmallScreen/> :
		<EditableKeyConext.Provider value={editableKeyList}>
			<ViewSection publishLabelData={props.publishLabelData} />
		</EditableKeyConext.Provider>;
};

export default Home;
