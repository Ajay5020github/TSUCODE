
"use client"
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Grid2, Paper } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import TreeOther from './TreeOther';
import PropertyUpdateNew from './PropertyUpdateNew';
import { jsonBuilderTheme } from '../themes/JsonBuilderTheme';
import { ThemeProvider } from '@mui/system';
// import { fetchJsonSuccess } from '../reducers/jsonReducer';
import { fetch_json_success, clear_json } from '../actions';
import { searchObject } from '../components/helper/helper';
import '../../containers/custom.css';
// import { clearSelectedNode } from '../reducers/selectedNodeReducer';
import { clear_selected_node } from '../selectedNodeActions';

const useStyles = makeStyles({
    root: {
        flexGrow: 1
    },
    pageContent: {
        margin: jsonBuilderTheme.spacing(1),
        padding: jsonBuilderTheme.spacing(1),
        backgroundColor: jsonBuilderTheme.palette.pageContent.main,
        borderRadius: '0px',
        height: 'calc(100vh - 100px)'
    },
    paper: {
        padding: jsonBuilderTheme.spacing(2),
        textAlign: 'center',
        color: jsonBuilderTheme.palette.text.secondary,
        height: 'calc(100vh - 115px)',
        overflow: 'auto',
        borderRadius: '0px'
    }
});

const Editor = () => {
    const classes = useStyles();
	const currentState = useSelector(state => state.jsonReducer.present);
	const dispatch = useDispatch();

	const checkROOT = searchObject(currentState.jsonData, function (value) {
		return value !== null && value !== undefined && value.$ID === 'ROOT'; });
        const currentStatestringfy =JSON.stringify(currentState.jsonData)
        const Jsonparse =JSON.parse(currentStatestringfy)
	useEffect(() => {		
        dispatch(clear_selected_node());
		dispatch(fetch_json_success(Jsonparse));		
	},[checkROOT.length === 0]);

    return (
        <ThemeProvider theme={jsonBuilderTheme}>
            <>
                <Paper>
                    <Grid2 container>
                        <Grid2 className="MuiGrid-grid-xs-4" item xs={4}>
                            <Paper variant="elevation" className={`${classes.paper} leftJSONEditor jss721`}>
                                {currentState.jsonData && Object.keys(currentState.jsonData).length > 0 ? (
                                    <TreeOther data={currentState.jsonData} />
                                ) : null}
                            </Paper>
                        </Grid2>
                        <Grid2 className="MuiGrid-grid-xs-8" item xs={8}>
                            <Paper className={`${classes.paper} jss721`}>
                                <PropertyUpdateNew />
                            </Paper>
                        </Grid2>
                    </Grid2>
                </Paper>
            </>
        </ThemeProvider>
    );
};

export default Editor;