"use client"

import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { AppBar, Tabs, Tab, Box, Typography, Grid2 } from '@mui/material';
import { styled, ThemeProvider } from '@mui/system';
import Header from './Header';
import PropTypes from 'prop-types';
import Editor from './Editor';
import { JsonView } from './JsonView/';
import { jsonBuilderTheme } from '../themes/JsonBuilderTheme';
import { RemoveParentId } from '../components/helper/helper';
import './customJson.css';

// Styled components (replacing makeStyles)
const Root = styled(AppBar)({
    flexGrow: 0,
    flex: 0
});

const StyledTabs = styled(Tabs)(({ theme }) => ({
    backgroundColor: theme.palette.viewSectiontab.main,
    minHeight: '20px',
    color: theme.palette.contentColor.white,
    '& div.MuiTabs-scroller': {
        position: 'inherit'
    },
    '& .MuiTabs-indicator': {
        display: 'none'
    },
    '& .Mui-selected ': {
        borderBottom: `2px solid ${theme.palette.viewSectiontab.border}`,
        borderRadius: '1px',
        boxShadow: `1px 2px 3px ${theme.palette.viewSectiontab.boxshadow}`
    },
    '& .MuiPaper-rounded': {
        border: '1px solid rgb(0 0 0 / 20%)',
        boxShadow: '0px 0px 0px 0px transparent'
    }
}));

const TabButton = styled(Tab)({
    minHeight: '34px',
    fontSize: '12px',
    fontFamily: ['Open Sans', 'sans-serif'].join(',')
});

/*************** Tab view *************** */
const TabPanel = ({ children, value, index, ...other }) => {
    return (
        <div
            role='tabpanel'
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={0}>
                    <Typography component={'div'}>{children}</Typography>
                </Box>
            )}
        </div>
    );
};

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired
};

const a11yProps = (index) => ({
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`
});

/************************************** */
const ViewSection = (props) => {
    const [value, setValue] = useState(0);
    const [btnDisabled, setBtnDisabled] = useState(true);

    const handleChange = (_, newValue) => {
        setValue(newValue);
    };

    const currentState = useSelector(state => state?.jsonReducer?.present);
    const tempJson = useSelector(state => state?.jsonReducer?.present?.tempJson);
    const jsonSchemaStatus = useSelector(state => state?.jsonReducer?.present?.jsonSchemaStatus);

    useEffect(() => {
        if (currentState.jsonData && Object.keys(currentState.jsonData).length === 0 && tempJson.length === 0) {
            setBtnDisabled(true);
            setValue(0);
        } else if (currentState.jsonData && Object.keys(currentState.jsonData).length > 0 && tempJson.length > 0) {

            setBtnDisabled(false);
            setValue(1);
        } else if (currentState.jsonData && Object.keys(currentState.jsonData).length > 2) {
            setBtnDisabled(false);
        }
    }, [currentState.jsonData, tempJson]);

    return (
            <form>
                <Grid2 container>
                    <Grid2 item>
                        <Header publishLabelData={props.publishLabelData} />
                    </Grid2>
                    <Grid2 item xs={12} sx={{ width: "100vw", maxWidth: "100%"}}>
                        <Root position='static'>
                            <StyledTabs value={value} onChange={handleChange}>
                                <TabButton
                                    disabled={btnDisabled}
                                    label={props.publishLabelData?.content?.labels?.config?.treeView}
                                    {...a11yProps(0)}
                                />
                                <TabButton
                                    disabled={btnDisabled}
                                    label={props.publishLabelData?.content?.labels?.config?.jsonView}
                                    {...a11yProps(1)}
                                />
                            </StyledTabs>
                        </Root>
                        <TabPanel value={value} index={0}>
                            <Editor />
                        </TabPanel>
                        <TabPanel value={value} index={1}>
                            <JsonView
                                JsonData={
                                    currentState?.properJSON === false
                                        ? tempJson
                                        : RemoveParentId(currentState?.jsonData, '$ID', '$PID')
                                }
                            />
                        </TabPanel>
                    </Grid2>
                </Grid2>
            </form>
    );
};

export default ViewSection;
