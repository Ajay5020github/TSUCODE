"use client"

import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, Button } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import TextField from '@mui/material/TextField';

// import { fetchJsonSuccess } from '../reducers/jsonReducer';
// import { clearSelectedNode } from '../reducers/selectedNodeReducer';
// import { clearUpdatedJsonData, saveJsonSuccessful } from '../reducers/updatedJsonReducer';

import { fetch_json_success } from '../actions';
import { clear_selected_node } from '../selectedNodeActions';
import { clear_updated_json, json_file_save_successful } from '../updatedJsonActions';

import { ErrorMessage } from '../components/helper/ErrorMessage'
// Configure Publiher Service
import { saveJson } from '../../services/ConfigurePublisherService';
import Storage from '../../utils/storage';
import { RemoveParentId } from '../components/helper/helper';
import MessageFromAPI from './MessageFromAPI';

const useStyles = makeStyles({
    root: {
        width: '450px',
        minHeight: '450px',
        borderRadius: '3px',
        fontFamily: 'Open Sans',
        boxShadow: '0px 0px 18px #00000036',
    },
    messageDialog : {
        width: '430px',
        borderRadius: '3px',
        minHeight: '330px',
        fontFamily: 'Open Sans',
        boxShadow: '0px 0px 18px #00000036',
    },
    closeButton: {
        position: 'absolute',
        right: '10px',
        top: '10px',
        color: '#274463'
    },
    dialogTitle: {
        color: '#274463',
        fontSize: '30px',
        fontWeight: 'bold',
    },
    formControl: {
        minWidth: 130,
    },
    btnCancel: {
        backgroundColor: '#fff',
        border: '1px solid #274463',
        marginRight: '20px',
        padding: '10px 18px',
        borderRadius: '3px',
        color: '#274463',
        fontWeight: 'bold',
        textTransform: 'none',
    },
    btnOK: {
        backgroundColor: '#274463',
        border: '1px solid #274463',
        padding: '10px 48px',
        borderRadius: '3px',
        fontWeight: 'bold',
        textTransform: 'none',
        '&:hover': {
            backgroundColor: '#274463',
            border: '1px solid #274463',
            color: '#fff'
        },
    },
    formControlWrap: {
        display: 'flex',
        justifyContent: 'space-between',
        marginTop: '40px'
    },
    formOpen: {
        display: 'flex',
        flexDirection: 'column',
    },
    btnWrap: {
        display: 'flex',
        justifyContent: 'flex-end',
        fontSize: '21px',
        marginTop: '100px',
        fontFamily: 'Open Sans'
        
    },
    dropdownStyle: {
        borderRadius: 0,
        /* "& ul": {
            
        }, */
        '& li': {
            fontSize: 14,
        },
    },
    formSelect: {
        fontSize: 14
    },
    inputRad: {
        backgroundColor: '#fff',
        borderRadius: '0px',
        boxShadow: '0px 1px 9px #00000029',
        color: '#000',
        '&.Mui-focused': {
            backgroundColor: '#fff',
            boxShadow: '0px 1px 11px #00000029',
            color: '#000 !important',
        },
        '&:hover' : {
            backgroundColor: '#fff',
            boxShadow: '0px 1px 11px #00000029',
        },
        '&:hover:before': {
            borderBottom: '0px'
        },
        "&::before" : {
            borderBottom: '0px'
        }
    }
});

const SaveToDatabase = ({ saveFileDialog, handleCloseSaveFile, labels,  buttons }) => {

    const dispatch = useDispatch();
    const classes = useStyles();
    const currentState = useSelector(state => state.jsonReducer.present);
    
    const currentUpdatedState = useSelector(state => state.updatedJsonReducer);

    
    const [openDialog, setOpenDialog] = useState(saveFileDialog);
    const [title, setTitle] = useState(labels.changeCommentLabel);
    const [dialogClasss, setDialogClass] = useState('root')
    const [jsonComments, setJsonComments] = useState('');

    // Error State
    const [isValid, setIsValid] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    // ScreenName and Language
    // fetch STorage Items
    const fileName = Storage.getItem('fileName');
    const languageId = Storage.getItem('languageId');
    const screenName = Storage.getItem('screenName');

    // Handle Error
    /* istanbul ignore next */
    const handleError = (status, errorMsg) => {
        setErrorMessage(errorMsg);
    };

    // Set Selected Screen Name onchange
    /* istanbul ignore next */
    const handleCommentsChange = (event) => {
        setJsonComments(event.target.value);
    }

    // Submit Form Data
    /* istanbul ignore next */
    const submitFormData = (event) => {
        event.preventDefault();
        if (jsonComments !== '') {

            let jsonData = '';

            if (currentUpdatedState.updated === true)
            {
                jsonData = currentUpdatedState.updatedJsonData;
            }
            else
            {
                jsonData = currentState.jsonData;
            }
            
            let saveJsondata = {
                "jsonScreenName": screenName,
                "language": languageId,
                "comments": jsonComments,
                "json": RemoveParentId(jsonData, '$ID', '$PID'),
                "jsonFileName": fileName
            };
            
            saveJsonToAPI(saveJsondata);
        }
    }
    
    /* istanbul ignore next */
    const saveJsonToAPI = (saveJsondata) => {
        saveJson(saveJsondata)
            .then(response => {
                if (response.statusCode === 200 && response.success === true) {
                    if(Object.keys(response.body.json).length !== 0) {   
                        dispatch(clear_updated_json());
                        dispatch(clear_selected_node());
                        dispatch(json_file_save_successful());
                        dispatch(fetch_json_success(response.body.json));

                        // try { window.appInsights.trackEvent('Admin - Save JSON', { 'pageName': "Configuration Publisher" }, { 'adminUserId': Storage.getItem('adminUserId')  }); }
                        // catch { }
                        
                    }
                    setDialogClass('messageDialog')
                    setTitle(labels.saveJSONLabel);
                    setSuccessMessage(`${fileName} ${labels.savedFileText}`);
                    //handleDialogClose();
                } else {
                    handleError(true, response.message);
                }
               // handleDialogClose();
            });
    }

    /* istanbul ignore next */
    const handleDialogClose = () => {
        setOpenDialog(false);
        handleCloseSaveFile(false);
    };

    return (<>
        {openDialog ?
            <>
                <Dialog fullWidth={false}
                    id='dialogURL'
                    open={openDialog} onClose={handleDialogClose}
                    // classes = { dialogClasss === 'root' ? { paperWidthSm: classes.root }  : { paperWidthSm: classes.messageDialog } }
                    sx={{
                        "& .MuiDialog-paper": { 
                        //   width: "500px", // Set width
                        //   height: "350px", // Set height
                          maxWidth: "none" // Prevent default max-width behavior
                        }
                      }}  
                      className='SaveJsonPopup'
                >
                  <DialogTitle id="customized-dialog-title">
                            <h6 sx={{ color: '#274463', fontSize: '30px', fontWeight: 'bold' }}>{title}</h6>
                            <IconButton
                                aria-label="close"
                                sx={{
                                    position: 'absolute',
                                    right: '10px',
                                    top: '10px',
                                    color: '#274463'
                                }}
                                onClick={handleDialogClose}
                                size="large">
                                <CloseIcon />
                            </IconButton>
                        </DialogTitle>

                        <DialogContent className="open-cloud-dialog">
                            {errorMessage && <ErrorMessage errorMessage={errorMessage} />}
                            {successMessage !== '' ?
                            <MessageFromAPI filename={fileName} message={successMessage} handleDialogClose={handleDialogClose} />
                            :
                            <>
                            <form onSubmit={submitFormData} sx={{ display: 'flex', flexDirection: 'column' }}>
                                <div sx={{ display: 'flex', justifyContent: 'space-between', marginTop: '40px' }}>
                                    <label style={{position:"absolute", "left":"-10000px",
                                    top:"auto", width:"1px", height:"1px", overflow:"hidden"
                                    }} for="outlined-multiline-static">.</label>
                                        <TextField
                                            id="outlined-multiline-static"
                                            placeholder={labels.enterComments}
                                            multiline
                                            rows={4}
                                            value={jsonComments}
                                            variant="filled"
                                            onChange={handleCommentsChange}
                                            fullWidth
                                            required
                                            InputProps={{ sx : {
                                                backgroundColor: '#fff',
                                                borderRadius: '0px',
                                                boxShadow: '0px 1px 9px #00000029',
                                                color: '#000',
                                                '&.Mui-focused': {
                                                    backgroundColor: '#fff',
                                                    boxShadow: '0px 1px 11px #00000029',
                                                    color: '#000 !important',
                                                },
                                                '&:hover' : {
                                                    backgroundColor: '#fff',
                                                    boxShadow: '0px 1px 11px #00000029',
                                                },
                                                '&:hover:before': {
                                                    borderBottom: '0px'
                                                },
                                                "&::before" : {
                                                    borderBottom: '0px'
                                                }
                                            }
                                            }}       
                                            inputProps= {{ maxLength: 50 }}                                     
                                        />
                                </div>
                                <Box sx = {{ display: 'flex', 
												justifyContent: 'flex-end', 
												fontSize: '21px', 
												marginTop: '70px', 
												fontFamily: 'Open Sans', 
												marginBottom: '20px' }}>
                                    <Button onClick={handleDialogClose} variant='outlined' color="primary" 
                                        sx={{
                                            backgroundColor: '#fff',
                                            border: '1px solid #274463',
                                            marginRight: '20px',
                                            padding: '10px 18px',
                                            borderRadius: '3px',
                                            color: '#274463',
                                            fontWeight: 'bold',
                                            textTransform: 'none',
                                        }}>
                                    {buttons.cancelButton}
                                    </Button>
                                    <Button variant='outlined' color="primary" type="submit" 
                                        sx={{
                                            backgroundColor: '#274463',
                                            border: '1px solid #274463',
                                            padding: '10px 48px',
                                            borderRadius: '3px',
                                            fontWeight: 'bold',
                                            textTransform: 'none',
                                            '&:hover': {
                                                backgroundColor: '#274463',
                                                border: '1px solid #274463',
                                                color: '#fff'
                                            },
                                        }} >
                                        {buttons.okButton}
                                    </Button>
                                </Box>
                            </form>
                            </>
                            }
                        </DialogContent>
                </Dialog>
        </>
    : null}
    </>);
};

export default SaveToDatabase;
