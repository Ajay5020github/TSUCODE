import { createSlice } from "@reduxjs/toolkit";
import { desimplify, add, remove } from '../../utils/simplifr';

// Action Types
export const SELECTED_NODE_JSON = "SELECTED_NODE_JSON";
export const CLEAR_SELECTED_NODE = "CLEAR_SELECTED_NODE";

// Initial State
const initialState = {
    selectedNodeData: [],
    nodeSelected: false
};

// Create Slice with extraReducers
const selectedNodeSlice = createSlice({
    name: "selectedNode",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(SELECTED_NODE_JSON, (state, action) => {
                return {
                    ...state,
                    selectedNodeData: action.selectedNodeData,
                    nodeSelected: true
                };
            })
            .addCase(CLEAR_SELECTED_NODE, (state) => {
                return {
                    ...state,
                    selectedNodeData: [],
                    nodeSelected: false
                }
            });
    }
});

// Export Reducer
export default selectedNodeSlice.reducer;
