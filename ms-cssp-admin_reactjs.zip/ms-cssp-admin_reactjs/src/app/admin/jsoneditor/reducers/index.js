import jsonReducer from './jsonReducer';
import selectedNodeReducer from './selectedNodeReducer';
import updatedJsonReducer from './updatedJsonReducer';
import { combineReducers } from 'redux';

import undoable from 'redux-undo';
const allReducers = combineReducers({
	jsonReducer: undoable(jsonReducer, {
		limit: 25
	}),
	selectedNodeReducer,
	updatedJsonReducer
});

export default allReducers;
