import { createSlice } from '@reduxjs/toolkit';
import { update } from '../../utils/simplifr';
import { simplify, desimplify } from '../../utils/simplifr';
import { convertToJson } from '../components/helper/helper';

// Action Types
export const UPDATE_JSON = 'UPDATE_JSON';
export const SAVE_CODE_JSON = 'SAVE_CODE_JSON';
export const CLEAR_UPDATED_JSON_DATA = 'CLEAR_UPDATED_JSON_DATA';
export const SAVE_JSON_SUCCESSFUL = 'SAVE_JSON_SUCCESSFUL';
export const SAVE_JSON_FAILED = 'SAVE_JSON_FAILED';
export const UPDATE_COMPLETE = 'UPDATE_COMPLETE';

// Initial State
const initialState = {
    updatedJsonData: [],
    updated: false,
    properJSON: false,
    codeView: false,
    jsonSaved: false
};

// Create Slice with extraReducers
const updatedJsonSlice = createSlice({
    name: 'updatedJson',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(UPDATE_JSON, (state, action) => {
                let updatedJSON = '';

                Object.keys(action.payload).map((key) => {
                    if (key === 'root' + action.path + '.' + action.key)
                    {
                        const data = action.payload;
                        updatedJSON = update(data, 'root' + action.path, action.json);
                    }
                });

                return {
                    ...state,                    
                    updatedJsonData: desimplify({...updatedJSON}),
                    updated: true,
                    jsonSaved: false
                                       
                };
            })
            .addCase(SAVE_CODE_JSON, (state, action) => {
                const jsonPayload = action.payload;

                return {
                    ...state,                    
                    updatedJsonData: jsonPayload,                    
                    updated: true,
                    codeView: true
                 };	
            })
            .addCase(CLEAR_UPDATED_JSON_DATA, (state) => {
                return {			
                    updatedJsonData: [],
                    updated: false,    
                    properJSON: false,
                    codeView: false
                 };
            })
            .addCase(SAVE_JSON_SUCCESSFUL, (state) => {
                return {
                    ...state,
                    jsonSaved: true
                }
            })
            .addCase(UPDATE_COMPLETE, (state) => {                
                return {
                    ...state,
                    updated: false
                } 
            })
            .addCase(SAVE_JSON_FAILED, (state) => {
                return {
                    ...state,
                    jsonSaved: false
                } 
            });
    }
});

// Export Reducer
export default updatedJsonSlice.reducer;
