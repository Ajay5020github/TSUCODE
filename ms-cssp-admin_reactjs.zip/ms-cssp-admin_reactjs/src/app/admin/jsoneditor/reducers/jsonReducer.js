import { createSlice } from '@reduxjs/toolkit';
import { desimplify, add, remove } from '../../utils/simplifr';
import { convertToJson, RemoveParentId } from '../components/helper/helper';
import { update } from '../../utils/simplifr';

// Action Types
export const FETCH_JSON_REQUEST = 'FETCH_JSON_REQUEST';
export const FETCH_JSON_SUCCESS = 'FETCH_JSON_SUCCESS';
export const FETCH_JSON_FAILURE = 'FETCH_JSON_FAILURE';
export const CLEAR_JSON_DATA = 'CLEAR_JSON_DATA';
export const ADD_OBJECT_JSON = 'ADD_OBJECT_JSON';
export const ADD_NODE_JSON = 'ADD_NODE_JSON';
export const REMOVE_OBJECT_JSON = 'REMOVE_OBJECT_JSON';
export const REMOVE_NODE_JSON = 'REMOVE_NODE_JSON';
export const SAVE_JSON_SCHEMA = 'SAVE_JSON_SCHEMA';
export const SAVE_JSON_SCHEMA_STATUS = 'SAVE_JSON_SCHEMA_STATUS';
export const SAVE_CODE_JSON = 'SAVE_CODE_JSON';
export const SET_TEMP_JSON_VALUE = 'SET_TEMP_JSON_VALUE';
export const SAVE_TEMP_JSON = 'SAVE_TEMP_JSON';
export const NOT_PROPER_JSON = 'NOT_PROPER_JSON';
export const SAVE_JSON_SCHEMA_READONLY = 'SAVE_JSON_SCHEMA_READONLY';
export const JSON_VIEW_UPDATED_VALUE = 'JSON_VIEW_UPDATED_VALUE';
export const SET_JSON_VIEW_VALUE = 'SET_JSON_VIEW_VALUE';
export const UPDATE_JSON_DATA = 'UPDATE_JSON_DATA';
export const GET_UPDATED_JSON_DATA = 'GET_UPDATED_JSON_DATA';
export const SET_UPDATED_JSON_DATA = 'SET_UPDATED_JSON_DATA';

// Initial State
let initialState = {
    loading: false,
    jsonData: [],
    tempJson: [],
    jsonSchemaData: [],
    JsonSchemaStatus: 0,
    jsonSchemaReadOnlyData: [],
    error: '',
    updated: false,
    properJSON: false,
    jsonView: false
};

// Create Slice with extraReducers
let jsonSlice = createSlice({
    name: 'json',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(FETCH_JSON_REQUEST, (state) => {
                return {
                    ...state
                };
            })
            .addCase(FETCH_JSON_SUCCESS, (state, action) => {
                const payload = convertToJson(action.payload);
                let properJSONValue = false;

                if (state.tempJson.length > 0)
                {
                    properJSONValue = false;
                }
                else
                {
                    properJSONValue = true;
                }

                return {
                    ...state,                    
                    loading: false,
                    jsonData: payload,			
                    error: '',
                    updated: false,
                    properJSON: properJSONValue,
                    jsonView: false
                };
            })
            .addCase(FETCH_JSON_FAILURE, (state, action) => {
                return {
                    ...state,
                    loading: false,
                    jsonData: [],
                    error: action.payload,
                    updated: false
                };
            })
            .addCase(SET_UPDATED_JSON_DATA, (state, action) => {
                let updatedJSON = '';
                
                Object.keys(action.payload).map((key) => {
                    if (key === 'root' + action.path + '.' + action.key)
                    {
                        const data = action.payload;
                        updatedJSON = update(data, 'root' + action.path, action.json);
                    }
                });

                return {
                    ...state,                    
                    jsonData: desimplify({...updatedJSON})
                };
            })
            .addCase(CLEAR_JSON_DATA, (state) => {
                return {			
                    loading: false,
                    jsonData: [],
                    tempJson: [],
                    jsonSchemaData: [],	
                    JsonSchemaStatus: 0,
                    jsonSchemaReadOnlyData:[],
                    error: '',
                    updated: false,
                    properJSON: false,
                    jsonView: false
                };
            })
            .addCase(ADD_OBJECT_JSON, (state, action) => {
                let jsonUpdatedObjects = '';
                let updatedJsonObjects = '';

                const dataPayload = action.payload;
                let jsonNewObject = '';

                if (action.typeOfObject === 'ArrayObject')
                {
                    jsonNewObject = action.jsonToAdd;
                }
                else if (action.typeOfObject === 'Object')
                {
                    jsonNewObject = {fields: [action.jsonToAdd]};
                }

                jsonUpdatedObjects = add(dataPayload, 'root' + action.path, jsonNewObject);
                
                updatedJsonObjects = desimplify(jsonUpdatedObjects);

                return {
                    ...state,
                    jsonData: updatedJsonObjects
                };
            })
            .addCase(ADD_NODE_JSON, (state, action) => {
                let jsonAfterAddition = '';
                const jsonObject = {[action.jsonToAdd.newJSON.jsonKey]: action.jsonToAdd.newJSON.jsonValue};

                const dataAdd = action.payload;
                jsonAfterAddition = add(dataAdd, 'root' + action.path, jsonObject);

                return {
                    ...state,
                    jsonData: desimplify(jsonAfterAddition)
                };
            })
            .addCase(REMOVE_OBJECT_JSON, (state, action) => {
                let jsonAfterRemoval = '';

                const dataObject = action.payload;

                jsonAfterRemoval = remove(dataObject, 'root' + action.path);

                return {
                    ...state,
                    jsonData: desimplify(jsonAfterRemoval)
                };
            })
            .addCase(REMOVE_NODE_JSON, (state, action) => {
                let jsonNodesAfterRemoval = '';

                const dataNode = action.payload;
                jsonNodesAfterRemoval = remove(dataNode, 'root' + action.path);

                return {
                    ...state,
                    jsonData: desimplify(jsonNodesAfterRemoval)
                };
            })
            .addCase(SAVE_JSON_SCHEMA, (state, action) => {
                return {
                    ...state,
                    loading: false,
                    jsonSchemaData: action.payload,
                    error: '',
                    updated: false,
                    jsonSchemaStatus: action.status
                };
            })
            .addCase(SAVE_JSON_SCHEMA_STATUS, (state, action) => {
                return {
                    ...state,
                    loading: false,
                    jsonSchemaStatus: action.payload,
                    error: '',
                    updated: false
                };
            })
            .addCase(SAVE_CODE_JSON, (state, action) => {
                const jsonPayload = convertToJson(action.payload);
                let jsonProper = false;

                if (state.tempJson.length > 0)
                {
                    jsonProper = false;
                }
                else
                {
                    jsonProper = true;
                }

                return {
                    ...state,
                    loading: false,
                    jsonData: jsonPayload,			
                    error: '',
                    updated: true,
                    properJSON: jsonProper
                };	
            })
            .addCase(SET_TEMP_JSON_VALUE, (state) => {
                return {
                    ...state,
                    tempJson: [],
                    properJSON: true
                };
            })
            .addCase(SAVE_TEMP_JSON, (state, action) => {
                return {
                    ...state,
                    tempJson: action.payload,
                    properJSON: false
                };
            })
            .addCase(NOT_PROPER_JSON, (state) => {
                return {
                    ...state,
                    jsonData: [],
                    properJSON: false
                };
            })
            .addCase(SAVE_JSON_SCHEMA_READONLY, (state, action) => {
                return {
                    ...state,
                    loading: false,
                    jsonSchemaReadOnlyData: action.payload,
                    error: '',
                    updated: false
                };
            })
            .addCase(JSON_VIEW_UPDATED_VALUE, (state) => {
                return {
                    ...state,
                    updated: true
                }
            })
            .addCase(UPDATE_JSON_DATA, (state, action) => {
                const payload = action.payload;
                let properJSONValue = false;

                if (state.tempJson.length > 0)
                {
                    properJSONValue = false;
                }
                else
                {
                    properJSONValue = true;
                }

                return {
                    ...state,
                    loading: false,
                    jsonData: payload,			
                    error: '',
                    updated: false,
                    properJSON: properJSONValue,
                    jsonView: false
                };                  
            })
            .addCase(GET_UPDATED_JSON_DATA, (state, action) => {
                return {
                    ...state,
                    loading: false,
                    jsonData: convertToJson(RemoveParentId(action.payload, "$ID", "$PID"))
                };
            })
            .addCase(SET_JSON_VIEW_VALUE, (state) => {
                return {
                    ...state,
                    jsonView: true
                }
            });
    }
});

// Export Reducer
export default jsonSlice.reducer;
