/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Gets the configuration publisher data
 */

import CONFIG from '../../config/index';
import { configPublishService } from './configurationsPublisherService';
import * as types from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import 'cross-fetch/polyfill';

// Start fetching the data.
export const fetchConfigPublishDataBegin = () => ({
	type: types.FETCH_CONFIG_PUBLISH_DATA_BEGIN
});

// Data fetching the successful.
export const fetchConfigPublishDataSuccess = data => ({
	type: types.FETCH_CONFIG_PUBLISH_DATA_SUCCESS,
	payload: { data }
});

// Data fetching the failed.
export const fetchConfigPublishDataFailure = error => ({
	type: types.FETCH_CONFIG_PUBLISH_DATA_FAILURE,
	payload: { error }
});

export const fetchConfigPublishData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	/* istanbul ignore next */
	return dispatch => {
		/* istanbul ignore next */
		dispatch(fetchConfigPublishDataBegin());
		/* istanbul ignore next */
		return new Promise(resolve => {
			configPublishService(languageId, stateId)
				.then(configPublishData => {
					dispatch(
						fetchConfigPublishDataSuccess(
							configPublishData.data
						)
					);
					resolve();
					return configPublishData.data;
				})
				.catch(() => {
					dispatch(
						fetchConfigPublishDataFailure(
							ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
};


