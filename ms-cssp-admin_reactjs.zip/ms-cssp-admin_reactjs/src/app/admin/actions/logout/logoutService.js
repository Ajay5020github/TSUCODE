import https from 'https';
import axios from 'axios';
import CONFIG from '../../config/index';
import Storage from '../../utils/storage';
import * as types from '../actionTypes';

export const clear_search_details = () => ({
	type: types.CLEAR_SEARCH_DETAILS
});

export const logoutService = () => {
	const agent = new https.Agent({
		rejectUnauthorized: true
	});

	// Fake token is verified by node.js service
	const authToken = {
		authToken: Storage.getItem('authToken'),
		userId: Storage.getItem("adminUserId"),
		department: Storage.getItem("loginType")
	};
	const headers = {
		contentType: 'application/json'
	};
	const endPoint = `${CONFIG.api.nodeUrl}/adminService/logout`;
	//let queryParams = `?authToken=${authToken}`;
	
	return axios
	.post(endPoint, authToken, { httpsAgent: agent, headers })
	.then(response => {
		response.data;
		clear_search_details();

	})
	.catch(error => {
	});
	
};
