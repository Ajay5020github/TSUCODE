
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Sets the loader text.
 */

import * as types from '../actionTypes';

export const setLoaderText = text => ({
	type: types.SET_LOADER_TEXT,
	payload: { text }
});
