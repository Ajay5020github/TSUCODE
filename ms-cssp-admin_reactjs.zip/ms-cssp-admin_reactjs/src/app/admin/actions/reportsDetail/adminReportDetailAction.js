/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Gets the Admin Report data
 */

import CONFIG from '../../config/index';
import { adminReportDetailService } from './adminReportDetailService';
import * as types from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import 'cross-fetch/polyfill';

// Start fetching the data.
export const fetchAdminReportDetailDataBegin = () => ({
	type: types.FETCH_ADMIN_REPORT_DETAIL_DATA_BEGIN
});

// Data fetching the successful.
export const fetchAdminReportDetailDataSuccess = data => ({
	type: types.FETCH_ADMIN_REPORT_DETAIL_DATA_SUCCESS,
	payload: { data }
});

// Data fetching the failed.
export const fetchAdminReportDetailDataFailure = error => ({
	type: types.FETCH_ADMIN_REPORT_DETAIL_DATA_FAILURE,
	payload: { error }
});

export const fetchAdminReportDetailData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	return dispatch => {
		dispatch(fetchAdminReportDetailDataBegin());
		return new Promise(resolve => {
			adminReportDetailService(languageId, stateId)
				.then(adminReportDetailData => {
					dispatch(
						fetchAdminReportDetailDataSuccess(
							adminReportDetailData.data
						)
					);
					resolve();
					return adminReportDetailData.data;
				})
				.catch(() => {
					dispatch(
						fetchAdminReportDetailDataFailure(
							ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
};


