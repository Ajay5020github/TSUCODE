/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Gets the configuration publisher data
 */

import CONFIG from '../../config/index';
import { userAuthService } from './userAuthService';
import * as types from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import 'cross-fetch/polyfill';
import { viewUserService } from '../../services/UserService';

// Start fetching the data.
export const userAuthDataBegin = () => ({
	type: types.FETCH_USER_AUTH_DATA_BEGIN
});

// Data fetching the successful.
export const userAuthDataSuccess = data => ({
	type: types.FETCH_USER_AUTH_DATA_SUCCESS,
	payload: { data }
});

// Data fetching the failed.
export const userAuthDataFailure = error => ({
	type: types.FETCH_USER_AUTH_DATA_FAILURE,
	payload: { error }
});

//sai kiran added userdetails to store
export const userAuthDataSuccesski = data => ({

	type: types.AUTH_DETAIL,
	payload: { data },
	
});
//@sai kiran calling userauth action redux
export const authdetils = function (data,dispatch){
	dispatch(userAuthDataSuccesski(data));
}

/* istanbul ignore next */
export const fetchUserAuthData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	return dispatch => {
		dispatch(userAuthDataBegin());
		return new Promise(resolve => {
			userAuthService(languageId, stateId)
				.then(userDetailsData => {
					dispatch(
						userAuthDataSuccess(
							userDetailsData.data
						)
					);
					resolve();
					return userDetailsData.data;
				})
				.catch(() => {
					dispatch(
						userAuthDataFailure(
							ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
};


// Fetch User details Succes
export const singleUserAuthSuccess = data => ({
	type: types.FETCH_SINGLE_USER_AUTH_DETAILS_SUCCESS,
	payload: { data }
});

//Failure
export const singleUserAuthError = error => ({
	type: types.FETCH_SINGLE_USER_AUTH_FAILURE,
	payload: { error }
});

// Reset
export const ClearUserAuth = () => ({
	type: types.CLEAR_USER_AUTH,
	payload: {
		singleSelectedUser: {},
		userDetailsData: {}
	}
});



/* istanbul ignore next */
// Stored Selected data
export const storeSelectedUserAUTHData = data => ({
	type: types.STORE_SELECTED_USER_AUTH,
	payload: { data }
});

/* istanbul ignore next */
export const fetchViewUserAuthAction = (userDetail) => {
	return dispatch => {
		dispatch(
			storeSelectedUserAUTHData(JSON.parse(JSON.stringify(userDetail)))
		);
		return new Promise(resolve => {
			viewUserService(userDetail).then(response =>  {
				dispatch(singleUserAuthSuccess(response))
				resolve(response)
				return response.body;				
			})
			.catch(() => {
				dispatch(
					singleUserAuthError('NOT FOUND')
				)
			});
		});
	};
}

