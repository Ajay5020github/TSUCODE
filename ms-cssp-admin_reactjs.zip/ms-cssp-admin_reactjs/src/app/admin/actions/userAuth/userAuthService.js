/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Gets the configuration json for the
 * user details.
 */

import https from 'https';
import axios from 'axios';
import CONFIG from '../../config/index';
import Storage from '../../utils/storage';

// Gets seperate json based on language id and state id.
export const userAuthService = (languageId, stateId) => {
	const agent = new https.Agent({
		rejectUnauthorized: true
	});

	// Fake token is verified by node.js service
	const headers = {
		token: CONFIG.fakeToken,
		authToken: Storage.getItem('authToken')
	};

	const requestBody = {		
		"userId":  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		"authToken": Storage.getItem('authToken'),
		"department": Storage.getItem("loginType"),
		"screenName": "AdminPortalUserAuth",
		"id": Storage.getItem('sid')
	};

	//need to chnge after  gettin azur service url
	const endpoint = `${CONFIG.api.nodeUrl}/fetchConfigJson`;	
	
	return axios
		.post(endpoint, requestBody, { httpsAgent: agent, headers })
		.then(response => response.data);
	//.get('http://localhost:3000/src/resources/json/enAdminPortalUserAuth.json', { httpsAgent: agent, headers })
	//.then(response => response); 
};
