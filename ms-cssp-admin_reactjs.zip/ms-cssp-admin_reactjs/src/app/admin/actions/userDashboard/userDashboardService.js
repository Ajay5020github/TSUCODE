/*
 * Gets the configuration json for the
 * user dashboard page.
 */

import https from 'https';
import axios from 'axios';
import CONFIG from '../../config/index';
import Storage from '../../utils/storage';

// Gets seperate json based on language id and state id.
export const userDashboardService = (languageId, stateId) => {
	const agent = new https.Agent({
		rejectUnauthorized: true
	});

	// Fake token is verified by node.js service
	const headers = {
		token: CONFIG.fakeToken,
		authToken: Storage.getItem('authToken')
	};

	const requestBody = {		
		"userId":  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		"authToken": Storage.getItem('authToken'),
		"department": Storage.getItem("loginType"),
		"screenName": "AdminDashboard",
		"id": Storage.getItem('sid')
	};

	const endpoint = `${CONFIG.api.nodeUrl}/fetchConfigJson`;	

	return axios
		.post(endpoint, requestBody, { httpsAgent: agent, headers }).then(response => response.data);
	//  .get('http://localhost:3000/src/resources/json/enAdminDashboard.json',
	//  { httpsAgent: agent, headers })
	//  .then(response => response);
};

// Gets user application list
/* istanbul ignore next */
export const applicationListService = () => {
	const agent = new https.Agent({
		rejectUnauthorized: false
	});

	const headers = {
		contentType: 'application/json',
		authToken: Storage.getItem('authToken')
	};


	return new Promise((resolve, reject) => {
		axios
			.post(`${CONFIG.api.nodeUrl}/dashboard/applicationlist`, {
				authToken: Storage.getItem('authToken'),
				consumerAccountId: Storage.getItem('consumerAccountId')
			}, { httpsAgent: agent, headers })
			.then(response => response.data)
			.then(data => {
				resolve(data);
			})
			.catch(() => {
				reject();
			});
	});
};

export const fetchRoleService = (userData) => {

	const { userId, userRoles } = userData;

	const requestBody = {
		userRoles: userRoles || null,
		userId:  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		authToken: Storage.getItem('authToken'),
		department: Storage.getItem("loginType"),
		id: Storage.getItem('sid')
	};
	const agent = new https.Agent({
		rejectUnauthorized: false
	});

	const headers = {
		contentType: 'application/json',
		authToken: Storage.getItem('authToken')
	};

	const endpoint = `${CONFIG.api.nodeUrl}/adminService/fetchRoleMatrix`;
	return axios
		.post(endpoint, requestBody, { httpsAgent: agent, headers })
		.then(response => response.data)
		.catch(error => { 
		});
};


export const fetchAuthDataService = (emailValue) => {

	const agent = new https.Agent({
		rejectUnauthorized: false
	});

	const headers = {
		contentType: 'application/json'
	};

	const endpoint = `${CONFIG.api.nodeUrl}/externalAuth/getToken`;
	
	return axios
		.post(endpoint, { httpsAgent: agent, headers })
		.then(response => response.data)
		.catch(error => { 
		});
};
