/*
 * Gets the configuration json for the
 * user dashboard page.
 */

import CONFIG from '../../config/index';
import {
	userDashboardService,
	applicationListService,
	fetchRoleService,
	fetchAuthDataService

} from './userDashboardService';
import * as types from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import createSetTimeoutPolyFill from '../../createSetTimeoutPolyFill';

// Start fetching the data.
export const fetchUserDashboardDataBegin = () => ({
	type: types.FETCH_USER_DASHBOARD_DATA_BEGIN
});

// Data fetching the successful.
export const fetchUserDashboardDataSuccess =
	userDashboardData => ({
		type: types.FETCH_USER_DASHBOARD_DATA_SUCCESS,
		payload: { userDashboardData }
	});

// Data fetching the failed.
export const fetchUserDashboardDataFailure = error => ({
	type: types.FETCH_USER_DASHBOARD_DATA_FAILURE,
	payload: { error }
});

// Set Banner Content on Menu and Submenu Changes
export const setDashboardBannerTextData = data => ({
	type: types.SET_DASHBOARD_BANNER_TEXT_DATA,
	payload: { ...data }
});

// Toggle header links when switcing menu and sub menu.
export const toggleDashboardHeaderLinkData = data => ({
	type: types.TOGGLE_DASHBOARD_HEADER_LINK_DATA,
	payload: { data }
});

// Set user application list
export const fetchDashboardApplicationListData = data => ({
	type: types.FETCH_DASHBOARD_APPLICATION_LIST_DATA,
	payload: { data }
});


export const storefetchRoleDataCriteria = data => ({
	type: types.STORE_FETCH_ROLE_CRITERIA,
	payload: { data }
});
export const fetchRoleDataSuccess = data => ({
	type: types.FETCH_ROLE_MATRIX,
	payload: { data }
});

export const fetchRoleDataFailure = error => ({
	type: types.FETCH_ROLE_MATRIX_FAILURE,
	payload: { error }
});

export const storefetchAuthDataCriteria = data => ({
	type: types.STORE_FETCH_AUTH_CRITERIA,
	payload: { data }
});
export const fetchAuthDataSuccess = data => ({
	type: types.FETCH_AUTH_DATA,
	payload: { data }
});

export const fetchAuthDataFailure = error => ({
	type: types.FETCH_AUTH_DATA_FAILURE,
	payload: { error }
});

// Set user application list
export const setUserApplicationTrackingId = data => ({
	type: types.SET_USER_APPLICATION_TRACKING_ID,
	payload: { data }
});

// Reset user application list
export const resetUserApplicationList = () => ({
	type: types.RESET_USER_APPLICATION_LIST,
	payload: {}
});


let attempt = 0;
export const fetchUserDashboardData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	return dispatch => {

		dispatch(fetchUserDashboardDataBegin());
		return new Promise(resolve => {
				userDashboardService(languageId, stateId)
				.then(userDashboardData => {
					
					dispatch(
						fetchUserDashboardDataSuccess(
							userDashboardData.data
						)
					);
							
					resolve(userDashboardData);
					return userDashboardData.data;
				})
				.catch(() => {					
					attempt++;

					if (attempt < CONFIG.api.attemptAllowed) {

						// createSetTimeoutPolyFill(() => {
							dispatch(
								fetchUserDashboardData(
									languageId,
									stateId
								)
							);
						// }, CONFIG.api.attemptInterval);
					} else {
						attempt = 0;
						dispatch(
							fetchUserDashboardDataFailure(
								ERROR_MESSAGES[languageId]
							)
						);
					}
				});			
		});
	};
};

export const fetchUserDashboardApplicationList = function () {
	return dispatch => {
		return new Promise((resolve, reject) => {
			applicationListService()
				.then((data) => {
					const payload = data.data.applicationInfo;
					if (data.success) {
						const applicationInfo = [];
						(payload.length > 0) ? applicationInfo.push(payload[payload.length - 1]) : false;
						dispatch((fetchDashboardApplicationListData(applicationInfo)));
						resolve(applicationInfo);
					} else {
						dispatch((fetchDashboardApplicationListData([])));
						if (data.statusCode === 401) {
							reject();
						} else {
							resolve([]);
						}
					}
				})
				.catch(() => {
					dispatch((fetchDashboardApplicationListData([])));
					resolve([]);
				});
		});
	};
};

export const resetApplicationListData = function () {
	return dispatch => {
		dispatch(
			resetUserApplicationList()
		);
	};
};

export const fetchRoleManagementAction = function (request) {
	/* istanbul ignore next */
	return dispatch => {
		// dispatch(fetchLoginDataBegin());
		 dispatch(
		 	storefetchRoleDataCriteria(request)
		 );
		return new Promise(resolve => {
			fetchRoleService(request)
				.then(fetchRoleData => {
			
					if (fetchRoleData.body.statusCode === 200) {
						dispatch(
							fetchRoleDataSuccess(fetchRoleData.body)
						);
					} else {
						dispatch(
							fetchRoleDataFailure(
								fetchRoleDataFailure('Roles not returned')
							)
						);
					}
					resolve(fetchRoleData.body);
					return fetchRoleData.body;
				})
				.catch(() => {
					dispatch(
						fetchRoleDataFailure(
							fetchRoleDataFailure('Something went wrong')
						)
					);
				});
		});
	};
}


export const  fetchAuthDataManagementAction  = function (request) {

	/* istanbul ignore next */
	return dispatch => {
		// dispatch(fetchLoginDataBegin());
		 dispatch(	
			 
			storefetchAuthDataCriteria()
		 );
		return new Promise(resolve => {

			fetchAuthDataService(request)
				.then(fetchAuthData => {
			
					if (fetchAuthData.statusCode === 200) {
						dispatch(
							fetchAuthDataSuccess(fetchAuthData)
						);
					} else {
						dispatch(
							fetchAuthDataFailure(
								fetchAuthDataFailure('Roles not returned')
							)
						);
					}
					resolve(fetchAuthData);
					return fetchAuthData;
				})
				.catch(() => {
					dispatch(
						fetchAuthDataFailure(
							fetchAuthDataFailure('Something went wrong')
						)
					);
				});
		});
	};
}