/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Gets the Contact Us data
 */

import CONFIG from '../../config/index';
import { contactLocalOfficeService } from './contactLocalOfficeService';
import * as types from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import 'cross-fetch/polyfill';

// Start fetching the data.
export const fetchContactLocalOfficeDataBegin = () => ({
	type: types.FETCH_CONTACT_LOCAL_OFFICE_DATA_BEGIN
});

// Data fetching the successful.
export const fetchContactLocalOfficeDataSuccess = data => ({
	type: types.FETCH_CONTACT_LOCAL_OFFICE_DATA_SUCCESS,
	payload: { data }
});

// Data fetching the failed.
export const fetchContactLocalOfficeDataFailure = error => ({
	type: types.FETCH_CONTACT_LOCAL_OFFICE_DATA_FAILURE,
	payload: { error }
});

export const fetchContactLocalOfficeData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	/* istanbul ignore next */
	return dispatch => {
		/* istanbul ignore next */
		dispatch(fetchContactLocalOfficeDataBegin());
		/* istanbul ignore next */
		return new Promise(resolve => {
			contactLocalOfficeService(languageId, stateId)
				.then(contactLocalOfficeData => {                    		
					dispatch(
						fetchContactLocalOfficeDataSuccess(
							contactLocalOfficeData.data
						)
					);
					resolve();
					return contactLocalOfficeData.data;
				})
				.catch(() => {
					dispatch(
						fetchContactLocalOfficeDataFailure(
							ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
};


