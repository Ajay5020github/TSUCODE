/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Gets the configuration json for the
 * auth idletimeout modal.
 */

import https from 'https';
import axios from 'axios';
import CONFIG from '../../config/index';
import Storage from '../../utils/storage';

/* istanbul ignore next */
// Gets seperate json based on language id and state id.
export const authIdleTimeoutService = (languageId, stateId) => {
	/* istanbul ignore next */
	const agent = new https.Agent({
		rejectUnauthorized: true
	});
	
	/* istanbul ignore next */
	// Fake token is verified by node.js service
	const headers = {
		token: CONFIG.fakeToken,
		authToken: Storage.getItem('authToken')
	};

	const requestBody = {		
		"userId":  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		"authToken": Storage.getItem('authToken'),
		"department": Storage.getItem("loginType"),
		"screenName": "AdminIdleTimeout",
		"id": Storage.getItem('sid')
	};

	/* istanbul ignore next */
	const endpoint = `${CONFIG.api.nodeUrl}/fetchConfigJson`;	

	return axios
		 .post(endpoint, requestBody,
		 { httpsAgent: agent, headers }		
		)
		.then(response => {
			return response.data;
		});
};
