/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Gets the multilingual data for idletimeout modal in auth.
 */

import CONFIG from '../../config/index';
import { authIdleTimeoutService } from './authIdleTimeoutService';
import {
	FETCH_AUTH_IDLETIMEOUT_DATA_BEGIN,
	FETCH_AUTH_IDLETIMEOUT_DATA_SUCCESS,
	FETCH_AUTH_IDLETIMEOUT_DATA_FAILURE
} from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import 'cross-fetch/polyfill';
import createSetTimeoutPolyFill from "../../createSetTimeoutPolyFill"

// Start fetching the data.
export const fetchAuthIdleTimeoutDataBegin = () => ({
	type: FETCH_AUTH_IDLETIMEOUT_DATA_BEGIN
});

// Data fetching the successful.
export const fetchAuthIdleTimeoutDataSuccess = data => ({
	type: FETCH_AUTH_IDLETIMEOUT_DATA_SUCCESS,
	payload: { data }
});

// Data fetching the failed.
export const fetchAuthIdleTimeoutDataFailure = error => ({
	type: FETCH_AUTH_IDLETIMEOUT_DATA_FAILURE,
	payload: { error }
});


let attempt = 0;
export const fetchAuthIdleTimeoutData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	/* istanbul ignore next */
	return dispatch => {
		/* istanbul ignore next */
		dispatch(fetchAuthIdleTimeoutDataBegin());
		/* istanbul ignore next */
		return new Promise(resolve => {

			// createSetTimeoutPolyFill(() => {
				authIdleTimeoutService(languageId, stateId)
				.then(authIdleTimeoutData => {
					attempt++;
					if (authIdleTimeoutData.statusCode !== 200) {
						if (attempt < CONFIG.api.attemptAllowed) {
							createSetTimeoutPolyFill(() => {
								dispatch(
									fetchAuthIdleTimeoutData(
										languageId,
										stateId
									)
								);
							}, CONFIG.api.attemptInterval);
						} else {
							attempt = 0;
							dispatch(
								fetchAuthIdleTimeoutDataFailure(
									ERROR_MESSAGES[languageId]
								)
							);
						}
					} else {
						attempt = 0;
						dispatch(
							fetchAuthIdleTimeoutDataSuccess(
								authIdleTimeoutData.data
							)
						);
						resolve();
						return authIdleTimeoutData.data;
					}
				})
				.catch(() => {
					attempt++;
					if (attempt < CONFIG.api.attemptAllowed) {
						createSetTimeoutPolyFill(() => {
							dispatch(
								fetchAuthIdleTimeoutData(
									languageId,
									stateId
								)
							);
						}, CONFIG.api.attemptInterval);
					} else {
						attempt = 0;
						dispatch(
							fetchAuthIdleTimeoutDataFailure(
								ERROR_MESSAGES[languageId]
							)
						);
					}
				});
			// }, CONFIG.api.attemptInterval);
		});
	};
};

