/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Gets the Contact Us data
 */

import CONFIG from '../../config/index';
import { contactUsService } from './contactUsService';
import * as types from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import 'cross-fetch/polyfill';

// Start fetching the data.
export const fetchContactUsDataBegin = () => ({
	type: types.FETCH_CONTACT_US_DATA_BEGIN
});

// Data fetching the successful.
export const fetchContactUsDataSuccess = data => ({
	type: types.FETCH_CONTACT_US_DATA_SUCCESS,
	payload: { data }
});

// Data fetching the failed.
export const fetchContactUsDataFailure = error => ({
	type: types.FETCH_CONTACT_US_DATA_FAILURE,
	payload: { error }
});

export const fetchContactUsData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	/* istanbul ignore next */
	return dispatch => {
		/* istanbul ignore next */
		dispatch(fetchContactUsDataBegin());
		/* istanbul ignore next */
		return new Promise(resolve => {
			contactUsService(languageId, stateId)
				.then(contactUsData => {					
					dispatch(
						fetchContactUsDataSuccess(
							contactUsData.data
						)
					);
					resolve();
					return contactUsData.data;
				})
				.catch(() => {
					dispatch(
						fetchContactUsDataFailure(
							ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
};


