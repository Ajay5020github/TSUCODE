/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Gets the Contact Us data
 */

import CONFIG from '../../config/index';
import { printableApplicationService } from './printableApplicationService';
import * as types from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import 'cross-fetch/polyfill';

// Start fetching the data.
export const fetchPrintableApplicationDataBegin = () => ({
	type: types.FETCH_PRINTABLE_APPLICATION_DATA_BEGIN
});

// Data fetching the successful.
export const fetchPrintableApplicationSuccess = data => ({
	type: types.FETCH_PRINTABLE_APPLICATION_DATA_SUCCESS,
	payload: { data }
});

// Data fetching the failed.
export const fetchPrintableApplicationFailure = error => ({
	type: types.FETCH_PRINTABLE_APPLICATION_DATA_FAILURE,
	payload: { error }
});

export const fetchPrintableApplicationData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	/* istanbul ignore next */
	return dispatch => {
		/* istanbul ignore next */
		dispatch(fetchPrintableApplicationDataBegin());
		/* istanbul ignore next */
		return new Promise(resolve => {
			printableApplicationService(languageId, stateId)
				.then(printableApplicationData => {                    		
					dispatch(
						fetchPrintableApplicationSuccess(
							printableApplicationData.data
						)
					);
					resolve();
					return printableApplicationData.data;
				})
				.catch(() => {
					dispatch(
						fetchPrintableApplicationFailure(
							ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
};


