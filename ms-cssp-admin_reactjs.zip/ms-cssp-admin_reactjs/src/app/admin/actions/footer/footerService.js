
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Infinite 2022.
 */
/*
 * Gets the configuration json for the
 * Footer section
 */

import https from 'https';
import axios from 'axios';
import CONFIG from '../../config/index';
import Storage from '../../utils/storage';

// Gets seperate json based on language id and state id.
export const footerService = (languageId, stateId) => {
	const agent = new https.Agent({
		rejectUnauthorized: true
	});

	let headers = {}

	if (Storage.getItem('authToken')) {
		headers = {
			token: CONFIG.fakeToken,
			authToken: Storage.getItem('authToken')
		};
	}
	else {
		headers = {
			token: CONFIG.fakeToken
		};
	}

	const requestBody = {		
		"userId":  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		"authToken": Storage.getItem('authToken'),
		"department": Storage.getItem("loginType"),
		"screenName": "AdminFooter",
		"id": Storage.getItem("sid")
	};

	const endpoint = `${CONFIG.api.nodeUrl}/fetchConfigJson`;

	return axios
	.post(endpoint, requestBody, 
			{ httpsAgent: agent, headers }
		)
		.then(response => response.data.data);
	//  	.get('http://localhost:3000/src/resources/json/enFooter.json', { httpsAgent: agent, headers })
	//  .then(response => response);
};
