
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Infinite 2022.
 */
/*
 * Gets the configuration json for the
 * footer section.
 */

import CONFIG from '../../config/index';
import { footerService } from './footerService';
import * as types from '../actionTypes';
import {
	ERROR_MESSAGES
} from '../../resources/data/errorMessages';
import { logErrorService } from "../../errorNodeLogService";
import createSetTimeoutPolyFill from '../../createSetTimeoutPolyFill';
import createSetIntervalPolyFill from '../../createSetIntervalPolyFill'

// Start fetching the data.
export const fetchFooterPageDataBegin = () => ({
	type: types.FETCH_FOOTER_PAGE_DATA_BEGIN
});

// Data fetching the successful.
export const fetchFooterPageDataSuccess = footerPageData => ({
	type: types.FETCH_FOOTER_PAGE_DATA_SUCCESS,
	payload: { footerPageData }
});

// Data fetching the failed.
export const fetchFooterPageDataFailure = error => ({
	type: types.FETCH_FOOTER_PAGE_DATA_FAILURE,
	payload: { error }
});

let attempt = 0;
export const fetchFooterPageData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	return dispatch => {
		dispatch(fetchFooterPageDataBegin());
		const { setIntervalPolyFill, clearIntervalPolyFill } = createSetIntervalPolyFill();
		var interval = setIntervalPolyFill(() => {
		footerService(languageId, stateId)
			.then(footerPageData => {
				dispatch(
					fetchFooterPageDataSuccess(
						footerPageData.data.data
					)
				);
				return footerPageData.data;
			})
			.catch(err => {
				/* istanbul ignore next */
				attempt++;
				/* istanbul ignore next */
				if (attempt < CONFIG.api.attemptAllowed) {
					createSetTimeoutPolyFill(() => {
						dispatch(
							fetchFooterPageData(
								languageId,
								stateId
							)
						);
					}, CONFIG.api.attemptInterval);
				} else {
					attempt = 0;
					/* istanbul ignore next */
					dispatch(
						fetchFooterPageDataFailure(
							ERROR_MESSAGES[languageId]
						)
					);
					logErrorService(err)
				}
			});
			clearIntervalPolyFill(interval);
			// }
		}, 1000);
	};
};
