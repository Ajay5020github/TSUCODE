"use client "
import CONFIG from '../../config/index';
import { UserManageService, searchUserService } from './userManagementServices';
import * as types from '../actionTypes';
import 'cross-fetch/polyfill';
import { containerClasses } from '@mui/material';

export const fetchUserManagementDataSuccess = data => ({
	type: types.FETCH_USERMANAGEMENT_DATA_SUCCESS,
	payload: { data }
});

export const fetchUserManagementDataFailure = error => ({
	type: types.FETCH_USERMANAGEMENT_DATA_FAILURE,
	payload: { error }
});

export const storeSerchUserCriteria = data => ({
	type: types.STORE_SEARCH_USER_CRITERIA,
	payload: { data }
});

export const searchUserDataSuccess = data => ({
	type: types.SEARCH_USER_DETAILS,
	payload: { data }
});

export const searchUserDataFailure = error => ({
	type: types.SEARCH_USER_DETAILS_FAILURE,
	payload: { error }
});



// Reset
export const ClearSearchDetail = () => ({
	type: types.CLEAR_SEARCH_DETAILS,
	payload: {
		loading: false,
		searchUserData: {},
		storeSearchUserCriteria: {}
	}
});

export const ClearFormDetail = () => ({
	type: types.CLEAR_FORM_DETAILS,
	payload: {
		loading: false,
		storedata: {}
	}
});
// Store Selected Benifits.
export const storeSearchInfo = storedata => ({
	type: types.STORE_SEARCH_DATA,
	payload: { storedata }
});

// export const fetchUserManagementDataAction = function (
// 	languageId = CONFIG.defaultLang,
// 	stateId = CONFIG.defaultState
// ) {
// 	/* istanbul ignore next */
// 	return dispatch => {
// 		dispatch(fetchLoginDataBegin());
// 		return new Promise(resolve => {
// 			UserManageService()
// 				.then(screenData => {	
// 					dispatch(
// 						fetchUserManagementDataSuccess(
// 							screenData
// 						)
// 					);
// 					resolve(screenData);
// 					return screenData;
// 				})
// 				.catch(() => {
// 					dispatch(
// 						fetchUserManagementDataFailure(
// 							'JSON NOT FOUND'
// 						)
// 					);
// 				});
// 		});
// 	};
// };

export const fetchUserManagementDataAction = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
 ) {
	
 
	return async (dispatch) => {
	   try {
		  const screenData = await UserManageService(languageId, stateId);
		  dispatch(fetchUserManagementDataSuccess(screenData));
		  return screenData;
	   } catch (error) {
		  dispatch(fetchUserManagementDataFailure('JSON NOT FOUND'));
	   }
	};
 };
 
export const searchUserManagementAction = function (request) {
	/* istanbul ignore next */
	
	return dispatch => {
		// dispatch(fetchLoginDataBegin());
		dispatch(
			storeSerchUserCriteria(request)
		);
		return new Promise(resolve => {
			searchUserService(request)
				.then(searchData => {
					dispatch(
						searchUserDataSuccess(searchData)
					);
					resolve(searchData);
					return searchData;
					
				})
				.catch(() => {
					dispatch(
						searchUserDataFailure(
							searchUserDataFailure('Something went wrong')
						)
					);
				});
		});
	};
};

/* istanbul ignore next */
export const getStoreSearchForm = (storedata) => {
	return dispatch => {	
		dispatch(storeSearchInfo(storedata));
	}
}

/* istanbul ignore next */
export const getClearSearchForm = () => {
	return dispatch => {	
		dispatch(ClearFormDetail());
	}
}

export const resetSearchDetails = function () {
	return dispatch => {
		dispatch(ClearSearchDetail());
	};
};