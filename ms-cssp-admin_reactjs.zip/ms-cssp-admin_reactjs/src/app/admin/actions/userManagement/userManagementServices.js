import https from 'https';
import axios from 'axios';
import CONFIG from '../../config/index';
import Storage from '../../utils/storage';

export const UserManageService = async (languageId, stateId) => {
   const agent = new https.Agent({
      rejectUnauthorized: false
   });

   // Fake token is verified by node.js service
   const headers = {
      token: CONFIG.fakeToken,
      authToken: Storage.getItem('authToken')
   };

   const requestBody = {
      "userId": Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
      "authToken": Storage.getItem('authToken'),
      "department": Storage.getItem("loginType"),
      "screenName": "AdminUserManagement",
      "id": Storage.getItem('sid')
   };

   const endpoint = `${CONFIG.api.nodeUrl}/fetchConfigJson`;   

   try {
      const response = await axios.post(endpoint, requestBody, { httpsAgent: agent, headers });
      return response.data;
   } catch (error) {
      throw error;
   }
};

export const searchUserService = async (searchData) => {
   const { firstName, lastName, userId, emailAddress, fromDate, toDate, programName , arInd, currentPage, sizePerPage } = searchData;
	const requestBody = {
		authToken: Storage.getItem('authToken'),
		arInd: arInd || null,
		emailAddress: emailAddress || null,
		firstName: firstName || null,
		fromDate: fromDate || null,
		lastName: lastName || null,
		programName: programName || null,
		toDate: toDate || null,		
		userId: Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		department: Storage.getItem("loginType"),
		id: Storage.getItem('sid'),
		page: parseInt(currentPage - 1),
		size: sizePerPage
	};
   const agent = new https.Agent({
      rejectUnauthorized: true
   });

   const headers = {
      contentType: 'application/json',
      authToken: Storage.getItem('authToken')
   };

   const endpoint = `${CONFIG.api.nodeUrl}/adminService/searchUserMS`;

   try {
      const response = await axios.post(endpoint, requestBody, { httpsAgent: agent, headers });
      return response.data;
   } catch (error) {
      // throw error;
   }
};

export default UserManageService;
