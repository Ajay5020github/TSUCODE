/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Gets the configuration json for the
 * Login screen.
 */

import https from 'https';
import axios from 'axios';
import CONFIG from '../../config/index';
import Storage from '../../utils/storage';

// Gets seperate json based on language id and state id.
export const loginService = (languageId, stateId) => {
	const agent = new https.Agent({
		rejectUnauthorized: true
	});

	// Fake token is verified by node.js service
	const headers = {
		//token: CONFIG.fakeToken
	};

	const requestBody = {		
		"userId":  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
		"authToken": Storage.getItem('authToken'),
		"department": Storage.getItem("loginType"),
		"screenName": "AdminLogin"
	};

	const endpoint = `${CONFIG.api.nodeUrl}/fetchConfigJson`;

	return axios
		.post(endpoint, requestBody,
			{ httpsAgent: agent, headers }
		)
		.then(response => response.data);
	// .get('http://localhost:3000/src/resources/json/enAdminLogin.json', { httpsAgent: agent, headers })
	// .then(response => response);
};

export const loginValidate = (loginData) => {
	const agent = new https.Agent({
		rejectUnauthorized: false
	});

	// Fake token is verified by node.js service
	const headers = {
		contentType: 'application/json'
	};

	const endpoint = `${CONFIG.api.nodeUrl}/adminService/adminLogin`;
	return axios
		.post(endpoint, loginData,
			{ httpsAgent: agent, headers }
		)
		.then(response => response.data);
};

// export const azureValidate = (loginData) => {
// 	const agent = new https.Agent({
// 		rejectUnauthorized: false
// 	});

// 	// Fake token is verified by node.js service
// 	const headers = {
// 		contentType: 'application/json'
// 	};

// 	const endpoint = `${CONFIG.api.nodeUrl}/adminService/azureLoginValidate`;
// 	return axios
// 		.post(endpoint, loginData,
// 			{ httpsAgent: agent, headers }
// 		)
// 		.then(response => response.data);
// };


export const loginAuth = (loginData) => {

	const agent = new https.Agent({
		rejectUnauthorized: false
	});

	// Fake token is verified by node.js service
	const headers = {
		contentType: 'application/json'
	};
	// alert(loginData)
	let data =  {"loginData": loginData  } ;

	const endpoint = `${CONFIG.api.nodeUrl}/externalAuth/extLogin`;

	//const endpoint = `http://localhost:3000/adminService/azureLogin`;

	return axios
		.post(endpoint, data,
			{ httpsAgent: agent, headers }
		)
		.then(response => response.data);

};

export const getAuthtokenData = (email) => {

	const agent = new https.Agent({
		rejectUnauthorized: false
	});

	// Fake token is verified by node.js service
	const headers = {
		contentType: 'application/json'
	};	
	
	let data =  {"email": email, "id": Storage.getItem("sid"), department: Storage.getItem("loginType"), firstName : Storage.getItem("firstName"), adminUserId : Storage.getItem("adminUserId")  }
	const endpoint = `${CONFIG.api.nodeUrl}/externalAuth/getToken`;

	//const endpoint = `http://localhost:3000/adminService/azureLogin`;

	return axios
		.post(endpoint, data,
			{ httpsAgent: agent, headers }
		)
		.then(response => response.data);

};


