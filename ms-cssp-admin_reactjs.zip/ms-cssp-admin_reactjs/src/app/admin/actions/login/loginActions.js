/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Gets the create account and form field data
 */

import CONFIG from '../../config/index';
import { loginService, loginValidate, loginAuth, getAuthtokenData } from './loginService';
import * as types from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import 'cross-fetch/polyfill';
import createSetTimeoutPolyFill from "../../createSetTimeoutPolyFill"
// Start fetching the data.
export const fetchLoginDataBegin = () => ({
	type: types.FETCH_LOGIN_DATA_BEGIN
});

// Data fetching the successful.
export const fetchLoginDataSuccess = data => ({
	type: types.FETCH_LOGIN_DATA_SUCCESS,
	payload: { data }
});

// Data fetching the failed.
export const fetchLoginDataFailure = error => ({
	type: types.FETCH_LOGIN_DATA_FAILURE,
	payload: { error }
});

// Start saving the data.
export const validateLoginDataBegin = () => ({
	type: types.VALIDATE_LOGIN_DATA_BEGIN
});

// Data saving the successful.
export const validateLoginDataSuccess = data => ({
	type: types.VALIDATE_LOGIN_DATA_SUCCESS,
	payload: { data }
});


// Data saving the failed.
export const validateLoginDataFailure = error => ({
	type: types.VALIDATE_LOGIN_DATA_FAILURE,
	payload: { error }
});

// Data saving the invalid.
export const validateLoginDataInvalid = data => ({
	type: types.VALIDATE_LOGIN_DATA_INVALID,
	payload: { data }
});


export const authURLDataBegin = () => ({
	type: types.AUTHURL_LOGIN_DATA_BEGIN
});

export const authURLDataSuccess = data => ({
	type: types.AUTHURL_LOGIN_DATA_SUCCESS,
	payload: { data }
});
export const authURLDataFailure = error => ({
	type: types.AUTHURL_LOGIN_DATA_FAILURE,
	payload: { error }
});
export const authURLDataInvalid = data => ({
	type: types.AUTHURL_LOGIN_DATA_INVALID,
	payload: { data }
});

export const tokenDataBegin = () => ({
	type: types.TOKEN_DATA_BEGIN
});

export const tokenDataSuccess = data => ({
	type: types.TOKEN_DATA_SUCCESS,
	payload: { data }
});
export const tokenDataFailure = error => ({
	type: types.TOKEN_DATA_FAILURE,
	payload: { error }
});
export const tokenDataInvalid = data => ({
	type: types.TOKEN_DATA_INVALID,
	payload: { data }
});

let attempt = 0;
/* istanbul ignore next */
export const fetchLoginData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	/* istanbul ignore next */
	return dispatch => {
		/* istanbul ignore next */
		dispatch(fetchLoginDataBegin());
		/* istanbul ignore next */
		return new Promise(resolve => {
			loginService(languageId, stateId)
				.then(loginData => {
					dispatch(
						fetchLoginDataSuccess(
							loginData.data
						)
					);
					resolve();
					return loginData.data;
				})
				.catch(() => {
					attempt++;
					if (attempt < CONFIG.api.attemptAllowed) {
						createSetTimeoutPolyFill(() => {
							dispatch(
								fetchLoginData(
									languageId,
									stateId
								)
							);
						}, CONFIG.api.attemptInterval);
					} else {
						attempt = 0;
						dispatch(
							fetchLoginDataFailure(
								ERROR_MESSAGES[languageId]
							)
						);
					}
				});
		});
	};
};
export const getAuthUrl = function ( loginData) {

	return dispatch => {
		/* istanbul ignore next */
		dispatch(authURLDataBegin());
		/* istanbul ignore next */
		return new Promise(resolve => {
			loginAuth(loginData)
				.then(resData => {
					if (+resData.statusCode === 200 && resData.success) {
						dispatch(
							authURLDataSuccess(
								resData
							)
						);
					} else {
						dispatch(
							authURLDataFailure(
								resData
							)
						);
					}
					resolve(resData);		
					
				//	resData.data = "https://login.microsoftonline.com/657f0c85-1824-433c-983b-7743863f2ff2/oauth2/v2.0/authorize?client_id=8d46d5d7-8ce8-4a7c-b6b8-ab4ef5bd86da&response_type=token&redirect_uri=http://localhost:3000/auth/openid/return&response_mode=form_post&scope=openid+profile+User.Read&state=12345"
					
					return resData.data;
				})
				.catch(/* istanbul ignore  next */() => {
					dispatch(
						tokenDataInvalid(
							//ERROR_MESSAGES[languageId]
					//		resData.data = "https://login.microsoftonline.com/657f0c85-1824-433c-983b-7743863f2ff2/oauth2/v2.0/authorize?client_id=8d46d5d7-8ce8-4a7c-b6b8-ab4ef5bd86da&response_type=token&redirect_uri=http://localhost:3000/auth/openid/return&response_mode=form_post&scope=openid+profile+User.Read&state=12345";
					//		ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
}
export const getToken = function (email) {

	return dispatch => {
		/* istanbul ignore next */
		dispatch(tokenDataBegin());
		/* istanbul ignore next */
		return new Promise(resolve => {
			getAuthtokenData(email)
				.then(resData => {
					if (+resData.statusCode === 200 && resData.success) {
						dispatch(
							tokenDataSuccess(
								resData
							)
						);
					} else {
						dispatch(
							tokenDataFailure(
								resData
							)
						);
					}
					resolve(resData);		
					
				//	resData.data = "https://login.microsoftonline.com/657f0c85-1824-433c-983b-7743863f2ff2/oauth2/v2.0/authorize?client_id=8d46d5d7-8ce8-4a7c-b6b8-ab4ef5bd86da&response_type=token&redirect_uri=http://localhost:3000/auth/openid/return&response_mode=form_post&scope=openid+profile+User.Read&state=12345"
					
					return resData.data;
				})
				.catch(/* istanbul ignore  next */() => {
					dispatch(
						authURLDataInvalid(
							//ERROR_MESSAGES[languageId]
					//		resData.data = "https://login.microsoftonline.com/657f0c85-1824-433c-983b-7743863f2ff2/oauth2/v2.0/authorize?client_id=8d46d5d7-8ce8-4a7c-b6b8-ab4ef5bd86da&response_type=token&redirect_uri=http://localhost:3000/auth/openid/return&response_mode=form_post&scope=openid+profile+User.Read&state=12345";
					//		ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
}
export const validateLoginData = function (languageId, loginData) {
	/* istanbul ignore next */
	return dispatch => {
		/* istanbul ignore next */
		dispatch(validateLoginDataBegin());
		/* istanbul ignore next */
		return new Promise(resolve => {
			loginValidate(loginData)
				.then(resData => {
					if (+resData.statusCode === 200 && resData.success) {
						dispatch(
							validateLoginDataSuccess(
								resData
							)
						);
					} else {
						dispatch(
							validateLoginDataInvalid(
								resData
							)
						);
					}
					resolve(resData);
					return resData.data;
				})
				.catch(/* istanbul ignore  next */() => {
					dispatch(
						validateLoginDataFailure(
							ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
};

