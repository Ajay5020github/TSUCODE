/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Gets the Admin Report data
 */

import CONFIG from '../../config/index';
import { adminReportListService } from './adminReportListService';
import * as types from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import 'cross-fetch/polyfill';

// Start fetching the data.
export const fetchAdminReportDataBegin = () => ({
	type: types.FETCH_ADMIN_REPORT_DATA_BEGIN
});

// Data fetching the successful.
export const fetchAdminReportDataSuccess = data => ({
	type: types.FETCH_ADMIN_REPORT_DATA_SUCCESS,
	payload: { data }
});

// Data fetching the failed.
export const fetchAdminReportDataFailure = error => ({
	type: types.FETCH_ADMIN_REPORT_DATA_FAILURE,
	payload: { error }
});

export const fetchAdminReportListData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	/* istanbul ignore next */
	return dispatch => {
		/* istanbul ignore next */
		dispatch(fetchAdminReportDataBegin());
		/* istanbul ignore next */
		return new Promise(resolve => {
			adminReportListService(languageId, stateId)
				.then(adminReportData => {
					dispatch(
						fetchAdminReportDataSuccess(
							adminReportData.data
						)
					);
					resolve();
					return adminReportData.data;
				})
				.catch(() => {
					dispatch(
						fetchAdminReportDataFailure(
							ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
};


