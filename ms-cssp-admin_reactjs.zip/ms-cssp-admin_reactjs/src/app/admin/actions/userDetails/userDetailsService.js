/*
 * Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Gets the configuration json for the user details.
 */

import https from 'https';
import axios from 'axios';
import CONFIG from '../../config/index';
import Storage from '../../utils/storage';

// Gets separate json based on language id and state id.
export const userDetailsService = async (languageId, stateId) => {
    const agent = new https.Agent({
        rejectUnauthorized: true 
    });

    // Fake token is verified by node.js service
    const headers = {
        token: CONFIG.fakeToken,
        authToken: Storage.getItem('authToken')
    };

    const requestBody = {        
        userId: Storage.getItem('loginType') === 'internal' ? Storage.getItem('adminUserId') : Storage.getItem('email'),
        authToken: Storage.getItem('authToken'),
        department: Storage.getItem('loginType'),
        screenName: 'AdminPortalUserDetails',
        id: Storage.getItem('sid')
    };

    //need to change after getting Azure service url
    const endpoint = `${CONFIG.api.nodeUrl}/fetchConfigJson`;

    try {
        const response = await axios.post(endpoint, requestBody, { httpsAgent: agent, headers });
        return response.data;
    } catch (error) {
        // throw error; // Re-throw the error to handle it higher up if needed
    }
};
