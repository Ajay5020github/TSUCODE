/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Gets the configuration publisher data
 */

import CONFIG from '../../config/index';
import { userDetailsService } from './userDetailsService';
import * as types from '../actionTypes';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import 'cross-fetch/polyfill';
import { viewUserService } from '../../services/UserService';

// Start fetching the data.
export const userDetailsDataBegin = () => ({
	type: types.FETCH_USER_DETAILS_DATA_BEGIN
});

// Data fetching the successful.
export const userDetailsDataSuccess = data => ({
	type: types.FETCH_USER_DETAILS_DATA_SUCCESS,
	payload: { data }
});

// Data fetching the failed.
export const userDetailsDataFailure = error => ({
	type: types.FETCH_USER_DETAILS_DATA_FAILURE,
	payload: { error }
});

// Fetch User details Succes
export const singleUserDetailSuccess = data => ({
	type: types.FETCH_SINGLE_USER_DETAILS,
	payload: { data }
});

//Failure
export const singleUserDetailError = error => ({
	type: types.FETCH_SINGLE_USER_DETAILS_FAILURE,
	payload: { error }
});

// Reset
export const ClearUserDetail = () => ({
	type: types.CLEAR_USER_DETAILS,
	payload: {
		singleSelectedUser: {},
		userDetailsData: {}
	}
});


/* istanbul ignore next */
// Stored Selected data
export const storeSelectedUserData = data => ({
	type: types.STORE_SELECTED_USER_DETAIL,
	payload: { data }
});

/* istanbul ignore next */
export const fetchUserDetailsData = function (
	languageId = CONFIG.defaultLang,
	stateId = CONFIG.defaultState
) {
	return dispatch => {
		dispatch(userDetailsDataBegin());
		return new Promise(resolve => {
			userDetailsService(languageId, stateId)
				.then(userDetailsData => {
					dispatch(
						userDetailsDataSuccess(
							userDetailsData.data
						)
					);
					resolve(userDetailsData.data);
					return userDetailsData.data;
				})
				.catch(() => {
					dispatch(
						userDetailsDataFailure(
							ERROR_MESSAGES[languageId]
						)
					);
				});
		});
	};
};

/* istanbul ignore next */
export const fetchViewUserDetailsAction = (userDetail) => {
	return dispatch => {
		dispatch(
			storeSelectedUserData(JSON.parse(JSON.stringify(userDetail)))
		);
		return new Promise(resolve => {
			viewUserService(userDetail).then(response =>  {
				dispatch(singleUserDetailSuccess(response))
				resolve(response)
				return response.body;				
			})
			.catch(() => {
				dispatch(
					userDetailsDataFailure('NOT FOUND')
				)
			});
		});
	};
}

export const resetUserDetails = function () {
	return dispatch => {
		dispatch(ClearUserDetail());
	};
};