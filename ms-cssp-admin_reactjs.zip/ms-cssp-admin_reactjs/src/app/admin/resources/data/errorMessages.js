
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 
 */
/*
 * List of error messages displayed
 * by the system in case of api failure.
 */

export const ERROR_MESSAGES = {
	en: 'Oops! Something went wrong. Please try again.',
	vi: 'Rất tiếc! Đã xảy ra lỗi. Vui lòng thử lại.',
	uk: 'На жаль! Щось пішло не так. Будь ласка спробуйте ще раз.',
	ru: 'К сожалению! Что-то пошло не так. Пожалуйста, попробуйте еще раз.',
	es: '¡Uy! Algo salió mal. Inténtalo de nuevo.',
	pt: 'Opa! Algo deu errado. Por favor, tente novamente.',
	zh: '哎呀！有些不对劲。请再试一次。'
};
