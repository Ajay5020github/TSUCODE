
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Monitors the reducer used in the application
 */

const monitorReducerEnhancer = createStore => (
	reducer,
	initialState,
	enhancer
) => {
	const monitoredReducer = (state, action) => {
		const newState = reducer(state, action);

		return newState;
	};

	return createStore(monitoredReducer, initialState, enhancer);
};

export default monitorReducerEnhancer;
