/* Copyright(C) Conduent Inc. - All Rights Reserved
	* Unauthorized copying of this file, via any medium is strictly prohibited
		* Proprietary and confidential
			
				* /
/*
 * Used to update the page wise login,
 * answers, validation errors.
 */

import * as types from '../../actions/actionTypes';
import { initialState } from '../initialState';
import { PURGE, REHYDRATE } from 'redux-persist';

export default function userAuthReducer(
	state = {},
	action
) {

	if (typeof state === 'undefined') {
		state = initialState.userAuthReducer;
	}

	switch (action.type) {

		case types.FETCH_USER_AUTH_DATA_BEGIN:

			// Mark the state as "loading" so we
			// can show a spinner or something
			// Also, reset any errors. We're starting fresh.

			return {
				...state,
				loading: true,
			};

		case types.FETCH_USER_AUTH_DATA_SUCCESS:
			// All done: set loading "false".
			// Also, replace the items with the
			// ones from the server

			return {
				...state,
				loading: false,
				userAuthData: action.payload
			};
			case  types.AUTH_DETAIL:

			// Mark the state as "loading" so we
			// can show a spinner or something
			// Also, reset any errors. We're starting fresh.
			
			return {
				...state,
				person: action.payload
			};

		case types.FETCH_USER_AUTH_DATA_FAILURE:
			// The request failed. It's done. So set loading to "false".
			// Save the error, so we can display it somewhere.
			// Since it failed, we don't have items
			// to display anymore, so set `items` empty.
			return {
				...state,
				loading: false,
				error: action.payload.error,
				userAuthData: {}
			};
		


			case types.FETCH_SINGLE_USER_AUTH_DETAILS_SUCCESS:
			return {
				...state,
				loading: true,
				singleUserAuthDetail: action.payload
			};
		case types. STORE_SELECTED_USER_AUTH:
			return {
				...state,
				singleSelectedUserAuth: action.payload
			};
		case types.CLEAR_USER_AUTH:
			return {
				singleUserAuthDetail : {},
				singleSelectedUserAuth: {},
				loading: false,
				error: null
			};
	
		default:
			// ALWAYS have a default case in a reducer
			return state;
	}
}
