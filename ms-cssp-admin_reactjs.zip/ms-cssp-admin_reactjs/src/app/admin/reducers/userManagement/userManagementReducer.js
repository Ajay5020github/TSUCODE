import * as types from '../../actions/actionTypes';
import { initialState } from '../initialState';

export default function userManagementReducer(
	state = {},
	action
) {

	if (typeof state === 'undefined') {
		state = initialState.userManagementReducer;
	}
	switch (action.type) {

		case types.FETCH_USERMANAGEMENT_DATA_SUCCESS:
			return {
				...state,
				loading: false,
				userManagementData: action.payload
			};

		case types.FETCH_USERMANAGEMENT_DATA_FAILURE:
			return {
				...state,
				loading: false,
				error: action.payload.error,
				userManagementData: {}
			};

		case types.STORE_SEARCH_USER_CRITERIA:
			return {
				...state,
				loading: false,
				storeSearchUserCriteria: action.payload
			};

			
		case types.SEARCH_USER_DETAILS:
			return {
				...state,
				loading: false,
				searchUserData: action.payload
			};
		
			case types.STORE_SEARCH_DATA:
			return {
				...state,
				loading: false,
				storedata: action.payload
			};
		
		
		case types.CLEAR_SEARCH_DETAILS:
			return {
				loading: false,
				searchUserData: {},
				storeSearchUserCriteria: {}
			};
		
			case types.CLEAR_FORM_DETAILS:
			return {
				loading: false,
				storedata: {}
			};
			
			
			
		default:
			// ALWAYS have a default case in a reducer
			return state;
	}
}
