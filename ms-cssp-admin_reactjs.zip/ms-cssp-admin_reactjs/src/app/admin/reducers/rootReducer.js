/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 
 */

/**
 * It combines all the reducers used by
 * the application
 */

import { combineReducers } from 'redux';

import loaderReducer from './loader/loaderReducer';
import loginReducer from './login/loginReducer';
import userDashboardReducer from './userDashboard/userDashboardReducer';
//adding import for auth idle timeout
import authIdleTimeoutReducer from './authIdleTimeout/authIdleTimeoutReducer';
import configurationPublisherReducer from './configurationPublisher/configurationPublisherReducer'
import userManagementReducer from './userManagement/userManagementReducer';
import userDetailsReducer from './userDetails/userDetailsReducer';
import userAuthReducer from './userAuth/userAuthReducer';
import adminReportReducer from './adminReport/adminReportReducer';
import contactUsReducer from './contactUs/contactUsReducer';
import contactLocalOfficeReducer from './contactLocalOffice/contactLocalOfficeReducer';
import printableApplicationReducer from './printableApplication/printableApplicationReducer';
import adminReportDetailReducer from './adminReportDetail/adminReportDetailReducer';
import footerReducer from './footer/footerReducer';
export default combineReducers({	
	loaderReducer,
	loginReducer,	
	userDashboardReducer,	
	footerReducer,
	//adding auth idle timeout modal reducer
	authIdleTimeoutReducer,
	configurationPublisherReducer,
	userManagementReducer,
	userDetailsReducer,
	adminReportReducer,
	adminReportDetailReducer,
	contactUsReducer,
	contactLocalOfficeReducer,
	printableApplicationReducer,
	userAuthReducer
});
