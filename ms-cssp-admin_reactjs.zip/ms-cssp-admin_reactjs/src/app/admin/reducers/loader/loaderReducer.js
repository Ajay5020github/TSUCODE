
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 
 */
/*
 * Used to update the loader text
 * during page transition.
 */

import * as types from '../../actions/actionTypes';
import { initialState } from '../initialState';

export default function loaderReducer(
	state,
	action
) {

	if (typeof state === 'undefined') {
		state = initialState.loaderReducer
	}

	switch (action.type) {
	case types.SET_LOADER_TEXT:
		return {
			...state,
			text: action.payload.text
		};
	default:
		return state;
	}
}
