/* Copyright(C) Conduent Inc. - All Rights Reserved
	* Unauthorized copying of this file, via any medium is strictly prohibited
		* Proprietary and confidential
			
				* /
/*
 * Used to update the page wise login,
 * answers, validation errors.
 */

import * as types from '../../actions/actionTypes';
import { initialState } from '../initialState';
import { PURGE, REHYDRATE } from 'redux-persist';

export default function userDetailsReducer(
	state = {},
	action
) {

	if (typeof state === 'undefined') {
		state = initialState.userDetailsReducer;
	}

	switch (action.type) {

		case types.FETCH_USER_DETAILS_DATA_BEGIN:

			// Mark the state as "loading" so we
			// can show a spinner or something
			// Also, reset any errors. We're starting fresh.

			return {
				...state,
				loading: true,
			};

		case types.FETCH_USER_DETAILS_DATA_SUCCESS:
			// All done: set loading "false".
			// Also, replace the items with the
			// ones from the server

			return {
				...state,
				loading: false,
				userDetailsData: action.payload
			};

		case types.FETCH_USER_DETAILS_DATA_FAILURE:
			// The request failed. It's done. So set loading to "false".
			// Save the error, so we can display it somewhere.
			// Since it failed, we don't have items
			// to display anymore, so set `items` empty.
			return {
				...state,
				loading: false,
				error: action.payload.error,
				userDetailsData: {}
			};
		case types.FETCH_SINGLE_USER_DETAILS:
			return {
				...state,
				loading: true,
				singleUserDetail: action.payload
			};
		case types.STORE_SELECTED_USER_DETAIL:
			return {
				...state,
				singleSelectedUser: action.payload
			};
		case types.CLEAR_USER_DETAILS:
			return {
				singleUserDetail : {},
				singleSelectedUser: {},
				loading: false,
				error: null
			};
		default:
			// ALWAYS have a default case in a reducer
			return state;
	}
}
