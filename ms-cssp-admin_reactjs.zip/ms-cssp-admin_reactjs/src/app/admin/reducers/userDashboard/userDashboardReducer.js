/*
 * Used to update the json configuration
 * for the user dashboard page.
 */

import * as types from '../../actions/actionTypes';
import { initialState } from '../initialState';

export default function userDashboardReducer(
	state,
	action
) {
	if (typeof state === 'undefined') {
		state = initialState.userDashboardReducer
	}
	switch (action.type) {
	case types.FETCH_USER_DASHBOARD_DATA_BEGIN:
		// Mark the state as "loading" so we
		// can show a spinner or something
		// Also, reset any errors. We're starting fresh.
		return {
			...state,
			loading: true,
			error: null
		};

	case types.FETCH_USER_DASHBOARD_DATA_SUCCESS:
		// All done: set loading "false".
		// Also, replace the items with the
		// ones from the server
		return {
			...state,
			loading: false,
			userDashboardData: action.payload
		};

	case types.FETCH_USER_DASHBOARD_DATA_FAILURE:
		// The request failed. It's done. So set loading to "false".
		// Save the error, so we can display it somewhere.
		// Since it failed, we don't have items to
		// display anymore, so set `items` empty.
		return {
			...state,
			loading: false,
			error: action.payload.error,
			userDashboardData: {}
		};

	case types.SET_DASHBOARD_BANNER_TEXT_DATA:
		// Set banner text when switching menu and sub menu.
		return {
			...state,
			userDashboardData: {
				...state.userDashboardData,
				userDashboardData: {
					...state.userDashboardData.userDashboardData,
					content: {
						...state.userDashboardData.userDashboardData.content,
						banner: {
							...state.userDashboardData.userDashboardData
								.content.banner,
							content: {
								...state.userDashboardData.userDashboardData
									.content.banner.content,
								headline: {
									...state.userDashboardData
										.userDashboardData.content.banner
										.content.paragraph,
									text: action.payload.headline
								},
								paragraph: {
									...state.userDashboardData
										.userDashboardData.content.banner
										.content.paragraph,
									text: action.payload.text
								}
							}
						}
					}
				}
			}
		};
	/* istanbul ignore next */
	case types.TOGGLE_DASHBOARD_HEADER_LINK_DATA:
		// Toggle header links when switcing menu and sub menu.
		return {
			...state,
			userDashboardData: {
				...state.userDashboardData,
				userDashboardData: {
					...state.userDashboardData.userDashboardData,
					content: {
						...state.userDashboardData.userDashboardData.content,
						dashboard: {
							...state.userDashboardData
								.userDashboardData.content.dashboard,
							content: {
								...state.userDashboardData.userDashboardData
									.content.dashboard.content,
								dashboardHeaderLinks: state.userDashboardData
									.userDashboardData.content.dashboard.content
									.dashboardHeaderLinks.map(
										dashboardHeaderLink => {
											const dashboardHeaderLinkData =
											{...dashboardHeaderLink};
											dashboardHeaderLinkData.show =
											action.payload.data;
											return dashboardHeaderLinkData;
										})
							}
						}
					}
				}
			}
		};

	case types.FETCH_DASHBOARD_APPLICATION_LIST_DATA:
		// Toggle header links when switcing menu and sub menu.
		return {
			...state,
			applicationList: action.payload.data
		};
	/* istanbul ignore next */	
	case types.SET_USER_APPLICATION_TRACKING_ID:
		// Set selected application tracking id
		return {
			...state,
			applicationTrackingId: action.payload.data
		};
	/* istanbul ignore next */
	case types.RESET_USER_APPLICATION_LIST:
		return {
			...state,
			applicationList: []
		};

	default:
		// ALWAYS have a default case in a reducer
		return state;
	}
}
