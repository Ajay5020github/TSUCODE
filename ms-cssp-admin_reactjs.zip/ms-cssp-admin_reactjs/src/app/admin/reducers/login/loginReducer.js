/* Copyright(C) Conduent Inc. - All Rights Reserved
	* Unauthorized copying of this file, via any medium is strictly prohibited
		* Proprietary and confidential
			
				* /
/*
 * Used to update the page wise login,
 * answers, validation errors.
 */

import * as types from '../../actions/actionTypes';
import { initialState } from '../initialState';

export default function loginReducer(
	state,
	action
) {

	if (typeof state === 'undefined') {
		state = initialState.loginReducer;
	}

	switch (action.type) {

	case types.FETCH_LOGIN_DATA_BEGIN:
	case types.VALIDATE_LOGIN_DATA_BEGIN:
		// Mark the state as "loading" so we
		// can show a spinner or something
		// Also, reset any errors. We're starting fresh.
		return {
			...state,
			loading: true,
			invalidData: null,
			validData: null,
			error: null
		};

	case types.FETCH_LOGIN_DATA_SUCCESS:
		// All done: set loading "false".
		// Also, replace the items with the
		// ones from the server
		return {
			...state,
			loading: false,
			loginData: action.payload
		};

	case types.FETCH_LOGIN_DATA_FAILURE:
		// The request failed. It's done. So set loading to "false".
		// Save the error, so we can display it somewhere.
		// Since it failed, we don't have items
		// to display anymore, so set `items` empty.
		return {
			...state,
			loading: false,
			error: action.payload.error,
			loginData: {}
		};
	case types.VALIDATE_LOGIN_DATA_SUCCESS:
		// All done: set loading "false".
		// Also, replace the items with the
		// ones from the server
		return {
			...state,
			// loading: false,
			validData: action.payload.data
		};
	case types.VALIDATE_LOGIN_DATA_FAILURE:
		// The request failed. It's done. So set loading to "false".
		// Save the error, so we can display it somewhere.
		// Since it failed, we don't have items
		// to display anymore, so set `items` empty.
		return {
			...state,
			loading: false,
			error: action.payload.error
		};
	case types.VALIDATE_LOGIN_DATA_INVALID:
		// The request failed. It's done. So set loading to "false".
		// Save the error, so we can display it somewhere.
		// Since it failed, we don't have items
		// to display anymore, so set `items` empty.
		return {
			...state,
			loading: false,
			invalidData: action.payload.data
		};
	default:
		// ALWAYS have a default case in a reducer
		return state;
	}
}
