import Storage from '../utils/storage';

const getUserReducerKeys = () => {
	let userId = 'mockUserId';
	if (
		Storage.getItem('consumerAccountId') &&
		Storage.getItem('consumerAccountId') !== ''
	) {
		userId = Storage.getItem('consumerAccountId');
	}

	return {
		documentUploadReducer: {
			keyDocumentUploadPageData: `documentUploadPageData_${userId}`,
			keyUploadedDocData: `uploadedDocData_${userId}`,
			keyUploadSubmitData: `uploadSubmitData_${userId}`,
			keyShowUploadModal: `showUploadModal_${userId}`,
			keyShowSubmitModal: `showSubmitModal_${userId}`,
			keyPersonData: `personData_${userId}`,
			keyLoading: `loading_${userId}`,
			keyError: `error_${userId}`,
			keyApiError: `apiError_${userId}`,
			keyApiErrorMsg: `apiErrorMsg_${userId}`,
			keyShowSaveUploadError: `showSaveUploadError_${userId}`,
			keyFileNames: `fileNames_${userId}`,
			keyUploadDocumentScanData: `uploadDocumentScanData_${userId}`
		},
		personListReducer: {
			keyUser: `user_${userId}`
		}
	};
};

export default getUserReducerKeys;
