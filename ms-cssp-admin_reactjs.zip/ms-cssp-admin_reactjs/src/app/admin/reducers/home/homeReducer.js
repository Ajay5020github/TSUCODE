
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 
 */
/*
 * Used to update the json configuration
 * for the home page.
 */

import * as types from '../../actions/actionTypes';
import { initialState } from '../initialState';

export default function homeReducer(
	state,
	action
) {

	if (typeof state === 'undefined') {
		state = initialState.homeReducer
	}

	switch (action.type) {
	case types.FETCH_HOME_PAGE_DATA_BEGIN:
		// Mark the state as "loading" so
		// we can show a spinner or something
		// Also, reset any errors. We're starting fresh.
		return {
			...state,
			loading: true,
			error: null
		};

	case types.FETCH_HOME_PAGE_DATA_SUCCESS:
		// All done: set loading "false".
		// Also, replace the items with
		//the ones from the server
		return {
			...state,
			loading: false,
			homePageData: action.payload
		};

	case types.FETCH_HOME_PAGE_DATA_FAILURE:
		// The request failed. It's done. So set loading to "false".
		// Save the error, so we can display it somewhere.
		// Since it failed, we don't have items to
		// display anymore, so set `items` empty.
		return {
			...state,
			loading: false,
			error: action.payload.error,
			homePageData: []
		};

	default:
		// ALWAYS have a default case in a reducer
		return state;
	}
}
