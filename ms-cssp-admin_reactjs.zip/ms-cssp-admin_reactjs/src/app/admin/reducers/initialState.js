/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 
 */

/**
 * It defines the initial state
 * of the application.
 * All the initial states for every
 * reducer should be defined in this file.
 */



export const initialState = {
	loaderReducer: {
		text: ''
	},
	loginReducer: {
		loginData: {},
		validData: {},
		invalidData: null,
		loading: false,
		error: null
	},
	userDashboardReducer: {
		userDashboardData: {},
		loading: false,
		error: null,
		applicationList: []
	},	
	forgotPasswordReducer: {
		forgotPasswordData: {},
		validatedUserIdData: {},
		validatedSecurityQuestionsData: {},
		resetUserPasswordData: {},
		loading: false,
		error: null
	},
	updatePasswordReducer: {
		updatePasswordData: {},
		updateUserPasswordData: {},
		loading: false,
		error: null
	},
	forgotUserIdReducer: {
		forgotUserIdData: {},
		validatedUserInfoData: {},
		validatedUserIdSecurityQuestionsData: {},
		loading: false,
		error: null
	},	
	//adding auth idle timeout reducer to initial state
	authIdleTimeoutReducer: {
		authIdleTimeoutData: null
	},
	userDetailsReducer: {
		singleUserDetail : {},
		singleSelectedUser: {},
		loading: false,
		error: null
	},
	footerReducer: {
		footerPageData: {},		
		loading: false,
		error: null
	},
	userManagementReducer: {
		userManagementData: {},
		storeSearchUserCriteria: {},
		searchUserData: {},
		storedata: {},
		loading: false,
		error: null
	},
	userAuthReducer: {
		 person :{},
		userAuthData: {},
		singleUserAuthDetail: {},
		loading: false,
		error: null
	}

};
