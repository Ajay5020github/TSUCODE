
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Infinite 2022.
 */
/*
 * Used to update the json configuration
 * for the footer section.
 */

import * as types from '../../actions/actionTypes';

export default function footerReducer(
	state = {},
	action
) {

	switch (action.type) {
	case types.FETCH_FOOTER_PAGE_DATA_BEGIN:
		// Mark the state as "loading" so
		// we can show a spinner or something
		// Also, reset any errors. We're starting fresh.
		return {
			...state,
			loading: true,
			error: null
		};

	case types.FETCH_FOOTER_PAGE_DATA_SUCCESS:
		// All done: set loading "false".
		// Also, replace the items with
		//the ones from the server
		return {
			...state,
			loading: false,
			footerPageData: action.payload
		};

	case types.FETCH_FOOTER_PAGE_DATA_FAILURE:
		// The request failed. It's done. So set loading to "false".
		// Save the error, so we can display it somewhere.
		// Since it failed, we don't have items to
		// display anymore, so set `items` empty.
		return {
			...state,
			loading: false,
			error: action.payload.error,
			footerPageData: []
		};

	default:
		// ALWAYS have a default case in a reducer
		return state;
	}
}
