export default function createSetIntervalPolyFill() {
  // closure
  var intervalID = 0;
  var intervalMap = {};
  function setIntervalPolyFill(callbackFn, delay = 0, ...args) {
    if (typeof callbackFn !== 'function') {
      throw new Error("'callback' should be a function")
    }
    // Unique
    var id = intervalID++;
    function repeat() {
      intervalMap[id] = setMyTimeOut(
        () => {
          callbackFn(...args);
          // Terminating
          if (intervalMap[id]) {
            repeat();
          }
        }, delay)
    }
    repeat();
    return id;
  }
  function clearIntervalPolyFill(intervalID) {
    // clearTimeout(intervalMap[intervalID]);
    delete intervalMap[intervalID];
  }
  return {
    setIntervalPolyFill,
    clearIntervalPolyFill
  }
}
function setMyTimeOut(cb, ms) {
  var now = performance.now();
  window.addEventListener('message', handleMessage);
  let num = Math.random()
  postMessage('timeout' + num, '*');
  function handleMessage(evt) {
    if (evt.data === 'timeout' + num) {
      if (performance.now() - now >= ms) {
        window.removeEventListener('message', handleMessage);
        cb();
      }
      else {
        postMessage('timeout' + num, '*');
      }
    }
  }
  return true;
}

