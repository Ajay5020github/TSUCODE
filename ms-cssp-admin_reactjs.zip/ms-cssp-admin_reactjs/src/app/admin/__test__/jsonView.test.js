
import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import { createStore } from 'redux';
import { RemoveParentId } from '../jsoneditor/components/helper/helper';

import allReducers from '../jsoneditor/reducers';
import {JsonView} from '../jsoneditor/components/JsonView/index';
import {mockdata} from './__mockData__/mockdata'
import expect from 'expect';

const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;

const jsonStore = createStore(
	allReducers
);

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

describe('Configuration Publisher Testing:', () => {
	test('Opening JSON file in a JSON View', async () => {
        
        const stateMock = {
			testData: mockdata.treeViewLabelData
        };

        const component = mount(
			<Router>
                <Provider store={jsonStore}>
                    <JsonView data = {RemoveParentId(stateMock.testData, "$ID", "$PID")}/>
                </Provider>                
        </Router>);
    }, 60000);
});
