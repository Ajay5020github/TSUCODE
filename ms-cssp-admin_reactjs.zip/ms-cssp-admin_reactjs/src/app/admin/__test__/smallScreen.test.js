import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import { createStore } from 'redux';
import { convertToJson } from '../jsoneditor/components/helper/helper';

import allReducers from '../jsoneditor/reducers';
import SmallScreen from '../jsoneditor/components/SmallScreen';

import expect from 'expect';
import {mockdata} from './__mockData__/mockdata'

const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;

const jsonStore = createStore(
	allReducers
);

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

describe('Configuration Publisher Testing:', () => {
	test('Testing SmallScreen', async () => {
       
        const component = mount(
			<Router>
                <Provider store={jsonStore}>
                    <SmallScreen />
                </Provider>                
        </Router>);
    }, 60000);
});
