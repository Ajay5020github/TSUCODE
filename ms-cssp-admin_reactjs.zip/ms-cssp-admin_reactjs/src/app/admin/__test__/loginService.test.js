import React from 'react';
import '../matchMedia.mock';
import { render, fireEvent, screen } from '@testing-library/react';

import CONFIG from '../config/index';
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import { async } from 'q';
import {loginValidate} from '../actions/login/loginService';
import Storage from '../utils/storage';
import {mockdata} from './__mockData__/mockdata'
import axios from 'axios';
// import { render, waitFor } from "react-testing-library";

const saveJSON = {};
let authToken = "";

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

jest.mock('axios');

describe('Login Service:  ', () => {
    test('Check Login Service', async () => {
        saveJSON.userId = "superuser";
		saveJSON.password = "Password1";

        const fakeResp = {
            data : {
                "consumerUserId": "superuser",
                "authToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJzdXBlcnVzZXIiLCJpYXQiOjE2MzIzNzc4OTcsImV4cCI6MTYzMjQ2NDI5N30.j-axxtGtq36dRB9jxyYoimJ5_9sr9Ykvr2Ucj_Aol6E",
                "statusCode": 0,
                "message": "User authenticated successfully",
                "firstName": "Super",
                "roleCodes": [
                "REPORTS",
                "ACCOUNTMANAGEMENT",
                "JSONEDITOR"
                ]
            }            
          };

        const expectedRes =  {
            data : {
                "consumerUserId": "superuser",
                "authToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJzdXBlcnVzZXIiLCJpYXQiOjE2MzIzNzc4OTcsImV4cCI6MTYzMjQ2NDI5N30.j-axxtGtq36dRB9jxyYoimJ5_9sr9Ykvr2Ucj_Aol6E",
                "statusCode": 0,
                "message": "User authenticated successfully",
                "firstName": "Super",
                "roleCodes": [
                "REPORTS",
                "ACCOUNTMANAGEMENT",
                "JSONEDITOR"
                ]
            }
        }

        axios.post.mockResolvedValue(fakeResp);

        await loginValidate(saveJSON).then(res => expect(expectedRes.data.firstName).toContain(res.firstName));
    })
})
