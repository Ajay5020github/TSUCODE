import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import UserManagementTable from '../components/userManagementComponents/userManagementTable';
import {userDashboardService} from '../actions/userDashboard/userDashboardService';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import expect from 'expect';
//import configureMockStore from 'redux-mock-store';
import Storage from '../utils/storage';
import withStyles from '@mui/styles/withStyles';
import configureStore from '../store/configureStore';
import { Provider } from 'react-redux';
import {mockdata} from './__mockData__/mockdata'
import * as actions from '../actions/userManagement/userManagementActions'
import * as types from '../actions/actionTypes'
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store';
import { userManageService } from '../actions/userManagement/userManagementServices';
import axios from 'axios';
const { store, persistor } = configureStore();
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
let userManagementJson = {};
let applicationListData = {};
//let loginData = {};

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

const middlewares = [thunk];
//const mockStore = configureMockStore(middlewares);

//usermanagement component render testing
jest.mock('axios');

describe('login report services : ', () => {
    test('Fetch the label JSON Service', async () => {

        userManagementJson = mockdata.userManagementJson;
        axios.get.mockResolvedValue(userManagementJson);

		await userManageService(languageId, stateId).then(res => {
			expect(userManagementJson.data).toEqual(res);
			userManagementJson = res;
		})
       
    })
});

describe('user management table component testing', () => {
	test('usermanagement table should not be null', async () => {
        //Storage.setItem('roleCodes', ["REPORTS", "ACCOUNTMANAGEMENT", "JSONEDITOR"]);
       let searchData = [{}];
       let jsonData = {}
        userManagementJson = mockdata.userManagementJson;
        const component = mount(
			<Router><Provider store={store}>
		<UserManagementTable searchResult={searchData} json={userManagementJson} />
        
        </Provider></Router>);
    }, 60000);
});
// describe('actions test', () => {
// 	const data = mockdata.userManagementJson;
// 	// Actions for fetch configPublis JSon
	
// 	it('should create an action to fetch usermanagement data success', () => {
// 		const expectedAction = {
// 			type: types.FETCH_USERMANAGEMENT_DATA_SUCCESS,
// 			payload: {data}
// 		};
// 		expect(actions.fetchUserManagementDataSuccess(data)).toMatchObject(expectedAction);
// 	}, 60000);
// 	it('should create an action to fetch usermanagement data error', () => {
// 		const error = 'Error occured';
// 		const expectedAction = {
// 			type: types.FETCH_USERMANAGEMENT_DATA_FAILURE,
// 				payload: { error }
// 		};
// 		expect(actions.fetchUserManagementDataFailure(error)).toMatchObject(expectedAction);
//     }, 60000);
// });

