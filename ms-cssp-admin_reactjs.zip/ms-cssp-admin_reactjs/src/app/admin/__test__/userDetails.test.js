import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import { createStore } from 'redux';
import { convertToJson } from '../jsoneditor/components/helper/helper';

import allReducers from '../reducers/rootReducer';
import User from '../components/userManagementComponents/user';

import expect from 'expect';
import Storage from '../utils/storage';
import SaveToDatabase from '../jsoneditor/components/SaveToDatabase';
import {mockdata} from './__mockData__/mockdata'
import * as actions from '../actions/userDetails/userDetailsActions'
import * as types from '../actions/actionTypes'
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store';
import { userDetailsService } from '../actions/userDetails/userDetailsService';
import axios from 'axios';

const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
let userDetailsData = {};
const jsonStore = createStore(
	allReducers
);

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

jest.mock('axios');

describe('login report services : ', () => {
    test('Fetch the label JSON Service', async () => {

			userDetailsData = mockdata.userDetailsData;
        axios.get.mockResolvedValue(userDetailsData);

		await userDetailsService(languageId, stateId).then(res => {
			expect(userDetailsData.data).toEqual(res);
			userDetailsData = res;
		})
       
    })
});

describe('User detail Testing:', () => {
	
	test('user detail test', async () => {
		
        
  const userDetailsData = mockdata.userDetailsData;
	const component = mount(
			
     <Provider store={jsonStore}>
  	    <User
					buttons={userDetailsData && userDetailsData.content && userDetailsData.content.buttons.config}
					labels={userDetailsData && userDetailsData.content && userDetailsData.content.labels.config}
					breadcrumb={userDetailsData && userDetailsData.content && userDetailsData.content.banner.content.breadCrumb}
				/>
      </Provider>                
        )
    }, 60000);
});

describe('actions test', () => {
	const data = mockdata.userDetailsData;
	// Actions for fetch userDetails JSon
	it('should create an action to fetch userDetails data begin', () => {
		const expectedAction = {
			type: types.FETCH_USER_DETAILS_DATA_BEGIN
		};
		expect(actions.userDetailsDataBegin()).toEqual(expectedAction);
	}, 60000);
	it('should create an action to fetch userDetails data success', () => {
		const expectedAction = {
			type: types.FETCH_USER_DETAILS_DATA_SUCCESS,
			payload: {data}
		};
		expect(actions.userDetailsDataSuccess(data)).toMatchObject(expectedAction);
	}, 60000);
	it('should create an action to fetch userDetails data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.FETCH_USER_DETAILS_DATA_FAILURE,
				payload: { error }
		};
		expect(actions.userDetailsDataFailure(error)).toMatchObject(expectedAction);
    }, 60000);
/////////////////////////////////////////////////////////////////////////////////////////////////////
    
	it('should create an action to fetch userDetails data success', () => {
		const expectedAction = {
			type: types.FETCH_SINGLE_USER_DETAILS,
			payload: {data}
		};
		expect(actions.singleUserDetailSuccess(data)).toMatchObject(expectedAction);
	}, 60000);
	it('should create an action to fetch userDetails data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.FETCH_SINGLE_USER_DETAILS_FAILURE,
				payload: { error }
		};
		expect(actions.singleUserDetailError(error)).toMatchObject(expectedAction);
    }, 60000);
    /////////////////////////////////////////////////////////////////////////////////////////////////////
    it('should create an action to fetch userDetails data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.CLEAR_USER_DETAILS,
				payload: { singleSelectedUser: {},
                            userDetailsData: {} }
		};
		expect(actions.ClearUserDetail()).toMatchObject(expectedAction);
    }, 60000);

    it('should create an action to fetch userDetails data error', () => {
		const data = {};
		const expectedAction = {
			type: types.STORE_SELECTED_USER_DETAIL,
				payload: { data }
		};
		expect(actions.storeSelectedUserData(data)).toMatchObject(expectedAction);
		}, 60000);
});
