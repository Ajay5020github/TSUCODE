import React from 'react';
import '../matchMedia.mock';

import CONFIG from '../config/index';
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import { async } from 'q';
import { publishJson } from '../services/ConfigurePublisherService';
import Storage from '../utils/storage';
import axios from 'axios';


import {mockdata} from './__mockData__/mockdata'

const saveJSON = {};
let authToken = "";

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

jest.mock('axios');

describe('Configuration Publisher Services :  ', () => {
    test('Publish JSON Service', async () => {

        let publishJsondata = {
            "jsonScreenName": "EducationAndTrainingJSON",
            "language": "en",
            "comments": "Publish JSON through Jest Test",
            "json": mockdata.treeViewLabelData,
            "jsonFileName": "enEducationAndTraining.json"
        };

        
        const fakeResp = {
            data : {
                "json": mockdata.saveJsonFakeResponse
            }
        }

        const expectedRes = {
            data : {
                "json": mockdata.saveJsonExpectedResult
            }
        }

        axios.post.mockResolvedValue(fakeResp);

        await publishJson(publishJsondata).then(res => expect(expectedRes.data).toEqual(res))
       
    })
})
