import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import UserManagementComponent from '../components/userManagementComponents/userManagementComponents';
import UserData from '../components/userManagementComponents/userData';
import {userDashboardService} from '../actions/userDashboard/userDashboardService';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import expect from 'expect';
//import configureMockStore from 'redux-mock-store';
import Storage from '../utils/storage';
import withStyles from '@mui/styles/withStyles';
import configureStore from '../store/configureStore';
import { Provider } from 'react-redux';
import {mockdata} from './__mockData__/mockdata'
import * as actions from '../actions/userManagement/userManagementActions'
import * as types from '../actions/actionTypes'
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store';
import { userManageService, searchUserService  } from '../actions/userManagement/userManagementServices';
import axios from 'axios';
const { store, persistor } = configureStore();
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
let userManagementJson = {};
let searchUserData = {};
let searchUserResults = {};
let applicationListData = {};
//let loginData = {};

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

const middlewares = [thunk];
//const mockStore = configureMockStore(middlewares);

//usermanagement component render testing
jest.mock('axios');

describe('User Management services : ', () => {
    test('Fetch the label JSON Service', async () => {

        userManagementJson = mockdata.userManagementJson;
        axios.get.mockResolvedValue(userManagementJson);

		await userManageService(languageId, stateId).then(res => {
			expect(userManagementJson.data).toEqual(res);
			userManagementJson = res;
		})
       
    })
});

describe('User Management services : ', () => {
    test('Search User Data', async () => {

		searchUserData = mockdata.fakeSearchUserRequest;
		searchUserResults = mockdata.fakeSearchUserResponse;
        axios.post.mockResolvedValue(searchUserResults);

		await searchUserService(searchUserData).then(res => {
			expect(searchUserResults.data).toEqual(res);
			searchUserResults = res;
		})

	
       
    })
});

describe('user management component testing', () => {
	test('usermanagement should not be null', async () => {
        //Storage.setItem('roleCodes', ["REPORTS", "ACCOUNTMANAGEMENT", "JSONEDITOR"]);
        
        const component = mount(
			<Router><Provider store={store}>
		<UserManagementComponent json={userManagementJson} 
        userSearchCriteria={[]}
        />
        
        </Provider></Router>);
    }, 60000);
});

describe('user management component testing', () => {
	test('User Data should not be null', async () => {
        //Storage.setItem('roleCodes', ["REPORTS", "ACCOUNTMANAGEMENT", "JSONEDITOR"]);
        
        const component = mount(
			<Router><Provider store={store}>
				<UserData viewUserJson = {() => {}} user={() => {}} key={() => {}}/>
        		{/* /> */}
        
        </Provider></Router>);
    }, 60000);
});



describe('actions test', () => {
	const data = mockdata.userManagementJson;
	// Actions for fetch configPublis JSon
	
	it('should create an action to fetch usermanagement data success', () => {
		const expectedAction = {
			type: types.FETCH_USERMANAGEMENT_DATA_SUCCESS,
			payload: {data}
		};
		expect(actions.fetchUserManagementDataSuccess(data)).toMatchObject(expectedAction);
	}, 60000);
	it('should create an action to fetch usermanagement data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.FETCH_USERMANAGEMENT_DATA_FAILURE,
				payload: { error }
		};
		expect(actions.fetchUserManagementDataFailure(error)).toMatchObject(expectedAction);
    }, 60000);
});

