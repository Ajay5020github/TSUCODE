import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Footer from '../components/footer/footer';
//import {userDashboardService} from '../actions/userDashboard/userDashboardService';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import expect from 'expect';
//import configureMockStore from 'redux-mock-store';
import Storage from '../utils/storage';
import configureStore from '../store/configureStore';
import { Provider } from 'react-redux';
import {mockdata} from './__mockData__/mockdata'
const { store, persistor } = configureStore();
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;


Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

const middlewares = [thunk];
//const mockStore = configureMockStore(middlewares);

//dashboard component render testing
describe('header component testing', () => {
	test('header should render', async () => {
        Storage.setItem('roleCodes', ["REPORTS", "ACCOUNTMANAGEMENT", "JSONEDITOR"]);
        const adminReportDetailLabelData = mockdata.adminReportDetailLabelData;
        const component = mount(
			<Router><Provider store={store}>
		<Footer content={adminReportDetailLabelData.footer && adminReportDetailLabelData.footer.content} />
       </Provider> </Router>);
    }, 60000);
});
