import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import AdminReportComponent from '../components/adminReport/adminReportComponent';
import {userDashboardService} from '../actions/userDashboard/userDashboardService';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import expect from 'expect';
//import configureMockStore from 'redux-mock-store';
import Storage from '../utils/storage';
import {mockdata} from './__mockData__/mockdata'
import * as actions from '../actions/reportList/adminReportListAction'
import * as types from '../actions/actionTypes'
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store';
import { adminReportListService } from '../actions/reportList/adminReportListService';
import axios from 'axios';
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
let adminReportLabelData = {};
let applicationListData = {};
//let loginData = {};

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

const middlewares = [thunk];
//const mockStore = configureMockStore(middlewares);

//dashboard component render testing

jest.mock('axios');

describe('Admin report services : ', () => {
    test('Fetch the label JSON Service', async () => {

        adminReportLabelData = mockdata.adminReportLabelData;
        axios.get.mockResolvedValue(adminReportLabelData);

		await adminReportListService(languageId, stateId).then(res => {
			expect(adminReportLabelData.data).toEqual(res);
			adminReportLabelData = res.data;
		})
       
    })
});

describe('admin report component testing', () => {
	test('adminreport should not be null', async () => {
        Storage.setItem('roleCodes', ["REPORTS", "ACCOUNTMANAGEMENT", "JSONEDITOR"]);
		const adminReportLabelData = mockdata.adminReportLabelData;
		let environment = "DEV";

        const component = mount(
			<Router>
		<AdminReportComponent adminReportLabelData={adminReportLabelData} environment={environment} />
        </Router>);
    }, 60000);
});

describe('actions test', () => {
	const data = mockdata.adminReportLabelData;
    // Actions for fetch configPublis JSon
    it('should create an action to fetch configPublis data begin', () => {
		const expectedAction = {
			type: types.FETCH_ADMIN_REPORT_DATA_BEGIN
		};
		expect(actions.fetchAdminReportDataBegin()).toEqual(expectedAction);
	}, 60000);
	
	it('should create an action to fetch usermanagement data success', () => {
		const expectedAction = {
			type: types.FETCH_ADMIN_REPORT_DATA_SUCCESS,
			payload: {data}
		};
		expect(actions.fetchAdminReportDataSuccess(data)).toMatchObject(expectedAction);
	}, 60000);
	it('should create an action to fetch usermanagement data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.FETCH_ADMIN_REPORT_DATA_FAILURE,
				payload: { error }
		};
		expect(actions.fetchAdminReportDataFailure(error)).toMatchObject(expectedAction);
    }, 60000);
});
