import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import LoginForm from '../components/loginForm/loginForm';
//import {userDashboardService} from '../actions/userDashboard/userDashboardService';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import expect from 'expect';
//import configureMockStore from 'redux-mock-store';
import Storage from '../utils/storage';
import configureStore from '../store/configureStore';
import { Provider } from 'react-redux';
import {mockdata} from './__mockData__/mockdata'
import * as actions from '../actions/login/loginActions'
import * as types from '../actions/actionTypes'
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store';
import { loginService } from '../actions/login/loginService';
import axios from 'axios';
const { store, persistor } = configureStore();
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
let loginData = {};

Enzyme.configure({
    adapter: new Adapter(),
    disableLifecycleMethods: true
});

const middlewares = [thunk];
//const mockStore = configureMockStore(middlewares);

//login component render testing
jest.mock('axios');

describe('login report services : ', () => {
    test('Fetch the label JSON Service', async () => {

        loginData = mockdata.loginData;
        axios.get.mockResolvedValue(loginData);

		await loginService(languageId, stateId).then(res => {
			expect(loginData.data).toEqual(res);
			loginData = res;
		})
       
    })
});

describe('login component testing', () => {
    test('login should render', async () => {
        //Storage.setItem('roleCodes', ["REPORTS", "ACCOUNTMANAGEMENT", "JSONEDITOR"]);
        //const loginData = mockdata.loginData;
        const component = mount(
            <Router><Provider store={store}>
                <LoginForm
                    {...loginData.content.login}
                    onSubmitModalButtonClick={
                        () => { }
                    }
                    onShowSubmitModal={
                        () => { }
                    }
                    showSubmitModal={
                        false
                    }
                    onShowChangePasswordModal={
                        () => { }
                    }
                    showChangePasswordModal={
                        false
                    }
                    componentState={{}}
                    handleChange={() => { }}
                    onClickSubmit={() => { }}
                    onClickGoBackToHome={() => { }}
                    invalidData={''}
                    validData={''}
                    handleBlur={() => { }}
                />

            </Provider> </Router>);
    }, 60000);
});

describe('actions test', () => {
	const data = mockdata.loginData;
	// Actions for fetch configPublis JSon
	it('should create an action to fetch login data begin', () => {
		const expectedAction = {
			type: types.FETCH_LOGIN_DATA_BEGIN
		};
		expect(actions.fetchLoginDataBegin()).toEqual(expectedAction);
	}, 60000);
	it('should create an action to fetch login data success', () => {
		const expectedAction = {
			type: types.FETCH_LOGIN_DATA_SUCCESS,
			payload: {data}
		};
		expect(actions.fetchLoginDataSuccess(data)).toMatchObject(expectedAction);
	}, 60000);
	it('should create an action to fetch login data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.FETCH_LOGIN_DATA_FAILURE,
				payload: { error }
		};
		expect(actions.fetchLoginDataFailure(error)).toMatchObject(expectedAction);
    }, 60000);

////////////////////////////////////////////////////////////////////////////////////////////////////////////
    it('should create an action to fetch login data begin', () => {
		const expectedAction = {
			type: types.VALIDATE_LOGIN_DATA_BEGIN
		};
		expect(actions.validateLoginDataBegin()).toEqual(expectedAction);
	}, 60000);
	it('should create an action to fetch login data success', () => {
		const expectedAction = {
			type: types.VALIDATE_LOGIN_DATA_SUCCESS,
			payload: {data}
		};
		expect(actions.validateLoginDataSuccess(data)).toMatchObject(expectedAction);
	}, 60000);
	it('should create an action to fetch login data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.VALIDATE_LOGIN_DATA_FAILURE,
				payload: { error }
		};
		expect(actions.validateLoginDataFailure(error)).toMatchObject(expectedAction);
    }, 60000);

    it('should create an action to fetch login data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.VALIDATE_LOGIN_DATA_INVALID,
				payload: { data }
		};
		expect(actions.validateLoginDataInvalid(data)).toMatchObject(expectedAction);
    }, 60000);
});
