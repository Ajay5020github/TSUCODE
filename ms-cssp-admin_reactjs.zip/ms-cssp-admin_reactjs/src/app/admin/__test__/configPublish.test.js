import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import ReactJsonBuilder from '../jsoneditor/ReactJsonBuilder';
//import {userDashboardService} from '../actions/userDashboard/userDashboardService';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import expect from 'expect';
//import configureMockStore from 'redux-mock-store';
import Storage from '../utils/storage';
import {mockdata} from './__mockData__/mockdata'
import * as actions from '../actions/configurationPublisher/configurationsPublisherActions'
import * as types from '../actions/actionTypes'
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store';
import { configPublishService } from '../actions/configurationPublisher/configurationsPublisherService';
import axios from 'axios';

const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
let publishLabelData = {}
//let dashboardData = {};
//let applicationListData = {};
//let loginData = {};

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

const middlewares = [thunk];
//const mockStore = configureMockStore(middlewares);

//dashboard component render testing
jest.mock('axios');

describe('Configuration Publisher Services : ', () => {
    test('Fetch the label JSON Service', async () => {

        publishLabelData = mockdata.publishLabelData;
        axios.get.mockResolvedValue(publishLabelData);

		await configPublishService(languageId, stateId).then(res => {
			expect(publishLabelData.data).toEqual(res);
			publishLabelData = res;
		})
       
    })
});

describe('configuration publisher component testing', () => {
	test('configurationpublisher should render', async () => {
        Storage.setItem('roleCodes', ["REPORTS", "ACCOUNTMANAGEMENT", "JSONEDITOR"]);
        //const publishLabelData = mockdata.publishLabelData.data;
        const component = mount(
			<Router>
		<ReactJsonBuilder publishLabelData={publishLabelData} />
        </Router>);
    }, 60000);
});

describe('actions test', () => {
	const data = mockdata.publishLabelData;
	// Actions for fetch configPublis JSon
	it('should create an action to fetch configPublis data begin', () => {
		const expectedAction = {
			type: types.FETCH_CONFIG_PUBLISH_DATA_BEGIN
		};
		expect(actions.fetchConfigPublishDataBegin()).toEqual(expectedAction);
	}, 60000);
	it('should create an action to fetch configPublis data success', () => {
		const expectedAction = {
			type: types.FETCH_CONFIG_PUBLISH_DATA_SUCCESS,
			payload: {data}
		};
		expect(actions.fetchConfigPublishDataSuccess(data)).toMatchObject(expectedAction);
	}, 60000);
	it('should create an action to fetch configPublis data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.FETCH_CONFIG_PUBLISH_DATA_FAILURE,
				payload: { error }
		};
		expect(actions.fetchConfigPublishDataFailure(error)).toMatchObject(expectedAction);
    }, 60000);
});
