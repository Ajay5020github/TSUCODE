import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import { createStore } from 'redux';
import { convertToJson } from '../jsoneditor/components/helper/helper';

import allReducers from '../jsoneditor/reducers';
import RevertFromDatabase from '../jsoneditor/components/RevertFromDatabase';

import expect from 'expect';
import Storage from '../utils/storage';
import OpenFromCloud from '../jsoneditor/components/OpenFromCloud';
import {mockdata} from './__mockData__/mockdata'
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;

const jsonStore = createStore(
	allReducers
);

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

describe('Configuration Publisher Testing:', () => {
	test('Open from Cloud JSON Dialog', async () => {
        const fileName = Storage.setItem('fileName', 'enEducationAndTrainingJSON.json');
        const languageId = Storage.setItem('languageId', 'en');
        const screenName = Storage.setItem('screenName', 'EducationAndTrainingJSON');

        const publishLabelData = mockdata.publishLabelData.data;

        const component = mount(
			<Router>
                <Provider store={jsonStore}>
                <OpenFromCloud 
                    openFileDialog={false} 
                    handleCloseFileDialog={true} 
                    labels={publishLabelData.content && publishLabelData.content.labels && publishLabelData.content.labels.config}                    
                    buttons={publishLabelData.content && publishLabelData.content.buttons && publishLabelData.content.buttons.config}
                    />
                </Provider>                
        </Router>);
    }, 60000);
});
