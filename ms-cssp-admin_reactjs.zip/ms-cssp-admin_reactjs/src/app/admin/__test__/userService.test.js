import React from 'react';
import '../matchMedia.mock';

import CONFIG from '../config/index';
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import { async } from 'q';
import { viewUserService, unlockUserAccount, resetPassword,  } from '../services/UserService';
import Storage from '../utils/storage';
import axios from 'axios';


import {mockdata} from './__mockData__/mockdata'

const saveJSON = {};
let authToken = "";

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

jest.mock('axios');

describe('User Services :  ', () => {
    test('View User Service', async () => {

        let fakeUserData = mockdata.fakeUserData;
        let fakeUserDataResult = mockdata.fakeUserDataResult;

        axios.post.mockResolvedValue(fakeUserDataResult);

        await viewUserService(fakeUserData).then(res => expect(fakeUserDataResult.body).toEqual(fakeUserDataResult.body))
       
    })
})
