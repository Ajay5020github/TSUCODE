import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import { createStore } from 'redux';
import { convertToJson } from '../jsoneditor/components/helper/helper';

import allReducers from '../jsoneditor/reducers';
import ViewLockedJsons from '../jsoneditor/components/ViewLockedJsons';

import expect from 'expect';
import Storage from '../utils/storage';
import {mockdata} from './__mockData__/mockdata'
import configureMockStore from 'redux-mock-store';
import * as actions from '../actions/configurationPublisher/configurationsPublisherActions';
import * as types from '../actions/actionTypes';
import {configPublishService} from '../actions/configurationPublisher/configurationsPublisherService';
import axios from 'axios';
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
let publishLabelData = {};

const jsonStore = createStore(
	allReducers
);

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

describe('Configuration Publisher Testing:', () => {
	test('Opening View Log JSON Dialog', async () => {
        
        const publishLabelData = mockdata.publishLabelData.data;

        const component = mount(
			<Router>
                <Provider store={jsonStore}>
                    <ViewLockedJsons 
                        lockedJsonFilesDialog={false} 
                        handleCloseLockedJsonFiles={true} 
                        messages={publishLabelData  && publishLabelData.formMessages}
                        viewLockedJsons={publishLabelData  &&  publishLabelData.content && publishLabelData.content.viewlockedjson.config}                        
                    />
                </Provider>                
        </Router>);
    }, 60000);
});

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

jest.mock('axios');

describe('Configuration Publisher Services : ', () => {
    test('Fetch the label JSON Service', async () => {
        publishLabelData = mockdata.publishLabelData;
        axios.get.mockResolvedValue(publishLabelData);
                await configPublishService(languageId, stateId).then(res => {
                expect(publishLabelData.data).toEqual(res)
                publishLabelData = res;
        })       
    })
});

describe('actions test', () => {
	const configPublishData = publishLabelData;
	// Actions for fetch dashboard JSon
	it('should create an action to fetch config publish begin', () => {
		const expectedAction = {
			type: types.FETCH_CONFIG_PUBLISH_DATA_BEGIN
		};
		expect(actions.fetchConfigPublishDataBegin()).toEqual(expectedAction);
	}, 60000);
	it('should create an action to fetch config publish success', () => {
		const expectedAction = {
			type: types.FETCH_CONFIG_PUBLISH_DATA_SUCCESS,
			payload: {}
		};
		expect(actions.fetchConfigPublishDataSuccess({})).toMatchObject(expectedAction);
	}, 60000);
	it('should create an action to fetch config publish error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.FETCH_CONFIG_PUBLISH_DATA_FAILURE,
				payload: { error }
		};
		expect(actions.fetchConfigPublishDataFailure(error)).toMatchObject(expectedAction);
	}, 60000);
/////////////////////////////////////////////////////////////////////////////////

});
