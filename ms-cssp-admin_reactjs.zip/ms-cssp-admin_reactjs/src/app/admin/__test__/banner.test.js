import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Banner from '../components/banner/banner';
//import {userDashboardService} from '../actions/userDashboard/userDashboardService';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import expect from 'expect';
//import configureMockStore from 'redux-mock-store';
import Storage from '../utils/storage';
import {mockdata} from './__mockData__/mockdata'
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
//let dashboardData = {};
//let applicationListData = {};
//let loginData = {};

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

const middlewares = [thunk];
//const mockStore = configureMockStore(middlewares);

//dashboard component render testing
describe('banner component testing', () => {
	test('banner should render', async () => {
        Storage.setItem('roleCodes', ["REPORTS", "ACCOUNTMANAGEMENT", "JSONEDITOR"]);
        const adminReportDetailLabelData = mockdata.adminReportDetailLabelData;
        const component = mount(
			<Router>
		<Banner
            config={adminReportDetailLabelData.content && adminReportDetailLabelData.content.banner.config}
            content={adminReportDetailLabelData.content && adminReportDetailLabelData.content.banner.content} />
        </Router>);
    }, 60000);
});
