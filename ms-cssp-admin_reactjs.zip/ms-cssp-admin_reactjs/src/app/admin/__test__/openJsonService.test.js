import React from 'react';
import '../matchMedia.mock';

import CONFIG from '../config/index';
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import { async } from 'q';
import { fetchJson } from '../services/ConfigurePublisherService';
import Storage from '../utils/storage';
import axios from 'axios';


import {mockdata} from './__mockData__/mockdata'

const saveJSON = {};
let authToken = "";

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

jest.mock('axios');

describe('Open JSON Service:  ', () => {
    test('Check JSON open Service', async () => {

        const fetchJsonData = {
            "jsonScreenName": "EducationAndTrainingJSON",
            "language": "en"
        };

        
        const fakeResp = {
            data : {
                "json": mockdata.treeViewLabelData
            }
        }

        const expectedRes = {
            data : {
                "json": mockdata.expectedEducationTrainingResult
            }
        }

        axios.post.mockResolvedValue(fakeResp);

        await fetchJson(fetchJsonData).then(res => expect(expectedRes.data.json).toEqual(res.json))
       
    })
})
