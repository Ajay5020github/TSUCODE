import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import LoginForm from '../components/loginForm/loginForm';
//import {userDashboardService} from '../actions/userDashboard/userDashboardService';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import expect from 'expect';
//import configureMockStore from 'redux-mock-store';
import Storage from '../utils/storage';
import configureStore from '../store/configureStore';
import { Provider } from 'react-redux';
import {mockdata} from './__mockData__/mockdata'
import * as actions from '../actions/loader/loaderActions'
import * as types from '../actions/actionTypes'
import Loader from '../components/loader/loader';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store';
const { store, persistor } = configureStore();
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;


Enzyme.configure({
    adapter: new Adapter(),
    disableLifecycleMethods: true
});

const middlewares = [thunk];
//const mockStore = configureMockStore(middlewares);

describe('Admin Portal Testing:', () => {
	test('Testing Loader', async () => {
       
        const component = mount(
		    <Loader />
        );
    }, 60000);
});

describe('actions test', () => {
	const text = '';
	// Actions for fetch idal time out JSon
	it('should create an action to fetch idal time out data begin', () => {
		const expectedAction = {
            type: types.SET_LOADER_TEXT,
            payload: { text }
		};
		expect(actions.setLoaderText(text)).toEqual(expectedAction);
	}, 60000);
	
});
