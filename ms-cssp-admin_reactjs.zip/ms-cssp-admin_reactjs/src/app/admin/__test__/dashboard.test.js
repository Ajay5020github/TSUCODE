import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Dashboard from '../components/dashboard/dashboard';
import {userDashboardService} from '../actions/userDashboard/userDashboardService';
import thunk from 'redux-thunk';
import fetchMock from 'fetch-mock';

import expect from 'expect';
import configureMockStore from 'redux-mock-store';
import Storage from '../utils/storage';
import {mockdata} from './__mockData__/mockdata'
import * as actions from '../actions/userDashboard/userDashboardActions'
import * as types from '../actions/actionTypes';
//import { userDashboardService } from '../actions/userDashboard/userDashboardService';
import axios from 'axios';
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
let userDashboardLabelData = {};
let applicationListData = {};
//let loginData = {};

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

jest.mock('axios');

describe('Dashboard Services : ', () => {
    test('Fetch the label JSON Service', async () => {

		userDashboardLabelData = mockdata.userDashboardLabelData;
	    axios.get.mockResolvedValue(userDashboardLabelData);
		await userDashboardService(languageId, stateId).then(res => {
			expect(userDashboardLabelData.data).toEqual(res)
			userDashboardLabelData = res;
		})
       
    })
});

//dashboard component render testing
describe('dashboard component testing', () => {
	test('dashboardData should not be null', async () => {
        Storage.setItem('roleCodes', ["REPORTS", "ACCOUNTMANAGEMENT", "JSONEDITOR"]);
		//const userDashboardLabelData = mockdata.userDashboardLabelData;
		
        const component = mount(
			<Router>
		<Dashboard
		    buttons={userDashboardLabelData.content && userDashboardLabelData.content.buttons.config}
			labels={userDashboardLabelData.content && userDashboardLabelData.content.labels.config}
			welcomeText={userDashboardLabelData.content && userDashboardLabelData.content.welcomeText}
		/>
        </Router>);
    }, 60000);
});

describe('actions test', () => {
	const userDashboardData = userDashboardLabelData;
	// Actions for fetch dashboard JSon
	it('should create an action to fetch dashboard data begin', () => {
		const expectedAction = {
			type: types.FETCH_USER_DASHBOARD_DATA_BEGIN
		};
		expect(actions.fetchUserDashboardDataBegin()).toEqual(expectedAction);
	}, 60000);
	it('should create an action to fetch dashboard data success', () => {
		const expectedAction = {
			type: types.FETCH_USER_DASHBOARD_DATA_SUCCESS,
			payload: {userDashboardData}
		};
		expect(actions.fetchUserDashboardDataSuccess(userDashboardData)).toMatchObject(expectedAction);
	}, 60000);
	it('should create an action to fetch dashboard data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.FETCH_USER_DASHBOARD_DATA_FAILURE,
				payload: { error }
		};
		expect(actions.fetchUserDashboardDataFailure(error)).toMatchObject(expectedAction);
	}, 60000);
});

 describe('async actions test', () => {
	afterEach(() => {
		fetchMock.restore();
	});
	const userDashboardData = userDashboardLabelData;
	test('creates FETCH_USER_DASHBOARD_DATA_SUCCESS when fetching data has been done', () => {
		const endpoint = `${CONFIG.api.nodeUrl}/fetchConfigJson`;
		
		fetchMock.getOnce(endpoint, {
			resData: {
				statusCode: 200,
				success: true,
				data: 'do something'
			},
			headers: { 'content-type': 'application/json' }
		});

		const expectedActions = [
			{ type: types.FETCH_USER_DASHBOARD_DATA_BEGIN },
			{
				type: types.FETCH_USER_DASHBOARD_DATA_SUCCESS, payload: {
					userDashboardData
				}
			}
		];
		const store = mockStore({});

		return store.dispatch(actions.fetchUserDashboardData(languageId, stateId)).then(() => {
			// return of async actions
			expect(store.getActions()[0].type).toEqual(expectedActions[0].type);
		});
	}, 60000); 

}); 


