import React from 'react';
import '../matchMedia.mock';

import CONFIG from '../config/index';
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import { async } from 'q';
import { fetchLog } from '../services/ConfigurePublisherService';
import Storage from '../utils/storage';
import axios from 'axios';


import {mockdata} from './__mockData__/mockdata'

const saveJSON = {};
let authToken = "";

Enzyme.configure({
	adapter: new Adapter(),
	disableLifecycleMethods: true
});

jest.mock('axios');

describe('Configuration Publisher Services :  ', () => {
    test('Fetch Log JSON Service', async () => {

        const fetchInput = {
			"jsonScreenName": "EducationAndTrainingJSON",
			"language": "en"
		}
        
        const fakeResp = {
            data : {
                "json": mockdata.fetchLogFakeResponse
            }
        }

        const expectedRes = {
            data : {
                "json": mockdata.fetchLogExpectedResponse
            }
        }

        axios.post.mockResolvedValue(fakeResp);

        await fetchLog(fetchInput).then(res => expect(expectedRes.data).toEqual(res))
       
    })
})
