import React from 'react';
import '../matchMedia.mock';
import { render } from '@testing-library/react';
import CONFIG from '../config/index';
import { BrowserRouter as Router } from 'react-router-dom';
import Adapter from 'enzyme-adapter-react-16';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import LoginForm from '../components/loginForm/loginForm';
//import {userDashboardService} from '../actions/userDashboard/userDashboardService';
import thunk from 'redux-thunk';
//import fetchMock from 'fetch-mock';

import expect from 'expect';
//import configureMockStore from 'redux-mock-store';
import Storage from '../utils/storage';
import configureStore from '../store/configureStore';
import { Provider } from 'react-redux';
import {mockdata} from './__mockData__/mockdata'
import * as actions from '../actions/authIdleTimeout/authIdleTimeoutActions'
import * as types from '../actions/actionTypes'
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store';
const { store, persistor } = configureStore();
const languageId = CONFIG.defaultLang;
const stateId = CONFIG.defaultState;


Enzyme.configure({
    adapter: new Adapter(),
    disableLifecycleMethods: true
});

const middlewares = [thunk];
//const mockStore = configureMockStore(middlewares);


describe('actions test', () => {
	const data = mockdata.loginData;
	// Actions for fetch idal time out JSon
	it('should create an action to fetch idal time out data begin', () => {
		const expectedAction = {
			type: types.FETCH_AUTH_IDLETIMEOUT_DATA_BEGIN
		};
		expect(actions.fetchAuthIdleTimeoutDataBegin()).toEqual(expectedAction);
	}, 60000);
	it('should create an action to fetch idal time out data success', () => {
		const expectedAction = {
			type: types.FETCH_AUTH_IDLETIMEOUT_DATA_SUCCESS,
			payload: {data}
		};
		expect(actions.fetchAuthIdleTimeoutDataSuccess(data)).toMatchObject(expectedAction);
	}, 60000);
	it('should create an action to fetch idal time out data error', () => {
		const error = 'Error occured';
		const expectedAction = {
			type: types.FETCH_AUTH_IDLETIMEOUT_DATA_FAILURE,
				payload: { error }
		};
		expect(actions.fetchAuthIdleTimeoutDataFailure(error)).toMatchObject(expectedAction);
    }, 60000);
});
