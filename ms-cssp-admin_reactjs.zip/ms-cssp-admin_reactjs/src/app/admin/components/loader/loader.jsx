"use client"
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';

import './loader.module.scss';

class Loader extends Component {
	render() {
		return (
			<div className="loader-container d-flex
			flex-column align-items-center justify-content-center">
				<p className="mb-0">
					{this.props.text || ''}
				</p>
				<svg
					xmlns="http://www.w3.org/2000/svg"
					xlink="http://www.w3.org/1999/xlink"
					className="lds-message" width="200px"
					height="100px" viewBox="0 30 100 70"
					preserveAspectRatio="xMidYMid"
					style={{background: 'none'}}>
					<g transform="translate(20 50)">
						<circle
							cx="0"
							cy="0"
							r="6"
							fill="#000000"
							transform="scale(0.902356 0.902356)">
							<animateTransform
								attributeName="transform"
								type="scale"
								begin="-1.2374999999999998s"
								calcMode="spline"
								keySplines="0.3 0 0.7 1;0.3 0 0.7 1"
								values="0;1;0" keyTimes="0;0.5;1"
								dur="3.3s"
								repeatCount="indefinite" />
						</circle>
					</g>
					<g transform="translate(40 50)">
						<circle
							cx="0"
							cy="0"
							r="6"
							fill="#5b5b5b"
							transform="scale(0.594264 0.594264)">
							<animateTransform
								attributeName="transform"
								type="scale"
								begin="-0.825s"
								calcMode="spline"
								keySplines="0.3 0 0.7 1;0.3 0 0.7 1"
								values="0;1;0"
								keyTimes="0;0.5;1"
								dur="3.3s"
								repeatCount="indefinite" />
						</circle>
					</g>
					<g transform="translate(60 50)">
						<circle
							cx="0"
							cy="0"
							r="6"
							fill="#9e9e9e"
							transform="scale(0.246909 0.246909)">
							<animateTransform
								attributeName="transform"
								type="scale"
								begin="-0.4125s"
								calcMode="spline"
								keySplines="0.3 0 0.7 1;0.3 0 0.7 1"
								values="0;1;0"
								keyTimes="0;0.5;1"
								dur="3.3s"
								repeatCount="indefinite" />
						</circle>
					</g>
					<g transform="translate(80 50)">
						<circle
							cx="0"
							cy="0"
							r="6"
							fill="#cfcfcf"
							transform="scale(0.0148123 0.0148123)">
							<animateTransform
								attributeName="transform"
								type="scale"
								begin="0s"
								calcMode="spline"
								keySplines="0.3 0 0.7 1;0.3 0 0.7 1"
								values="0;1;0"
								keyTimes="0;0.5;1"
								dur="3.3s"
								repeatCount="indefinite" />
						</circle>
					</g>
				</svg>
			</div >
		);
	}
}

Loader.propTypes = {
	text: PropTypes.string.isRequired
};

Loader.defaultProps = {
	text: ''
};

export default Loader;
