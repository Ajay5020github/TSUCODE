"use client"
/*
 * This component is used to render
 * the user dashboard after login where other primary
 * components are rendered.
 */

import React, {useState, useEffect} from 'react';
import PropTypes from 'prop-types';
import './adminReportDetail.scss';
import { Button } from '@mui/material';
import Storage from '../../utils/storage';
import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from 'powerbi-client';
import Loader from '../../components/loader/loader';

const AdminReportDetailComponent = (props) => {

	const [accessToken, setAccessToken] = React.useState(undefined);
	const [embedUrl, setEmbedUrl] = React.useState(undefined);
	const [reportId, setReportId] = React.useState(undefined);

	React.useEffect(() => {
		setAccessToken(Storage.getItem('accessToken'));
		setEmbedUrl(Storage.getItem('embedUrl'));
		setReportId(Storage.getItem('reportId'));
	}, [Storage.getItem('reportId') !== '' && Storage.getItem('reportId').length > 0]);

	const scrollToTop = () => {
		window.scroll({
			top: 0,
			left: 0,
			behavior: 'smooth'
		});
	};

	useEffect(() => {		
		scrollToTop();
	}, [])

    return (
        <div>
		
			{
				(accessToken !== undefined && accessToken.length > 0 && embedUrl !== undefined && embedUrl.length > 0 && reportId !== undefined && reportId.length > 0 ? 
					<PowerBIEmbed
						embedConfig = {{
							type: 'report',   // Supported types: report, dashboard, tile, visual and qna
							id: reportId,
							embedUrl: embedUrl,
							accessToken: accessToken,
							tokenType: models.TokenType.Embed,
							settings: {
								panes: {
									filters: {
										expanded: false,
										visible: false
									}
								},
								bars: {
									actionBar: {
										visible: true
									}
								},
								background: models.BackgroundType.Transparent,
							}
						}}

						eventHandlers = { 
							new Map([
								['loaded', function () {}],
								['rendered', function () {}],
								['error', function (event) {}]
							])
						}
						
						cssClassName = { "Embed-container" }

						getEmbeddedComponent = { (embeddedReport) => {
							window.report = embeddedReport;
						}}
					/> : null
				)
			}  
        </div>
    );
};

// AdminReportDetailComponent.displayName = "Admin Report Details";

export default AdminReportDetailComponent;
