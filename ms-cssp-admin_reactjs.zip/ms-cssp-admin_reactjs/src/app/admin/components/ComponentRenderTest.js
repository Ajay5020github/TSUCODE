import React from 'react';
import Content from './content';

// import Modal from './fields/modal'

class ComponentRenderTest extends React.Component {
	constructor(props) {
		super(props);
		this.state = props.data;
		this.onChange = this.onChange.bind(this);
	}
	onChange(e) {
		if (this.state.fields[e.target.name]) {
			this.setState({
				fields: {
					...this.state.fields,
					[e.target.name]: {
						...this.state.fields[e.target.name],
						value: e.target.value
					}
				}
			});
		}
	}
	render() {
		return (
			<div className="container">
				<Content
					onChange={this.onChange}
					currentPage={this.state}
					workflowMap={this.props.workflowMap}
					field={this.state.fields.email}
				/>
				<Content
					onChange={this.onChange}
					currentPage={this.state}
					workflowMap={this.props.workflowMap}
					field={this.state.fields.middleName}
				/>
				{/* <Select
                    name="countries"
                    type="text"
                    label="Countries"
                    placeholder="Select Country"
                    options={["A", "B", "C"]}
                    selected="B"
                />
                */}
				{/* <RadioGroup
                    label="Select Gender"
                    options={["Male", "Female"]}
                    selected="Female"
                    error="Please select one"
                /> */}

				{/* <CheckboxGroup
                    label="Your Hobbies"
                    options={["Basketball", "Internet", "PUBG"]}
                    selectedOptions={["Internet", "PUBG"]}
                    error="Please check one"
                />  */}

				{/* <Table data={[
                    { 'Name': 'Abc', 'Age': 15, 'Location': 'Bangalore', 'Action': <Checkbox value={true}/> },
                    { 'Name': 'Def', 'Age': 43, 'Location': 'Mumbai', 'Action': <Checkbox value={true}/>  },
                    { 'Name': 'Uff', 'Age': 30, 'Location': 'Chennai', 'Action': <Checkbox value={true}/>  },
                    { 'Name': 'Ammse', 'Age': 87, 'Location': 'Delhi', 'Action': <Checkbox value={true}/>  },
                    { 'Name': 'Yysse', 'Age': 28, 'Location': 'Hyderabad', 'Action': <Checkbox value={true}/>  }
                ]} />
     */}
				{/* <Button
                    title="Submit"
                />
     */}
				{/* <Modal show={true} /> */}
			</div>
		);
	}
}

export default ComponentRenderTest;
