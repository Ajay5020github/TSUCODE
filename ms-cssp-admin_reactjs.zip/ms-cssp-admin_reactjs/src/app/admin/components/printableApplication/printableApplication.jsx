/**
 * Auther:- Vishal Sabnis
 * Purpose:- UC-MS-PHP-12
 * Date:-01/07/2022
 */
import React, { useState, useEffect, useLayoutEffect } from 'react';
import {
	Row, Col, Button, Form, Card, Container
} from 'react-bootstrap';
import PropTypes from 'prop-types';
import CONFIG from '../../config/index';

// import { Link } from 'react-router-dom';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import Storage from '../../utils/storage';
import './printableApplication.scss';
const PrintableApplicationComponent = (props) => {

	const {
		config,
		content,
	} = props;

	/* const {
		headline
	} = content; */

	let defaultLangId = Storage.getItem('defaultLangCode');
	defaultLangId = defaultLangId ? defaultLangId : 'en';

	const [loading, setLoading] = useState(false);

	const onPrintLinkClick = linkItem => {
		// try { window.appInsights.trackEvent('Blank Application Download', { 'pageName': linkItem }); }
		// catch { }
	};

	return (
        // config.theme : theme-background-light-grey
        (<section className={`${config.theme ||
			'theme-background-light-grey'} py-3 py-md-5
                `}
		>
            <Container
				className="pb-3"
				id={config.id || ''}
			>
				<Row className="mb-3 justify-content-center">
					<Col md={{ span: 6 }} className="ms-login-section">
						<Card className="print-card-wrap section-style">
							<Card.Header className="border-0 bg-white">
								<Card.Title
									className="mb-0 d-flex ms-item-center ms-custom-printable-title"
								>
									{content.headline.text}
								</Card.Title>
							</Card.Header>
							<Card.Body>
								<div className="ms-custom-printable-link">
									{content.items.map((item, index) =>
										<li key={index}>
											<a onClick={() => onPrintLinkClick(item.label) } href={CONFIG.blobUrl+item.href || ''} target={item.target || '_blank'}>
												{item.label}
											</a>
										</li>
									)}
								</div>
							</Card.Body>
						</Card>
					</Col>
				</Row>
			</Container>
        </section>)
    );
};

/* PrintableApplicationComponent.propTypes = {
	componentState: PropTypes.object.isRequired,
	onClickSubmit: PropTypes.func.isRequired,
	handleChange: PropTypes.func.isRequired,
	handleBlur: PropTypes.func,
	onSubmitModalButtonClick: PropTypes.func.isRequired,
	onShowSubmitModal: PropTypes.func.isRequired,
	onShowChangePasswordModal: PropTypes.func,
	onClickGoBackToHome: PropTypes.func,
	showSubmitModal: PropTypes.bool.isRequired,
	invalidData: PropTypes.any,
	validData: PropTypes.any,
	viewport: PropTypes.string,
	config: PropTypes.shape({
		id: PropTypes.string,
		theme: PropTypes.oneOf([
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		icon: PropTypes.shape({
			url: PropTypes.string,
			alt: PropTypes.string,
			title: PropTypes.string
		}),
		height: PropTypes.oneOf(['short', 'tall']),
		align: PropTypes.oneOf(['right', 'left', 'center'])
	}),
	content: PropTypes.shape({
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired,
			iconDetails: PropTypes.shape({
				url: PropTypes.string,
				altText: PropTypes.string
			})
		}).isRequired,
	}),
	className: PropTypes.string
}; */

export default PrintableApplicationComponent;
