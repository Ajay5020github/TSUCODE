
""
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */

import React from 'react';
import htmlToReact from 'html-to-react';
import { Container, Row, Col, Image, Button } from 'react-bootstrap';
import PropTypes from 'prop-types';
import CustomModal from '../modal/customModal';
import './banner.scss';

class Banner extends React.Component {
	/* constructor(props) {
		super(props);
		this.handleShow = this.handleShow.bind(this);
		this.htmlToReactParser = new htmlToReact.Parser();

		this.state = {
			show: false
		};
	} */
/* istanbul ignore next */
	/* handleClose = () => {
		this.setState({ show: false });
	} */
/* istanbul ignore next */
	/* handleShow = () => {
		this.setState({ show: true });
	} */
/* istanbul ignore next */
	/* onModalButtonClick = () => {
		this.props.onModalButtonClick();
	} */

	/* renderBannerImage() {
		return (
			this.props.config.bannerImage ? <Image className='banner-image'
				src={`${this.props.config.bannerImage.url}`}
				alt={`${this.props.config.bannerImage.alt}`}
				title={`${this.props.config.bannerImage.title}`} /> : '');
	} */

	/* renderBannerText() {
		return (
			<div className="text-center text-lg-left banner-content">
				{(this.props.content.headline &&
					this.props.content.headline.text) ?
					<h1 className='banner-headline'>
						{this.htmlToReactParser.parse(this.props
							.content.headline.text)}
					</h1> : ''}
				{(this.props.content.paragraph &&
					this.props.content.paragraph.text) ?
					<p className='banner-paragraph'>
						{this.htmlToReactParser.parse(this.props
							.content.paragraph.text)}
					</p> : ''}
				{(this.props.content.primaryButton &&
					this.props.content.primaryButton.text) ?
					<Button variant="dark"
						target={`${this.props.content.primaryButton.target}`}
						id={this.props.content.primaryButton.id}
						href={this.props.content.primaryButton.href}
						onClick={this.handleShow} >
						{`${this.props.content.primaryButton.text}`}
					</Button> : ''}
				{(this.props.content.hatchText &&
					this.props.content.hatchText.text) ?
					<React.Fragment>
						<br />
						<p className='banner-hatchText'>
							{`${this.props.content.hatchText.text}`}
						</p>
					</React.Fragment> : ''}
				{this.props.content.modal ? this.renderModal() : ''}
			</div>
		);
	} */

	/* renderModal() {
		return (
			<CustomModal
				{...this.props.content.modal}
				show={this.state.show}
				onHide={this.handleClose}
				onModalButtonClick={this.onModalButtonClick} />
		);
	} */

	render() {
		return (
			<div id="468" className="banner theme-ms-background-dark short right theme-ms-banner-border-bottom container">
				<div className="row">
					<div className="img-border-right col-lg-3 col-md-12 col-sm-12">
						<img src={this.props.config  && this.props.config.bannerImage.url} alt={this.props.config   && this.props.config.bannerImage.alt} title="" className="banner-image" />
					</div>
					<div className="col-lg-9 col-md-12 col-sm-12">
						<div className="text-center text-lg-left banner-content">
							<h1 className="banner-headline">{ this.props.content  && this.props.content.text}</h1>
						</div>
					</div>
				</div>
			</div>
	);
	}
}

Banner.propTypes = {
	config: PropTypes.shape({
		id: PropTypes.string,
		bannerImage: PropTypes.shape({
			url: PropTypes.string.isRequired,
			alt: PropTypes.string.isRequired,
			title: PropTypes.string.isRequired
		}).isRequired,
		theme: PropTypes.oneOf([
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		height: PropTypes.oneOf(['short', 'tall']),
		align: PropTypes.oneOf(['right', 'left']).isRequired
	}),
	content: PropTypes.shape({
		headline: PropTypes.shape({
			text: PropTypes.string
		}),
		paragraph: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		primaryButton: PropTypes.shape({
			href: PropTypes.string.isRequired,
			text: PropTypes.string.isRequired,
			id: PropTypes.string,
			target: PropTypes.oneOf(['_self', '_blank', ''])
		}),
		hatchText: PropTypes.shape({
			text: PropTypes.string
		}),
		modal: PropTypes.shape({
			id: PropTypes.string,
			title: PropTypes.string.isRequired,
			paragraph: PropTypes.string.isRequired,
			primaryButton: PropTypes.shape({
				href: PropTypes.string.isRequired,
				text: PropTypes.string.isRequired,
				id: PropTypes.string,
				target: PropTypes.oneOf(['_self', '_blank', ''])
			}),
			closeLink: PropTypes.shape({
				image_url: PropTypes.string,
				altText: PropTypes.string,
				title: PropTypes.string
			})
		})
	}),
	className: PropTypes.string,
	onModalButtonClick: PropTypes.func,
	noBorder: PropTypes.bool
};

Banner.defaultProps = {
	config: {
		id: '',
		align: 'right',
		theme: 'theme-background-light',
		bannerImage: {
			url: '',
			alt: 'banner image',
			title: 'banner image'
		},
		height: 'tall'
	},
	content: {
		headline: {
			text: 'Let’s see if we can help'
		},
		paragraph: {
			text:
				'Itia nis evelit quid quiatur emperfe rorepudae quis aut.'
		},
		primaryButton: {
			id: '',
			href: '#',
			text: 'Am I Eligible?',
			target: '_blank'
		},
		hatchText: {
			text: ''
		}
	},
	className: '',
	noBorder: false
};


export default Banner;
