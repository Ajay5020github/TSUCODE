/*
 * This component is used to render
 * content of dashboard home.
 */

import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'next/router';
import {
	Row,
	Col,
	Card,
	Accordion,
	Button
} from 'react-bootstrap';
// import ReactCollapsingTable from 'react-collapsing-table';

import CustomModal from '../modal/customModal';

import './dashboardHomeContent.scss';

const applicationProgram = {
	healthcare: 'P01',
	tanf: 'P02',
	snap: 'P03'
};

const DashboardHomeContent = (props) => {
	const [accordians, setAccordians] = useState(null);
	const navigate = (href) => {
		if (href !== '') {
			props.history.push(href);
		}
	};

	const navigateToWelcomeIntroduction = (href) => {
		let isProgramSelected = false;
		for (const program of props.programList) {
			if (program.checked) {
				isProgramSelected = true;
				break;
			}
		}
		if (href !== '' && isProgramSelected) {
			props.history.push(href);
		} else {
			props.onToggleModal(true);
		}
	};

	const formatDate = (dateString) => {
		if (dateString === '') {
			return '';
		} else {
			const dateObj = new Date(dateString);
			let month = dateObj.getMonth() + 1;
			month = month < 10 ? `0${month}` : month;

			let date = dateObj.getDate();
			date = date < 10 ? `0${date}` : date;

			const year = dateObj.getFullYear();

			return [month, date, year].join('/');
		}
	};

	const renderNotificationContent = (detail) => {
		return (
			<div
				className="d-flex flex-column
				justify-content-between align-items-center
				details-content mx-1">
				<img
					src={detail
						.iconDetails.url || ''}
					alt={detail
						.iconDetails.altText || ''}/>
				<p className="headline-text">
					{detail.headline.text || ''}
				</p>
				<p className="headline-msg">
					<span
						className="headline-count">
						{detail.headline.count || ''}
					</span>
					{' '}
					<span
						className="headline-message">
						{detail.headline.message || ''}
					</span>
				</p>
				<a
					className="link"
					href={detail.link.href || ''}
					target={detail.link.target || '_self'}>
					{detail.link.text || ''}
				</a>
			</div>
		);
	};

	const renderNotifications = () => {
		return (
			<div className={`${props.notifications.theme ||
			'theme-background-dark'} card d-flex flex-column py-3 h-100 notification-container card-custom`}>
				<div className="d-flex justify-content-center
				align-items-center py-2 mb-2 headline px-3">
					<img
						src={props.notifications.iconDetails.url || ''}
						alt={props.notifications
							.iconDetails.altText || ''}/>
					<p className="mb-0 ml-2">
						{props.notifications.headline.text || ''}
					</p>
				</div>
				<div className="d-flex justify-content-center align-items-center mx-3 mt-5 pt-5
				notifications">
					{props.notifications && props.notifications.message &&
						<p className="text-center message">{props.notifications.message}</p>
					}
				</div>
				{/* This part will be used in next iteration */}
				{/* <div className="d-flex justify-content-between mx-3 my-4
				notifications desktop-only">
					{props.notifications &&
						props.notifications.details.map((detail, i) => {
							return (
								<div key={`notification-${detail.id}-${i}`}>
									{renderNotificationContent(detail)}
								</div>
							);
						})
					}
				</div> */}

				{/* <div className="d-flex justify-content-between mx-3 my-4
				notifications mobile-only">
					{props.notifications &&
						props.notifications.details.map((detail, i) => {
							return (
								<div key={`notification-${detail.id}-${i}`}>
									{i < 2 &&
										<div>
											{renderNotificationContent(detail)}
										</div>
									}
								</div>
							);
						})
					}
				</div> */}

				{/* This part will be used in next iteration */}
				{/* <div className="d-flex justify-content-center mx-3 my-4
				notifications mobile-only">
					{props.notifications &&
						props.notifications.details.map((detail, i) => {
							return (
								<div key={`notification-${detail.id}-${i}`}>
									{i === 2 &&
										<div>
											{renderNotificationContent(detail)}
										</div>
									}
								</div>
							);
						})
					}
				</div> */}
			</div>
		);
	};

	const renderAnnouncements = () => {
		return (
			<div className={`${props.announcements.theme ||
			'theme-background-dark-green'} card d-flex flex-column py-3 h-100 announcements-container card-custom`}>
				<div className="d-flex justify-content-center
				align-items-center py-2 mb-2 headline px-3">
					<img
						src={props.announcements.iconDetails.url || ''}
						alt={props.announcements
							.iconDetails.altText || ''}/>
					<p className="mb-0 ml-2">
						{props.announcements.headline.text || ''}
					</p>
				</div>
				<div className="announcements mx-3 my-2">
					{props.announcements && props.announcements.items && props.announcements.items.length &&
					<ul>
						{   props.announcements.items
								.map((item, i) => {
									return (
										<li key={`announcement-${item.id}-${i}`}>
											{(item
												.text.length > 150) ?
												`${item
													.text
													.substring(0, 150)}...` :
												item.text}
										</li>
									);
								})
						}
					</ul>
					}
					{props.announcements && props.announcements.items && props.announcements.items.length === 0 && props.announcements.message &&
						<div className="d-flex justify-content-center align-item-center mx-3 mt-5 pt-4">
							<p className="text-center message">{props.announcements.message}</p>
						</div>
					}
					{props.announcements && props.announcements.items && props.announcements.items.length &&
					<div className="d-flex justify-content-center">
						{props.announcements.primaryButton &&
							<Button
								variant="light"
								className="btn-transperant-outline-light floating-button"
								onClick={props.onViewMoreButtonClick}
							>
								{props.announcements.primaryButton.text || ''}
							</Button>
						}
					</div>
					}
				</div>
			</div>
		);
	};

	const renderAuthorizedRepresentatives = () => {
		return (
			<div className={`${props.authorizedRepresentatives.theme ||
			'theme-background-dark'} card d-flex flex-column py-3 h-100 authorized-representatives-container card-custom`}>
				<div className="d-flex justify-content-center
				align-items-center py-2 mb-2 headline px-3">
					<img
						src={props.authorizedRepresentatives.iconDetails.url || ''}
						alt={props.authorizedRepresentatives
							.iconDetails.altText || ''}/>
					<p className="mb-0 ml-2">
						{props.authorizedRepresentatives.headline.text || ''}
					</p>
				</div>
				<div className="authorized-representatives mx-4 my-3">

					{props.authorizedRepresentatives && props.authRepData &&
						props.authorizedRepresentatives.items
							.map((item, i) => {
								return (
									<p key={`authorized-representatives-${item.id}-${i}`}
										className="authorized-representatives-label d-flex">
										<span>
											{item.label || ''}
										</span>&nbsp;{props.authRepData[i] || ''}
									</p>
								);
							})
					}
				</div>
			</div>
		);
	};

	const isChecked = (programId, programs) => {
		let isChecked = false;
		for (const program of programs) {
			if (programId === program.programId && program.checked) {
				isChecked = true;
				break;
			}
		}
		return isChecked;
	};

	const handleChange = (e, id) => {
		props.onCheckedChanged(e.target.checked, id);
	};

	const renderPrograms = () => {
		return (
			<div className={`${props.programs.theme ||
			'theme-background-dark'} card d-flex flex-column py-3 card-custom`}>
				<div className="d-flex justify-content-center
				align-items-center py-2 mb-2 headline px-3">
					<img
						src={props.programs.iconDetails.url || ''}
						alt={props.programs
							.iconDetails.altText || ''}/>
					<p className="mb-0 ml-2 headline-programs">
						{props.programs.headline.text || ''}
					</p>
				</div>
				<div className="programs mx-3 my-5 d-flex flex-column flex-grow-1">
					<div className="d-flex justify-content-center flex-column">
						<div className="program-container flex-grow-1">
							{props.programs &&
								props.programs.items
									.map((item, i) => {
										return (
											<div
												key={`programs-${item.id}-${i}`}
												className="program-item d-flex
												justify-content-between">
												<div className="d-flex align-items-center mr-2">
													<div className={`custom-control custom-checkbox mr-1 ${props.disabledApplication ? 'disabled' : ''}`}>
														<input type="checkbox" className="custom-control-input" id={`custom-check-program-${item.id || ''}`}
															checked={isChecked(
																item.programId,
																props.programList
															)}
															onChange={(e) => handleChange(e, item.programId)}
															disabled={props.disabledApplication}/>
														<label className="custom-control-label" htmlFor={`custom-check-program-${item.id || ''}`}>
															<span className="d-none">Program</span>
														</label>
													</div>
													<p className="mb-0">
														{item.text || ''}
													</p>
												</div>
												<a
													className="program-link"
													href={item
														.tooltipLink.href || ''}
													target={item
														.tooltipLink
														.target || '_blank'}>
													{item
														.tooltipLink.text || ''}
												</a>
											</div>
										);
									})
							}
						</div>
					</div>
				</div>
				<div className="card-footer pt-0">
					<div className="d-flex justify-content-center">
						{props.programs.primaryButton &&
							<Button
								onClick={() => props.navigateToWelcomeIntroduction(
									(props.programs.primaryButton.href || '')
								)}
								variant="light"
								className={`btn-transperant-outline-dark floating-button ${props.disabledApplication ? 'disabled' : ''}`}
								disabled={props.disabledApplication}>
								{props.programs.primaryButton.text || ''}
							</Button>
						}
						{!props.applicationList.length && props.programs.modal && props.programs.modal[0] &&
							<CustomModal
								{...props.programs.modal[0]}
								onHide={() => props.onToggleModal(false)}
								onModalButtonClick={() => props.onToggleModal(false)}
								show={props.showProgramSelectedModal}
								secondaryButton={null}/>
						}
						{props.applicationList.length > 0 && props.applicationList[0].trackingId && props.programs.modal && props.programs.modal[1] &&
							<CustomModal
								{...props.programs.modal[1]}
								onHide={() => props.onToggleModal(false)}
								onModalButtonClick={() => props.onToggleModal(false)}
								show={props.showProgramSelectedModal}
								secondaryButton={null}/>
						}
						{!props.applicationList.length && props.programs.modal && props.programs.modal[2] &&
							<CustomModal
								{...props.programs.modal[2]}
								onHide={() => props.toggleShowLinkMembershipModal(false)}
								onModalButtonClick={() => props.toggleShowLinkMembershipModal(false)}
								onSecondaryButtonClick={() => props.onSecondaryButtonClick((props.programs.primaryButton.href || ''))}
								show={props.showLinkMembershipModal}
								customSecondaryButton={true}/>
						}
					</div>
				</div>
			</div>
		);
	};

	const renderModal = () => {
		return (
			<CustomModal
				{...props.eligibility.modal[0]}
				show={props.showEligibilityModal}
				onHide={props.handleCloseEligibilityModal}
				onModalButtonClick={props.handleEligibilityModalButton} />
		);
	};

	const openEligibilityModal = (href) => {
		if (href !== '') {
			props.openEligibilityModal(href);
		}
	};

	const renderEligibility = () => {
		return (
			<div className={`${props.eligibility.theme ||
			'theme-background-dark'} card d-flex flex-column py-3 card-custom`}>
				<div className="d-flex justify-content-center
				align-items-center py-2 mb-2 headline px-3">
					<img
						src={props.eligibility.iconDetails.url || ''}
						alt={props.eligibility
							.iconDetails.altText || ''}/>
					<p className="mb-0 ml-2">
						{props.eligibility.headline.text || ''}
					</p>
				</div>
				<div className="eligibility mx-3 my-4 d-flex flex-column flex-grow-1">
					<p className="paragraph py-4 flex-grow-1">
						{props.htmlToReactParser.parse(props.eligibility.paragraph.text) || ''}
					</p>
				</div>
				<div className="card-footer pt-0">
					<div className="d-flex justify-content-center">
						{props.programs.primaryButton &&
							<Button
								onClick={() => openEligibilityModal(
									(props.eligibility.primaryButton.href || '')
								)}
								variant="light"
								className="btn-transperant-outline-dark floating-button">
								{props.eligibility.primaryButton.text}
							</Button>
						}
					</div>
				</div>
				{props.eligibility.modal && props.eligibility.modal[0] ? renderModal() : ''}
			</div>
		);
	};

	const renderEnrollment = () => {
		return (
			<div className={`${props.enrolled.theme ||
			'theme-background-dark'} card d-flex flex-column py-3 card-custom`}>
				<div className="d-flex justify-content-center
				align-items-center py-2 mb-2 headline px-5">
					<img
						src={props.enrolled.iconDetails.url || ''}
						alt={props.enrolled
							.iconDetails.altText || ''}/>
					<p className="mb-0 ml-2 headline-enrolled">
						{props.enrolled.headline.text || ''}
					</p>
				</div>
				<div className="enrolled mx-3 my-3 d-flex flex-column flex-grow-1">
					<p className="paragraph py-4 flex-grow-1">
						{props.enrolled.paragraph.text || ''}
					</p>
				</div>
				<div className="card-footer pt-0">
					<div className="d-flex justify-content-center">
						{props.programs.primaryButton &&
							<Button
								variant="light"
								className="btn-transperant-outline-dark floating-button">
								{props.enrolled.primaryButton.text}
							</Button>
						}
					</div>
				</div>
			</div>
		);
	};

	const onContinueButtonClicked = (trackingId) => {
		props.onContinueButtonClick(trackingId);
	};

	const onRenewButtonClicked = (trackingId) => {
	};

	const icons = {
		openRow: <img src="/src/resources/images/accordion_plus.png" alt="expand" className="mr-2" />
		,
		closeRow: <img src="/src/resources/images/accordion_minus.png" alt="expand" className="mr-2" />
	};

	const getKeyForAccordian = (columns,key)=>{
		const keyForAccordian = columns.filter(el => el.accessor === key)
		if(keyForAccordian.length > 0 && keyForAccordian[0].label){
			return keyForAccordian[0].label
		}
	}

	const toggleAccordian = (i) => {
		let accordiansObj;
		if (accordians) {
			accordiansObj = { ...accordians };
			for (const accordian in accordiansObj) {
				if (accordian !== `accordian-${i}`) {
					accordiansObj[accordian] = false;
				}
			}
			accordiansObj[`accordian-${i}`] = !accordiansObj[`accordian-${i}`];
		} else {
			accordiansObj = {};
			accordiansObj[`accordian-${i}`] = true;
		}

		setAccordians(accordiansObj);
	}

	const renderAccordian = (rows,columns) => {
		return (
			<Accordion defaultActiveKey="0">
				{rows.map((row, i) =>
					<Card key={`${row.id}-${i}`}>
						<Accordion.Toggle as={Card.Header}
							eventKey={row.id}
							tabIndex={0}
							onClick={() => toggleAccordian(i)}
							onKeyUp={(e) => {
								const keyCode = e.keyCode || e.which;
								if (keyCode === 13) {
									toggleAccordian(i);
								}
							}}
							className="px-2">
							<div className="d-flex justify-content-start align-items-center">
								<div className="ml-2">
									{(accordians &&
										accordians[`accordian-${i}`]) ? icons.closeRow : icons.openRow}
								</div>
								<div className="pl-1">
									<div className="application-header-title">
										{getKeyForAccordian(columns, 'personName')}
									</div>
									<div className="application-header-text">
										{row.personName}
									</div>
								</div>
							</div>
							</Accordion.Toggle>
						<Accordion.Collapse eventKey={row.id} className={`collapse ${(accordians &&
							accordians[`accordian-${i}`]) ?
							'show' : ''}`}>
							<Card.Body className="my-0">
								{columns.map((col, key) => {
									if (col.accessor && col.accessor !== 'personName' && col.accessor !== 'buttons') {
										return (
											<div className="mb-4" key={key}>
												<div className="application-header-title">
													{col.label}
												</div>
												<div className="application-header-text">
													{row[col.accessor]}
												</div>
											</div>
										);
									} else if(col.accessor && col.accessor === 'buttons'){
										return (
											<Button
												key={key}
												variant="light"
												className="primary-button float-left mb-3
												btn-transperant-outline-dark"
												onClick={() => {
													onContinueButtonClicked(row.id);
												}}>
												{props.application.table
													.secondaryButton.text}
											</Button>
										);
									}
								})}
							</Card.Body>
						</Accordion.Collapse>
					</Card>
				)
				}
			</Accordion>
		)
	}

	const renderApplicationTable = () => {
		const { applicationList } = props;
		const rows = [];

		for (const application of applicationList) {
			const programIds = [];
			const programs = [];

			if (application.healthcare.toLowerCase() === 'yes') {
				programIds.push(applicationProgram.healthcare);
			}
			if (application.snap.toLowerCase() === 'yes') {
				programIds.push(applicationProgram.snap);
			}
			if (application.tanf.toLowerCase() === 'yes') {
				programIds.push(applicationProgram.tanf);
			}

			if (props.programs && props.programs.items.length > 0) {
				for (const item of props.programs.items) {
					if (programIds.includes(item.programId)) {
						programs.push(item.text);
					}
				}
			}

			const applicationRowItem = {
				id: application.trackingId,
				personName: application.personName,
				programName: programs.join(', '),
				enrollBeginDate: formatDate(application.enrollBeginDate),
				enrollEndDate: formatDate(application.enrollEndDate),
				formType: props.application.table.formType.filter((type) => {
					if (type.value === application.formType) {
						return true;
					}
					return false;
				})[0].text,
				programStatus: props.application.table.programStatus.filter((status) => {
					if (status.value === application.applicationStatus) {
						return true;
					}
					return false;
				})[0].text,
				buttons: 1
			};
			rows.push(applicationRowItem);
		}

		let columns = [];

		if (props.application && props.application.table &&
			props.application.table.headers) {
			columns = props.application.table.headers.map((header, i) => {
				if (header.field === 'buttons') {
					return {
						accessor: header.field,
						label: (header.text) ? header.text : props.htmlToReactParser.parse('<span class="d-none">selectedId</span>'),
						priorityLevel: (i + 1),
						position: (i + 1),
						minWidth: (i < 2) ? 150 : ((i === 2) ? 350 : 220),
						sortable: false,
						CustomComponent: ({ row, accessor }) => {
							return (
								<div>
									{row[accessor] === 1 && props.application.table.secondaryButton &&
									<Button
										variant="light"
										className="primary-button
										btn-transperant-outline-dark btn-float-right"
										onClick={() => {
											onContinueButtonClicked(row.id);
										}}>
										{props.application.table
											.secondaryButton.text}
									</Button>
									}
									{row[accessor] === 0 && props.application.table.primaryButton &&
									<Button
										variant="dark"
										className="secondary-button btn-float-right"
										onClick={() => {
											onRenewButtonClicked(row.id);
										}}>
										{props.application.table
											.primaryButton.text}
									</Button>
									}
								</div>
							);
						}
					};
				} else {
					let minWidth = 170;
					if (i > 4) {
						minWidth = 200;
					}

					return {
						accessor: header.field,
						label: header.text,
						priorityLevel: (i + 1),
						position: (i + 1),
						minWidth: minWidth,
						sortable: false
					};
				}
			});
		}


		return (
			<div>
				{/* <div className='d-none d-lg-block'>
					<ReactCollapsingTable
						rows={rows}
						columns={columns}
						icons={icons} />
				</div> */}
				<div className = 'd-lg-none d-block'>
					{renderAccordian(rows,columns)}
				</div>
			</div>

		);
	};

	const renderPendingRenewals = () => {
		return (
			<div className={`${props.pendingRenewals.theme ||
			'theme-background-dark-green'} card d-flex flex-column py-3 h-100 pendingRenewal-container card-custom`}>
				<div className="d-flex justify-content-center
				align-items-center py-2 mb-2 headline px-5 mx-2">
					<img
						src={props.pendingRenewals.iconDetails.url || ''}
						alt={props.pendingRenewals
							.iconDetails.altText || ''}/>
					<p className="mb-0 ml-2">
						{props.pendingRenewals.headline.text || ''}
					</p>
				</div>
				<div className="pendingRenewal mx-3 my-2">
					{props.pendingRenewals && props.pendingRenewals.message &&
						<div className="d-flex justify-content-center align-item-center mx-3 mt-5 pt-4">
							<p className="text-center message">{props.pendingRenewals.message}</p>
						</div>
					}
				</div>
			</div>
		);
	};

	return (
		<div className={'dashboard-home-content-container'}>
			{props.header && props.applicationList.length === 0 && !props.hasSubmittedApplication &&
				<div className={
					`${props.header.theme || 'theme-background-light'}
					header`
				}>
					<p className="headline">
						{props.header.headline.text}
					</p>
					<p className="paragraph">
						{props.htmlToReactParser.parse(props.header.paragraph.text)}
					</p>
				</div>
			}

			{props.application && (props.applicationList.length > 0 || props.hasSubmittedApplication) &&
				<div className={
					`${props.application.theme || 'theme-background-light-grey'}
					application px-4 pt-4 pb-5`
				}>
					<div className="application-headline d-flex
					align-items-center">
						<img
							className="mr-2"
							src={props
								.application.iconDetails.url || ''}
							alt={props.application
								.iconDetails.altText || ''}/>
						<p className="application-headline-text mb-0">
							{props.application.headline.text}
						</p>
					</div>
					{
						props.applicationList.length > 0 &&
						<div className="application-table mt-3">
							{renderApplicationTable()}
						</div>
					}
					{
						props.applicationList.length == 0 && props.pendingRenewals && props.pendingRenewals.message &&
						<div className="mt-4">
							<p className="text-left message">{props.pendingRenewals.message}</p>
						</div>
					}
				</div>
			}

			{(props.applicationList.length > 0 || props.hasSubmittedApplication) &&
				<div>
					<Row className="mb-3">
						<Col lg={((props.hasAuthorizedRepresentative) ? 4 : 6)} className="mb-3 mb-lg-0">
							{renderNotifications()}
						</Col>
						<Col lg={((props.hasAuthorizedRepresentative) ? 4 : 6)} className="mb-3 mb-lg-0">
							{renderAnnouncements()}
						</Col>
						{props.hasAuthorizedRepresentative &&
							<Col lg={4} className="mb-3 mb-lg-0">
								{renderAuthorizedRepresentatives()}
							</Col>
						}
					</Row>

					<Row>
						<Col lg={4} className="mb-3 mb-lg-0 d-flex">
							{renderPrograms()}
						</Col>
						<Col lg={4} className="mb-3 mb-lg-0 d-flex">
							{renderEligibility()}
						</Col>
						<Col lg={4} className="mb-3 mb-lg-0 d-flex">
							{renderEnrollment()}
						</Col>
					</Row>
				</div>
			}

			{props.applicationList.length === 0 && !props.hasSubmittedApplication &&
				<div>
					<Row className="mb-3">
						<Col lg={4} className="mb-3 mb-lg-0 d-flex">
							{renderEnrollment()}
						</Col>
						<Col lg={4} className="mb-3 mb-lg-0 d-flex">
							{renderPrograms()}
						</Col>
						<Col lg={4} className="mb-3 mb-lg-0 d-flex">
							{renderEligibility()}
						</Col>
					</Row>

					<Row>
						<Col lg={4} className="mb-3 mb-lg-0">
							{renderNotifications()}
						</Col>
						<Col lg={4} className="mb-3 mb-lg-0">
							{renderAnnouncements()}
						</Col>
						<Col lg={4} className="mb-3 mb-lg-0">
							{renderPendingRenewals()}
						</Col>
					</Row>
				</div>
			}
		</div>
	);
};

DashboardHomeContent.propTypes = {
	disabledApplication: PropTypes.bool,
	showProgramSelectedModal: PropTypes.bool.isRequired,
	onToggleModal: PropTypes.func.isRequired,
	onCheckedChanged: PropTypes.func.isRequired,
	onContinueButtonClick: PropTypes.func,
	htmlToReactParser: PropTypes.any,
	applicationList: PropTypes.array,
	hasAuthorizedRepresentative: PropTypes.bool.isRequired,
	history: PropTypes.shape({
		push: PropTypes.func
	}),
	programList: PropTypes.arrayOf(PropTypes.shape({
		programId: PropTypes.string.isRequired,
		programName: PropTypes.string.isRequired,
		checked: PropTypes.bool.isRequired
	})),
	header: PropTypes.shape({
		theme: PropTypes.oneOf([
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		paragraph: PropTypes.shape({
			text: PropTypes.string.isRequired
		})
	}),
	application: PropTypes.shape({
		theme: PropTypes.oneOf([
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		iconDetails: PropTypes.shape({
			url: PropTypes.string.isRequired,
			altText: PropTypes.string.isRequired
		}),
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		table: PropTypes.shape({
			headers: PropTypes.arrayOf(PropTypes.shape({
				id: PropTypes.string.isRequired,
				text: PropTypes.string.isRequired,
				field: PropTypes.string.isRequired
			})),
			primaryButton: PropTypes.shape({
				text: PropTypes.string.isRequired,
				href: PropTypes.string,
				target: PropTypes.string
			}),
			secondaryButton: PropTypes.shape({
				text: PropTypes.string.isRequired,
				href: PropTypes.string,
				target: PropTypes.string
			}),
			formType: PropTypes.arrayOf(PropTypes.shape({
				text: PropTypes.string,
				value: PropTypes.string
			})),
			programStatus: PropTypes.arrayOf(PropTypes.shape({
				text: PropTypes.string,
				value: PropTypes.string
			}))
		})
	}),
	notifications: PropTypes.shape({
		theme: PropTypes.oneOf([
			'theme-background-dark-green',
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		iconDetails: PropTypes.shape({
			url: PropTypes.string.isRequired,
			altText: PropTypes.string.isRequired
		}),
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		details: PropTypes.arrayOf(PropTypes.shape({
			id: PropTypes.isRequired,
			iconDetails: PropTypes.shape({
				url: PropTypes.string.isRequired,
				altText: PropTypes.string.isRequired
			}),
			headline: PropTypes.shape({
				count: PropTypes.string.isRequired,
				text: PropTypes.string.isRequired,
				message: PropTypes.string.isRequired
			}),
			link: PropTypes.shape({
				text: PropTypes.string.isRequired,
				href: PropTypes.string.isRequired,
				target: PropTypes.string
			})
		})),
		message: PropTypes.string
	}),
	announcements: PropTypes.shape({
		theme: PropTypes.oneOf([
			'theme-background-dark-green',
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		iconDetails: PropTypes.shape({
			url: PropTypes.string.isRequired,
			altText: PropTypes.string.isRequired
		}),
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		items: PropTypes.arrayOf(PropTypes.shape({
			id: PropTypes.any.isRequired,
			text: PropTypes.string.isRequired
		})),
		primaryButton: PropTypes.shape({
			text: PropTypes.string.isRequired,
			href: PropTypes.string,
			target: PropTypes.string
		}),
		message: PropTypes.string
	}),
	authorizedRepresentatives: PropTypes.shape({
		theme: PropTypes.oneOf([
			'theme-background-dark-green',
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		iconDetails: PropTypes.shape({
			url: PropTypes.string.isRequired,
			altText: PropTypes.string.isRequired
		}),
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		name: PropTypes.string.isRequired,
		items: PropTypes.arrayOf(PropTypes.shape({
			id: PropTypes.string.isRequired,
			label: PropTypes.string.isRequired,
			text: PropTypes.string
		}))
	}),
	programs: PropTypes.shape({
		theme: PropTypes.oneOf([
			'theme-background-dark-green',
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		iconDetails: PropTypes.shape({
			url: PropTypes.string.isRequired,
			altText: PropTypes.string.isRequired
		}),
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		items: PropTypes.arrayOf(PropTypes.shape({
			id: PropTypes.string.isRequired,
			programId: PropTypes.string,
			text: PropTypes.string.isRequired,
			tooltipLink: PropTypes.shape({
				text: PropTypes.string.isRequired,
				href: PropTypes.string.isRequired,
				target: PropTypes.string
			})
		})),
		primaryButton: PropTypes.shape({
			text: PropTypes.string.isRequired,
			href: PropTypes.string,
			target: PropTypes.string
		}),
		modal: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.any,
				title: PropTypes.string,
				paragraph: PropTypes.string.isRequired,
				primaryButton: PropTypes.shape({
					id: PropTypes.any,
					text: PropTypes.string.isRequired,
					href: PropTypes.string,
					target: PropTypes.string
				}),
				closeLink: PropTypes.shape({
					image_url: PropTypes.string.isRequired,
					url: PropTypes.string.isRequired,
					altText: PropTypes.string.isRequired,
					title: PropTypes.string
				})
			})
		)
	}),
	eligibility: PropTypes.shape({
		theme: PropTypes.oneOf([
			'theme-background-dark-green',
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		iconDetails: PropTypes.shape({
			url: PropTypes.string.isRequired,
			altText: PropTypes.string.isRequired
		}),
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		paragraph: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		primaryButton: PropTypes.shape({
			text: PropTypes.string.isRequired,
			href: PropTypes.string,
			target: PropTypes.string
		})
	}),
	enrolled: PropTypes.shape({
		theme: PropTypes.oneOf([
			'theme-background-dark-green',
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		iconDetails: PropTypes.shape({
			url: PropTypes.string.isRequired,
			altText: PropTypes.string.isRequired
		}),
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		paragraph: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		primaryButton: PropTypes.shape({
			text: PropTypes.string.isRequired,
			href: PropTypes.string,
			target: PropTypes.string
		})
	}),
	pendingRenewals: PropTypes.shape({
		theme: PropTypes.oneOf([
			'theme-background-dark-green',
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		iconDetails: PropTypes.shape({
			url: PropTypes.string.isRequired,
			altText: PropTypes.string.isRequired
		}),
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired
		}),
		message: PropTypes.string
	})
};

DashboardHomeContent.defaultProps = {
	applicationList: [],
	header: {
		theme: 'theme-background-light',
		headline: {
			text: 'PH - Help text'
		},
		paragraph: {
			text: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'
		}
	},
	application: {
		theme: 'theme-background-light-grey',
		iconDetails: {
			url: '/src/resources/images/dashboard_application.png',
			altText: 'Dashboard Application'
		},
		headline: {
			text: 'Pending Applications, Changes and Renewals'
		},
		table: {
			headers: [
				{
					id: '1',
					text: 'Person Name',
					field: 'personName'
				},
				{
					id: '2',
					text: 'Program Name',
					field: 'programName'
				},
				{
					id: '3',
					text: 'Enroll Begin Date',
					field: 'enrollBeginDate'
				},
				{
					id: '4',
					text: 'Enroll End Date',
					field: 'enrollEndDate'
				},
				{
					id: '5',
					text: 'Program Status',
					field: 'programStatus'
				},
				{
					id: '6',
					text: '',
					field: 'buttons'
				}
			],
			primaryButton: {
				text: 'RENEW',
				href: '',
				target: '_self'
			},
			secondaryButton: {
				text: 'CONTINUE',
				href: '',
				target: '_self'
			}
		}
	},
	notifications: {
		theme: 'theme-background-dark',
		iconDetails: {
			url: '/src/resources/images/dashboard_notification.png',
			altText: 'Notifications'
		},
		headline: {
			text: 'Notifications'
		},
		details: [
			{
				id: '1',
				iconDetails: {
					url: '/src/resources/images/dashboard_inbox.png',
					altText: 'Inbox'
				},
				headline: {
					count: '3',
					text: 'Inbox',
					message: 'Unread Messages'
				},
				link: {
					text: 'View Details',
					href: '#',
					target: '_self'
				}
			},
			{
				id: '2',
				iconDetails: {
					url: '/src/resources/images/dashboard_renewal.png',
					altText: 'Renewals'
				},
				headline: {
					count: '2',
					text: 'Renewals',
					message: 'Renewals Pending'
				},
				link: {
					text: 'View Details',
					href: '#',
					target: '_self'
				}
			},
			{
				id: '3',
				iconDetails: {
					url: '/src/resources/images/dashboard_appointment.png',
					altText: 'Appointments'
				},
				headline: {
					count: '1',
					text: 'Appointments',
					message: 'Upcoming Appointments'
				},
				link: {
					text: 'View Details',
					href: '#',
					target: '_self'
				}
			}
		]
	},
	announcements: {
		theme: 'theme-background-dark-green',
		iconDetails: {
			url: '/src/resources/images/dashboard_announcement.png',
			altText: 'Announcements'
		},
		headline: {
			text: 'Announcements'
		},
		items: [
			{
				id: '1',
				text: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'
			},
			{
				id: '2',
				text: 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
			},
			{
				id: '3',
				text: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'
			}
		],
		primaryButton: {
			text: 'VIEW ANNOUNCEMENTS',
			href: '',
			target: '_self'
		}
	},
	authorizedRepresentatives: {
		theme: 'theme-background-dark',
		iconDetails: {
			url: '/src/resources/images/dashboard_authorized_representatives.png',
			altText: 'Authorized Representatives'
		},
		headline: {
			text: 'Authorized Representatives'
		},
		name: 'James Smith',
		items: [
			{
				id: '1',
				label: 'Type',
				text: 'Individual'
			},
			{
				id: '2',
				label: 'Address',
				text: '1010 Smitsonian St, Mclean, VA, 20102'
			},
			{
				id: '3',
				label: 'Phone',
				text: '(100) 230-2030'
			},
			{
				id: '4',
				label: 'Email',
				text: 'james@gmail.com'
			}
		]
	},
	programs: {
		theme: 'theme-background-light-grey',
		iconDetails: {
			url: '/src/resources/images/dashboard_programs.png',
			altText: 'Enroll for New Programs'
		},
		headline: {
			text: 'Enroll for New Programs'
		},
		items: [
			{
				id: '1',
				programId: 'P01',
				text: 'Healthcare',
				tooltipLink: {
					text: 'Learn More',
					href: 'http://dhhs.ne.gov/Pages/Medicaid-Eligibility.aspx',
					target: '_blank'
				}
			},
			{
				id: '2',
				programId: 'P03',
				text: 'SNAP',
				tooltipLink: {
					text: 'Learn More',
					href: 'http://dhhs.ne.gov/Pages/SNAP.aspx',
					target: '_blank'
				}
			},
			{
				id: '3',
				programId: 'P02',
				text: 'TANF',
				tooltipLink: {
					text: 'Learn More',
					href: 'http://dhhs.ne.gov/Pages/TANF.aspx',
					target: '_blank'
				}
			}
		],
		primaryButton: {
			text: 'APPLY NOW',
			href: '',
			target: '_self'
		}
	},
	eligibility: {
		theme: 'theme-background-grey',
		iconDetails: {
			url: '/src/resources/images/dashboard_eligibility.png',
			altText: 'Am I Eligible'
		},
		headline: {
			text: 'Am I Eligible'
		},
		paragraph: {
			text: 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
		},
		primaryButton: {
			text: 'START SCREEN QUESTIONNAIRE',
			href: '/eligibility-questions',
			target: '_self'
		}
	},
	enrolled: {
		theme: 'theme-background-light-grey',
		iconDetails: {
			url: '/src/resources/images/dashboard_enrolled.png',
			altText: 'Are you Enrolled'
		},
		headline: {
			text: 'Are you Enrolled ?'
		},
		paragraph: {
			text: 'Enroll my member ID'
		},
		primaryButton: {
			text: 'LINK TO THE PROGRAM',
			href: '',
			target: '_self'
		}
	},
	pendingRenewals: {
		theme: 'theme-background-dark',
		iconDetails: {
			url: '/src/resources/images/dashboard_pending_renewal.png',
			altText: 'Pending Applications, Changes and Renewals'
		},
		headline: {
			text: 'Pending Applications, Changes and Renewals'
		},
		message: 'You donot have any pending actions at this time'
	}
};

export default withRouter(DashboardHomeContent);
