"use client";
import React, { useEffect, useState, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useIdleTimer } from 'react-idle-timer';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import axios from 'axios';
import https from 'https';
import CustomModal from '../components/modal/customModal';
import { isAuthenticated } from '../utils/authenticate';
import CONFIG from '../config';
import Storage from '../utils/storage';
import { fetchAuthIdleTimeoutData } from '../actions/authIdleTimeout/authIdleTimeoutActions';
import GetBuildVersion from '../ChunkReload';

const withAuth = (WrappedComponent) => {
  const AuthComponent = (props) => {
    const router = useRouter();
    const { authIdleTimeoutData, loading, error } = props;
    const [showModal, setShowModal] = useState(false);
    const [userLoggedIn, setUserLoggedIn] = useState(false);
    const timeoutID = useRef(null);

    const handleAction = () => clearTimeout(timeoutID.current);

    const handleIdle = () => {
      setShowModal(true);
      timeoutID.current = setTimeout(() => {
        if (showModal) {
          // router.replace('/admin/logout');
          // router.refresh();
          window.location.reload();
        }
      }, CONFIG.idleDebounce);
    };

    const handleClose = () => {
      setShowModal(false);
      if (userLoggedIn) {
        refreshAuthToken();
      } else {
        timeoutID.current = setTimeout(handleIdle, CONFIG.idleTimeout);
      }
    };

    const handleLogin = () => {
      setUserLoggedIn(true);
      handleClose();
    };

    const refreshAuthToken = async () => {
      const agent = new https.Agent({ rejectUnauthorized: false });
      const headers = {
        contentType: 'application/json',
        authToken: Storage.getItem("authToken"),
      };

      try {
        const response = await axios.post(`${CONFIG.api.nodeUrl}/adminService/refreshToken`, {
          id: Storage.getItem('sid'),
          userId: Storage.getItem('loginType') === 'internal' ? Storage.getItem('adminUserId') : Storage.getItem('email'),
          department: Storage.getItem('loginType'),
          authToken: Storage.getItem('authToken'),
          email: Storage.getItem('email'),
        }, { httpsAgent: agent, headers });

        if (response?.data?.statusCode === 200) {
          // Storage.setItem('token', response.data.authToken);
          Storage.setItem('authToken', response.data.authToken);
          Storage.setItem('authTimer', new Date());
          Storage.setItem('sid', response.data.id);
        } else {
          // router.replace('/admin/logout');
          // router.replace('/admin/login');
          // router.refresh();
        }
      } catch (error) {
        // router.replace('/admin/logout');
        // router.replace('/admin/login');
        // router.refresh();
      }
    };

    useEffect(() => {
      refreshAuthToken();
      window.addEventListener('focus', handleAction);

      return () => {
        window.removeEventListener('focus', handleAction);
        clearTimeout(timeoutID.current);
      };
    }, []);

    useEffect(() => {
      const checkAuth = async () => {
        const authenticated = await isAuthenticated();
        if (!authenticated) {
          router.replace('/admin/login');
          // router.refresh();
        } else {
          setUserLoggedIn(true);
        }
      };
      checkAuth();
    }, [router]);

    useEffect(() => {
      const defaultLangObj = Storage.getItem('defaultLangCode');
      if (defaultLangObj) {
        props.fetchAuthIdleTimeoutData(defaultLangObj);
      } else {
        props.fetchAuthIdleTimeoutData();
      }
    }, []);

    const { getRemainingTime, getLastActiveTime } = useIdleTimer({
      timeout: CONFIG.idleTimeout, // Adjust as needed
      onIdle: handleIdle,
      onAction: handleAction,
      debounce: 250,
    });

    const renderIdleTimeoutModal = () => {
      if (authIdleTimeoutData && authIdleTimeoutData.data && authIdleTimeoutData.data.content) {
        return (
          <>
            <CustomModal
              {...authIdleTimeoutData.data.content.modal.content.timeoutModal}
              show={showModal}
              onHide={handleClose}
              onModalButtonClick={handleLogin}
              alignButtonsVertically={true}
              primaryButtonWidth={true}
              iconInBody={true}
              extraLarge={true}
              modalClass="msTimeoutModal"
            />
          </>
        );
      } else {
        return null;
      }
    };

    if (!isAuthenticated()) return null; // Render nothing while redirecting

    return (
      <>
      {/* kunal Added code for chunk reload */}
      {GetBuildVersion()}
        {renderIdleTimeoutModal()}
        {userLoggedIn && (
          <div>
            <WrappedComponent {...props} />
          </div>
        )}
      </>
    );
  };

  const mapStateToProps = (state) => ({
    authIdleTimeoutData: state.authIdleTimeoutReducer.authIdleTimeoutData,
    loading: state.authIdleTimeoutReducer.loading,
    error: state.authIdleTimeoutReducer.error,
  });

  const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
      { fetchAuthIdleTimeoutData },
      dispatch
    );

  return connect(mapStateToProps, mapDispatchToProps)(AuthComponent);
};

export default withAuth;
