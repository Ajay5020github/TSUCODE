""
import React from "react";
import PropTypes from "prop-types";
import { Row, Col, ToggleButtonGroup, ToggleButton } from "react-bootstrap";
import Header from "../components/header/header"

import "./componentStyle.css";

const NavBar = ({ stepIndex, steps, goToStep }) => {
  let newArr = steps.slice(0, stepIndex + 1).reverse();
  const moduleTitle = (steps && steps[stepIndex].module) ?
    steps[stepIndex].module.title :
    newArr.filter(x => x.module)[0].module.title;

  return (
    <div>
      <Header />
      <Col md={12} className="b-padding-left">
        <div className="card-text-1">
          <div class="img-border-right col-lg-3 col-md-12 col-sm-12 img-padding">
            <img
              src="/src/resources/images/small_banner.jpg"
              alt="banner image"
              title=""
              width="100%"
              height="100%"
              class="banner-image"
            />
          </div>
          <div class="col-lg-9 col-md-12 col-sm-12 custom-title">
            <div class="text-center text-lg-left banner-content">
              <div class="banner-headline">
                {/* On this application you will be asked questions about you and
                  your household members. To help you provide information you
                  may first want to collect verification documents you have,
                  such as Social Security numbers, most recent tax filings,
                  employer information, income, expenses and resource documents.
                  For a full list of documents you may be asked to provide,
                  click on the "Verification List" hyperlink. */}
                {moduleTitle}
              </div>
            </div>
          </div>
        </div>
        <div className="horizontal-line"></div>
      </Col>
    </div>
  );
};

NavBar.propTypes = {
  stepIndex: PropTypes.number.isRequired,
  steps: PropTypes.arrayOf(PropTypes.shape()).isRequired,
  goToStep: PropTypes.func.isRequired
};

export default NavBar;


