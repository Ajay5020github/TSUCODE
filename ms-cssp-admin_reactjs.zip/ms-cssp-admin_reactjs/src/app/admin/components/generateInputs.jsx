
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Alert, Form, Col } from 'react-bootstrap';

class GenerateInputs extends React.Component {
	render() {
		const {
			input: {
				value,
				label,
				type,
				required,
				meta: {
					touched,
					error,
					warning
				}
			}
		} = this.props;
		return (
			<Col md="4">
				<Form.Control
					{...value}
					placeholder={label}
					type={type}
					className="form-control"
					required={required ?
						'required' : ''} />
				{touched && ((error && <Alert variant="danger">
					{error}
				</Alert>) || (warning && <Alert variant="warning">
					{warning}
				</Alert>))}
			</Col>
		);
	}
}

GenerateInputs.propTypes = {
	input: PropTypes.arrayOf({
		checked: PropTypes.bool,
		name: PropTypes.string,
		onBlur: PropTypes.func,
		onChange: PropTypes.func,
		onDragStart: PropTypes.func,
		onDrop: PropTypes.func,
		onFocus: PropTypes.func,
		value: PropTypes.any,
		label: PropTypes.string,
		type: PropTypes.string,
		required: PropTypes.bool,
		meta: PropTypes.arrayOf({
			active: PropTypes.bool,
			autofilled: PropTypes.bool,
			asyncValidating: PropTypes.bool,
			dirty: PropTypes.bool,
			dispatch: PropTypes.func,
			error: PropTypes.string,
			form: PropTypes.string,
			initial: PropTypes.any,
			invalid: PropTypes.bool,
			pristine: PropTypes.bool,
			submitting: PropTypes.bool,
			submitFailed: PropTypes.bool,
			valid: PropTypes.bool,
			visited: PropTypes.bool,
			touched: PropTypes.bool,
			warning: PropTypes.string
		}).isRequired
	}).isRequired
};

export default GenerateInputs;
