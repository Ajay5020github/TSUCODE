
"use client"
import React, { useEffect } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import dynamic from "next/dynamic";

import Layout from "../layout";
import GetBuildVersion from "../../ChunkReload";

const Login = dynamic(() => import("../login/login"));
const UserDashboard = dynamic(() => import("../../containers/userDashboard/userDashboard"));
const UserManagement = dynamic(() => import("../../containers/userManagement/userManagement"));
const AdminReport = dynamic(() => import("../../containers/adminReport/adminReportContainer"));
const AdminReportDetail = dynamic(() => import("../../containers/adminReportDetail/adminReportDetailContainer"));
const JSONEditor = dynamic(() => import("../../containers/JSONEditor/JSONEditorContainers"));
const UserDetail = dynamic(() => import("../../containers/userDetails/UserDetailContainer"));
const UserAuthentication = dynamic(() => import("../../containers/userAuthentication/userAuthenticationContainer"));
const Logout = dynamic(() => import("../../containers/logout/logout"));
const PrintableApplication = dynamic(() => import("../../containers/printableApplication/printableApplication"));
const ContactLocalOffice = dynamic(() => import("../../containers/contactLocalOffice/contactLocalOffice"));
const ContactUs = dynamic(() => import("../../containers/contactUs/contactUs"));
const Authenticate = dynamic(() => import("../../containers/userAuthentication/userAuthenticationContainer"));

const componentsMap = {
    "/admin/login": Login,
    "/admin/dashboard": UserDashboard,
    "/admin/userManagement": UserManagement,
    "/admin/reports": AdminReport,
    "/admin/reportDetail": AdminReportDetail,
    "/admin/jsoneditor": JSONEditor,
    "/admin/userManagement/userdetail": UserDetail,
    "/admin/userManagement/authneticateuser": UserAuthentication,
    "/admin/printable-application": PrintableApplication,
    "/admin/contact-local-office": ContactLocalOffice,
    "/admin/contact-us": ContactUs,
    "/admin/userManagement/authneticateuser": Authenticate,
    "/admin/logout": Logout
};

const AppHome = ()=>{   

    const pathname = usePathname();
    
      useEffect(() => {
          GetBuildVersion(); // Call function on mount
      }, []);

    // Find the component that matches the current pathname
    const matchEntry = Object.entries(componentsMap).find(
        ([path]) => pathname === path
    ) || Object.entries(componentsMap).find(
        ([path]) => pathname.startsWith(path)
    );    

    // If a match is found, render its component, otherwise render 404
    const Component = matchEntry ? matchEntry[1] : null;
  
    return (     
        <Layout>
          {Component ? <Component /> : <div>404 - Page Not Found</div>}
        </Layout>
      
    );
};

// AppHome.displayName = "Home"

export default AppHome;