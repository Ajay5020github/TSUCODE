import AppHome from "./home";

export default AppHome;