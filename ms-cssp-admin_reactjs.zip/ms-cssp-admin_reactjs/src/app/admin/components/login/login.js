"use client"
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import Storage from '../../utils/storage';
import { fetchLoginData, getAuthUrl } from '../../actions/login/loginActions';
import Loader from '../../components/loader/loader';
import Header from '../../components/header/header';
import Banner from '../../components/banner/banner';
import Footer from '../../components/footer/footer';

import LoginForm from '../../components/loginForm/loginForm';
import { validateLoginData } from '../../actions/login/loginActions';
import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';
import { fetchUserDashboardData, fetchRoleManagementAction, fetchAuthDataManagementAction } from '../../actions/userDashboard/userDashboardActions';
import { useRouter } from 'next/navigation';
// import { v4 as uuidv4 } from 'uuid';

export class Login extends Component {
	constructor(props) {
		super(props);
		this.onShowSubmitModal = this.onShowSubmitModal.bind(this);
		this.onShowChangePasswordModal = this.onShowChangePasswordModal.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.loginappBlur = this.loginappBlur.bind(this);
		this.handleBlur = this.handleBlur.bind(this);
		this.onClickSubmit = this.onClickSubmit.bind(this);
	}
	state = {
		formErrors: null,
		formValid: false,
		isFormSubmited: false,
		showSubmitModal: false,
		showChangePasswordModal: false,
		loading: false
	};
	componentDidMount() {
		const defaultLangObj = Storage.getItem('defaultLangCode');
		if (Storage.getItem("authToken"))
		{
			Storage.removeItem('authToken');
		}

		if (defaultLangObj) {
			this.props.fetchLoginData(defaultLangObj).then(() => {
				setTimeout(function () {
					this.setInitialState();
				}.bind(this), 500)
			});
		} else {
			this.props.fetchLoginData().then(() => {
				setTimeout(function () {
					this.setInitialState();
				}.bind(this), 500)
			});
		}
		window.scroll({
			top: 0,
			left: 0,
			behavior: 'smooth'
		});
	}

	componentWillUnmount() {
	}

	onChangeFetchLoginData = languageOption => {
		this.props.fetchLoginData(languageOption.value).then(() => {
			this.setInitialState();
		});
	};

	onSubmitModalButtonClick = () => {
		// this.props.history.prefetch('/admin/login');
		// this.props.history.prefetch('/admin/jsoneditor');
		// this.props.history.prefetch('/admin/userManagement');
		// this.props.history.prefetch('/admin/reports');
		// this.props.history.push('/admin/login');		
		replace('/admin/login')
		// refresh();
	}

	onClickGoBackToHome = () => {
		replace('/admin/home')
		// this.props.history.push('/admin/home');
		// refresh();
	}

	onShowChangePasswordModal = () => {
		// this.setState({ showChangePasswordModal: showChangePasswordModal });
		// this.props.history.push({
		// 	pathname: '/user/update-password', state: {
		// 		fromLoginScreen: true,
		// 		// eslint-disable-next-line max-len
		// 		showLoggedInHeader: ((this.props.invalidData && this.props.invalidData.statusCode === 150) || (this.props.validData && this.props.validData.statusCode === 200)) ? false : true
		// 	}
		// });


		replace({
			pathname: '/user/update-password', state: {
				fromLoginScreen: true,
				// eslint-disable-next-line max-len
				showLoggedInHeader: ((this.props.invalidData && this.props.invalidData.statusCode === 150) || (this.props.validData && this.props.validData.statusCode === 200)) ? false : true
			}
		})
	}
	onShowSubmitModal = (showSubmitModal) => {
		this.setState({ showSubmitModal: showSubmitModal });
	};

	onSuccessfulLogin = response => {
		this.setState({ loading: true });
		//Clean if there is any person list from previous session
		///window.appInsights.trackEvent('User successfully logged in', { 'userid': response.data.userId });
		Storage.setItem('authToken', response.authToken);
		// Storage.setItem('token', response.authToken);
		Storage.setItem('firstName', response.body.firstName);
		Storage.setItem('lastName', response.body.lastName);
		/*Storage.setItem('userId', response.data.userId); */
		Storage.setItem('adminUserId', response.body.userId);
		Storage.setItem('roleCodes', response.body.roles);
		Storage.setItem('loginType', response.loginType);
		Storage.setItem('email', response.body.userId + "@ms.com")
		Storage.setItem('sid', response.id)

		let roleDataMapping = {};
		let roleData = [];
		let roleUserId = '';
		let roleMatrixData;

		if (Storage.getItem("roleCodes") != null) {
			roleData = Storage.getItem('roleCodes');
			roleUserId = Storage.getItem('adminUserId');
		}

		roleDataMapping = {
			"userRoles": roleData,
			"userId": roleUserId
		}
		const { replace } = this.props; 
		// replace('/admin/dashboard');
		this.props.fetchRoleManagementAction(roleDataMapping)
			.then(data => {
				if (data.rolesMatrix !== null) {
					Storage.setItem('Authenticate', data.rolesMatrix.Authenticate);
					Storage.setItem('UserManagement', data.rolesMatrix.UserManagement);
					Storage.setItem('Reports', data.rolesMatrix.Reports);
					Storage.setItem('JsonEditor', data.rolesMatrix.JsonEditor);
					replace('/admin/dashboard');					

				}
				// this.setState({
				// 	roleMatrixData: data.userRoles
				// })

			}).finally(() => {
				this.setState({ loading: false }); // Hide loader
			});

		//Clean if there is any Doc to upload data from previous session
		//this.onShowSubmitModal(true)

	};

	getFormErrorRules = item => {
		return {
			isValid: item.isRequired ? false : true,
			isTouched: false,
			activeValidator: {},
			validations: item.validations,
			isRequired: item.isRequired,
			minValue: item.minValue,
			maxValue: item.maxValue,
			minLength: item.minLength,
			maxLength: item.maxLength
		};
	};
	setPrevActiveValidator = (curFormErrors, item) => {
		const { formErrors } = this.state;
		if (formErrors) {
			curFormErrors[item.name].isValid = formErrors[item.name].isValid;
			curFormErrors[item.name].isTouched = formErrors[item.name].isTouched;
			if (
				formErrors[item.name].activeValidator &&
				formErrors[item.name].activeValidator.type
			) {
				const activeValidator = curFormErrors[item.name].validations.filter(
					elem => elem.type === formErrors[item.name].activeValidator.type
				);
				if (activeValidator?.length) {
					curFormErrors[item.name].activeValidator = activeValidator[0];
				}
			}
		}
		return curFormErrors;
	};
	//set initial state dynamically
	setInitialState() {
		const fields = {};
		let formErrors = {};

		const { content } = this.props.loginData && this.props.loginData.content && this.props.loginData.content.login;
		const { userLoginDetails } = content;
		const fieldTypeArr = ['input', 'checkbox', 'select'];
		userLoginDetails && userLoginDetails.length && userLoginDetails.forEach(item => {
			if (fieldTypeArr.includes(item.fieldType.toLowerCase())) {
				if (this.state[item.name]) {
					fields[item.name] = this.state[item.name];
				} else {
					fields[item.name] = item.defaultValue;
				}
				if (item.name !== 'showPassword') {
					formErrors[item.name] = this.getFormErrorRules(item);
					formErrors = { ...this.setPrevActiveValidator(formErrors, item) };
				}
			}
		});
		fields.formErrors = formErrors;
		this.setState(fields);
	}

	loginappBlur = (e) => {


		let domurl;


		if (e.target.value != "Internal") {

			this.props.getAuthUrl(e.target.value).then(res => {

				if (res.statusCode === 200) {
					//	this.onSuccessfulLogin(res);
					domurl = res.url;
					window.location.href = domurl;
				} else {

					//	domurl = "https://login.microsoftonline.com/657f0c85-1824-433c-983b-7743863f2ff2/oauth2/v2.0/authorize?client_id=8d46d5d7-8ce8-4a7c-b6b8-ab4ef5bd86da&response_type=token&redirect_uri=http://localhost:3000/auth/openid/return&response_mode=form_post&scope=openid+profile+User.Read&state=12345";
				}
			});

		}


	}

	handleChange = (e, field) => {
		const fields = {};
		const currTarget = e.currentTarget;
		const target = e.target;
		/**
		 * Prevent typing if allowed field length is reached.
		 */
		let maxLength = 0;
		if (field && field.maxLength) {
			maxLength = parseInt(field.maxLength);
		}
		if (maxLength > 0 && e.target.value.length > maxLength) {
			return;
		}
		/**
		 * End of maxLength checking
		 */

		if (currTarget.type === 'checkbox') {
			fields[target.name] = currTarget.checked;
		} else {
			fields[target.name] = target.value;
		}

		// this.setState(fields);
		
		// kunal on autopopulate click login issue
		this.setState(fields, () => { // Validate the field after setting state
		 this.validateField(target.name, target.value, true); });
	};
	

	handleBlur = e => {
		this.validateField(e.target.name, e.target.value, true);
	};

	validateField(fieldName, value, isTouched) {
		const fieldValidationErrors = {
			...this.state.formErrors
		};
		if (isTouched !== undefined) {
			if(fieldValidationErrors[fieldName]){
				fieldValidationErrors[fieldName].isTouched = isTouched;
			}		
		}
		let validationObj = {};
		validationObj = this.getFieldIsValid(
			value,
			fieldValidationErrors[fieldName],
			fieldName
		);
		const errcount = validationObj.errcount;
		fieldValidationErrors[fieldName] = {
			...validationObj.fieldValidationError
		};

		switch (fieldName) {
			case 'password':
				if (!errcount) {
					fieldValidationErrors[fieldName].isValid = true;
					fieldValidationErrors[fieldName].activeValidator = {};
				} else {
					fieldValidationErrors[fieldName].isValid = false;
				}
				break;
			default:
				if (!errcount) {
					fieldValidationErrors[fieldName].isValid = true;
					fieldValidationErrors[fieldName].activeValidator = {};
				} else {
					fieldValidationErrors[fieldName].isValid = false;
				}
		}
		this.setState(
			{
				formErrors: fieldValidationErrors
			},
			this.validateForm
		);
	}

	validateForm = () => {
		let isValid = true;
		Object.keys(this.state.formErrors).forEach(fieldName => {
			if (!this.state.formErrors[fieldName].isValid && isValid) {
				isValid = false;
			}
		});
		this.setState({
			formValid: isValid
		});
	};

	getFieldIsValid = (value, fieldValidationError, fieldName) => {
		let validationObj = {
			fieldValidationError: fieldValidationError,
			errcount: 0
		};
		if (+fieldValidationError?.isRequired === 1) {
			validationObj = this.checkValidationByValidationTypes(
				value,
				fieldValidationError,
				fieldName
			);
		} else {
			if (value) {
				validationObj = this.checkValidationByValidationTypes(
					value,
					fieldValidationError,
					fieldName
				);
			}
		}
		return validationObj;
	};

	checkValidationByValidationTypes = (
		value,
		fieldValidationError,
		fieldName
	) => {
		const validationTypes = [
			'empty',
			'email',
			'password',
			'integer',
			'characterMismatch'
		];
		let errcount = 0;
		let activeValidator = null;
		validationTypes && validationTypes.length && validationTypes.forEach(validationType => {
			activeValidator = fieldValidationError?.validations?.filter(
				validation => validation.type === validationType
			);
			if (activeValidator?.length) {
				if (validationType === 'empty') {
					if (fieldName === 'userId' && value.length !== 0) {
						const userId = value;
						const newUserId = userId.replace(/\s+/g, ' ').trim();
						if (newUserId.length === 0) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					} else {
						if (!value) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					}
				}
				if (!errcount) {
					if (validationType === 'integer') {
						if (!new RegExp(activeValidator[0].validationRule).test(value)) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						} else if (
							fieldValidationError.minValue &&
							+value <= fieldValidationError.minValue
						) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					} else {
						if (!new RegExp(activeValidator[0].validationRule).test(value)) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					}
				}
			}
		});
		return {
			fieldValidationError: fieldValidationError,
			errcount: errcount
		};
	};

	onClickSubmit = e => {
		e.preventDefault();
		this.setState({ isFormSubmited: true });
		const fieldValidationErrors = {
			...this.state.formErrors
		};
		Object.keys(fieldValidationErrors).forEach(fieldName => {
			this.validateField(fieldName, this.state[fieldName]);
		});
		this.createValidateJSON();
	};

	createValidateJSON = () => {
		const { userId, password, formValid } = this.state;
		const saveJSON = {};
		const defaultLangObj = Storage.getItem('defaultLangCode');
		// Storage.setItem('oldPassword', password);
		if (formValid) {
			saveJSON.userId = userId;
			saveJSON.password = password;
			this.props.validateLoginData(defaultLangObj, saveJSON).then(res => {
				if (res.statusCode === 200) {
					this.onSuccessfulLogin(res);
				} else {
					this.onShowSubmitModal(true);
				}
			});
		}
	};

	render() {
		const { loginData, loading, error } = this.props;

		return (

			<React.Fragment>

				{loading ? (
					<Loader />
				) : (
						<React.Fragment>
							{error ? (
								<ErrorMessage text={error} />
							) : (
									<React.Fragment>

										{loginData && loginData.content && loginData.content.header ? (
											<Header
												jsonHeader={loginData.content.header}
												onLanguageChange={this.onChangeFetchLoginData}
											/>
										) : (
												''
											)}

										{loginData && loginData.content && loginData.content.banner ? (
											<Banner
												config={loginData.content.banner.config}
												content={loginData.content.banner.content}
											/>
										) : (
												''
											)}
										{/*page content here*/}
										{loginData && loginData.content && loginData.content ? (
											<LoginForm
												{...loginData.content.login}
												onSubmitModalButtonClick={
													this.onSubmitModalButtonClick
												}
												onShowSubmitModal={
													this.onShowSubmitModal
												}
												showSubmitModal={
													this.state.showSubmitModal
												}
												onShowChangePasswordModal={
													this.onShowChangePasswordModal
												}
												showChangePasswordModal={
													this.state.showChangePasswordModal
												}
												componentState={this.state}
												handleChange={this.handleChange}
												loginappBlur={this.loginappBlur}
												onClickSubmit={this.onClickSubmit}
												onClickGoBackToHome={this.onClickGoBackToHome}
												invalidData={this.props.invalidData}
												validData={this.props.validData}
												handleBlur={this.handleBlur}
											/>
										) : (
												''
											)}


										<Footer />
									</React.Fragment>
								)}
						</React.Fragment>
					)}
			</React.Fragment>
		);
	}
}
const mapStateToProps = state => ({
	loginData: state.loginReducer.loginData.data,
	invalidData: state.loginReducer.invalidData,
	validData: state.loginReducer.validData,
	loading: state.loginReducer.loading,
	error: state.loginReducer.error
});

const mapDispatchToProps = dispatch =>
	bindActionCreators(
		{
			fetchLoginData,
			getAuthUrl,
			validateLoginData,
			fetchRoleManagementAction
		},
		dispatch
	);
	//DASBOARD NAVIGATION USING PROPS
	function LoginWithRouter(props) {
		const { replace } = useRouter();
		return <Login {...props} replace={replace}/>;
	}

	export default connect(
	mapStateToProps,
	mapDispatchToProps
)(LoginWithRouter);
