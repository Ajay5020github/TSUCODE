import React from "react";
import { FormLabel, FormControl, FormGroup } from "react-bootstrap";
import getValidationState from "./controls/getValidationState";

import "./componentStyle.css";

export default class Table extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }

    renderTableHeader() {
        if (this.props.datalist !== undefined && this.props.datalist.length > 0) {
            let header = Object.keys(this.props.datalist[0])
            return header.map((key, index) => {
                return <th key={index}>{key.toUpperCase()}</th>
            })
        }
    }

    renderTableData() {
        return this.props.datalist.map((student, index) => {
            const { firstname, middlename, lastname, relationship } = student //destructuring
            return (
                <tr key={index}>
                    <td>{firstname}</td>
                    <td>{middlename}</td>
                    <td>{lastname}</td>
                    <td>{relationship}</td>
                </tr>
            )
        })
    }

    render() {
        const { input, type, meta, label, style, onClick, placeholder, ivalue , datalist} = this.props;

        return (
            <FormGroup validationState={getValidationState(meta)}>
            <div>
                <h3 id='title'>Relationship Summary</h3>
                <table id='students'>
                    <tbody>
                        <tr>{this.renderTableHeader()}</tr>
                        {this.renderTableData()}
                    </tbody>
                </table>
                </div>

                <FormControl.Feedback />
            </FormGroup>
        )
    }
}

//ReactDOM.render(<Table />, document.getElementById('root'));
