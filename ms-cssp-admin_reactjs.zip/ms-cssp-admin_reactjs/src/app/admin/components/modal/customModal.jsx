
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
"use client"
import React from 'react';
import htmlToReact from 'html-to-react';
import { Modal, Button } from 'react-bootstrap';
import PropTypes from 'prop-types';
// import Radio from '@mui/material/Radio';
import Radio from '@mui/material/Radio';
// import RadioGroup from '@mui/material/RadioGroup';
import RadioGroup from '@mui/material/RadioGroup';
// import FormControlLabel from '@mui/material/FormControlLabel';

import { FormControlLabel } from '@mui/material';

import './customModal.scss';

class CustomModal extends React.Component {
	constructor(props) {
		super(props);
		this.htmlToReactParser = new htmlToReact.Parser();
		this.modalButton = null;
	}

	handleOnChange = (e) => {
		this.props.onChange(e)
	}

	render() {
		const {
			iconDetails,
			title,
			guidelineInfo,
			iconInBody
		} = this.props;
		return (
			<Modal id={this.props.id}
				className={`${this.props.modalClass ? this.props.modalClass : ''}`}
				show={this.props.show}
				onHide={this.props.onHide} enforceFocus autoFocus
				backdrop='static' centered
				size={this.props.size ? this.props.size : 'lg'}
				onShow={() => this.modalButton && this.modalButton.focus()}
				dialogClassName={`${this.props.extraLarge ? 'extra-large-modal' : ''}`}>
				<button type="button" className="close banner-modal-close"
					onClick={this.props.onHide}>
					{this.props.closeLink && this.props.closeLink.image_url ?
						<img src={this.props.closeLink.image_url || ''}
							alt={this.props.closeLink.altText || ''}
							title={this.props.closeLink.title || ''} /> : ''
					}
				</button>
				<Modal.Header className="banner-modal-header">

					<Modal.Title
						className="justify-content-center
					mb-0 d-flex align-items-center"
					>
						{
							!iconInBody && iconDetails ? (
								<figure>
									<img
										src={iconDetails.url}
										alt={iconDetails.altText}
										className={title ? 'max-width' : ''}
									/>
								</figure>
							) : ''
						}
						{
							title ? (
								<span>
									{this.htmlToReactParser.parse(title)}
								</span>
							) : ''
						}
					</Modal.Title>
				</Modal.Header>
				<Modal.Body className="px-5 pt-0">
					{
						iconInBody && iconDetails ? (
							<figure>
								<img
									src={iconDetails.url}
									alt={iconDetails.altText}
									className={title ? 'max-width' : ''}
								/>
							</figure>
						) : ''
					}
					{this.props.paragraph &&
						<p>
							{this.htmlToReactParser.parse(this.props.paragraph)}
						</p>}
					{this.props.successlabel &&
						<p>
							{
								this.htmlToReactParser.parse(
									this.props.successlabel
								)
							}: <strong>{this.props.userId}</strong>
						</p>
					}
				
					
					{this.props.form ? this.props.form() : ''}
					{this.props.data && <RadioGroup aria-label="address" name="address" onChange={(e) => this.handleOnChange(e)}>
					<FormControlLabel value={this.props.data[0] && this.props.data[0].inputData.fullAddress} control={<Radio color="primary" id="inputData"/>} label={this.props.data[0] && this.props.data[0].inputData.fullAddress} />
					<FormControlLabel value={this.props.data[0] && this.props.data[0].outputData.fullAddress} control={<Radio color="primary" id="outputData"/>} label={this.props.data[0] && this.props.data[0].outputData.fullAddress} />
					</RadioGroup>}
					{/* {
						this.props.containsControl && <RadioGroup row  className="whatsNextPopUp" aria-label="survey" name="survey" >
						<FormControlLabel className="inputRadio" value="Yes" control={<Radio color="primary" id="selectYes"/>} label={templateContent.yes_txt} />
						<FormControlLabel className="inputRadio" value="No" control={<Radio color="primary" id="selectNo"/>} label={templateContent.no_txt} />
						</RadioGroup>
					} */}
				</Modal.Body>
				{(this.props.primaryButton && this.props.secondaryButton) ? ((this.props.primaryControlFirst === undefined || this.props.primaryControlFirst=== true ) ?
					<Modal.Footer className={`mb-3 d-flex
					justify-content-around ${this.props.alignButtonsVertically ? 'flex-column flex-md-row alignVertical' : ''}`}>
						<Button className={`primary ripple ${this.props.primaryButtonWidth ? 'buttonWidthPrimary' : ''} ${(this.props.preserveButtonTextCase) ? 'preserveButtonTextCase' : ''}`} tabIndex="0"
							variant="dark"
							ref={(el) => this.modalButton = el}
							target={`${this.props.primaryButton.target}`}
							id={this.props.primaryButton.id}
							href={this.props.primaryButton.href}
							onClick={/* istanbul ignore next */() => this.props.onModalButtonClick()}>
							{(this.props.preserveButtonTextCase) ? this.props.primaryButton.text : this.props.primaryButton.text.toUpperCase()}
						</Button>
						<Button className={`secondary ripple ${this.props.primaryButtonWidth ? 'buttonWidthSecondary' : ''} ${(this.props.preserveButtonTextCase) ? 'preserveButtonTextCase' : ''}`} tabIndex="0"
							variant="outline-dark"
							target={`${this.props.secondaryButton.target}`}
							id={this.props.secondaryButton.id}
							href={this.props.secondaryButton.href}
							onClick={/* istanbul ignore next */this.props.customSecondaryButton ? this.props.onSecondaryButtonClick : this.props.onHide}>
							{(this.props.preserveButtonTextCase) ? this.props.secondaryButton.text : this.props.secondaryButton.text.toUpperCase()}
						</Button>
					</Modal.Footer> :
					<Modal.Footer className={`mb-3 d-flex
					justify-content-around ${this.props.buttonColumn ? 'flex-column flex-lg-row' : ''} ${this.props.alignButtonsVertically ? 'flex-column flex-md-row alignVertical' : ''}`}>
						<Button className={`secondary ripple ${this.props.primaryButtonWidth ? 'buttonWidthPrimary' : ''} ${this.props.buttonColumn ? 'btn-fullWidth order-1 order-lg-0' : ''} ${(this.props.preserveButtonTextCase) ? 'preserveButtonTextCase' : ''}`} tabIndex="0"
							variant="outline-dark"
							target={`${this.props.secondaryButton.target}`}
							id={this.props.secondaryButton.id}
							href={this.props.secondaryButton.href}
							onClick={/* istanbul ignore next */this.props.customSecondaryButton ? this.props.onSecondaryButtonClick : this.props.onHide}>
							{(this.props.preserveButtonTextCase) ? this.props.secondaryButton.text : this.props.secondaryButton.text.toUpperCase()}
						</Button>
						<Button className={`primary ripple ${this.props.primaryButtonWidth ? 'buttonWidthSecondary' : ''} ${this.props.buttonColumn ? 'btn-fullWidth order-0 order-lg-1' : ''} ${(this.props.preserveButtonTextCase) ? 'preserveButtonTextCase' : ''}`} tabIndex="0"
							variant="dark"
							ref={/* istanbul ignore next */(el) => this.modalButton = el}
							target={`${this.props.primaryButton.target}`}
							id={this.props.primaryButton.id}
							href={this.props.primaryButton.href}
							onClick={/* istanbul ignore next */() => this.props.onModalButtonClick()}>
							{(this.props.preserveButtonTextCase) ? this.props.primaryButton.text : this.props.primaryButton.text.toUpperCase()}
						</Button>
					</Modal.Footer>)
					: this.props.primaryButton ?
						<Modal.Footer className="mb-3">
							<Button tabIndex="0"
								className={`ripple ${(this.props.preserveButtonTextCase) ? 'preserveButtonTextCase' : ''}`}
								variant="dark"
								ref={/* istanbul ignore next */(el) => {
									if (!this.props.removeModalButtonFocus) {
										this.modalButton = el;
									}
								}}
								target={`${this.props
									.primaryButton.target}`}
								id={this.props.primaryButton.id}
								href={this.props.primaryButton.href}
								onClick={/* istanbul ignore next */() =>
									this.props.onModalButtonClick()
								}>
								{(this.props.preserveButtonTextCase) ? this.props
									.primaryButton.text : this.props
									.primaryButton.text.toUpperCase()
								}
							</Button>
						</Modal.Footer> :
						this.props.secondaryButton ?
							<Modal.Footer className="mb-3">
								<Button tabIndex="0"
									className={`ripple ${(this.props.preserveButtonTextCase) ? 'preserveButtonTextCase' : ''}`}
									variant="outline-dark"
									ref={/* istanbul ignore next */(el) => {
										if (!this.props.removeModalButtonFocus) {
											this.modalButton = el;
										}
									}}
									target={`${this.props
										.secondaryButton.target}`}
									id={this.props.secondaryButton.id}
									href={this.props.secondaryButton.href}
									onClick={/* istanbul ignore next */this.props.onHide}>{(this.props.preserveButtonTextCase) ? this.props
										.secondaryButton.text : this.props
										.secondaryButton.text.toUpperCase()}
								</Button>
							</Modal.Footer>: ''}
			</Modal>
		);
	}
}

CustomModal.propTypes = {
	id: PropTypes.string,
	form: PropTypes.func,
	title: PropTypes.string,
	paragraph: PropTypes.string,
	primaryControlFirst: PropTypes.any,
	primaryButton: PropTypes.shape({
		href: PropTypes.string.isRequired,
		text: PropTypes.string.isRequired,
		id: PropTypes.string,
		target: PropTypes.oneOf(['_self', '_blank', ''])
	}),
	secondaryButton: PropTypes.shape({
		href: PropTypes.string.isRequired,
		text: PropTypes.string.isRequired,
		id: PropTypes.string,
		target: PropTypes.oneOf(['_self', '_blank', ''])
	}),
	closeLink: PropTypes.shape({
		image_url: PropTypes.string,
		altText: PropTypes.string,
		title: PropTypes.string
	}),
	onHide: PropTypes.func,
	onModalButtonClick: PropTypes.func,
	show: PropTypes.bool,
	size: PropTypes.string,
	iconDetails: PropTypes.shape({
		url: PropTypes.string,
		altText: PropTypes.string
	}),
	guidelineInfo: PropTypes.shape({
		config: PropTypes.shape({
			theme: PropTypes.string,
			id: PropTypes.string,
			align: PropTypes.string
		}),
		content: PropTypes.shape({
			id: PropTypes.string,
			title: PropTypes.string.isRequired,
			iconDetails: PropTypes.shape({
				url: PropTypes.string,
				altText: PropTypes.string
			}),
			
		})
	}),
	url: PropTypes.string,
	autoPlay: PropTypes.bool,
	muted: PropTypes.bool,
	successlabel: PropTypes.string,
	userId: PropTypes.string,
	customSecondaryButton: PropTypes.bool,
	onSecondaryButtonClick: PropTypes.func,
	removeModalButtonFocus: PropTypes.bool,
	alignButtonsVertically: PropTypes.bool,
	buttonWidth: PropTypes.bool,
	iconInBody: PropTypes.bool,
	extraLarge: PropTypes.bool,
	buttonColumn: PropTypes.bool,
	preserveButtonTextCase: PropTypes.bool
};

CustomModal.defaultProps = {
	id: '',
	title: 'Let\'s get started!',
	paragraph: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.',
	primaryButton: {
		id: '',
		href: '#',
		text: 'I understand',
		target: '_blank'
	},
	customSecondaryButton: false,
	removeModalButtonFocus: false,
	alignButtonsVertically: false,
	buttonWidth: false,
	iconInBody: false,
	extraLarge: false,
	preserveButtonTextCase: false
};

export default CustomModal;
