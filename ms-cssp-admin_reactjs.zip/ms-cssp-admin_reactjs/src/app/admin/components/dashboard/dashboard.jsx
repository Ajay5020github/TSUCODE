"use client"
/*
 * This component is used to render
 * the user dashboard after login where other primary
 * components are rendered.
 */

import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import './dashboard.scss';
// import { useHistory } from "react-router";
// import { useRouter } from 'next/router';
import { useRouter } from 'next/navigation'; // Ensure correct import// import { useRouter } from 'next/navigation'; // Ensure correct import
import Button from '@mui/material/Button';
import Storage from '../../utils/storage';
import Loader from '../../components/loader/loader';
import withAuth from '../withAuth';
import '../userManagementComponents/userManagement.scss'
import "../../containers/custom.css"
import "../adminReport/adminReport.scss"

const Dashboard = (props) => {
	const renderDashboardHeaderLinks = () => {
		return props.content.dashboardHeaderLinks.map((item, i) => {
			return (
				<div key={`dashboard-header-link-${item.id}-${i}`}>
					{item.show ? (
						<div className="dashboard-header-link"></div>
					) : ''}
				</div>
			);
		});
	};

	const history = useRouter();
	
	const [authenticate, setAuthenticate] = useState('');
	const [userManagement, setUserManagement] = useState('');
	const [reports, setReports] = useState('');
	const [jsonEditor, setJsonEditor] = useState('');
	const [tileLoader, setTileLoader] = useState(false);
	
	const handleNavigationStart = () => {
		setTileLoader(true);
	  };
	  
	const handleNavigationEnd = () => {
		setTileLoader(false);
	};  

	const { replace } = props; 

	const redirectJSONEditor = () => {	
		handleNavigationStart();
		replace('/admin/jsoneditor');
		// refresh();
	}
	const redirectUserAccount = () => {		
		handleNavigationStart();		
		replace('/admin/userManagement');
		// refresh();
	}
	const adminReport = () => {
		handleNavigationStart();		 
		replace('/admin/reports');
		// refresh();
	}
	
	const {
		config,
		content,
		className,
		buttons,
		labels,
		welcomeText
	} = props;
	

	useEffect(() => {
				
		setAuthenticate(Storage.getItem('Authenticate'));
		setUserManagement(Storage.getItem('UserManagement'));
		setReports(Storage.getItem('Reports'));
		setJsonEditor(Storage.getItem('JsonEditor'));

		if (Storage.getItem('JsonEditor')) {
			setTileLoader(false);
		}
		else {
			setTileLoader(true);
		}
		
	}, []);


	

	useEffect(() => { setAuthenticate(Storage.getItem('Authenticate')); setUserManagement(Storage.getItem('UserManagement')); setReports(Storage.getItem('Reports')); setJsonEditor(Storage.getItem('JsonEditor')); const handleRouteChangeComplete = () => { handleNavigationEnd(); }; 
	// Add event listeners for route changes
	 window.addEventListener('routeChangeComplete', handleRouteChangeComplete);
	  window.addEventListener('routeChangeError', handleRouteChangeComplete); 
	  return () => { // Cleanup event listeners on unmount
		 window.removeEventListener('routeChangeComplete', handleRouteChangeComplete);
		  window.removeEventListener('routeChangeError', handleRouteChangeComplete); }; },
		   []);


	const renderSuperUserComponent = () => {
		return (<div><div className="mb-3 row">

		{reports && reports !== "X"   ?

			<div className="mb-3 mb-lg-0 d-flex col-lg-4">
				<div className="theme-background-light-grey card d-flex flex-column py-3 card-custom admin-card-custom">
					<div className={`custom-admin-dashboard-card-title Reports_And_Analytics`}>
						<div className="d-flex justify-content-center align-items-center mb-2 headline">
							<img src={labels && labels.reportImg} alt="Get More Out of Your Account"/>
							<p class="mb-0 ml-2 headline-enrolled">{labels && labels.reportText}</p>
							{/*<div className='dashboard-icon match-svg-img'>
								<img src={labels && labels.reportImg} alt="View Reports" />
							</div>
							<div className='dashboard-icon-title'>
								<h2>{labels && labels.reportText}<br></br>
							{labels && labels.Analytics}</h2>
							</div> */}
						</div>
					</div>
					<div className="custom-admin-dashboard-card-content">
						<p>{labels && labels.reportPh}</p>
					</div>
					<div class="custom-admin-dashboard-card-content-button card-footer pt-0">
						<div class="d-flex justify-content-center">						
							<button type="button" className="btn-transperant-outline-dark floating-button btn btn-light" 
							onMouseEnter={() => history.prefetch('/admin/reports')} 
							onClick={adminReport}>{buttons && buttons.viewReportButton}</button>
						</div>
					</div>
				</div>
			</div>	
			: null }

			{userManagement && userManagement  !== "X" ?
			<div className="mb-3 mb-lg-0 d-flex col-lg-4">
				<div className="theme-background-light-grey card d-flex flex-column py-3 card-custom admin-card-custom">
				<div className={`custom-admin-dashboard-card-title User_Account`}>
				<div className="d-flex justify-content-center align-items-center mb-2 headline">
							<img src={labels && labels.userAccImg} alt="Get More Out of Your Account"/>
							<p class="mb-0 ml-2 headline-enrolled">{labels  && labels.userAccountText}
							{labels  && labels.managementText}</p>
							{/*<div className='dashboard-icon match-svg-img'>
								<img src={labels && labels.userAccImg} alt="User Account" />
							</div>
							<div className='dashboard-icon-title'>
							<h2>{labels  && labels.userAccountText}<br></br>
							{labels  && labels.managementText}</h2>
							</div>*/}
						</div>
					</div>
					<div className="custom-admin-dashboard-card-content">
						<p>{labels && labels.userAccountPh}</p> 
					</div>
					<div class="custom-admin-dashboard-card-content-button card-footer pt-0">
						<div class="d-flex justify-content-center">
						<button type="button" className="btn-transperant-outline-dark floating-button btn btn-light" 
						onMouseEnter={() => history.prefetch('/admin/userManagement')}
						onClick={redirectUserAccount}>{buttons && buttons.viewUserButton}</button>
						</div>
					</div>
				</div>
			</div>
			 : null}
					
			{jsonEditor && jsonEditor  !== "X" ?
			<div className="mb-3 mb-lg-0 d-flex col-lg-4" >
				<div className="theme-background-light-grey card d-flex flex-column py-3 card-custom admin-card-custom">
				<div className="custom-admin-dashboard-card-title">
						<div className="d-flex justify-content-center align-items-center mb-2 headline">
							<img src={labels && labels.configPubImg} alt="Get More Out of Your Account"/>
							<p class="mb-0 ml-2 headline-enrolled">{labels && labels.configTileText}
								{labels &&  labels.PublishTitleText}</p>
							{/*<div className='dashboard-icon'>
								<img src={labels && labels.configPubImg} alt="JSON-File" />
							</div>
							<div className='dashboard-icon-title'>
								<h2>{labels && labels.configTileText} <br></br>
								{labels &&  labels.PublishTitleText}</h2>
							</div>*/}
						</div>
					</div>
					<div className="custom-admin-dashboard-card-content">
						<p>{labels && labels.configPublishPh}</p>
					</div>
					<div class="custom-admin-dashboard-card-content-button card-footer pt-0">
						<div class="d-flex justify-content-center">
						<button  type="button" 
						onMouseEnter={() => history.prefetch('/admin/jsoneditor')}
						onClick={redirectJSONEditor} className="btn-transperant-outline-dark floating-button btn btn-light">{buttons && buttons.modifyJSONButton}</button>
					</div>
					</div>					
				</div>				
			</div>
			 : null }

		</div></div>);
	};

	// renderSuperUserComponent.displayName = "Render Tiles"

	return (
		<>
			{tileLoader ? (
						<Loader />
			) : (
				<>
					<div className={`dashboard-container
							${className || 'dashboard'}
							${config.theme || 'theme-background-light-grey'}`}
							id={config.id || 'dashboard'}>
								{content.dashboardHeaderLinks &&
									content.dashboardHeaderLinks.length > 0 &&
									<div className="d-flex flex-column flex-sm-row
									justify-content-end dashboard-header-link mb-3">
										{renderDashboardHeaderLinks()}
									</div>
								}
								<div className="menu-container">
									<div className="card">										
									
										<div className="main-panel mt-3">
										<div className="custom-admin-title">
										<h2>{welcomeText && welcomeText.mainText}</h2>
										{<p></p>}
										</div>
											<div className="dashboard-home-content-container">
												<div className="dashboard-home-content-container">
													{renderSuperUserComponent()}
												</div>
											</div>
										</div>
									</div>
								</div>	
					</div>
				</>
			)}
		</>
	);
		
};

// Dashboard.displayName = "Admin Dashboard";

Dashboard.propTypes = {
	children: PropTypes.element,
	config: PropTypes.shape({
		id: PropTypes.string,
		theme: PropTypes.oneOf([
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		height: PropTypes.oneOf(['short', 'tall']),
		align: PropTypes.oneOf(['right', 'left', 'center'])
	}),
	content: PropTypes.shape({
		dashboardHeaderLinks: PropTypes.arrayOf(PropTypes.shape({
			id: PropTypes.string.isRequired,
			text: PropTypes.string.isRequired,
			href: PropTypes.string,
			target: PropTypes.string,
			iconDetails: PropTypes.shape({
				url: PropTypes.string.isRequired,
				altText: PropTypes.string
			}),
			show: PropTypes.bool
		})),
		menu: PropTypes.arrayOf(PropTypes.shape({
			id: PropTypes.string.isRequired,
			text: PropTypes.string.isRequired,
			disabled: PropTypes.bool,
			showHeaderLinks: PropTypes.bool,
			subMenu: PropTypes.arrayOf(PropTypes.shape({
				id: PropTypes.string.isRequired,
				text: PropTypes.string.isRequired,
				disabled: PropTypes.bool,
				tabId: PropTypes.string,
				showHeaderLinks: PropTypes.bool
			}))
		})),
		pages: PropTypes.shape({
			home: PropTypes.shape({
				header: PropTypes.shape({
					theme: PropTypes.oneOf([
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					headline: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					paragraph: PropTypes.shape({
						text: PropTypes.string.isRequired
					})
				}),
				application: PropTypes.shape({
					theme: PropTypes.oneOf([
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					iconDetails: PropTypes.shape({
						url: PropTypes.string.isRequired,
						altText: PropTypes.string.isRequired
					}),
					headline: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					table: PropTypes.shape({
						headers: PropTypes.arrayOf(PropTypes.shape({
							id: PropTypes.string.isRequired,
							text: PropTypes.string.isRequired,
							field: PropTypes.string.isRequired
						})),
						primaryButton: PropTypes.shape({
							text: PropTypes.string.isRequired,
							href: PropTypes.string,
							target: PropTypes.string
						}),
						secondaryButton: PropTypes.shape({
							text: PropTypes.string.isRequired,
							href: PropTypes.string,
							target: PropTypes.string
						})
					})
				}),
				notifications: PropTypes.shape({
					theme: PropTypes.oneOf([
						'theme-background-dark-green',
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					iconDetails: PropTypes.shape({
						url: PropTypes.string.isRequired,
						altText: PropTypes.string.isRequired
					}),
					headline: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					details: PropTypes.arrayOf(PropTypes.shape({
						id: PropTypes.isRequired,
						iconDetails: PropTypes.shape({
							url: PropTypes.string.isRequired,
							altText: PropTypes.string.isRequired
						}),
						headline: PropTypes.shape({
							count: PropTypes.string.isRequired,
							text: PropTypes.string.isRequired,
							message: PropTypes.string.isRequired
						}),
						link: PropTypes.shape({
							text: PropTypes.string.isRequired,
							href: PropTypes.string.isRequired,
							target: PropTypes.string
						})
					}))
				}),
				announcements: PropTypes.shape({
					theme: PropTypes.oneOf([
						'theme-background-dark-green',
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					iconDetails: PropTypes.shape({
						url: PropTypes.string.isRequired,
						altText: PropTypes.string.isRequired
					}),
					headline: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					items: PropTypes.arrayOf(PropTypes.shape({
						id: PropTypes.any.isRequired,
						text: PropTypes.string.isRequired
					})),
					primaryButton: PropTypes.shape({
						text: PropTypes.string.isRequired,
						href: PropTypes.string,
						target: PropTypes.string
					})
				}),
				authorizedRepresentatives: PropTypes.shape({
					theme: PropTypes.oneOf([
						'theme-background-dark-green',
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					iconDetails: PropTypes.shape({
						url: PropTypes.string.isRequired,
						altText: PropTypes.string.isRequired
					}),
					headline: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					name: PropTypes.string.isRequired,
					items: PropTypes.arrayOf(PropTypes.shape({
						id: PropTypes.string.isRequired,
						label: PropTypes.string.isRequired,
						text: PropTypes.string
					}))
				}),
				programs: PropTypes.shape({
					theme: PropTypes.oneOf([
						'theme-background-dark-green',
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					iconDetails: PropTypes.shape({
						url: PropTypes.string.isRequired,
						altText: PropTypes.string.isRequired
					}),
					headline: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					items: PropTypes.arrayOf(PropTypes.shape({
						id: PropTypes.string.isRequired,
						programId: PropTypes.string,
						text: PropTypes.string.isRequired,
						tooltipLink: PropTypes.shape({
							text: PropTypes.string.isRequired,
							href: PropTypes.string.isRequired,
							target: PropTypes.string
						})
					})),
					primaryButton: PropTypes.shape({
						text: PropTypes.string.isRequired,
						href: PropTypes.string,
						target: PropTypes.string
					}),
					modal: PropTypes.shape({
						id: PropTypes.any,
						title: PropTypes.string,
						paragraph: PropTypes.string.isRequired,
						closeLink: PropTypes.shape({
							url: PropTypes.string.isRequired,
							altText: PropTypes.string.isRequired,
							title: PropTypes.string
						})
					})
				}),
				eligibility: PropTypes.shape({
					theme: PropTypes.oneOf([
						'theme-background-dark-green',
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					iconDetails: PropTypes.shape({
						url: PropTypes.string.isRequired,
						altText: PropTypes.string.isRequired
					}),
					headline: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					paragraph: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					primaryButton: PropTypes.shape({
						text: PropTypes.string.isRequired,
						href: PropTypes.string,
						target: PropTypes.string
					})
				}),
				enrolled: PropTypes.shape({
					theme: PropTypes.oneOf([
						'theme-background-dark-green',
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					iconDetails: PropTypes.shape({
						url: PropTypes.string.isRequired,
						altText: PropTypes.string.isRequired
					}),
					headline: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					paragraph: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					primaryButton: PropTypes.shape({
						text: PropTypes.string.isRequired,
						href: PropTypes.string,
						target: PropTypes.string
					})
				})
			}),
			inboxDocuments: PropTypes.shape({
				config: PropTypes.shape({
					theme: PropTypes.oneOf([
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					id: PropTypes.string,
					align: PropTypes.string,
					height: PropTypes.string,
					columns: PropTypes.string
				}),
				content: PropTypes.shape({
					sections: PropTypes.arrayOf(
						PropTypes.shape({
							config: PropTypes.shape({
								theme: PropTypes.oneOf([
									'theme-background-dark',
									'theme-background-light',
									'theme-background-light-grey',
									'theme-background-grey',
									'theme-background-dark-grey'
								]),
								id: PropTypes.string,
								align: PropTypes.string
							}),
							content: PropTypes.shape({
								headline: PropTypes.shape({
									text: PropTypes.string,
									iconDetails: PropTypes.shape({
										alt: PropTypes.string,
										title: PropTypes.string,
										url: PropTypes.string
									})
								}),
								paragraph: PropTypes.shape({
									text: PropTypes.string
								}),
								primaryButton: PropTypes.shape({
									href: PropTypes.string,
									id: PropTypes.string,
									target: PropTypes.string,
									text: PropTypes.string
								})
							})
						})
					)
				}),
				className: PropTypes.string
			})
		})
	}),
	className: PropTypes.string
};

Dashboard.defaultProps = {
	config: {
		id: 'dashboard',
		align: 'center',
		theme: 'theme-background-light-grey'
	},
	content: {
		dashboardHeaderLinks: [
			{
				id: '1',
				text: 'PH - Application Walkthrough',
				href: 'https://google.com',
				target: '_blank',
				iconDetails: {
					url: '/src/resources/images/application_workthrough.png',
					altText: 'PH-Application Walkthrough'
				},
				show: true
			},
			{
				id: '2',
				text: 'Help - Dashboard',
				href: 'https://facebook.com',
				target: '_blank',
				iconDetails: {
					url: '/src/resources/images/help_dashboard.png',
					altText: 'Help - Dashboard'
				},
				show: true
			}
		],
		menu: [
			{
				id: '1',
				text: 'Home',
				disabled: false,
				tabId: 'home',
				showHeaderLinks: true,
				subMenu: []
			},
			{
				id: '2',
				text: 'My Benefits',
				disabled: true,
				tabId: 'myBenefits',
				showHeaderLinks: true,
				subMenu: []
			},
			{
				id: '3',
				text: 'Report Changes',
				disabled: true,
				tabId: 'reportChanges',
				showHeaderLinks: true,
				subMenu: []
			},
			{
				id: '4',
				text: 'Inbox',
				disabled: false,
				tabId: 'inbox',
				showHeaderLinks: false,
				subMenu: [
					{
						id: '5',
						text: 'Notifications',
						disabled: true,
						tabId: 'notifications',
						showHeaderLinks: false
					},
					{
						id: '6',
						text: 'My Documents',
						disabled: false,
						tabId: 'myDocuments',
						showHeaderLinks: false
					}
				]
			}
		],
		pages: {
			home: {
				header: {
					theme: 'theme-background-light',
					headline: {
						text: 'PH - Help text'
					},
					paragraph: {
						text: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'
					}
				},
				application: {
					theme: 'theme-background-light-grey',
					iconDetails: {
						url: '/src/resources/images/dashboard_application.png',
						altText: 'Dashboard Application'
					},
					headline: {
						text: 'Pending Applications, Changes and Renewals'
					},
					table: {
						headers: [
							{
								id: '1',
								text: 'Person Name',
								field: 'personName'
							},
							{
								id: '2',
								text: 'Program Name',
								field: 'programName'
							},
							{
								id: '3',
								text: 'Enroll Begin Date',
								field: 'enrollBeginDate'
							},
							{
								id: '4',
								text: 'Enroll End Date',
								field: 'enrollEndDate'
							},
							{
								id: '5',
								text: 'Program Status',
								field: 'programStatus'
							},
							{
								id: '6',
								text: '',
								field: 'buttons'
							}
						],
						primaryButton: {
							text: 'RENEW',
							href: '',
							target: '_self'
						},
						secondaryButton: {
							text: 'CONTINUE',
							href: '',
							target: '_self'
						}
					}
				},
				notifications: {
					theme: 'theme-background-dark',
					iconDetails: {
						url: '/src/resources/images/dashboard_notification.png',
						altText: 'Notifications'
					},
					headline: {
						text: 'Notifications'
					},
					details: [
						{
							id: '1',
							iconDetails: {
								url: '/src/resources/images/dashboard_inbox.png',
								altText: 'Inbox'
							},
							headline: {
								count: '3',
								text: 'Inbox',
								message: 'Unread Messages'
							},
							link: {
								text: 'View Details',
								href: '#',
								target: '_self'
							}
						},
						{
							id: '2',
							iconDetails: {
								url: '/src/resources/images/dashboard_renewal.png',
								altText: 'Renewals'
							},
							headline: {
								count: '2',
								text: 'Renewals',
								message: 'Renewals Pending'
							},
							link: {
								text: 'View Details',
								href: '#',
								target: '_self'
							}
						},
						{
							id: '3',
							iconDetails: {
								url: '/src/resources/images/dashboard_appointment.png',
								altText: 'Appointments'
							},
							headline: {
								count: '1',
								text: 'Appointments',
								message: 'Upcoming Appointments'
							},
							link: {
								text: 'View Details',
								href: '#',
								target: '_self'
							}
						}
					]
				},
				announcements: {
					theme: 'theme-background-dark-green',
					iconDetails: {
						url: '/src/resources/images/dashboard_announcement.png',
						altText: 'Announcements'
					},
					headline: {
						text: 'Announcements'
					},
					items: [
						{
							id: '1',
							text: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'
						},
						{
							id: '2',
							text: 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
						},
						{
							id: '3',
							text: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'
						}
					],
					primaryButton: {
						text: 'VIEW ANNOUNCEMENTS',
						href: '',
						target: '_self'
					}
				},
				authorizedRepresentatives: {
					theme: 'theme-background-dark',
					iconDetails: {
						url: '/src/resources/images/dashboard_authorized_representatives.png',
						altText: 'Authorized Representatives'
					},
					headline: {
						text: 'Authorized Representatives'
					},
					name: 'James Smith',
					items: [
						{
							id: '1',
							label: 'Type',
							text: 'Individual'
						},
						{
							id: '2',
							label: 'Address',
							text: '1010 Smitsonian St, Mclean, VA, 20102'
						},
						{
							id: '3',
							label: 'Phone',
							text: '(100) 230-2030'
						},
						{
							id: '4',
							label: 'Email',
							text: 'james@gmail.com'
						}
					]
				},
				programs: {
					theme: 'theme-background-light-grey',
					iconDetails: {
						url: '/src/resources/images/dashboard_programs.png',
						altText: 'Enroll for New Programs'
					},
					headline: {
						text: 'Enroll for New Programs'
					},
					items: [
						{
							id: '1',
							programId: 'P01',
							text: 'Healthcare',
							tooltipLink: {
								text: 'Learn More',
								href: 'http://dhhs.ne.gov/Pages/Medicaid-Eligibility.aspx',
								target: '_blank'
							}
						},
						{
							id: '2',
							programId: 'P03',
							text: 'SNAP',
							tooltipLink: {
								text: 'Learn More',
								href: 'http://dhhs.ne.gov/Pages/SNAP.aspx',
								target: '_blank'
							}
						},
						{
							id: '3',
							programId: 'P02',
							text: 'TANF',
							tooltipLink: {
								text: 'Learn More',
								href: 'http://dhhs.ne.gov/Pages/TANF.aspx',
								target: '_blank'
							}
						}
					],
					primaryButton: {
						text: 'APPLY NOW',
						href: '',
						target: '_self'
					}
				},
				eligibility: {
					theme: 'theme-background-grey',
					iconDetails: {
						url: '/src/resources/images/dashboard_eligibility.png',
						altText: 'Am I Eligible'
					},
					headline: {
						text: 'Am I Eligible'
					},
					paragraph: {
						text: 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
					},
					primaryButton: {
						text: 'START SCREEN QUESTIONNAIRE',
						href: '/eligibility-questions',
						target: '_self'
					}
				},
				enrolled: {
					theme: 'theme-background-light-grey',
					iconDetails: {
						url: '/src/resources/images/dashboard_enrolled.png',
						altText: 'Are you Enrolled'
					},
					headline: {
						text: 'Are you Enrolled ?'
					},
					paragraph: {
						text: 'Enroll my member ID'
					},
					primaryButton: {
						text: 'LINK TO THE PROGRAM',
						href: '',
						target: '_self'
					}
				}
			},
			inboxDocuments: {
				config: {
					theme: 'theme-background-light',
					id: '',
					align: 'center',
					height: 'tall',
					columns: '2'
				},
				content: {
					sections: [
						{
							config: {
								theme: 'theme-background-light-grey',
								id: '',
								align: 'center',
								height: 'tall',
								columns: '2'
							},
							content: {
								headline: {
									text: 'Upload and submit documents',
									iconDetails: {
										alt: 'upload and submit documents icon',
										title: 'upload and submit documents icon',
										url: '/src/resources/images/icon-Upload-Submit-Documents.png'
									}
								},
								paragraph: {
									text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas felis lectus, molestie aliquet justo sit amet, sollicitudin cursus ipsum. In mattis lorem nec ipsum pulvinar pulvinar. Donec vulputate pharetra urna, id sollicitudin lacus cursus ac. Cras sed est lacus.Sed tristique elit tellus, id fermentum purus tempus non.Nunc gravida ac lorem egestas iaculis.Integer egestas lorem id viverra facilisis.Mauris sed lacus a ligula condimentum maximus a sed est.Curabitur vitae facilisis dui.Nulla vestibulum mauris posuere, elementum tellus id, faucibus ipsum.Sed luctus nibh nec nibh gravida, et pretium diam accumsan.'
								},
								primaryButton: {
									href: '#',
									id: '93',
									target: '_self',
									text: 'SELECT FILES TO UPLOAD'
								}
							}
						},
						{
							config: {
								theme: 'theme-background-light-grey',
								id: '',
								align: 'center',
								height: 'tall',
								columns: '2'
							},
							content: {
								headline: {
									text: 'My saved documents',
									iconDetails: {
										alt: 'my saved documents icon',
										title: 'my saved documents icon',
										url: '/src/resources/images/icon-My-Saved-Documents.png'
									}
								},
								paragraph: {
									text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas felis lectus, molestie aliquet justo sit amet, sollicitudin cursus ipsum. In mattis lorem nec ipsum pulvinar pulvinar. Donec vulputate pharetra urna, id sollicitudin lacus cursus ac.<br/><br/>Cras sed est lacus.Sed tristique elit tellus, id fermentum purus tempus non.Nunc gravida ac lorem egestas iaculis.Integer egestas lorem id viverra facilisis.Mauris sed lacus a ligula condimentum maximus a sed est.Curabitur vitae facilisis dui.'
								},
								primaryButton: {
									href: '#',
									id: '93',
									target: '_self',
									text: 'SEND DOCUMENTS TO STATE'
								}
							}
						}
					]
				}
			}
		}
	},
	className: 'dashboard'

};
function Dashboardrouter (props) {
		const { replace } = useRouter();
		return <Dashboard {...props} replace={replace} />;
	}
export default withAuth(Dashboardrouter);
