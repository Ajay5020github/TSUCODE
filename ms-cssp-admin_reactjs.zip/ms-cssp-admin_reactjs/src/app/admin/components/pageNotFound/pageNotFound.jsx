"use client"
import React from 'react';

const PageNotFound = () => {   

    return (
        <>
           <h1>404</h1>
           <p>Oops... Something went wrong</p>
        </>
    );
        
};


export default PageNotFound;
