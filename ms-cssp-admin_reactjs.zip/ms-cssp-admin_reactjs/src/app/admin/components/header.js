import React from 'react';

const Header = (props) => {

	return (
		<div >
			<div className="verticalLine"></div>
			<div
				style={{
					fontWeight: "500"
				}}
			>
				{/* {s.text} */}
			</div>
		</div>
	);
};

export default Header;