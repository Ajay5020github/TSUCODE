
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Infinite 2022.
 */
/*
*Author: Rahul
*Purpose: UC-CP-PHP-09 - Contact Us Page - fetch data from json blob
*Date: 01/07/2022
*/
import React, { Component } from 'react';
import { Row, Col, Card, Container } from 'react-bootstrap';
import PropTypes from 'prop-types';
import { fetchContactUsData } from "../../actions/contactUs/contactUsActions";
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import './contactUs.scss';
import Loader from '../loader/loader';
import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';
import parse from 'html-react-parser';

export class ContactUs extends Component {
	/*
	*Author: Rahul
	*Purpose: UC-CP-PHP-09 - Contact Us Page - added htmlparser to render url
	*Date: 01/28/2022
	*/
	constructor(props) {
		super(props);
	}

	componentDidMount() {}

	fetchContactUsData = languageOption => {
		this.props.fetchContactUsData(languageOption.value);
	};

	render() {
		const {
			contactUsLabelData,
			loading,
			error
		} = this.props;	

				return (
			<React.Fragment>
				{loading ? <Loader /> :
					<React.Fragment>
						{error ? <ErrorMessage text={error} /> :
							<React.Fragment>								
								<section className={'theme-background-light-grey-one py-3 py-md-5'}>
									<Container className="pb-3" >
										<Row className="mb-3 justify-content-center">
											<Col md={{ span: 4 }} className="ms-login-section">
												<Card className="login-card-wrap section-style">

													<Card.Body>
														
														{contactUsLabelData 
															&& contactUsLabelData.content 
															&& contactUsLabelData.content.contactUs 
															&& contactUsLabelData.content.contactUs.content 
															&& contactUsLabelData.content.contactUs.content.contactBody
															&& contactUsLabelData.content.contactUs.content.contactBody.content
															&& contactUsLabelData.content.contactUs.content.contactBody.content.headline ?
															(
																<div className="d-flex ms-contact-heading">
																	{contactUsLabelData.content.contactUs.content.contactBody.content.headline.text}
																</div>

															) :
															''}
														<div>
															{contactUsLabelData 
																&& contactUsLabelData.content 
																&& contactUsLabelData.content.contactUs 
																&& contactUsLabelData.content.contactUs.content 
																&& contactUsLabelData.content.contactUs.content.contactBody
																&& contactUsLabelData.content.contactUs.content.contactBody.content
																&& contactUsLabelData.content.contactUs.content.contactBody.content.contactList
																&& contactUsLabelData.content.contactUs.content.contactBody.content.contactList.items
																&& contactUsLabelData.content.contactUs.content.contactBody.content.contactList.items.length > 0
																&& contactUsLabelData.content.contactUs.content.contactBody.content.contactList.items.map((item, i) =>
																(<div key={i} className="mt-4 mb-3">
																	<div className="d-flex ms-contact-data">
																		{item.contactName} </div>
																	<div className="d-flex ms-contact-data">
																		<a
																			key={`contact--${(item.id || '')}`}
																			href={item.href || ''}
																			target={item.target || '_blank'}
																			className="text-capitalize text-underline
																			mt-lg-0">
																			{item.contactDesc}
																		</a>
																	</div>
																	<div className="d-flex ms-contact-data ms-contact-address-format">
																		{parse(item.contactAddress)} </div>
																		{/*
																		*Author: Rahul
																		*Purpose: UC-CP-PHP-09 - Contact Us Page - added one additional parameter as per business requirement
																		*Date: 01/21/2022
																		*/}
																		{/*
																		*Author: Basha
																		*Purpose: UC-CP-PHP-09 - Contact Us Page - added htmlparser to render url
																		*Date: 02/01/2022
																		*/}
																		<div className="d-flex ms-contact-data ms-tollFreeNumber">
																		{parse(item.tollFreeNumber)} </div>
																	<div className="d-flex ms-contact-data">
																		{/*
																		*Author: Rahul
																		*Purpose: UC-CP-PHP-09 - Contact Us Page - added htmlparser to render url
																		*Date: 01/28/2022
																		*/}
																		{parse(item.contactNumber)} </div>
																		
																</div>))
															}


														</div>
														<div >

														</div>
													</Card.Body>
												</Card>
											</Col>
										</Row>
									</Container>
								</section>								
							</React.Fragment>
						}
					</React.Fragment>
				}
			</React.Fragment>
		);
	}
}

ContactUs.propTypes = {
	config: PropTypes.shape({
		id: PropTypes.string,
		align: PropTypes.string,
		theme: PropTypes.oneOf([
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey-one',
			'theme-background-grey',
			'theme-background-dark-grey'
		])
	}).isRequired,
	content: PropTypes.shape({
		mainContent: PropTypes.shape({
			textAlign: PropTypes.string,
			headline: PropTypes.shape({
				text: PropTypes.string.isRequired
			}).isRequired,
			text: PropTypes.string.isRequired
		}).isRequired,
		contactDetails: PropTypes.shape({
			textAlign: PropTypes.string,
			items: PropTypes.arrayOf(PropTypes.shape({
				id: PropTypes.string.isRequired,
				text: PropTypes.string.isRequired,
				iconDetails: PropTypes.shape({
					url: PropTypes.string.isRequired,
					altText: PropTypes.string,
					title: PropTypes.string
				}),
				target: PropTypes.string,
				href: PropTypes.string.isRequired
			})).isRequired
		}).isRequired,
		policyLinks: PropTypes.shape({
			textAlign: PropTypes.string,
			items: PropTypes.arrayOf(PropTypes.shape({
				id: PropTypes.string.isRequired,
				text: PropTypes.string.isRequired,
				href: PropTypes.string.isRequired,
				target: PropTypes.string
			})).isRequired
		}).isRequired,
		copyright: PropTypes.shape({
			textAlign: PropTypes.string,
			text: PropTypes.string.isRequired
		}).isRequired
	}).isRequired,
	className: PropTypes.string
};
ContactUs.defaultProps = {
	"config": {
		"id": "contactUs",
		"align": "center",
		"theme": "theme-background-light-grey-one ms-welcome-screen"
	},
	"content": {
		"headline": {
			"text": "<strong>Let's get Started</strong>"
		},
		"banner": {
			"config": {
				"id": "contactUsBanner",
				"bannerImage": {
					"url": "/src/resources/images/small_right_banner.png",
					"alt": "Banner Image",
					"title": "Banner Image"
				},
				"theme": "ms-theme-background-dark-green",
				"height": "short",
				"align": "left"
			},
			"content": {
				"headline": {
					"text": "<strong>Contact Us</strong>"
				},
				"paragraph": {
					"text": ""
				}
			}
		},

		"contactBody": {
			"config": {
				"id": "01",
				"align": "center",
				"theme": "theme-background-light-grey-one"
			},
			"content": {
				"headline": {
					"textAlign": "center",
					"text": "Contact Us",
					"style": "ms-headline"
				},
				"contactList": {
					"textAlign": "left",
					"items": {
						"mdhs": {
							"id": "02",
							"contactName": "MDHS",
							"contactDesc": "Mississippi Department of Human Services",
							"theme": "theme-background-light",
							"contactAddress": "200 South Lamar Street Jackson, MS 39201",
							"contactNumber": "601-359-4500"
						},
						"dom": {
							"id": "03",
							"contactName": "DOM",
							"contactDesc": "State of Mississippi, Division of Medicaid",
							"theme": "theme-background-light",
							"contactAddress": "P.O. Box 2222<br>Jackson, MS 39225",
							"contactNumber": "601-359-6050"
						}
					}
				}
			}
		}
	}
};

const withRouter = (Component) => {
	const ComponentWithRouter = (props) => {
		const router = useRouter();
		return <Component {...props} router={router} />;
	};

	// Adding display name for better debugging
	ComponentWithRouter.displayName = `withRouter(${Component.displayName || Component.name || 'Component'})`;

	return ComponentWithRouter;
}
/* istanbul ignore next */
/*
*Author: Rahul
*Purpose: UC-CP-PHP-09 - Contact Us Page - added state for loading and error.
*Date: 01/21/2022
*/
const mapStateToProps = state => ({
	contactUsLabelData: state.contactUsReducer.contactUsLabelData,
	loading: state.contactUsReducer.loading,
	error: state.contactUsReducer.error
});
/* istanbul ignore next */
const mapDispatchToProps = (dispatch) => bindActionCreators(
	{
		fetchContactUsData
	},
	dispatch
);

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(ContactUs));
