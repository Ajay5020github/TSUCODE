"use client"

import React, { Component } from 'react';
import './userManagement.scss';
import { viewUserService } from '../../services/UserService';
import { connect } from 'react-redux';
import { bindActionCreators, compose } from 'redux';
import { fetchViewUserDetailsAction } from '../../actions/userDetails/userDetailsActions';
import { fetchViewUserAuthAction } from '../../actions/userAuth/userAuthActions';
import CustomModal from '../modal/customModal';
import { convertDateToYMD } from './myBenefitUtil';
import { useRouter } from 'next/navigation';

class UserData extends Component {
    constructor(props) {
        super(props);

        this.state = {
            userDetail: {},
            open: false,
            title: ''
        };

        this.user = this.props && this.props.user;
        this.viewUserJson = this.props && this.props.viewUserJson;

        this.handleResetClose = this.handleResetClose.bind(this);
        this.fetchUserDetails = this.fetchUserDetails.bind(this);
    }

    handleResetClose = () => {
        this.setState({
            open: false
        });
    }

    fetchUserDetails = (user) => {
        let userData = {
            consumerUserID: user.consumerAccountId,
            emailAddress: user.emailAddress,
            firstName: user.firstName,
            lastName: user.lastName,
            phoneNumber: user.programs[0]
        };
        this.fetchUserDetailsFromAPI(JSON.parse(JSON.stringify(userData)));
    }

    fetchUserDetailsFromAPI = (userData) => {

        const { replace } = this.props; 

        let userSingleDetail = JSON.parse(JSON.stringify(userData));
        // this.props.fetchViewUserAuthAction(userSingleDetail).then(() => {});
        this.props.fetchViewUserDetailsAction(userSingleDetail).then(() => {
            if (this.props.singleUserDetail && this.props.singleUserDetail.data && !this.props.singleUserDetail.data.userExits) {
                this.setState({
                    open: true,
                    title: this.viewUserJson && this.viewUserJson.userExitAD
                });
            } else {
                replace('/admin/userManagement/userdetail')
                // this.props.router.push('/admin/userManagement/userdetail');
            }
        });
    }

    programNameList = (programs) => {
        let options = [];
        programs.forEach(ele => {
            options.push(ele);
        });

        return options.toString();
    }

    render() {
        let lockClassName;
        const { userId, firstName, programs, emailAddress, accountCreationDate, accountStatus, lastName, ssn, arInd } = this.user;
        if (accountStatus === 'locked') {
            lockClassName = 'custom-lock-status';
        } else {
            lockClassName = '';
        }

        return (
            <>
                <tr>
                    <td>{accountCreationDate ? accountCreationDate : null}</td>
                    <td>{firstName} {lastName}</td>
                    <td>{emailAddress}</td>
                    <td>{"XXX-XX-" + ssn}</td>
                    <td>{arInd ? arInd === 'Y' ? 'Yes' : 'No' : "No"}</td>
                    <td>{programs && programs.length > 0 ? this.programNameList(programs) : "-"}</td>
                    <td className={lockClassName}>
                        <span className="useraccountStatus">{accountStatus === 'Y' ? 'Locked' : 'Active'}</span>
                    </td>
                    <td className="actions">
                        <span className="custom-view-user-button" onClick={() => this.fetchUserDetails(this.user)}>{this.viewUserJson && this.viewUserJson.viewUserButton}</span>
                    </td>
                </tr>

                <CustomModal
                    size="md"
                    title={this.state.title}
                    paragraph=""
                    show={this.state.open}
                    onHide={this.handleResetClose}
                    onModalButtonClick={this.handleResetClose}
                    alignButtonsVertically={false}
                    primaryButtonWidth={false}
                    primaryButton={this.viewUserJson && this.viewUserJson.closeButton ? {
                        id: '',
                        href: '#',
                        text: this.viewUserJson && this.viewUserJson.closeButton,
                        target: '_blank'
                    } : ''}
                    iconInBody={true}
                    closeLink={{
                        image_url: '/src/resources/images/modal_close.png',
                        altText: 'close',
                        title: ''
                    }} />
            </>
        );
    }
}

const withRouter = (Component) => {
    const ComponentWithRouter = (props) => {
        const router = useRouter();
        return <Component {...props} replace={router.replace} />;
    };

    // Adding display name for better debugging
    ComponentWithRouter.displayName = `withRouter(${Component.displayName || Component.name || 'Component'})`;

    return ComponentWithRouter;
}


const mapStateToProps = state => ({
    singleSelectedUser: state.userDetailsReducer.singleSelectedUser,
    singleUserDetail: state.userDetailsReducer.singleUserDetail,
    singleSelectedUserAuth: state.userAuthReducer.singleSelectedUserAuth
});

const mapDispatchToProps = dispatch =>
    bindActionCreators(
        {
            fetchViewUserDetailsAction,
            fetchViewUserAuthAction
        },
        dispatch
    );

export default compose(
    connect(
        mapStateToProps,
        mapDispatchToProps,
    ),
    withRouter
)(UserData);
