"use client"
import React, { useState } from 'react';
import { useSelector, useDispatch } from "react-redux";
import {
	Row, Col, Button, Form, Card, Container
} from 'react-bootstrap';
import PropTypes from 'prop-types';

import htmlToReact from 'html-to-react';
import * as types from '../../constants/inputTypes';
import FormCheckbox from '../materialUI/formCheckbox/formCheckbox';

import CustomModal from '../modal/customModal';
import FormInput from '../materialUI/formInput/formInput';
import FormSelect from '../materialUI/formSelect/formSelect';
import FormDatePicker from '../materialUI/formDatePicker/formDatePicker';
import Storage from '../../utils/storage';
import { useRouter } from 'next/navigation';
import createSetTimeoutPolyFill from '../../createSetTimeoutPolyFill';

const UserManagementSearchForm = (props) => {
	const {
		className,
		config,
		content,
		componentState,
		handleChange,
		handleDateChange,
		onClickSubmit,
		handleBlur,
		checkBoxHandleChange,
		dobState,
		nameState,
		programTypeValueState,
		multiLabelFieldTitle,
		endDateMaxValue,
		btnDisable
	} = props;
	const {
		primaryFields,
		primaryButton
	} = content;
	const [displayLabel , setDisplayLabel] = useState(false);
	const [multiLabelFieldName, setMultiLabelFieldName] = useState([]) 
	const [programTypeState, setProgramTypeState ] = useState('');
	const [actionState, setActionState ] = useState(' ');
	const [isReduxData, setIsReduxData] = useState(false);
	const [storeData, setStoreData] = useState([]);
    const dispatch = useDispatch();
	const htmlToReactParser = new htmlToReact.Parser();
	const getParseData = content => htmlToReactParser.parse(content);
	const getLangSelectAll = () => {
        let langCode = Storage.getItem('defaultLangCode')
        switch (langCode) {
            case "en": return "Select all"
            case "es": return "Seleccionar todo"
            case "pt": return "Selecionar tudo"
            case "vi": return "Chọn tất cả"
            case "uk": return "Вибрати все"
            case "ru": return "Выбрать все"
            case "zh": return "全選"

            default: return "Select all"

        }
	}

	 
	const getFormFields = (field, index) => {	
        
		const { formErrors, isFormSubmited, formDataSet, formDate } = componentState;
		switch(field.fieldType.toUpperCase()){
		case types.INPUT:
			if(field.dataType === 'date'){
				return (

					<Form.Group
					style={{marginTop:"2rem"}}
						key={index}
						as={Col}
						className={`input-root col-md-4 col-12 primary-fields ${field.className ? field.className : ''}`}
					>
						<FormDatePicker
							field={field}
							fieldError={
								formErrors && !formErrors[field.name].isValid && (
									formErrors[field.name].isTouched
									|| isFormSubmited
								)
							}
							errorMessage={
								formErrors
								&& formErrors[field.name]
									.activeValidator
									.errorMessage
							}
							isClearable = {true}
							endDateMaxValue = {endDateMaxValue ? endDateMaxValue : ''}
							formData={formDataSet && formDataSet[field.name] ? formDataSet[field.name] : field.defaultValue ? field.defaultValue : ''}
							handleDateChange={/* istanbul ignore next */(e) => handleDateChange(e, 0, field)}
							handleBlur={handleBlur}	
							onMouseLeave={handleBlur}
							/*InputProps={storeResponseOfRequestAccess ? { readOnly: true }: { readOnly: false }}		disabled={ dobState && field.name==="dob" ? true : false}		*/		
						/>
					</Form.Group>
				);
			}else{
				return (
					<Form.Group
						key={index}
						as={Col}
						className={`input-root col-md-4 col-12 primary-fields ${field.className ? field.className : ''}`}
					>
						<FormInput
							field={field}
							fieldError={
								formErrors
								&& !formErrors[field.name].isValid
								&& (
									formErrors[field.name].isTouched
									|| isFormSubmited
								)
							}
							errorMessage={
								formErrors
								&& formErrors[field.name]
									.activeValidator
									.errorMessage
							}
							formData={ formDataSet && formDataSet[field.name] ? formDataSet[field.name] : field.defaultValue ? field.defaultValue : ''}
							handleChange={/* istanbul ignore next */(e) => handleChange(e, 0, field)}
							handleBlur={handleBlur}	
							/*InputProps={storeResponseOfRequestAccess ? { readOnly: true }: { readOnly: false }}	*/
									
						/>
					</Form.Group>
				);
			}
		case types.SELECT:
		
			return (
				<Form.Group
					key={index}
					as={Col}
					style={{marginTop:"2rem"}}
					className={`input-root col-md-4 col-12 primary-fields ${field.className ? field.className : ''}`}
				>
				
					<FormSelect
					
						field={field}
						formData={formDataSet && formDataSet[field.name] ? formDataSet[field.name] : field.defaultValue ? field.defaultValue : ''}
						fieldError={
							formErrors
							&& !formErrors[field.name].isValid
							&& (
								formErrors[field.name].isTouched
								|| isFormSubmited
							)
						}
						errorMessage={
							formErrors
							&& formErrors[field.name]
								.activeValidator
								.errorMessage
						}
						handleChange={/* istanbul ignore next */(e) => handleChange(e, 0, field)}
						handleBlur={handleBlur}/>
						
							
				</Form.Group>
			);
        
		case types.PARAGRAPH:
			return (
				<Form.Group
					key={index}
					as={Col}
					md={12}
					
					
					className={`text-md-${field.textAlign} text-center p-root ${field.className ? field.className : ''}`}
				>
					<Form.Label>
						{htmlToReactParser.parse(field.defaultValue)}
					</Form.Label>
				</Form.Group>
			);
			case types.CHECKBOX:
			return (
				<Form.Group
					key={index}
					as={Col}
					
					className="input-root col-md-4 col-12 primary-fields extra-padding-right col requestClientCheckbox form-group"
				>
					
					<FormCheckbox
						field={field}
						fieldError={false}
						isFormSubmited={isFormSubmited}
						formData={formDataSet ? formDataSet[field.name] : false}
						handleChange={/* istanbul ignore next */(e) => handleChange(e, 0, field)}
						handleBlur={handleBlur}/>
				</Form.Group>
			);
		default:
			/* istanbul ignore next */
			return null;
		}
	};
	
	const getPrimaryButton = (primaryButton, modal) => {
		
		return (
			<Form.Group
				
				
				className= {primaryButton.name === "search" ? " usermanagemnt-search-button-section mt-3" : "mt-3"}
			>
				
				<Button
					type="button"
					disabled= {btnDisable}
					className= {"btn-transperant-outline-dark btn-admin-search-button floating-button btn btn-light usermanagemnt-search-button"}
					// onMouseDown={/* istanbul ignore next */(e) => {}
					// 	 }
					// onClick={ () => props.onClickSubmit(primaryButton.href)}
					onMouseDown={ () => createSetTimeoutPolyFill(() => {						
						props.onClickSubmit(primaryButton.href)						
					}, 100)}>
					{primaryButton.text.toUpperCase()}
				</Button>
				<Button
					type="button"
					className= {"btn-admin-clear-button btn-transperant-outline-dark floating-button btn btn-light usermanagemnt-search-button"}
					onMouseDown={/* istanbul ignore next */(e) => {}
						 }
					onClick={ () => props.onClear()}>
					{primaryButton.clearButton.toUpperCase()}
				</Button>
				
			</Form.Group>
		
		);
	};
	
	


	
	return (
		
	

				<Row className="justify-content-center no-gutters custom-admin-user-search-container">
					<Col md={{ span: 12 }}>
					
						<Card>
						
							<Card.Body>
								<Form
									className = "phase-three-form"
									onSubmit={/* istanbul ignore next */(e) =>
										onClickSubmit(e)}
									noValidate
								>	<div className="form-row">			
													<Form className='FormRow' >
										{
											primaryFields.map((elem, index) => getFormFields(elem, index))
										}
										<Col className="col-12 d-flex userManagement-button" >
										{primaryButton ?
											primaryButton.map((elem, index) => getPrimaryButton(elem, index))
											:""}
										</Col>
									</Form>
									</div>
	
								</Form>
								
							</Card.Body>
						</Card>
					</Col>
					
				</Row>
	);
};

const withRouter = (Component) => {
    const ComponentWithRouter = (props) => {
        const router = useRouter();
        return <Component {...props} router={router} />;
    };

    // Adding display name for better debugging
    ComponentWithRouter.displayName = `withRouter(${Component.displayName || Component.name || 'Component'})`;

    return ComponentWithRouter;
};

export default withRouter(UserManagementSearchForm);
