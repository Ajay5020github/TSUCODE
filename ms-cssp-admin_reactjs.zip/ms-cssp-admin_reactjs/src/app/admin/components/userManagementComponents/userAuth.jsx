"use client"

import React, { useEffect, useState } from 'react';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import { useLocation } from 'next/navigation'
import { useRouter } from "next/navigation";
import { useSelector } from 'react-redux';
import MuiAlert from '@mui/material/Alert';
import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';
import { viewUserService, resetPassword, unlockUserAccount, lockAccountService, authenticateAccountService, activateAccountService, deactivateAccountService } from '../../services/UserService';
import CustomModal from '../modal/customModal';
import './userManagement.scss';
import Storage from '../../utils/storage';
import '../../components/userManagementComponents/userdetails.css';

/* istanbul ignore next */
const Alert = (props) => {
	return <MuiAlert elevation={6} variant="filled" {...props} />;
}
const UserAuth = (props) => {
	const history = useRouter();
	const [invalid, setInvalid] = useState(false);
	const [errorMessage, setErrorMessage] = useState("");
	const [userDetail, setUserDetail] = useState({});
	const [open, setOpen] = useState(false);
	const [openLock, setOpenLock] = useState(false);
	const [openUnLock, setUnOpenLock] = useState(false);
	const [openActive, setOpenActive] = useState(false);
	const [openAuthenticate, setOpenAuthenticate] = useState(false);
	const [openAuthenticateDecline, setOpenAuthenticateDecline] = useState(false);
	const [authenticateSuccess, setAuthenticateSuccess] = useState(false);
	const [openReset, setOpenReset] = useState(false);
	const [accoountLockStatus, setAccoountLockStatus] = useState(false);
	const [accoountUnLockStatus, setAccoountUnLockStatus] = useState(false);
	const [title, setTitle] = useState("");
	const [titleReset, setTitleReset] = useState("");
	const [successMessage, setSuccessMessage] = useState("");
	const [successResetMessage, setSuccessResetMessage] = useState("");
	const [isAuth, setIsAuth] = useState(false);
	const [isDecline, setIsDecline] = useState(false);
	const [showButtons, setShowButtons] = useState(true);
	const [openAuthenticateAccount, setOpenAuthenticateAccount] = useState(false);

	const singleUserDetailState = useSelector(state => state.userDetailsReducer.singleSelectedUser);
	//const location = useLocation()
	//@sai kiran calling userauth action redux
	const select = useSelector((sel)=> sel.userAuthReducer.person)

	useEffect(() => {
		const updatedUserDetails = select.data
		//const updatedUserDetails = Storage.getItem("useremail")
		setUserDetail(updatedUserDetails)
	},[])

	// useEffect(() => {
	// 	const {updatedUserDetails} = location.state
	// 	setUserDetail(updatedUserDetails)	
	// },[])

	const handleClose = () => {
		setOpen(false);
		setOpenLock(false)
		setOpenAuthenticate(false);
		setOpenAuthenticateDecline(false);
		setAuthenticateSuccess(false);
	}
	/* istanbul ignore next */
	const handleResetClose = () => {
		setOpen(false)
		setOpenReset(false);
		let userDetails = {
			"consumerUserID": userDetail.consumerAccountId,
			"emailAddress": userDetail.emailAddress,
			"firstName": userDetail.firstName,
			"lastName": userDetail.lastName
		};
		fetchUserDetailsFromAPI(userDetails);
	}
	const goBackToUserManagement = () => {
		history.push({
			pathname: '/admin/userManagement',
		});
	}
	/* istanbul ignore next */
	const fetchUserDetailsFromAPI = (user) => {
		const userData = setUserData(user);
		viewUserService(user).then(response => {
			if (response !== undefined && response.statusCode === 200 && response.success) {
				const userDetailResponse = response.body.userDetails;
				setUserDetail(userDetailResponse)

			} else {
				setInvalid(true);
				setErrorMessage(response.message)
			}
		})
	}

	/* istanbul ignore next */
	const setUserData = (user) => {
		return {
			"consumerUserID": user.consumerUserID,
			"emailAddress": user.emailAddress,
			"firstName": user.firstName,
			"lastName": user.lastName,
			"phoneNumber": user.phoneNumber,
			"zipCode": user.zipCode
		};
	}

	/* istanbul ignore next */
	const confirmDecline = (userId) => {
		setOpenAuthenticateDecline(true);
		setTitle(props.labels && props.labels.confirmDeclineAuthenticate);
		setSuccessMessage(props.labels && props.labels.confirmDeclineAuthenticateParagraph);
		//resetAccountPassword(userId)
	}

	/* istanbul ignore next */
	const confirmLock = (userId) => {
		setOpenLock(true);
		setTitle(props.labels && props.labels.confirmLock);
		setSuccessMessage('test');
		//resetAccountPassword(userId)
	}
	/* istanbul ignore next */
	const confirmUnLock = (userId) => {
		setUnOpenLock(true);
		setTitle(props.labels && props.labels.confirmUnLock);
		setSuccessMessage('');
		//resetAccountPassword(userId)
	}
	const confirmAuthenticate = () => {
		setOpenAuthenticate(true);
		setTitle(props.labels && props.labels.confirmAuthenticate);
		setSuccessMessage(props.labels && props.labels.confirmAuthenticateParagraph);
		//resetAccountPassword(userId)		
	}


	/* istanbul ignore next */
	const resetAccountPassword = (userId, userDetail) => {
		const userResetAccountDetail = userDetail.consumerAccountId;
		resetPassword(userDetail).then(response => {
			if (response.statusCode === 200 && response.success) {
				setOpen(false);
				let message = `Password : ${response.generatedPassword}`;
				setTitleReset(response.message);
				setSuccessResetMessage(message);
				setOpenReset(true);
			} else {
				//setInvalid(true);
				setErrorMessage(response.message)
			}

		});
	}



	const handleauthenticateDeclineAccount = (userId, userDetail) => {
		// authenticateDeclineAccount(userId, userDetail);

		setOpenAuthenticateDecline(false);
		setIsAuth(false);
		setIsDecline(true);
		setShowButtons(false);
	}
	const authenticateDeclineAccount = (userId, userDetail) => {

		authenticateAccountService(userDetail).then(response => {
			if (response.statusCode === 200 && response.success) {
				setOpenAuthenticateDecline(false);
				setIsAuth(false);
				setIsDecline(true);
				//setAccoountUnLockStatus(true)
			} else {
				//setInvalid(true);
				setErrorMessage(response.message)
			}

		});

	}
	/* istanbul ignore next */
	const handleauthenticateAccount = (userId, userDetail) => {
		authenticateAccount(userId, userDetail);
	}
	/* istanbul ignore next */
	const authenticateAccount = (userId, userDetail) => {
		authenticateAccountService(userDetail).then(response => {
			fetchUserDetailsFromAPI(userDetail);
			if (response.statusCode === 200 && response.success) {
				setOpenAuthenticate(false);
				setOpenAuthenticateAccount(true);
				setIsAuth(true);
				setIsDecline(false);
				setShowButtons(false);
				setAuthenticateSuccess(true);
				setTitle(props.labels && props.labels.authenticateSuccessTitle);
				setSuccessMessage(props.labels && props.labels.authenticateSuccessMessage);
				//setAccoountUnLockStatus(true)
			} else {
				//setInvalid(true);
				setErrorMessage(response.message)
				setShowButtons(false);
			}

		});

	}

	const getFormattedDate = () => {
		const d = new Date;
		let tail = '';
		const D = [d.getUTCMonth() + 1, d.getUTCDate(), d.getUTCFullYear()];
		const T = [d.getUTCHours(), d.getUTCMinutes()];
		if (+T[0] > 12) {
			T[0] -= 12;
			tail = ' PM';
		}
		else tail = ' AM';
		let i = 3;
		while (i) {
			--i;
			if (D[i] < 10) D[i] = '0' + D[i];
			if (T[i] < 10) T[i] = '0' + T[i];
		}
		//let time = new Date().toLocaleString('en-US', { hour: '2-digit', minute: '2-digit', timeZone: 'IST' });
		let time = new Date().toLocaleString('en-US', { hour: '2-digit', minute: '2-digit' });
		return D.join('/');
	};


	const accountStatusData = (userId) => {
		return {
			"consumerUserID": userId,
		}
	}
	// useEffect(() => {
	// 	if (singleUserDetailState && Object.keys(singleUserDetailState).length) {
	// 		fetchUserDetailsFromAPI(singleUserDetailState.data);
	// 	}
	// }, [singleUserDetailState])

	const renderUserDataJson = (userDetail) => {
		/* const { userId, consumerAccountId, accountStatus, emailAddress, firstName, lastName, phoneNumber, zipCode, securityQuestions } = userDetail; */
		let securityQuestions = userDetail.securityQuestions;
		return (
			<>
				<div className="my-account-wrap card">
					<div>
						<div className="card-header">
							<div className="mb-0 d-flex justify-content-md-between flex-column flex-md-row card-title h5">
								<div className="d-flex flex-column userInfo">
									<div className="userName header-row">{userDetail.firstName} {userDetail.lastName}</div>
									{/* <div className="header-row">
										<p><span className="useridspan">{props.labels && props.labels.accoutStatus}</span>: <span className="userId">{userDetail.accountType}</span></p>
										<p>
										<span className="useridspan">{props.labels && props.labels.emailVerified}</span>: <span className="userId">{userDetail.emailVerifiedInd === 'Y' ? "YES" : "NO"}</span></p>
										
									</div> */}
									<div className="header-row">
										<p><span className="useridspan">{props.labels && props.labels.accoutStatus}</span>: <span className="userId">{openAuthenticateAccount ? "ADVANCED" : userDetail.accountType === "UPGRADED" ? "ADVANCED" : userDetail.accountType}</span></p>
										<p>
											<span className="useridspan">{props.labels && props.labels.emailVerified}</span>: <span className="userId">{userDetail.emailVerifiedInd === 'Y' ? "YES" : "NO"}</span></p>
										{userDetail.accountType !== "BASIC" ?
											<>
												<p><span className="useridspan">{props.labels && props.labels.authTypeLabel}</span>: <span className="userId">{userDetail.authenticationType}</span></p>
												<p>
													<span className="useridspan">{props.labels && props.labels.sourceTypeLabel}</span>: <span className="userId">{userDetail.authenticationSource}</span></p></>
											: " "}
									</div>
								</div>

							</div>
						</div>
						<div className="card-body">
							<div className="row">
								<div className="col-md-12">
									<div className="subsection-header row">
										<div className="col-md-12">
											<div className="page-section-head d-flex justify-content-between">
												<span className="head-label">{props.labels && props.labels.portalUserDetails}</span>
											</div>
										</div>
									</div>
									<div className="row">
										<div className={"custom-field col-md-12"}>
											<ul className="section-list col-12 mb-0">
												{!isAuth && !isDecline ?
													<li className="row no-gutters">
														<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.nameLabels}</div>
														<div className="fieldValue col-md-6">{userDetail.firstName + " " + userDetail.lastName}</div>
													</li> : ""
												}
												{isAuth || isDecline ?
													<li className="row no-gutters">
														<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.lastNameLabels}</div>
														<div className="fieldValue col-md-6">{userDetail.lastName}</div>
													</li> : ""}
												<li className="row no-gutters">
													<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.emailAddressLabel} </div>
													<div className="fieldValue col-md-6">{userDetail.emailAddress}</div>
												</li>
												
												<li className="row no-gutters">
                                                    <div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.ssnLabel}</div>
                                                    <div className="fieldValue col-md-6">{"XXX-XX-" + (userDetail.socialSecurityNumber.length === 11 ? userDetail.socialSecurityNumber.substring(7) : userDetail.socialSecurityNumber.substring(5))}</div>
                                                </li>
												
												<li className="row no-gutters">
													<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.dateOfBirthLabel}</div>
													<div className="fieldValue col-md-6">{userDetail.dateOfBirth}</div>
												</li>
												{/* <li className="row no-gutters">
													<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.contactPreLabel}</div>
													<div className="fieldValue col-md-6">
														{userDetail.contactEmailPreference !== undefined && userDetail.contactEmailPreference === 'Y' ? 'Email' : ''}
														{userDetail.contactEmailPreference === 'Y' && userDetail.contactMobilePreference === 'Y' ? ' , ' : ''}
														{userDetail.contactMobilePreference !== undefined && userDetail.contactMobilePreference === 'Y' ? 'Mobile' : ''}
													</div>
												</li> */}

											</ul>
										</div>

									</div>
								</div>
							</div>
							<div className="subsection-header row">
								<div className="col-md-12">
									<div className="page-section-head d-flex justify-content-between">
										<span className="head-label">{props.labels && props.labels.authentication}</span>
									</div>
									<div className="row">
										<div className={"custom-field col-md-12"}>
											<ul className="section-list col-12 mb-0">
												<li className="row no-gutters">
													<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.Authenticated}</div>
													<div className="fieldValue col-md-6">{userDetail.authenticationType ? userDetail.authenticationType : "No"}</div>
												</li>
												{!isAuth && !isDecline ?
													<li className="row no-gutters">
														<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.AutomatedIdentitityCheck} </div>
														<div className="fieldValue col-md-6">{userDetail.authenticationSource ? userDetail.authenticationSource === 'UserNotAuthenticated' ? 'Fail' : 'None' : "None"}</div>
													</li> : ""}
												{isAuth ?
													<li className="row no-gutters">
														<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.authenticatedBy}</div>
														<div className="fieldValue col-md-6">{Storage.getItem("adminUserId")} {getFormattedDate()}</div>
													</li> : ""}
												{isDecline ?
													<li className="row no-gutters">
														<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.declinedby} </div>
														<div className="fieldValue col-md-6">{Storage.getItem("adminUserId")} {getFormattedDate()}</div>
													</li> : ""}

											</ul>
										</div>

									</div>


								</div>
							</div>

							{showButtons ?
								<div className="row">
									<div className="auth-button-row">
										<button className={"btn-account auth-button"} onClick={() => confirmDecline(userDetail.userId, userDetail)} >{props.buttons && props.buttons.DeclineButton}</button>
										<button className={"btn-account"} onClick={() => confirmAuthenticate(userDetail.userId, userDetail)} >{props.buttons && props.buttons.SaveButton}</button>
									</div>
								</div>
								: null}



						</div>
					</div>
				</div>


				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={openAuthenticateDecline}
					onHide={handleClose}
					onModalButtonClick={() => handleauthenticateDeclineAccount(userDetail.userId, userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.yesButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.yesButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					secondaryButton={props && props.buttons && props.buttons.noButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.noButton,
						target: ''
					} : {
						href: 'javascript:void(0)',
							text: ' ',
						}}
					onSecondaryButtonClick={handleClose}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={true} />


				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={openAuthenticate}
					onHide={handleClose}
					onModalButtonClick={() => handleauthenticateAccount(userDetail.userId, userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.yesButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.yesButton,
						target: ''
					} : {
						href: 'javascript:void(0)',
							text: ' ',
						}}
					secondaryButton={props && props.buttons && props.buttons.noButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.noButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					onSecondaryButtonClick={handleClose}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={true} />

				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={authenticateSuccess}
					onHide={handleClose}
					onModalButtonClick={() => handleClose()}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.okButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.okButton,
						target: ''
					} : {
						href: 'javascript:void(0)',
							text: ' ',
						}}					
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={false} />
			</>)
	}
	return (
		<>

			<div className="theme-background-light-grey py-3 py-md-5">
				<div id="16361" className="pb-3 container">
					<div className="mb-3 justify-content-center row">
						<div className="col-md-10">
							<div className="customBreadcrumb">
								<Breadcrumb>
									<Breadcrumb.Item href={props.breadcrumbUrl} >
										{props.breadcrumb}
									</Breadcrumb.Item>
								</Breadcrumb>
							</div>
							{!invalid && Object.keys(userDetail).length > 0 && userDetail && userDetail && renderUserDataJson(userDetail)}
							{invalid && errorMessage && <ErrorMessage errorMessage={errorMessage} />}

						</div>
					</div>
				</div>
			</div>
		</>
	);
}
export default UserAuth;