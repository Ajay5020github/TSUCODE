"use client"
import React, { useEffect, useState } from 'react';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from 'react-redux';
import MuiAlert from '@mui/material/Alert';
import Switch from '@mui/material/Switch';
import Checkbox from '@mui/material/Checkbox';
import Button from '@mui/material/Button';
import * as types from '../../constants/inputTypes';

import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';


import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';
import {
	viewUserService, resetPassword, unlockUserAccount, lockAccountService, authenticateAccountService,
	activateAccountService, deactivateAccountService, telephoneAssistorService, enableProgramService
} from '../../services/UserService';
import CustomModal from '../modal/customModal';
import './userManagement.scss';
import Storage from '../../utils/storage';
import UserAuthenticationContainer from '../../containers/userAuthentication/userAuthenticationContainer';
import Tooltip from '@mui/material/Tooltip';
import makeStyles from '@mui/styles/makeStyles';
import { Col, Form } from 'react-bootstrap';
import FormDatePicker from '../materialUI/formDatePicker/formDatePicker';
import FormInput from '../materialUI/formInput/formInput';
import { formatSSN } from './myBenefitUtil';
import userReducer from '../../reducers/userAuth/userAuthReducer';
import { authdetils, userAuthDataSuccesski } from '../../actions/userAuth/userAuthActions';


/* istanbul ignore next */
const Alert = (props) => {
	return <MuiAlert elevation={6} variant="filled" {...props} />;
}
const useStyles = makeStyles(theme => ({
	container: {
	  position: 'relative',
	  display: 'inline-block',
	},
	tooltip: {
	  position: 'absolute',
	  top: '100%',
	  left: '50%',
	  transform: 'translate(-50%, 10px)',
	  backgroundColor: '#ffffff',
	  color: 'rgba(0, 0, 0, 0.87)',
	  fontSize: 14,
	  border: '1px solid rgba(0, 0, 0, .2)',
	  padding: '10px',
	  zIndex: 999,
	  opacity: 0,
	  pointerEvents: 'none',
	  transition: 'opacity 0.1s ease',
	  width: '296px',
	  '&::before': {
		content: '""',
		position: 'absolute',
		top: '-10px',
		left: '50%',
		transform: 'translateX(-50%)',
		borderLeft: '10px solid transparent',
		borderRight: '10px solid transparent',
		borderBottom: '10px solid rgba(0, 0, 0, .2)',
	  },
	  '&::after': {
		content: '""',
		position: 'absolute',
		top: '-8.5px',
		left: '50%',
		transform: 'translateX(-50%)',
		borderLeft: '10px solid transparent',
		borderRight: '10px solid transparent',
		borderBottom: '10px solid rgba(255, 255, 255, 1)',
	  },
	},
	tooltipVisible: {
	  opacity: 1,
	  pointerEvents: 'auto',
	  position: 'absolute',
	  top: '100%',
	  left: '50%',
	  transform: 'translate(-50%, 10px)',
	  backgroundColor: '#ffffff',
	  color: 'rgba(0, 0, 0, 0.87)',
	},
  }));
  
function CustomTooltip({ title, children }) {
	const classes = useStyles();
	const [isTooltipVisible, setTooltipVisible] = useState(false);

	const handleMouseEnter = () => {
		setTooltipVisible(true);
	};

	const handleMouseLeave = (event) => {
		event.stopPropagation();
		setTooltipVisible(false);
	};

	return (
		<div
		className={classes.container}
		onMouseEnter={handleMouseEnter}
		onMouseLeave={handleMouseLeave}
		>
			{children}
			<div
				className={`${classes.tooltip} ${
				isTooltipVisible ? classes.tooltipVisible : ''
				}`}
			>
				{title}
			</div>
		</div>
	);
}
const User = (props) => {

		const dispatch = useDispatch()
		const { push } = props; 
		
		const [invalid, setInvalid] = useState(false);
		const [errorMessage, setErrorMessage] = useState("");
		const [userDetail, setUserDetail] = useState({});
		const [open, setOpen] = useState(false);
		const [openLock, setOpenLock] = useState(false);
		const [openUnLock, setUnOpenLock] = useState(false);
		const [openEnable, setOpenEnable] = useState(false);
		const [openDisable, setOpenDisable] = useState(false);
		const [accountEnable, setAccountEnable] = useState(false);
		const [accountDisable, setAccountDisable] = useState(false);
		const [openAuthenticate, setOpenAuthenticate] = useState(false);
		const [openAuthenticateAccount, setOpenAuthenticateAccount] = useState(false);
		const [btnDisabled, setBtnDisabled] = useState(true);
		const [btnRoleDisabled, setBtnRoleDisabled] = useState(false);
		const [openReset, setOpenReset] = useState(false);
		const [accoountLockStatus, setAccoountLockStatus] = useState(false);
		const [accoountUnLockStatus, setAccoountUnLockStatus] = useState(false);
		const [title, setTitle] = useState("");
		const [titleReset, setTitleReset] = useState("");
		const [successMessage, setSuccessMessage] = useState("");
		const [successResetMessage, setSuccessResetMessage] = useState("");
		const singleUserDetailState = useSelector(state => state.userDetailsReducer.singleSelectedUser);
		const [btnHideButtons, setHideButtons] = useState(false);
		const [btnHideAuthButton, setHideAuthButton] = useState(false);
		const [paragraph, setParagraph] = useState("");

		const [checked, setChecked] = React.useState(true);
		const [telephoneAssistor, setTelephoneAssistor] = useState(false);

		// Fix for INC-3253
		// START
		const [maskSSN, setMaskSSN] = useState(true);
		// END
		// Fix for INC-3253


		const [assistorInd, setAssistorInd] = useState(false);
		const [openEnableProgram, setOpenEnableProgram] = useState(false);
		const [openEnableProgramSuccess, setOpenEnableProgramSuccess] = useState(false);

		const [SNAPProgram, setSNAPProgram] = useState("")
		const [TANFProgram, setTANFProgram] = useState("")
		const [LIHEAPProgram, setLIHEAPProgram] = useState("")
		const {
			componentState,
			handleChange,
			handleDateChange,
			handleBlur,
			dobState,
			endDateMaxValue,
			onClickAuthenticateBtn,
			handleUserDetails
		} = props;
		//	const [userLabel, setUserLabel] = useState(props.labels);
		const scrollToTop = () => {
			window.scroll({
				top: 0,
				left: 0,
				behavior: 'smooth'
			});
		};
		const handleClose = () => {		
			setOpen(false);
			setOpenLock(false)
			setOpenAuthenticate(false);
			setUnOpenLock(false);
			setOpenEnable(false);
			setOpenDisable(false);
			setTelephoneAssistor(false);
			setOpenEnableProgram(false);
			setOpenEnableProgramSuccess(false);
			
			// Fix for INC-3253
			// START
			setMaskSSN(false);
			// END
			// Fix for INC-3253
			
		}

		/* istanbul ignore next */
		const handleResetClose = () => {
			setOpen(false)
			setOpenReset(false);
			let userDetails = {
				"consumerUserID": userDetail.consumerAccountId,
				"emailAddress": userDetail.emailAddress,
				"firstName": userDetail.firstName,
				"lastName": userDetail.lastName
			};
			fetchUserDetailsFromAPI(userDetails);
		}
		const goBackToUserManagement = () => {
			// history.push({
			// 	pathname: '/userManagement',
			// });
			replace('/admin/userManagement')
			// refresh()
		}
		/* istanbul ignore next */
		const fetchUserDetailsFromAPI = (user) => {
			
			const userData = setUserData(user);
			viewUserService(user).then(response => {

				if (response !== undefined && response.statusCode === 200 && response.success) {
					const userDetailResponse = response.body.userDetails;
					
					setUserDetail(userDetailResponse)

				} else {
					setInvalid(true);
					setErrorMessage(response.message)
				}
			})
		}

		const CLAIMS = [
			{ key: 0, label: "CLAIM OWNER", name: "DESIREE MOHUKA" },
			{ key: 1, label: "AUTHORITY CONSULTANT", name: "XXXXXXXXXXXX" },
			{ key: 2, label: "PROCESSOR CLAIM", name: "XXXXXXXXXXXX" },
			{ key: 3, label: "CONTROLLLER", name: "XXXXXXXXXXXX" },
			{ key: 4, label: "MANAGER", name: "XXXXXXXXXXXX" }
		];

		/* istanbul ignore next */
		const setUserData = (user) => {
			return {
				"consumerUserID": user.consumerUserID,
				"emailAddress": user.emailAddress,
				"firstName": user.firstName,
				"lastName": user.lastName,
				"phoneNumber": user.phoneNumber,
				"zipCode": user.zipCode
			};
		}

		/* istanbul ignore next */
		const confirmReset = (userId) => {
			setOpen(true);
			setTitle(props.labels && props.labels.confirmReset);
			setSuccessMessage(props.labels && props.labels.confirmResetParagraph);
			// resetAccountPassword(userId)
		}

		/* istanbul ignore next */
		const confirmTelephoneAssistor = (checked) => {
			
			setTelephoneAssistor(true);
			if (userDetail.assistorInd !== "Y") {
				setTitle(props.labels && props.labels.confirmAddTelephoneAssistor);
				setParagraph(props.labels && props.labels.confirmAddTelephoneAssistorParagraph)
				setSuccessMessage(props.labels && props.labels.confirmAddTelephoneAssistorParagraph);
				userDetail.assistorInd = "Y";			
			}
			else {
				setTitle(props.labels && props.labels.confirmRemoveTelephoneAssistor);
				setParagraph(props.labels && props.labels.confirmRemoveTelephoneAssistorParagraph)
				setSuccessMessage(props.labels && props.labels.confirmRemoveTelephoneAssistorParagraph);
				userDetail.assistorInd = "N";			
			}
		}

		/* istanbul ignore next */
		const handleTelephoneAssistor = (userId, userDetail) => {
			telephoneAssistorAccount(userId, userDetail);
		}

		/* istanbul ignore next */
		const telephoneAssistorAccount = (userId, userDetail) => {

			setTelephoneAssistor(false);
			
			telephoneAssistorService(userDetail).then(response => {
				
				if (response.statusCode === 200 && response.success) {
					
					let userDetails = {
						"consumerUserID": userDetail.consumerAccountId,
						"emailAddress": userDetail.emailAddress,
						"firstName": userDetail.firstName,
						"lastName": userDetail.lastName
					};
					fetchUserDetailsFromAPI(userDetails);

					// try { window.appInsights.trackEvent('Admin - Telephone Assistor', { 'pageName': "User Details" }, { 'consumerAccountId': userDetail.consumerAccountId }); }
					// catch { }

				} else {
					setErrorMessage(response.message)
				}
			});

		}

		/* istanbul ignore next */
		/// Fix for INC-3253
		// START
		const confirmMaskUnMask = () => {
			
			setMaskSSN(!maskSSN)
		}
		// END
		// Fix for INC-3253

		const selectProgram = (e, Program) => {

			switch (Program) {
				case "SNAP":

					if (e.target.checked) {					
						setSNAPProgram(Program);					
					}
					else {					
						setSNAPProgram("");					
					}				
					break;

				case "TANF":

					if (e.target.checked) {					
						setTANFProgram(Program);					
					}
					else {					
						setTANFProgram("");					
					}
					break;

				case "LIHEAP":

					if (e.target.checked) {
						setLIHEAPProgram(Program);					
					}
					else {
						setLIHEAPProgram("");					
					}
					break;

				default:				
					break;
			}		
		}

		/* istanbul ignore next */
		const confirmEnableProgram = () => {	
			
			setOpenEnableProgram(true);
			setTitle(props.labels && props.labels.confirmEnableProgram);
			setParagraph(props.labels && props.labels.confirmEnableProgramParagraph)
			setSuccessMessage(props.labels && props.labels.confirmEnableProgramParagraph);
			
		}

		/* istanbul ignore next */
		const handleEnableProgram = (userId, userDetail) => {

			let Programs = [];

			if (SNAPProgram) {
				Programs.push(SNAPProgram)
			}

			if (TANFProgram) {
				Programs.push(TANFProgram)
			}

			if (LIHEAPProgram) {
				Programs.push(LIHEAPProgram)
			}

			enableProgramFunction(userId, userDetail, Programs);
		}

		/* istanbul ignore next */
		const enableProgramFunction = (userId, userDetail, Programs) => {

			if (Programs && Programs.length > 0) {			
				setOpenEnableProgram(false);
				setOpenEnableProgramSuccess(true);

				setTitle(props.labels && props.labels.enableProgramSuccessTitle);
				setParagraph(props.labels && props.labels.enableProgramSuccessMessage)
				setSuccessMessage(props.labels && props.labels.enableProgramSuccessMessage);

				let AdminPersonFirstName = "";
				let AdminPersonLastName = "";

				if (Storage.getItem("Internal")) {
					if (Storage.getItem("firstName")) {
						AdminPersonFirstName = Storage.getItem("firstName");
					}
		
					if (Storage.getItem("lastName")) {
						AdminPersonLastName = Storage.getItem("lastName");
					}
					else {
						AdminPersonLastName = Storage.getItem("firstName");
					}
				}
				else if (!Storage.getItem("Internal")) {
					if (Storage.getItem("firstName")) {

						let personName = Storage.getItem("firstName").split(" ");

						if (personName && Object.keys(personName).length > 0) {

							if (Array.isArray(personName)) {
								AdminPersonFirstName = personName[0];
								AdminPersonLastName =  personName[1];
							}
							else {
								AdminPersonFirstName = personName;
								AdminPersonLastName =  personName;
							}						
						}					
					}
				}

				let mdhsVerifyCase = {
					"application": "MDHSVerifyCase",
					"payload": {
						"actionType": "enableprogram",
						"programsRequested": Programs,
						"caseid": "",
						"consumerAccountId": userDetail.consumerAccountId,
						"AdminPersonFirstName": AdminPersonFirstName,
						"AdminPersonLastName": AdminPersonLastName
					},
					"authToken": Storage.getItem('authToken'),
					"department": Storage.getItem('loginType'),
					"userId":  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
				}

				enableProgramService(mdhsVerifyCase).then(response => {
		
					if (response.statusCode === 200 && response.success) {

						

						let userDetails = {
							"consumerUserID": userDetail.consumerAccountId,
							"emailAddress": userDetail.emailAddress,
							"firstName": userDetail.firstName,
							"lastName": userDetail.lastName				
						};
						fetchUserDetailsFromAPI(userDetails);

						// try { window.appInsights.trackEvent('Admin - Enable Benefit Program', { 'pageName': "User Details" }, { 'consumerAccountId': userDetail.consumerAccountId }); }
						// catch { }
						
		
					} else {				
						setErrorMessage(response.message)
					}
				});
			}			
		}

		const handleTelephoneAssistorCancel = (userId, userDetail) => {
			
			if (userDetail.assistorInd === "Y") {
				userDetail.assistorInd = "N";
				setTelephoneAssistor(false);
			}
			else if (userDetail.assistorInd === "N") {
				userDetail.assistorInd = "Y";
				setTelephoneAssistor(false);
			}		
		}

		/* istanbul ignore next */
		const confirmLock = (userId) => {
			setOpenLock(true);
			setTitle(props.labels && props.labels.confirmLock);
			setParagraph(props.labels && props.labels.confirmLockParagraph)
			setSuccessMessage(props.labels && props.labels.confirmLockParagraph);
			//resetAccountPassword(userId)
		}
		/* istanbul ignore next */
		const confirmUnLock = (userId) => {
			setUnOpenLock(true);
			setTitle(props.labels && props.labels.confirmUnLock);
			setSuccessMessage(props.labels && props.labels.confirmUnLockParagraph);
			//resetAccountPassword(userId)
		}
		const confirmAuthenticate = (userId, userDetail) => {
			//@sai kiran calling userauth action redux
			authdetils(userDetail,dispatch)
			onClickAuthenticateBtn();
			const { formErrors } = componentState;
			const hasErrors = Object.keys(formErrors).some((fieldName) => !formErrors[fieldName].isValid); // If there are errors, display a message to the user and return early 
			if(hasErrors) { 
				return; 
			}
			// push("/admin/userManagement/authneticateuser", {updatedUserDetails: userDetail});
			push("/admin/userManagement/authneticateuser", {updatedUserDetails: userDetail})	
		}
		const confirmEnable = (userId, userDetail) => {
			setOpenEnable(true);
			setTitle(props.labels && props.labels.confirmEnable);
			setSuccessMessage(props.labels && props.labels.confirmEnableParagraph);
		}
		const confirmDisable = (userId, userDetail) => {
			setOpenDisable(true);
			setTitle(props.labels && props.labels.confirmDisable);
			setSuccessMessage(props.labels && props.labels.confirmDisableParagraph);
		}
		/* istanbul ignore next */
		const handleLock = (userId, userDetail) => {
			lockAccount(userId, userDetail);
		}
		/* istanbul ignore next */
		const lockAccount = (userId, userDetail) => {
			lockAccountService(userDetail).then(response => {
				if (response.statusCode === 200 && response.success) {
					setOpenLock(false)
					setAccoountLockStatus(true);
					fetchUserDetailsFromAPI(userDetail);
					// Button Enabled
				} else {
					//setInvalid(true);
					setErrorMessage(response.message)
				}
			});
		}
		/* istanbul ignore next */
		const handleResetPassword = (userId, userDetail) => {
			resetAccountPassword(userId, userDetail);
		}

		/* istanbul ignore next */
		const resetAccountPassword = (userId, userDetail) => {
			const userResetAccountDetail = userDetail.consumerAccountId;
			resetPassword(userDetail).then(response => {
				if (response.statusCode === 200 && response.success) {
					setOpen(false);
					let message = `Password : ${response.generatedPassword}`;
					setTitleReset(response.message);
					setSuccessResetMessage(message);
					setOpenReset(true);

					// try { window.appInsights.trackEvent('Admin - Reset Account Password', { 'pageName': "User Details" }, { 'consumerAccountId': userDetail.consumerAccountId }); }
					// catch { }

				} else {
					//setInvalid(true);
					setErrorMessage(response.message)
				}

			});
		}

		/* istanbul ignore next */
		const handleUnLock = (userId, userDetail) => {
			unlockAccount(userId, userDetail);
		}
		/* istanbul ignore next */
		const unlockAccount = (userId, userDetail) => {
			unlockUserAccount(userDetail).then(response => {
				if (response.statusCode === 200 && response.success) {
					setUnOpenLock(false)
					setAccoountLockStatus(false);
					fetchUserDetailsFromAPI(userDetail);

					// try { window.appInsights.trackEvent('Admin - Unlock User Account', { 'pageName': "User Details" }, { 'consumerAccountId': userDetail.consumerAccountId }); }
					// catch { }

				} else {
					//setInvalid(true);
					setErrorMessage(response.message)
				}

			});

		}


		/* istanbul ignore next */
		const handleauthenticateAccount = (userId, userDetail) => {
			authenticateAccount(userId, userDetail);
		}

		/* istanbul ignore next */
		const authenticateAccount = (userId, userDetail) => {
			authenticateAccountService(userDetail).then(response => {
				if (response.statusCode === 200 && response.success) {
					setOpenAuthenticate(false);
					setOpenAuthenticateAccount(true);
					setBtnDisabled(true)

					let userDetails = {
						"consumerUserID": userDetail.consumerAccountId,
						"emailAddress": userDetail.emailAddress,
						"firstName": userDetail.firstName,
						"lastName": userDetail.lastName,
						"dateOfBirth": userDetail.dateOfBirth,
						"socialSecurityNumber": userDetail.socialSecurityNumber
					};
					fetchUserDetailsFromAPI(userDetails);
					//setAccoountUnLockStatus(true)

					// try { window.appInsights.trackEvent('Admin - Authenticate User Account', { 'pageName': "User Details" }, { 'consumerAccountId': userDetail.consumerAccountId }); }
					// catch { }

				} else {
					//setInvalid(true);
					setErrorMessage(response.message)
				}
			});
		}	

		/* istanbul ignore next */
		const activateAccount = (userId, userDetail) => {

			activateAccountService(userDetail).then(response => {
				if (response.statusCode === 200 && response.success) {
					setOpenEnable(false);
					setAccountEnable(true);
					let userDetails = {
						"consumerUserID": userDetail.consumerAccountId,
						"emailAddress": userDetail.emailAddress,
						"firstName": userDetail.firstName,
						"lastName": userDetail.lastName
					};
					fetchUserDetailsFromAPI(userDetails);

					// try { window.appInsights.trackEvent('Admin - Enable User Account', { 'pageName': "User Details" }, { 'consumerAccountId': userDetail.consumerAccountId }); }
					// catch { }

				} else {
					//setInvalid(true);
					setErrorMessage(response.message)
				}
			});

		}

		/* istanbul ignore next */
		const deactivateAccount = (userId, userDetail) => {

			deactivateAccountService(userDetail).then(response => {
				if (response.statusCode === 200 && response.success) {
					setOpenDisable(false);
					setAccountEnable(false);
					let userDetails = {
						"consumerUserID": userDetail.consumerAccountId,
						"emailAddress": userDetail.emailAddress,
						"firstName": userDetail.firstName,
						"lastName": userDetail.lastName
					};
					fetchUserDetailsFromAPI(userDetails);

					// try { window.appInsights.trackEvent('Admin - Disable User Account', { 'pageName': "User Details" }, { 'consumerAccountId': userDetail.consumerAccountId }); }
					// catch { }

				} else {
					//setInvalid(true);
					setErrorMessage(response.message)
				}
			});

		}

		const getQuestions = (question) => {
			switch (question) {
				case "Q01": return "Who is your favorite actor?"
				case "Q02": return "What is the name of your high school?"
				case "Q03": return "What is your favorite movie?"
				case "Q04": return "What street did you grow up on?"
				case "Q05": return "What is your favorite social media website?"
				case "Q06": return "What is your mother's maiden name?"
				case "Q07": return "What was your favorite place to visit as a child?"
				case "Q08": return "In what city were you born?"
				case "Q09": return "What is the name of your favorite pet?"
				case "q1": return "Who is your favorite actor?"
				case "q2": return "What is the name of your high school?"
				case "q3": return "What is your favorite movie?"
				case "q4": return "What street did you grow up on?"
				case "q5": return "What is your favorite social media website?"
				case "q6": return "What is your mother's maiden name?"
				case "q7": return "What was your favorite place to visit as a child?"
				case "q8": return "In what city were you born?"
				case "q9": return "What is the name of your favorite pet?"

				default: return question

			}
		}

		/* istanbul ignore next */
		const convertToDateTime = (timeStamp) => {
			/* let dateTime = new Date(timeStamp);
			const day = dateTime.toLocaleString([], { hour12: false });
			return day; */
			const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

			let month = new Date(timeStamp).getMonth();
			let day = new Date(timeStamp).getDate();
			let year = new Date(timeStamp).getFullYear();
			let hours = new Date(timeStamp).getHours();
			let minutes = new Date(timeStamp).getMinutes();
			let seconds = new Date(timeStamp).getSeconds();

			let dateTime = new Date(Date.UTC(year, month, day, hours, minutes, seconds));

			let date = dateTime.toLocaleDateString();
			//let time = dateTime.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', });
			let time = dateTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
			return date + ' ' + time;
		}

		const accountStatusData = (userId) => {
			return {
				"consumerUserID": userId,
			}
		}
		/* useEffect(() => {
			
			if (fetchUserDetail !== undefined) {
				fetchUserDetailsFromAPI(fetchUserDetail);
			} else {
				setInvalid(true);
				setErrorMessage("Please Select User");
			}
		}, [fetchUserDetail !== undefined]) */

		useEffect(() => {
			if (singleUserDetailState && Object.keys(singleUserDetailState).length > 0) {
				fetchUserDetailsFromAPI(singleUserDetailState.data);					
			}
		}, [singleUserDetailState])
		// useEffect(() => {
		// 	if (singleUserDetailState && Object.keys(singleUserDetailState).length) {
		// 		viewUserService(singleUserDetailState.data).then(response => {
		// 			if (response !== undefined && response.statusCode === 200 && response.success) {
		// 				const userDetailResponse = response.body.userDetails;
		// 				handleUserDetails(userDetailResponse)	
		// 			} else {
		// 				setInvalid(true);
		// 				setErrorMessage(response.message)
		// 			}
		// 		})				
		// 	}
		// }, [])

		useEffect(() => {		
			scrollToTop();
		}, [])

		useEffect(() => {

			if (Storage.getItem("UserManagement") === "U") {
				setBtnRoleDisabled(false);
				setHideButtons(false);
				setHideAuthButton(false);
			}
			if (Storage.getItem("UserManagement") === "R" && Storage.getItem("Authenticate") === "R") {
				// Disable the button of Deativate Account
				setBtnRoleDisabled(true)
				setBtnDisabled(true);
				setHideButtons(true);
				setHideAuthButton(true);
			}
			if (Storage.getItem("Authenticate") === "U" && Storage.getItem("UserManagement") === "U") {
				setBtnDisabled(false);
				setHideButtons(false);
				setHideAuthButton(false);
			}
			if (Storage.getItem("Authenticate") === "U" && Storage.getItem("UserManagement") === "R") {
				setBtnDisabled(false)
				setHideButtons(true);
				setHideAuthButton(false);
			}
		}, [])
		
		function getStdDate(mydate) {
			const dateObj = new Date(mydate);
			const formattedDate = dateObj.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });
			return formattedDate
		}

		const getFormFields = (field, index, userDetails) => {
			const { formErrors, isFormSubmited, formDataSet, formDate } = componentState;
			switch(field.fieldType.toUpperCase()){
			case types.INPUT:
				if(field.type === 'date'){
					return (
						<Form.Group
							key={index}
							as={Col}
							className={`input-root col-md-${field.style && field.style.colWidth ? field.style.colWidth : ''} col-12 primary-fields ${field.style && field.style.class ?  field.style.class : ''}`}
						>
							<FormDatePicker
								field={field}
								fieldError={
									formErrors && !formErrors[field.name].isValid && (
										formErrors[field.name].isTouched
										|| isFormSubmited
									)
								}
								disable={false}
								readOnly = {false}
								errorMessage={formErrors && formErrors[field.name].activeValidator.message}
								isClearable = {true}
								endDateMaxValue = {endDateMaxValue ? endDateMaxValue : ''}
								formData={formDataSet && formDataSet[field.name] ? formDataSet[field.name] : field.defaultValue ? field.defaultValue : ''}
								handleDateChange={(e) => {
									handleDateChange( e, 0, field)
									setUserDetail({ ...userDetail, [field.name] : getStdDate(e) })
								}}
								handleBlur={handleBlur}	
							/>
						</Form.Group>
					);
				}else{
					return (
						(<Form.Group
																																																																																																																																																																																																									key={index}
																																																																																																																																																																																																									as={Col}
																																																																																																																																																																																																									className={`input-root col-md-${field.style && field.style.colWidth ? field.style.colWidth : ''} col-12 primary-fields ${field.style && field.style.class ?  field.style.class : ''}`}
																																																																																																																																																																																																								>
							<FormInput
								field={field}
								fieldError={
									formErrors
									&& !formErrors[field.name].isValid
									&& (formErrors[field.name].isTouched || isFormSubmited)
								}
								errorMessage={formErrors && formErrors[field.name].activeValidator.message}
								formData={ formDataSet && formDataSet[field.name] ? 
									formDataSet[field.name] 
									: 
									(field.defaultValue ? 
									field.defaultValue :
									(userDetails[field.name] && userDetails[field.name].length === 4 && (/^\d+$/.test(userDetails[field.name]))? 
										"XXX-XX-" + userDetails[field.name] : userDetails[field.name])
									)
								}
								handleChange={(e) => {
									handleChange(e, 0, field)
									setUserDetail({ ...userDetail, [field.name] : e.target.value })
								}}
								handleBlur={handleBlur}	
							/>
						</Form.Group>)
					);
				}
			default:
				return null;
			}
		};
		

		const renderUserDataJson = (userDetail) => {
			/* const { userId, consumerAccountId, accountStatus, emailAddress, firstName, lastName, phoneNumber, zipCode, securityQuestions } = userDetail; */
			let securityQuestions = userDetail.securityQuestions;
			const fieldJSONData = props.fields
			const dobfld = fieldJSONData && fieldJSONData.filter(obj => obj.name === "dateOfBirth")[0]
			const ssnfld = fieldJSONData && fieldJSONData.filter(obj => obj.name === "socialSecurityNumber")[0]
			/* const {labels} =  props.labels; */

			return (<>
				<div className="my-account-wrap card user_Details_Result_page">
					<div>
						<div className="card-header">
							<div className="mb-0 d-flex justify-content-md-between flex-column flex-md-row card-title h5">
								<div className="d-flex flex-column userInfo">
									<div className="userName header-row">{userDetail.firstName} {userDetail.lastName}</div>
								</div>
							</div>
							<div className="d-flex flex-column text-md-right">
								{(userDetail.accountStatusChangeTimeStamp !== undefined) ?
									<div className="custom-last-update">
										{props.labels && props.labels.lastUpdatedDate}: <span className="lastUpdate">
											{
												(userDetail.accountStatusChangeTimeStamp !== undefined) ?
													convertToDateTime(userDetail.accountStatusChangeTimeStamp) : ''
											}
										</span>
									</div>
									: ''
								}
								{btnHideButtons ? null :
									<div className="custom-unlock">
										{userDetail.accountActiveInd === "Y" &&
											<button className={btnRoleDisabled ? "btn-account btnDisable" : "btn-account"} disabled={btnRoleDisabled ? btnRoleDisabled : ""} onClick={() => confirmReset(userDetail.userId, userDetail)} >{props.buttons && props.buttons.resetPasswordButton}</button>
										}


										{userDetail.accountActiveInd === "Y" ?
											userDetail.accountLockedInd === "N" ? <button className={btnRoleDisabled ? "btn-account btnDisable" : "btn-account"} onClick={() => confirmLock(userDetail.userId, userDetail)} >{props.buttons && props.buttons.lockAccountButton}</button> : <button className="btn-account" onClick={() => confirmUnLock(userDetail.userId, userDetail)} >{props.buttons && props.buttons.unlockAccountButton}</button>
											: null
										}

										{userDetail.accountActiveInd === "N" && accountEnable === false ? <button className={btnRoleDisabled ? "btn-account btnDisable" : "btn-account"} disabled={btnRoleDisabled ? btnRoleDisabled : ""} onClick={() => confirmEnable(userDetail.userId, userDetail)} >{props.buttons && props.buttons.enableAccountButton}</button> : <button className={btnRoleDisabled ? "btn-account btnDisable" : "btn-account"} disabled={btnRoleDisabled ? btnRoleDisabled : ""} onClick={() => confirmDisable(userDetail.userId, userDetail)} >{props.buttons && props.buttons.disableAccountButton}</button>}
										{/* 
											{userDetail.accountActiveInd === "Y" &&
												<button className={btnRoleDisabled ? "btn-account btnDisable" : "btn-account"} disabled={ btnRoleDisabled? btnRoleDisabled: ""} onClick={() => confirmEnableProgram(userDetail.userId, userDetail)} >{props.buttons && props.buttons.enableProgramButton}</button>
											} */}

									</div>
								}
								<div className="custom-unlock TelephoneAssist">
									{userDetail.accountType === "BASIC" ?
										<>
											{userDetail.accountActiveInd === "Y" &&
												<>
													<span className="lastUpdate">{props.labels && props.labels.telephoneAssistorLabel}</span>
													
													<Switch
														className={`userId ${userDetail.assistorInd === "Y" ? 'ms-toggle-checked' : 'ms-toggle-unchecked'}`}
														checked={userDetail.assistorInd === "Y"}
														onClick={confirmTelephoneAssistor}
														inputProps={{ 'aria-label': 'Telephone Assistor' }}
													/>
												</>
											}
										</>
										: " "}
								</div>
							</div>
							<div className="mb-0 d-flex justify-content-md-between flex-column flex-md-row card-title h5">
								<div className="d-flex flex-column userInfo">
									{/* <div className="userName header-row">{userDetail.firstName} {userDetail.lastName}</div> */}
									<div className="header-row">
										<p><span className="useridspan">{props.labels && props.labels.accoutStatus}</span>: <span className="userId">{openAuthenticateAccount ? "ADVANCE" : userDetail.accountType === "UPGRADED" ? "ADVANCED" : userDetail.accountType}</span></p>
										<p>
											<span className="useridspan">{props.labels && props.labels.emailVerified}</span>: <span className="userId">{userDetail.emailVerifiedInd === 'Y' ? "YES" : "NO"}</span></p>
										{userDetail.accountType === "BASIC" ?
											<>
												<p>
													<span className="useridspan">{props.labels && props.labels.arLabel}</span>: <span className="userId">{userDetail.arInd === "Y" ? "Yes" : "No"}</span>
												</p>
											</>
											: " "}
										{userDetail.accountType !== "BASIC" ?
											<>
												<p><span className="useridspan">{props.labels && props.labels.authTypeLabel}</span>: <span className="userId">{userDetail.authenticationType}</span></p>
												<p>
													<span className="useridspan">{props.labels && props.labels.sourceTypeLabel}</span>: <span className="userId">{userDetail.authenticationSource}</span></p>
												<p>
													<span className="useridspan">{props.labels && props.labels.arLabel}</span>: <span className="userId">{userDetail.arInd === "Y" ? "Yes" : "No"}</span></p>
											</>
											: " "}
									</div>
								</div>
							</div>
						</div>
						<div className="card-body">
							<div className="subsection-header row">
								<div className="col-md-12">
									<div className="page-section-head d-flex justify-content-between">
										<span className="head-label">{props.labels && props.labels.portalUserDetails}</span>
									</div>
								</div>
							</div>
							<div className="row">
								<div className={userDetail.accountType === "BASIC" ? "custom-field col-md-9" : "custom-field col-md-12"}>
									<ul className="section-list col-12 mb-0">
										<li className="row no-gutters">
											<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.nameLabels}</div>
											<div className="fieldValue col-md-6">{userDetail.firstName + " " + userDetail.lastName}</div>
										</li>
										<li className="row no-gutters">
											<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.emailAddressLabel} </div>
											<div className="fieldValue col-md-6">{userDetail.emailAddress}</div>
										</li>
										{userDetail.accountActiveInd === "Y" ?
											userDetail.accountType === "BASIC" && 
											btnHideAuthButton !== true ? 
											// BASIC account - Put a Textbox to Edit the SSN with validations
											<li className="row no-gutters ms-admin-align">
												<div className="fieldLabel pr-3 col-md-6 ms-ssn-align">
													{props.labels && props.labels.ssnLabel}
													{dobfld?.isRequired ? <span className={'MuiFormLabel-asterisk'}>&nbsp;*</span> : ''}
												</div>
												{getFormFields(ssnfld, ssnfld?.id, userDetail)}
											</li> : 
											// ADVANCED account - Just display the SSN
											// Fix for INC-3253
											// START
											<>
												<li className="row no-gutters">
													<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.ssnLabel}</div>
													<div className="fieldValue col-md-6">
													{maskSSN ?
														userDetail && userDetail.socialSecurityNumber ? 
														("XXX-XX-" + (userDetail.socialSecurityNumber.length === 4 ? userDetail.socialSecurityNumber : 
														formatSSN(userDetail.socialSecurityNumber).substring(7))): ""
													: 
													formatSSN(userDetail.socialSecurityNumber)
													}
													&nbsp;&nbsp;&nbsp;

													<button className={"btn-account"} onClick={() => confirmMaskUnMask()} >
													
													{maskSSN ? props.buttons && props.buttons.unmaskButton : 
																props.buttons && props.buttons.maskButton
													}
													</button>
													</div>
												</li>												
											</>
											// END
											/// Fix for INC-3253
											
											
										: 
										""}

										{userDetail.accountActiveInd === "Y" ?
											userDetail.accountType === "BASIC" && 
											btnHideAuthButton !== true ? 

											// BASIC account - Put a Textbox with Date to Edit the DOB  with validations
											<li className="row no-gutters ms-admin-align users_dob">
												<div className="fieldLabel pr-3 col-md-6 ms-dob-align">
													{props.labels && props.labels.dateOfBirthLabel}
													{ssnfld.isRequired ? <span className={'MuiFormLabel-asterisk'}>&nbsp;*</span> : ''}
												</div>
												{getFormFields(dobfld, dobfld.id)} 
											</li> : 
											
											// ADVANCED account - Just display the DOB											
											// Fix for INC-3253
											// START
											<li className="row no-gutters">
												<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.dateOfBirthLabel}</div>
												<div className="fieldValue col-md-6">
													{userDetail && userDetail.dateOfBirth}
												</div>
											</li>
											// END
											// Fix for INC-3253											
										: 
										""}
										
										{userDetail.accountType !== "BASIC" ?
											<li className="row no-gutters">
												<div className="fieldLabel pr-3 col-md-6">{props.labels && props.labels.addressLabel} </div>
												<div className="fieldValue col-md-6">
													{userDetail && userDetail.address && userDetail.address.addressLine1 ? userDetail.address.addressLine1.replace(",", "").replace(/^\s+|\s+$/gm, "") + ", " : ""}
													{userDetail && userDetail.address && userDetail.address.addressLine2 ? userDetail.address.addressLine2.replace(",", "").replace(/^\s+|\s+$/gm, "") + ", " : ""}
													{userDetail && userDetail.address && userDetail.address.city ? userDetail.address.city.replace(",", "").replace(/^\s+|\s+$/gm, "") + ", " : ""}
													{userDetail && userDetail.address && userDetail.address.state ? userDetail.address.state.replace(",", "").replace(/^\s+|\s+$/gm, "") + " " : ""}
													{userDetail && userDetail.address && userDetail.address.zipCode ? userDetail.address.zipCode.replace(",", "").replace(/^\s+|\s+$/gm, "") : ""}
													{userDetail && userDetail.address && userDetail.address.county ? ", " + userDetail.address.county.replace(",", "").replace(/^\s+|\s+$/gm, "") : ""}
												</div>
											</li> : ""}

									</ul>
								</div>

								{userDetail.accountActiveInd === "Y" ?
									userDetail.accountType === "BASIC" && btnHideAuthButton !== true ?
										<div className="custom-authetic-section col-md-3">
											{(userDetail.accountType === "BASIC" && userDetail.emailVerifiedInd === "N") ?
												(
												<CustomTooltip
													title={(userDetail.accountType === "BASIC" && userDetail.emailVerifiedInd === "N") ? props.toolTipMessages.authBtnDisabledMsg : ""}
												>
													<button
													className={(userDetail.accountType === "BASIC" && userDetail.emailVerifiedInd === "N") ? "btn-account btnDisable" : "btn-account"}
													disabled={btnDisabled || (userDetail.accountType === "BASIC" && userDetail.emailVerifiedInd === "N")}
													onClick={() => confirmAuthenticate(userDetail.userId, userDetail)}>
														{props.buttons && props.buttons.AutheticateButton}
													</button>
											</CustomTooltip>
											)
											:
												(
												<button
													className={btnDisabled ? 'btn-account btnDisable' : 'btn-account'}
													disabled={btnDisabled}
													onClick={() => confirmAuthenticate(userDetail.userId, userDetail)}>
												{props.buttons && props.buttons.AutheticateButton}
											</button>
											)
											}	
											
										</div> : ""
									: ""}
							</div>
							<div className="subsection-header row">
								<div className="col-md-12">
									<div className="page-section-head d-flex justify-content-between">
										<span className="head-label">{props.labels && props.labels.securityQuestionsLabel}</span>
									</div>

									{
										securityQuestions.map((securityQuestion, index) => (
											<div className="row" key={index}>
												<ul className="section-list col-12 mb-0">
													<li className="row no-gutters">
														<div className="fieldLabel pr-3 col-md-6">{getQuestions(securityQuestion.question)}</div>
														<div className="fieldValue col-md-6">{securityQuestion.answer.replace(/./g, 'X')}</div>
													</li>
												</ul>
											</div>
										))
									}
								</div>
							</div>

							{userDetail.accountActiveInd === "Y" && 
									userDetail.accountType === "UPGRADED" && 
									(userDetail.authenticationType === "ThirdPartyAuthenticated" || 
									userDetail.authenticationType === "SoftAuthenticated") ? 
							
								<div className="subsection-header row selectproramUserDetails">
									<div className="col-md-12">
										<div className="page-section-head d-flex justify-content-between">
											<span className="head-label">Select Program(s) to Enable</span>

											<div>	
												<FormGroup row>
													<FormControlLabel control={<Checkbox color="default" onChange={(e) => selectProgram(e, "SNAP")} />} label="SNAP" />
													<FormControlLabel control={<Checkbox color="default" onChange={(e) => selectProgram(e, "TANF")}/>} label="TANF" />
													<FormControlLabel control={<Checkbox color="default" onChange={(e) => selectProgram(e, "LIHEAP")}/>} label="Community Services" />
												</FormGroup>
											</div>
											
											<div className="d-flex flex-column text-md-right">
												<div className="custom-unlock">												
													
													{SNAPProgram || TANFProgram || LIHEAPProgram ?
															<Button	
																	style={{ backgroundColor: "#244459", borderRadius: "3px", fontSize: "16px", padding: "3px 18px", color: "#FFFFFF", border: "none" }}
																	variant="contained" onClick={() => confirmEnableProgram(userDetail.userId, userDetail)}
															>
																{props.buttons && props.buttons.enableProgramButton}
															</Button>
													: 
															<Button	variant="contained" disabled 
																style={{ backgroundColor: "lightgrey", borderRadius: "3px", fontSize: "16px", padding: "3px 18px", color: "#FFFFFF", border: "none" }}
																	
															>
																{props.buttons && props.buttons.enableProgramButton}
															</Button>
													}
													
												</div>	
											</div>
										</div>
										
									</div>
								</div>
							: ""}
						</div>
					</div>
				</div>
				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={open}
					onHide={handleClose}
					onModalButtonClick={() => handleResetPassword(userDetail.userId, userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.resetButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.resetButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					secondaryButton={props && props.buttons && props.buttons.noButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.noButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					onSecondaryButtonClick={handleClose}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={true} />
				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={openLock}
					onHide={handleClose}
					onModalButtonClick={() => handleLock(userDetail.userId, userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.yesButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.yesButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					secondaryButton={props && props.buttons && props.buttons.noButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.noButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					onSecondaryButtonClick={handleClose}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={true} />
				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={openAuthenticate}
					onHide={handleClose}
					onModalButtonClick={() => handleauthenticateAccount(userDetail.userId, userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.yesButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.yesButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					secondaryButton={props && props.buttons && props.buttons.noButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.noButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					onSecondaryButtonClick={handleClose}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={false} />
				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={openUnLock}
					onHide={handleClose}
					onModalButtonClick={() => handleUnLock(userDetail.userId, userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.yesButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.yesButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					secondaryButton={props && props.buttons && props.buttons.noButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.noButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					onSecondaryButtonClick={handleClose}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={true} />
				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={titleReset}
					paragraph={successResetMessage}
					show={openReset}
					onHide={() => handleResetClose(userDetail)}
					onModalButtonClick={() => handleResetClose(userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props.buttons && props.buttons.okButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.okButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					customSecondaryButton={false} />
				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={openEnable}
					onHide={handleClose}
					onModalButtonClick={() => activateAccount(userDetail.userId, userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.yesButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.yesButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					secondaryButton={props && props.buttons && props.buttons.noButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.noButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					onSecondaryButtonClick={handleClose}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={true} />
				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={openDisable}
					onHide={handleClose}
					onModalButtonClick={() => deactivateAccount(userDetail.userId, userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.yesButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.yesButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					secondaryButton={props && props.buttons && props.buttons.noButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.noButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					onSecondaryButtonClick={handleClose}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={true} />
				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={telephoneAssistor}
					onHide={() => handleTelephoneAssistorCancel(userDetail.userId, userDetail)}
					onModalButtonClick={() => handleTelephoneAssistor(userDetail.userId, userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.yesButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.yesButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					secondaryButton={props && props.buttons && props.buttons.noButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.noButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					onSecondaryButtonClick={() => handleTelephoneAssistorCancel(userDetail.userId, userDetail)}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={true} />
				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={openEnableProgram}
					onHide={handleClose}
					onModalButtonClick={() => handleEnableProgram(userDetail.userId, userDetail)}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.yesButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.yesButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					secondaryButton={props && props.buttons && props.buttons.noButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.noButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}
					onSecondaryButtonClick={handleClose}
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={true} />
				<CustomModal
					size="md"
					modalClass="ms-modal"
					title={title}
					show={openEnableProgramSuccess}
					onHide={handleClose}
					onModalButtonClick={() => handleClose()}
					alignButtonsVertically={false}
					primaryButtonWidth={false}
					primaryButton={props && props.buttons && props.buttons.okButton ? {
						id: '',
						href: 'javascript:void(0)',
						text: props && props.buttons && props.buttons.okButton,
						target: ''
					} : {
							href: 'javascript:void(0)',
							text: ' ',
						}}					
					iconInBody={true}
					closeLink={{
						image_url: '/src/resources/images/modal_close.png',
						altText: 'close',
						title: ''
					}}
					paragraph={successMessage}
					customSecondaryButton={false} />
			</>);
		}

		const handleNavigationToUserMgmt = (path) => {
			push(path)
		}

		return (
			<>
				
				<div className="theme-background-light-grey py-3 py-md-5">
					<div id="16361" className="pb-3 container">
						<div className="mb-3 justify-content-center row">
							<div className="col-md-10">
								<div className="customBreadcrumb">
									<Breadcrumb>
										<Breadcrumb.Item onClick={() => {handleNavigationToUserMgmt('/admin/userManagement')}}> {/* href={props.breadcrumbUrl} */}
											{props.breadcrumb}
										</Breadcrumb.Item>
									</Breadcrumb>
								</div>

								{!invalid && userDetail && userDetail && Object.keys(userDetail).length > 0 && renderUserDataJson(userDetail)}
								{invalid && errorMessage && <ErrorMessage errorMessage={errorMessage} />}

							</div>
						</div>
					</div>
				</div>
			</>
		);
	
	
}
const mapDispatchToProps = dispatch =>
    bindActionCreators(
        {
            userReducer
        },
        dispatch
    );

	const withRouter = (Component) => {
		const ComponentWithRouter = (props) => {
			const { push } = useRouter();
			return <Component {...props} push={push} />;
		};
	
		// Adding display name for better debugging
		ComponentWithRouter.displayName = `withRouter(${Component.displayName || Component.name || 'Component'})`;
	
		return ComponentWithRouter;
	}
export default withRouter(User);