import React, { useRef } from "react";
import ReactSelect, { components } from "react-select";
/* istanbul ignore next */
const Option = props => {
  const optionProps = {
    ...props,
    innerProps: {
      ...props.innerProps,
      "data-member": props.data.value === "<SELECT_ALL>" ? 0 : props.data.value
    }
  };
  return (
    <div>
      <components.Option {...optionProps}>
        <input
          type="checkbox"
          className="kunall"
          checked={props.isSelected}
          onChange={() => null}
          data-member={props.data.value === "<SELECT_ALL>" ? 0 : props.data.value}
        />{" "}
        <span data-member={props.data.value === "<SELECT_ALL>" ? 0 : props.data.value}>
          {props.label}
        </span>
      </components.Option>
    </div>
  );
};

export const MultiSelectCheckboxGroup = (props) => {

  // isOptionSelected sees previous props.value after onChange

  const valueRef = useRef(props.value);
  valueRef.current = props.value;

  const selectAllOption = {
    value: "<SELECT_ALL>",
    label: props.selectAll()
  };

  const isSelectAllSelected = () =>
  valueRef.current && valueRef.current.length === props.options.length;

  const isOptionSelected = (option) =>
  valueRef.current && valueRef.current.some(({ value }) => value === option.value) ||
    isSelectAllSelected();


  let getOptions;

  if(props.showSelectAll){
    getOptions = () => [selectAllOption, ...props.options];
  }else{
    getOptions = () => [...props.options];
  }
  const getValue = () => props.value;
  /* istanbul ignore next */
  const onChange = (newValue, actionMeta) => {
    const { action, option, removedValue } = actionMeta;
    if (action === "select-option" && option.value === selectAllOption.value) {
      props.onChange(props.options, actionMeta);
    } else if (
      (action === "deselect-option" &&
        option.value === selectAllOption.value) ||
      (action === "remove-value" &&
        removedValue.value === selectAllOption.value)
    ) {
      props.onChange([], actionMeta);
    } else if (
      actionMeta.action === "deselect-option" &&
      isSelectAllSelected()
    ) {
      props.onChange(
        props.options.filter(({ value }) => value !== option.value),
        actionMeta
      );
    } else {
      props.onChange(newValue || [], actionMeta);
    }

  };

  function CustomMultiValue(props) {
    const { getValue, data } = props;
  
    const selectedOptions = getValue();
    const currentOptionIdx = selectedOptions.findIndex(
      (option) => option.value === data.value
    );
  
    return (
      <span>
        {data.label}
        {currentOptionIdx === selectedOptions.length - 1 ? "" : " , "}
      </span>
    );
  }


  return (

    <ReactSelect
      {...props}
      isOptionSelected={isOptionSelected}
      options={getOptions()}
      value={getValue()}
      onChange={onChange}
      //defaultMenuIsOpen={true}
      components={{
        Option,
        MultiValue: CustomMultiValue
      }}
      openMenuOnClick='true'
      hideSelectedOptions={false}
      closeMenuOnSelect={false}
      blurInputOnSelect={false}
      isMulti
    />

  );

};