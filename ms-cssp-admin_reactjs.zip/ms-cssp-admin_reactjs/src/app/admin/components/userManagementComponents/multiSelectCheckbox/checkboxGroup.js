import React from "react";
import { FormLabel, FormGroup } from "react-bootstrap";
import getValidationState from "../../../controls/getValidationState";
//import { MultiSelect } from "react-multi-select-component";
import { MultiSelectCheckboxGroup } from "./multiSelectCheckboxGroup";
import "../../../componentStyle.css";
import Storage from "../../../../utils/storage";

export default class CheckBoxGroup extends React.Component {
    constructor(props) {
        super(props)
        this.errors = "";
        let dataList = this.props.members;
      
        if(this.props.fields && this.props.fields[0].subFields){
            this.props.fields[0].subFields.forEach(sf => {
                if(sf.options && sf.component === "checkBoxGroup" && sf.options.length > 0){
                    dataList = sf.options ? sf.options : this.props.members;
                }
            });
        }else if(this.props.fields && this.props.fields[0].options && this.props.fields[0].options.length > 0){
            dataList = this.props.fields[0].options
        }
        
        this.state = {
            datalist: dataList,
            minorDatalist: this.props.minorMembers ? this.props.minorMembers : [],
            selected: this.props.ivalue? this.props.ivalue : [],
            error: ""
        };

    }

    static getDerivedStateFromProps(props, state) {
        let options = [];
        if (props.ivalue && props.ivalue.length > 0) {
            props.ivalue.forEach(ele => {
                /* The below commented loop is added to remove the member name 
                from the selected value textbox, if the Member is removed in meMyHousehold */
                //props.members.forEach(memEle => {
                    //if(ele.personFullName === memEle.label){
                        let obj = {
                            label: ele.personFullName,
                            value: ele.personNameIndex,
                            personNameIndex: ele.personNameIndex
                        }
                        options.push(obj);
                    //}
                //})
            })
            return {
                selected: options,
                isDisabled: (props.members.length===1 && !(props.section && props.section.ShouldNotBeRendered)) ? true : false
            };
        } 
        else if(props.members.length===1){
            if(props.section && !props.section.ShouldNotBeRendered){
                props.onSelectCheckbox(props.members,"","",true);
            }
            return {
                selected: props.members,
                isDisabled:true
            }
        }
        else {
            return {
                selected: [],
                isDisabled: false
            };
        }
        return null;
    }

    handleOnChange = (e) => {
        this.setState({selected: e})
        this.props.onSelectCheckbox(e);
    }
    customValueRenderer = (selected, _options) => {
        return selected.length
          ? selected.map(s => s.label).join(", ")
          : null;
    }

    getLangSelectAll = () => {
        let langCode = Storage.getItem('defaultLangCode')
        switch (langCode) {
            case "en": return "Select all"
            case "es": return "Seleccionar todo"
            case "pt": return "Selecionar tudo"
            case "vi": return "Chọn tất cả"
            case "uk": return "Вибрати все"
            case "ru": return "Выбрать все"
            case "zh": return "全選"

            default: return "Select all"
            					
         }
    }
    
    handleOnBlur = (e, id) => {
        this.props.input.onBlur(this.state.selected, id);
    }

    render() {
        const { meta, label, placeholder, onClick, id, currentStepIndex, required, onSelectCheckbox, errorMessage } = this.props;
        //debugger;
        return (
            <FormGroup validationState={getValidationState(meta)}>
                <FormLabel  className={this.props.style && this.props.style.snapClass && this.props.style.snapClass.includes("invisible") ? this.props.style+" "+this.props.style.snapClass : errorMessage ? "checkboxGroupErrorLabel" : null} for="Select">  {label}{required && label != '' ? (<span style={{ color: "#c92500" }}>&nbsp;*</span>) : ""}</FormLabel>
                    {/* <MultiSelect
                    className={errorMessage ? "checkboxGroupError" : null}
                    options={this.state.datalist}
                    value={this.state.selected}
                    showCheckbox={false}
                    onChange={e=>this.handleOnChange(e)}
                    disableSearch={true}
                    valueRenderer={this.customValueRenderer}
                    disabled = {this.state.isDisabled}
                    closeOnSelect={true}
                    overrideStrings={
                        required && label == '' ? 
                        {"selectSomeItems": <span>{placeholder}<span style={{ color: "#c92500" }}>&nbsp;*</span></span>, selectAll: this.getLangSelectAll(),} : 
                        {"selectSomeItems": <span>{placeholder}</span>, selectAll: this.getLangSelectAll()}

                    }
                /> */}
                <MultiSelectCheckboxGroup
                    key={id}
                    className={errorMessage ? "checkboxGroupError" : null}
                    options={this.state.datalist}
                    value={this.state.selected}
                    closeMenuOnSelect={true}
                    onChange={e => this.handleOnChange(e)}
                    onBlur={e => this.handleOnBlur(e, id)}
                    selectAll={this.getLangSelectAll}
                    classNamePrefix={'new-checkbox-group'}
                    isDisabled = {this.state.isDisabled}
                    isSearchable={false}
                    showSelectAll={true}
                    openOnClick={true}
                    placeholder={required && label == '' ?
                        <span>{placeholder}<span style={{ color: "#c92500" }}>&nbsp;*</span></span> :
                        <span>{placeholder}</span>}
                />
                {this.state.error || errorMessage ?
                <div className="errormessageCheckboxclass">
                    <span style={{ color: "#c92500", fontSize: "0.75rem" }}>
                        {this.state.error === "" ? errorMessage : this.state.error}
                    </span>
                    <span style={{float: "right",marginRight: "35px"}}>
                        <img src="/src/resources/images/error_icon.png" alt={''} />
                    </span>
                </div>
                : null }
            </FormGroup>
        )
    }
}


