import React, {Component} from 'react';
import PropTypes from 'prop-types';
import './userdetails.css';
import UserData from './userData';

class  UserManagementTable extends Component{
    constructor(props){
        super(props);

    }    

    render()
    { 
    const {json, searchResult} = this.props;
    const searchData = searchResult && searchResult.body && searchResult.body.users;
    return(
        <div className="custom-user-table">
                    <table className="table shadow">
                            <thead className="custom-table-label">
                            <tr>
                                <th>{json && json.content && json.content.dataTable && json.content.dataTable.columns && json.content.dataTable.columns.date}</th>
                                <th>{json && json.content && json.content.dataTable && json.content.dataTable.columns && json.content.dataTable.columns.name}</th>
                                <th>{json && json.content && json.content.dataTable && json.content.dataTable.columns && json.content.dataTable.columns.email}</th>
                                <th>{json && json.content && json.content.dataTable && json.content.dataTable.columns && json.content.dataTable.columns.ssn}</th>
                                <th>{json && json.content && json.content.dataTable && json.content.dataTable.columns && json.content.dataTable.columns.isAr}?</th>
                                <th>{json && json.content && json.content.dataTable && json.content.dataTable.columns && json.content.dataTable.columns.program}</th>
                                <th>{json && json.content && json.content.dataTable && json.content.dataTable.columns && json.content.dataTable.columns.accountStatus}</th>
                                <th >{json && json.content && json.content.dataTable && json.content.dataTable.columns && json.content.dataTable.columns.action}</th>
                            </tr>
                            </thead>
                            <tbody className="custom-table-datarow">                               
                            {searchData && searchData.map(user => {
                                return(
                                    <UserData viewUserJson = {json && json.content && json.content.dataTable && json.content.dataTable.columns} user={user} key={user.userId}/>
                                );
                            })}

                            </tbody>
                        </table>
        </div>
    );
}}

export default UserManagementTable;