
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Infinite Computer Solutions, Aug 2021.
 * Author: Sunny Bhattacharjee
 */

 
export const convertDate = dateToconvert => {
	const dateChange = new Date(dateToconvert);
	if (!isNaN(dateChange.getTime())) {
		return new Date(dateChange).toLocaleString("default", {
			month: "2-digit",
			day: "2-digit",
			year: "numeric"
		});
	}
};
export const convertDateToYMD = (date, format) =>{
	let myFutureDate=new Date(date);
	let dd = myFutureDate.getDate();
	let mm = myFutureDate.getMonth()+1; 
	let yyyy = myFutureDate.getFullYear();
	if(dd<10) 
	{
		dd='0'+dd;
	} 

	if(mm<10) 
	{
		mm='0'+mm;
	} 

	switch(format){
		case "mm/dd/yyyy":
		return mm+'/'+dd+'/'+yyyy;
		case "yyyy-mm-dd":
		return yyyy+'-'+mm+'-'+dd;
	}

}

const isDate = dateItem => {
	return dateItem && new Date(dateItem) !== "Invalid Date" && !isNaN(new Date(dateItem));
};

const formatDecimal = (value, hasDollarSymbol) => {
	if(value){
		let currVal = parseFloat(value);
		if(isNaN(currVal)){
			return value;
		}
		else {
			return hasDollarSymbol ? '$' + parseFloat(value).toFixed(2) : parseFloat(value).toFixed(2);
		}
	}
	else return value;
}

const maskCard = value => {
	if(value){
		let currValue = '';
		let currLength = value.length;
		for(let i=0;i<currLength;i++){
			if(i<(currLength-4)){
				if(value[i]=== '-'){
					currValue = currValue + value[i];
				} else {
					currValue = currValue + 'X'
				}
			}
			else {
				currValue = currValue + value[i];
			}
		}
		return currValue;
	}
	else return value
};

export const updateFormat = (dataFormatDate,fields) => {
	let headers = fields && fields.content &&  fields.content.table && fields.content.table.headers;
	return (
		dataFormatDate &&
		dataFormatDate.map(item => {
			for (let key in item) {
				let fKey = headers && headers.filter(h=>h.field===key);
				if(fKey && fKey.length>0 && fKey[0].type ==="date"){
					if (isDate(item[key])) item[key] = convertDate(item[key]);
				}
				else if(fKey && fKey.length>0 && fKey[0].type ==="mask"){
					item[key] = maskCard(item[key]);
				}
				else if(fKey && fKey.length>0 && fKey[0].type ==="decimal"){
					let hasDollarSymbol = fKey[0].isDollarSymbolRequired ? true : false;
					item[key] = formatDecimal(item[key],hasDollarSymbol);
				}			
			}			
			return item;
		})
	);
};

//Below function is for Inbox Notifications
export const stringToDate = (dateString) => {
	let dateValue = new Date(dateString);
	let formattedDate = ((dateValue.getUTCMonth() > 8) ? 
    (dateValue.getUTCMonth() + 1) : 
	('0' + (dateValue.getUTCMonth() + 1))) + '/' + ((dateValue.getUTCDate() > 9) ? 
	dateValue.getUTCDate() : ('0' + dateValue.getUTCDate())) + '/' + dateValue.getUTCFullYear()
    
	return {
		dateValue: dateValue,
		formattedDate: formattedDate,
		monthFromDate: dateValue.getUTCMonth() + 1,
		dayFromDate: dateValue.getUTCDate(),
		yearFromDate: dateValue.getUTCFullYear(),
		hoursFromDat: dateValue.getUTCHours(),
		minuteFromDate: dateValue.getUTCMinutes()};
}

export const getActuallHours = (timeInDate) => {
	let actualHrs = timeInDate.setUTCHours(0,0,0,0);
	return actualHrs;
}

export const formatSSN = (value) => {
    return value.replace(/\D/g, '')   
    .replace(/^(\d{3})/, '$1-')
    .replace(/-(\d{2})/, '-$1-')
    .replace(/(\d)-(\d{4}).*/, '$1-$2');
}