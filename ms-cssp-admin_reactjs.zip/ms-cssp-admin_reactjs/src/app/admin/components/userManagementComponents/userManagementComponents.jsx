"use client"
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators, compose } from 'redux';
// import { withRouter } from 'react-router-dom';
import moment from 'moment';
import Table from 'react-bootstrap/Table'
import Usertable from './userManagementTable';
import Header from '../../components/header/header';
import Footer from '../../components/footer/footer';
import Banner from '../../components/banner/banner';
import UserManagementTable from '../../components/userManagementComponents/userManagementTable';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import './userManagement.scss';
import withStyles from '@mui/styles/withStyles';

import { searchUserManagementAction, getStoreSearchForm, getClearSearchForm } from "../../actions/userManagement/userManagementActions"
import { Response } from 'cross-fetch';
import { convertDateToYMD } from './myBenefitUtil'
import Storage from '../../utils/storage';
import UserManagementSearchForm from './userManagementSearchForm';
import { fetchUserManagementDataAction } from '../../actions/userManagement/userManagementActions';
import createSetTimeoutPolyFill from '../../createSetTimeoutPolyFill';
import CONFIG from '../../config/index';
import { FETCH_CONFIG_PUBLISH_DATA_BEGIN } from '../../actions/actionTypes';

// import { TablePagination } from "'@mui/material/TablePagination';";

// import { Pagination } from "@material-ui/lab";
import Pagination from '@mui/material/Pagination';


import Loader from '../loader/loader';
import { useRouter } from 'next/navigation';

/* Material Ui Styling */
const styles = theme => ({
	root: {
		backgroundColor: '#468CFF',
		'&:hover': {
			backgroundColor: '#468CFF'
		}
	},
	searchUserButton: {
		'& .MuiButtonBase-root.Mui-disabled': {
			background: '#ccc !important',
		}
	}

});
class userManagementComponent extends Component {
	constructor(props) {
		super(props)

		this.state = {
			firstName: "",
			lastName: "",
			// userId: "",
			arInd: false,
			email: "",
			// phone: "",
			// zip: "",
			programName: "",
			fromDate: "",
			toDate: "",
			searchData: {},
			loading: false,
			firstNameEmpty: "",
			lastNameEmpty: "",
			noUsers: false,
			invalidEmail: "",
			btnDisabled: true,
			userTable: '',
			formErrors: null,
			formDataSet: null,
			formDate: null,
			formValid: false,
			isFormSubmited: false,
			roleMatrixData: [],
			btnDisableState: true,
			json: {},
			benifitToggle: true,
			page: 1,
			rowsPerPage: 10,
			mandatoryFieldsEntered: null
		}
	}


	onChangeFetchLinkMyBenefitsData = languageOption => {
		this.props.fetchRequestToClientsData(languageOption.value).then(() => {
			this.setInitialState();
			this.scrollToTop();
		});
	}
	scrollToTop = () => {
		window.scroll({
			top: 0,
			left: 0,
			behavior: 'smooth'
		});
	};
	scrollToErrorField = (formErrors) => {
		setImmediate(() => {
			for (const field in formErrors) {
				if (!formErrors[field].isValid) {
					Element.prototype.documentOffsetTop = function () {
						return this.offsetTop +
							(this.offsetParent ? this.offsetParent
								.documentOffsetTop() : 0);
					};

					const top =
						document.querySelector(`#${field}`)
							.documentOffsetTop() - (window.innerHeight / 2);
					window.scrollTo(0, top);
					if (document.getElementById(field)) {
						document.getElementById(field).focus();
					}
					if (document.getElementById(`${field}-radio-0`)) {
						document.getElementById(`${field}-radio-0`).focus();
					}
					break;
				}
			}
		});
	};

	//set initial state dynamically
	setInitialState(contentData) {
		const fields = {};
		const formData = {};
		let formErrors = {};
		const content = contentData && contentData.data && contentData.data.content;
		const { formDataSet } = this.state;

		if (this.props.storedata !== undefined && Object.keys(this.props.storedata).length > 0) {
			
				this.setState({
					formDataSet: null
				}, () => {
					this.setState({
						formDataSet: this.props.storedata.storedata
					}, () => {				
		
						const {
							primaryFields
						} = content;
	
						const fieldTypeArr = ['input', 'checkbox', 'select', 'progessbar', 'multiselect'];
						const fieldsForEach = (item) => {
							if (fieldTypeArr.includes(item.fieldType.toLowerCase())) {
								formData[item.name] = formDataSet && formDataSet[item.name] ? formDataSet[item.name] : item.defaultValue;
								formErrors[item.name] = this.getFormErrorRules(item);
								formErrors = { ...this.setPrevActiveValidator(formErrors, item) };
							}
						}
						primaryFields.forEach((item) => {
							fieldsForEach(item);
						});		
			
						fields.formErrors = formErrors;
						fields.formDataSet = this.props.storedata.storedata;
						fields.benifitToggle = true;	
			
						this.setState(fields, () => {
							this.setState({formErrors: formErrors}, () => {				
								if (this.props.storedata.storedata && fields) {
									this.onClickSubmit();
								}
							});
						});
					})
				})

		}
		else {

			const {
				primaryFields
			} = content;
			const fieldTypeArr = ['input', 'checkbox', 'select', 'progessbar', 'multiselect'];
			const fieldsForEach = (item) => {
				if (fieldTypeArr.includes(item.fieldType.toLowerCase())) {
					formData[item.name] = formDataSet && formDataSet[item.name] ? formDataSet[item.name] : item.defaultValue;
					formErrors[item.name] = this.getFormErrorRules(item);
					formErrors = { ...this.setPrevActiveValidator(formErrors, item) };
				}
			}
			primaryFields.forEach((item) => {
				fieldsForEach(item);
			});

			fields.formErrors = formErrors;
			fields.formDataSet = formData;
			fields.benifitToggle = true;

			this.setState(fields);
		}


	}
	onShowSubmitModal = (showSubmitModal) => {
		this.setState({ showSubmitModal: showSubmitModal, showWarningModal: false, benifitToggle: true });
	}
	scrollToTable = () => {
		document.getElementsByClassName('scroll-admin-card-custom')[0].scrollIntoView({ behavior: "smooth" });
	}
	/******************************** */

	getFormErrorRules = (item) => {
		return {
			isValid: item.isRequired ? false : true,
			isTouched: false,
			activeValidator: {},
			validations: item.validations,
			isRequired: item.isRequired,
			minValue: item.minValue,
			maxValue: item.maxValue,
			minLength: item.minLength,
			maxLength: item.maxLength
		};
	}
	setPrevActiveValidator = (curFormErrors, item) => {
		const { formErrors } = this.state;
		if (formErrors) {
			curFormErrors[item.name].isValid = formErrors[item.name].isValid;
			curFormErrors[item.name].isTouched = formErrors[item.name].isTouched;
			if (formErrors[item.name].activeValidator && formErrors[item.name].activeValidator.type) {
				const activeValidator = curFormErrors[item.name].validations.filter((elem) => elem.type === formErrors[item.name].activeValidator.type);
				if (activeValidator.length) {
					curFormErrors[item.name].activeValidator = activeValidator[0];
				}
			}
		}
		return curFormErrors;
	}
	resetPrevActiveValidator = (curFormErrors, item) => {
		const { formErrors } = this.state;
		if (formErrors) {
			curFormErrors[item.name].isValid = true;
			curFormErrors[item.name].isTouched = false;
			//curFormErrors[item.name].activeValidator = {};
			if (formErrors[item.name].activeValidator && formErrors[item.name].activeValidator.type) {
				const activeValidator = []//curFormErrors[item.name].validations.filter((elem) => elem.type === formErrors[item.name].activeValidator.type);
				if (activeValidator.length) {
					curFormErrors[item.name].activeValidator = activeValidator[0];
				}
			}
		}
		return curFormErrors;
	}
	//@Prithvi: To handle error msg when non mandate fields are filled without mandatory fields
	handleOnChangeErrorMsgForMandateFlds = (isAnyMandatoryFieldFilled, formErrors) => { 	  
		if (isAnyMandatoryFieldFilled) {
		  formErrors['firstName'].isValid = true;	  
		  formErrors['firstName'].isTouched = true;
		  formErrors['firstName'].activeValidator = {}
		} else {
		  formErrors['firstName'].isValid = false;	  
		  formErrors['firstName'].isTouched = true;
		  formErrors['firstName'].activeValidator = formErrors['firstName'].validations[0]
		}
	}

	handleDateChange = (e, subIndex, field) => {
		let dob = '';
		if(e === null){
			dob = ''
		}else{
			var date = new Date(e);
			dob = ((date.getMonth() > 8) ? (date.getMonth() + 1) : ('0' + (date.getMonth() + 1))) + '/' + ((date.getDate() > 9) ? date.getDate() : ('0' + date.getDate())) + '/' + date.getFullYear();
		}
		let formDataSet = {};
		const fields = {};
		if (field.dataType === 'date') {
			fields[field.name] = dob;
			// this.setState({ isBlocking: false, btnDisableState: false })
			//return
		}

		formDataSet = {
			...this.state.formDataSet,
			...fields
		};
		// Check if any of the mandatory fields are filled	  
		const isAnyMandatoryFieldFilled = formDataSet['firstName'] || formDataSet['lastName'] || formDataSet['emailId'];
		const formErrors = { ...this.state.formErrors };
		// this.handleOnChangeErrorMsgForMandateFlds(isAnyMandatoryFieldFilled, formErrors);
		let checkDate;
		if (formDataSet.fromdate && formDataSet.enddate) {
			checkDate = moment(formDataSet.enddate).isSameOrAfter(formDataSet.fromdate);
			if (checkDate) {
				this.setState({
					checkDateState: true
				})
			} else {
				this.setState({
					checkDateState: false
				})
			}
		}



		this.validateField(
			field.name, dob, fields, subIndex, true, checkDate
		);


		this.setState({
			formDataSet: formDataSet
		});

	}

	handleChange = (e, subIndex, field) => {
		let formDataSet = { ...this.state.formDataSet };	  
		const fields = { ...formDataSet };
			  
		let currTarget = e.currentTarget;
		let target = e.target;
		let value = '';	  
		// this.setState({ isBlocking: false, btnDisableState: false })	  
		/**Prevent more than once space */
		if(target && target.value ){
			if(field.dataType==="text"){
			target.value = target.value.trimStart();
			target.value = target.value.replace(/\s\s+/g, ' ');
		  }
		}
		/**
			 * Prevent typing if allowed field length is reached.
			 */
		let maxLength = 0;
		if (field && field.maxLength) {
		  maxLength = parseInt(field.maxLength);
		}
		if (maxLength > 0 && e.target.value.length > maxLength) {
		  e.target.value = e.target.value.substring(0, maxLength);
		  return;
		}
	  

		if (currTarget?.type === 'checkbox') {
		  fields[target.name] = currTarget.checked;
		} else {
		  fields[target.name] = target.value;

		}
		/**
		 * End of maxLength checking
		 */
		// fields[target.name] = target.value;
		// value = target.value;

		/*	this.validateField(
				target.name, value, fields, subIndex, true
			);*/

	  
		formDataSet = {
		  ...this.state.formDataSet,
			...fields
		};
	   
		// Check if any of the mandatory fields are filled	  
		const isAnyMandatoryFieldFilled = formDataSet['firstName'] || formDataSet['lastName'] || formDataSet['emailId'];
		const formErrors = { ...this.state.formErrors };
		// this.handleOnChangeErrorMsgForMandateFlds(isAnyMandatoryFieldFilled, formErrors);
	  
		this.setState({
		  formDataSet: formDataSet,	  
		  btnDisableState: !isAnyMandatoryFieldFilled,	  
		  formErrors: formErrors,
		});


	}

	handlePage = (newPage) => {
		
		this.setState({ page: newPage });

		this.onClickSubmit();
	}

	handleChangeRowsPerPage = (event) => {		
		this.setState({ rowsPerPage: parseInt(event.target.value, 10) });
		this.setState({ page: 1})		
	  };

	handleBlur = (e, subIndex) => {

		const { formDataSet, formErrors } = this.state;
		this.setState({ page: 1, rowsPerPage: 10 })
		const fields = {};
		const currTarget = e.currentTarget;
		const target = e.target;

		// Check if at least one of the mandatory fields is filled
		const isAnyMandatoryFieldFilled =
			formDataSet["firstName"] || formDataSet["lastName"] || formDataSet["emailId"];
		// this.setState({ btnDisableState: false });
		let value = '';
		fields[target.name] = target.value;
		value = target.value;
		this.validateField(target.name, value, fields, subIndex, true);

		let formErrorExist = false;

		let allFormObjects = [];

		allFormObjects.push(formErrors["firstName"]);
		allFormObjects.push(formErrors["lastName"]);
		allFormObjects.push(formErrors["emailId"]);
		allFormObjects.push(formErrors["fromDate"]);
		allFormObjects.push(formErrors["endDate"]);
		allFormObjects.push(formErrors["programType"]);
		allFormObjects.push(formErrors["arInd"]);


		if (allFormObjects && allFormObjects.length > 0) {
			for (let index = 0; index <= allFormObjects.length - 1; index++) {
				if (allFormObjects[index] && allFormObjects[index].isValid === false) {
					formErrorExist = true;
					break;
				}
			}
		}

		if (isAnyMandatoryFieldFilled === "") {
			formErrors["firstName"].isValid = true;
			formErrors["lastName"].isValid = true;
			formErrors["emailId"].isValid = true;
			this.setState({ btnDisableState: true, mandatoryFieldsEntered: false });
		}
		else if (isAnyMandatoryFieldFilled !== "") {

			this.setState({ mandatoryFieldsEntered: true });

			let firstNameValid = null;
			let lastnameValid = null;
			let emailValid = null;

			if (formDataSet["firstName"] !== "") {
				firstNameValid = new RegExp("^[A-Za-z]{2,}$")
					.test(formDataSet["firstName"]);
			}

			if (formDataSet["lastName"] !== "") {
				lastnameValid = new RegExp("^[A-Za-z]{2,}$")
					.test(formDataSet["lastName"])
			}

			if (formDataSet["emailId"] !== "") {
				emailValid = new RegExp("^(\\w+((-\\w+)|(\\.\\w+)|(\\+\\w+))*\\@[A-Za-z0-9]+((\\.)[A-Za-z0-9]+)*\\.[A-Za-z0-9]{2,4})$")
					.test(formDataSet["emailId"])
			}


			if (firstNameValid === false && lastnameValid === false) {

				if (firstNameValid === false) {
					formErrors["firstName"].isValid = false;
				}

				if (lastnameValid === false) {
					formErrors["lastName"].isValid = false;
				}
				this.setState({ searchData: {}, json: {}, loading: false })
				this.setState({ btnDisableState: true });
			}
			else if (firstNameValid === false && (lastnameValid === true || lastnameValid === null)) {

				if (firstNameValid === false) {
					formErrors["firstName"].isValid = false;
				}

				if (lastnameValid === true) {
					formErrors["lastName"].isValid = true;
				}
				this.setState({ searchData: {}, json: {}, loading: false })
				this.setState({ btnDisableState: true });
			}
			else if (firstNameValid === true && (lastnameValid === true || lastnameValid === null)) {

				

				if (firstNameValid === true) {
					formErrors["firstName"].isValid = true;
				}

				if (lastnameValid === true || lastnameValid === null) {
					formErrors["lastName"].isValid = true;
				}

				if ((emailValid === true || emailValid === null)) {
					
					this.setState({ searchData: {}, json: {}, loading: false, isFormSubmited: false })
					this.setState({ btnDisableState: false });
				}

			}
			else if ((firstNameValid === true || firstNameValid === null) && lastnameValid === false) {

				if (firstNameValid === true || firstNameValid === null) {
					formErrors["firstName"].isValid = true;
				}

				if (lastnameValid === false) {
					formErrors["lastName"].isValid = false;
				}
				this.setState({ searchData: {}, json: {}, loading: false })
				this.setState({ btnDisableState: true });
			}
			else if ((firstNameValid === true || firstNameValid === null) && lastnameValid === true) {

				if (firstNameValid === true || firstNameValid === null) {
					formErrors["firstName"].isValid = true;
				}

				if (lastnameValid === true) {
					formErrors["lastName"].isValid = true;
				}

				if ((emailValid === true || emailValid === null)) {
					
					this.setState({ searchData: {}, json: {}, loading: false, isFormSubmited: false })
					this.setState({ btnDisableState: false });
				}
			}
			else if (firstNameValid === true && lastnameValid === true) {
				if (!formErrorExist) {
					formErrors["firstName"].isValid = true;
					formErrors["lastName"].isValid = true;
					formErrors["emailId"].isValid = true;
					this.setState({ btnDisableState: false }); // 2nd MAIN CHANGE
				}
				else {
					this.setState({ btnDisableState: true }); // 2nd MAIN CHANGE
				}
			}

			if (emailValid === false) {
				formErrors["emailId"].isValid = false;
				this.setState({ searchData: {}, json: {}, loading: false })
				this.setState({ btnDisableState: true }); // 2nd MAIN CHANGE
			}

		}


		// Update the formErrors state
		this.setState({
			formErrors: formErrors,
		}, this.validateForm);
	}
	  
	
	validateField(fieldName, value, fields, subIndex, isTouched, checkDate) {
		const fieldValidationErrors = {
			...this.state.formErrors
		};
		let fieldValidationError, fieldValidationFirstNameError, fieldValidationLastNameError  = null;
		const fieldKey = Object.keys(fields)[0];		

		fieldValidationError = fieldValidationErrors[fieldName];

		if (isTouched !== undefined) {
			fieldValidationError.isTouched = isTouched;
		}

		let validationObj = {};
		validationObj =
			this.getFieldIsValid(
				value,
				fieldValidationError,
				fieldName,
				checkDate
			);


		if (typeof fields[fieldKey] === 'object' && fields[fieldKey] !== null) {
			fieldValidationErrors[fieldKey][subIndex][fieldName] = {
				...validationObj.fieldValidationError
			};
		} else {
			fieldValidationErrors[fieldName] = {
				...validationObj.fieldValidationError
			};
		}

		if (fieldName === 'fromdate' || fieldName === 'enddate') {
			if (checkDate === false) {
				this.customValidation(
					fieldName, value, validationObj, fieldKey, subIndex
				);
				this.setState({ searchData: {}, json: {}, loading: false })
			}
			else {
				// this.setState({ btnDisableState: false })
			}

		}
		else {
			this.customValidation(
				fieldName, value, validationObj, fieldKey, subIndex
			);
		}

		return validationObj.currvalue
	}

	getFieldIsValid = (value, fieldValidationError, fieldName, checkDate) => {

		const { formDataSet } = this.state;

		let validationObj = {
			fieldValidationError: fieldValidationError,
			errcount: 0
		};
		if (+fieldValidationError.isRequired === 1) {
			validationObj =
				this.checkValidationByValidationTypes(value, fieldValidationError, fieldName, checkDate);
		} else {			
			
			if (fieldName === "firstName" && (value === undefined || value === "")) {			
				validationObj = 
					this.checkValidationByValidationTypes(value, fieldValidationError, fieldName, checkDate);
			}
			else if (fieldName === "lastName" && value) {				
				validationObj = 
					this.checkValidationByValidationTypes(value, fieldValidationError, fieldName, checkDate);
			}
			else if (fieldName === "emailId" && value) {				
				validationObj = 
					this.checkValidationByValidationTypes(value, fieldValidationError, fieldName, checkDate);
			}
			else if (value) {
				validationObj = 
					this.checkValidationByValidationTypes(value, fieldValidationError, fieldName, checkDate);
			}
		}
		return validationObj;
	}

	checkValidationByValidationTypes = (value, fieldValidationError, fieldName, checkDate) => {
		const validationTypes = ['empty', 'email', 'password',
			'integer', 'characterMismatch', 'DateRange', 'IsMaxDate', 'IsMinDate', 'doubleSpace'];
		let errcount = 0;
		let activeValidator = null;
		let formData = this.state.formDataSet;
		formData[fieldName] = value

		validationTypes.forEach(validationType => {

			activeValidator = fieldValidationError.validations && fieldValidationError.validations
				.filter(validation =>
					validation.type === validationType);
			if (activeValidator && activeValidator.length) {
				if (validationType === 'empty') {
					if (fieldName === 'userId' && value.length !== 0) {
						const userId = value;
						const newUserId = userId.replace(/\s+/g, ' ').trim();
						if (newUserId.length === 0) {
							errcount++;
							fieldValidationError
								.activeValidator = activeValidator[0];
						}
					} else {
						if (!value) {
							errcount++;
							fieldValidationError
								.activeValidator = activeValidator[0];
						}
					}
				}
				if (validationType === 'DateRange') {
					errcount++;
					if (checkDate === false) {
						const activeValidator =
							fieldValidationError.validations
								.filter(validation =>
									validation.type === 'DateRange');
						if (activeValidator.length) {
							fieldValidationError.activeValidator = activeValidator[0]
						}
					} else {
						fieldValidationError.activeValidator = {}
						fieldValidationError.isValid = true
						fieldValidationError.isTouched = false
						errcount--;
					}
				}
				if (validationType === 'IsMaxDate' && value) {
					let enterDate = new Date(value);
					enterDate = new Date(new Date(enterDate.toString().substr(0, 16)))
					let currDate = null
					//Murali:- VSTS 279775 fix. max date validation in futur years
					if(!isNaN(enterDate)){
						if(activeValidator.yearsInFutur){
							let currentyear = new Date().getFullYear()
							currDate = new Date(currentyear+activeValidator.yearsInFutur,11,31)
						}else{
							currDate = activeValidator[0].maxDate === "newDate" ? new Date() : new Date(activeValidator[0].maxDate);
							currDate = new Date(new Date(currDate.toString().substr(0, 16)))
						}
						if (value && value.toString().toLowerCase() === 'invalid date' || enterDate > currDate) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
						/**@Murali: added validation to not accept current date(VSTS 286749) */
						if(activeValidator.noPresentDate){
							if (value && value.toString().toLowerCase() === 'invalid date' || enterDate >= currDate) {
								count = this.setErrorMessage(sfield, activeValidator, count, isPrg)
							}
						}
					}	
				}
				
				if (validationType === 'IsMinDate' && value) {
					const enterDate = new Date(value);
					let currDate = activeValidator[0].minDate === 'newDate' ? new Date() : new Date(activeValidator[0].minDate);
					currDate = new Date(new Date(currDate.toString().substr(0, 16)))
					if(!isNaN(enterDate)){
						if (value && value.toString().toLowerCase() === 'invalid date' || (enterDate < currDate)) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					}
        		}
				
				if (validationType === "doubleSpace" && value) {					
					formData[fieldName] = value;
					if (value && value.match("  ")) {
					  errcount++;
					  fieldValidationError.activeValidator = activeValidator[0];
					}
				  }

				if (!errcount) {
					if (validationType === 'integer') {
						if (!new RegExp(activeValidator[0].validationRule)
							.test(value)) {
							errcount++;
							fieldValidationError
								.activeValidator = activeValidator[0];
						} else if (fieldValidationError.minValue &&
							+value <=
							fieldValidationError.minValue) {
							errcount++;
							fieldValidationError
								.activeValidator = activeValidator[0];
						}
					} else {
						if (!new RegExp(activeValidator[0].validationRule)
							.test(value)) {
							errcount++;
							fieldValidationError
								.activeValidator = activeValidator[0];
						}
					}
				}
			}
		});
		return {
			fieldValidationError: fieldValidationError,
			errcount: errcount,
			currvalue: formData[fieldName]
		};
	}

	customValidation = (
		fieldName, value, validationObj, fieldKey, subIndex
	) => {
		const { formErrors, formDataSet } = this.state;
		const fieldValidationErrors = {
			...formErrors
		};
		let errcount = validationObj.errcount;

		switch (fieldName) {

			case 'emailId':
				if (!errcount) {
					fieldValidationErrors[fieldName].isValid = true;
					fieldValidationErrors[fieldName].activeValidator = {};
				} else {
					fieldValidationErrors[fieldName].isValid = false;
				}
				break;
			default:
				if (!errcount) {
					fieldValidationErrors[fieldName].isValid = true;
					fieldValidationErrors[fieldName].activeValidator = {};
				} else {
					fieldValidationErrors[fieldName].isValid = false;
				}
				break;
		}


		this.setState({
			formErrors: fieldValidationErrors
		}, this.validateForm);
	}

	validateForm() {
		let formValid = true;
		const { formErrors, formDataSet } = this.state;
		const formErrorKeys = Object.keys(formErrors);
		// Check if any of the mandatory fields are filled.
		let isAnyMandatoryFieldFilled = false;
		formErrorKeys.forEach((fieldName) => {
		  if (formDataSet[fieldName] && formDataSet[fieldName].length > 0) {
			isAnyMandatoryFieldFilled = true;
		  }
		});
		// If none of the mandatory fields are filled, form is invalid.
		if (!isAnyMandatoryFieldFilled) {
		  formValid = false;
		}
		// Check for individual field validations.
		for (let i = 0; i < formErrorKeys.length; i++) {
		  const fieldName = formErrorKeys[i];
			//skiping state validation as it has default value
		  if (!formErrors[fieldName].isValid && fieldName !== "state") {
				formValid = formErrors[fieldName].isValid;
			break;
	  
		  }
	  
		}
	  
	  
		this.setState({
		  formValid: formValid
		});
	  }

	  onClickSubmit = (href) => {

		const { formDataSet, formValid, formErrors } = this.state;

		if (!(formErrors["firstName"].isValid === false ||
			formErrors["lastName"].isValid === false ||
			formErrors["emailId"].isValid === false)) {

			
			this.setState({ isFormSubmited: true });
			this.setState({ loading: true });
			const fieldValidationErrors = {
				...formErrors
			};
			let lblnCheckCondition = false;			

			if (!(this.props.storedata !== undefined && Object.keys(this.props.storedata).length > 0)) {

				//fieldName, value, fields, subIndex, isTouched
				Object.keys(fieldValidationErrors).forEach((fieldName, index) => {
					if (typeof formDataSet[fieldName] === 'object' && formDataSet[fieldName] !== null) {
						formDataSet[fieldName].forEach((fieldObj, fieldIndex) => {

							Object.keys(fieldObj).forEach(fldName => {
								this.validateField(
									fldName,
									fieldObj[fldName],
									{ [fieldName]: formDataSet[fieldName] },
									fieldIndex
								);
							});
						});
					} else {

						if (formDataSet["firstName"] && formDataSet["firstName"].length > 0 ||
							formDataSet["lastName"] && formDataSet["lastName"].length > 0 ||
							formDataSet["emailId"] && formDataSet["emailId"].length > 0) {
							lblnCheckCondition = true;
						}

						if (lblnCheckCondition === false) {
							this.validateField(
								fieldName,
								formDataSet[fieldName],
								{ [fieldName]: formDataSet[fieldName] },
								index
							);
						}

					}
				});

				if (formDataSet && Object.keys(formDataSet).length > 0) {
					if (formDataSet["firstName"] && formDataSet["firstName"].length > 0 ||
						formDataSet["lastName"] && formDataSet["lastName"].length > 0 ||
						formDataSet["emailId"] && formDataSet["emailId"].length > 0) {

						this.props.getStoreSearchForm(formDataSet);
						this.setState({ formValid: true })

						let fieldValidationError = null;
						fieldValidationError = fieldValidationErrors["firstName"];
						fieldValidationError.isValid = true;

						let validationObj = {};
						validationObj =
							this.getFieldIsValid(
								null,
								fieldValidationError,
								"firstName",
								null
							);

					} else {

						this.props.getClearSearchForm();

						this.setState({ formValid: false })

					}

				} else {
					this.props.getClearSearchForm();
					this.setState({ formValid: false })
				}

				this.requestToClientCaseJSON();
			} else {

				if (formDataSet && Object.keys(formDataSet).length > 0) {
					if (formDataSet["firstName"] && formDataSet["firstName"].length > 0 ||
						formDataSet["lastName"] && formDataSet["lastName"].length > 0 ||
						formDataSet["emailId"] && formDataSet["emailId"].length > 0) {

						this.props.getStoreSearchForm(formDataSet);
						this.setState({ formValid: true })
						this.setState({ btnDisableState: false });

						let fieldValidationError = null;
						fieldValidationError = fieldValidationErrors["firstName"];
						fieldValidationError.isValid = true;

						let validationObj = {};
						validationObj =
							this.getFieldIsValid(
								null,
								fieldValidationError,
								"firstName",
								null
							);
					} else {

						this.props.getClearSearchForm();
						this.setState({ formValid: false })
					}
				} else {

					this.props.getClearSearchForm();
					this.setState({ formValid: false })
				}

				this.setState({ formErrors: this.state.formErrors });

				createSetTimeoutPolyFill(() => {
					this.requestToClientCaseJSON();
				}, 100);
			}
		}
	}



	requestToClientCaseJSON = () => {
		const { formDataSet, formValid, formErrors } = this.state;
		const saveJSON = { ...formDataSet };

		if (formDataSet && Object.keys(formDataSet).length > 0) {
			if (formDataSet["firstName"] && formDataSet["firstName"].length > 0 || 
				formDataSet["lastName"] && formDataSet["lastName"].length > 0 || 
				formDataSet["emailId"] && formDataSet["emailId"].length > 0) {

				let contactYou = [];
				let searchDataArray = {};
				searchDataArray["firstName"] = formDataSet["firstName"] ? formDataSet["firstName"] : null;
				searchDataArray["lastName"] = formDataSet["lastName"] ? formDataSet["lastName"] : null;
				searchDataArray["emailAddress"] = formDataSet["emailId"] ? formDataSet["emailId"] : null;
				searchDataArray["programName"] = formDataSet["programType"] ? formDataSet["programType"] === "Community Services" ? "LIHEAP" : formDataSet["programType"] : null;
				searchDataArray["arInd"] = formDataSet["arInd"] ? formDataSet["arInd"] : false;
				searchDataArray["fromDate"] = formDataSet["fromdate"] ? convertDateToYMD(formDataSet["fromdate"], "yyyy-mm-dd") : null;
				searchDataArray["toDate"] = formDataSet["enddate"] ? convertDateToYMD(formDataSet["enddate"], "yyyy-mm-dd") : null;
				searchDataArray["userId"] = Storage.getItem('adminUserId');
				searchDataArray["currentPage"] = this.state.page;
				searchDataArray["sizePerPage"] = 10;
				
				if (searchDataArray.arInd === true) {
					searchDataArray.arInd = 'Y';
				} else {
					searchDataArray.arInd = null;
				}

				this.props.searchUserManagementAction(searchDataArray).then((res) => {
					
					if (res.statusCode === 200 && res.message !== "204 NO_CONTENT") {						

						this.setState({ searchData: " " });
						this.setState({ searchData: res });
						this.setState({ noUsers: false })
						this.setState({ loading: false });
						this.scrollToTable();

						// try { window.appInsights.trackEvent('Admin - Search Users', { 'pageName': "User Management" }, { 'adminUserId': Storage.getItem('adminUserId')  }); }
						// catch { }
						
					}
					else {
						this.setState({ noUsers: true })
						this.setState({ searchData: " " });
						this.setState({ loading: false });
						this.scrollToTable();
					}
				})
			}
			else {			

				// this.setState({ noUsers: true })
				this.setState({ searchData: " " });
				this.setState({ loading: false });
				this.scrollToTable();
				this.scrollToErrorField(formErrors);
			}
		}
		else {
			// this.setState({ noUsers: true })
			this.setState({ searchData: " " });
			this.setState({ loading: false });
			this.scrollToTable();
			this.scrollToErrorField(formErrors);
		}

		//const defaultLangObj = Storage.getItem('defaultLangCode') ? Storage.getItem('defaultLangCode') : CONFIG.defaultLang;
		// if (formValid) {



	}

	onClear = () => {
		this.props.getClearSearchForm();

		this.setState({
			firstName: "",
			lastName: "",
			// userId: "",
			arInd: false,
			email: "",
			// phone: "",
			// zip: "",
			programName: "",
			fromDate: "",
			toDate: "",
			searchData: {},
			firstNameEmpty: "",
			lastNameEmpty: "",
			noUsers: false,
			invalidEmail: "",
			btnDisabled: true,
			userTable: '',
			formErrors: null,
			formDataSet: null,
			formDate: null,
			formValid: false,
			isFormSubmited: false,
			roleMatrixData: [],
			btnDisableState: true,
			json: {},
			benifitToggle: true,
			page: 1,
			rowsPerPage: 10,
			mandatoryFieldsEntered: null
		})

		this.props.fetchUserManagementDataAction().then((screenData) => {
			this.setInitialState(screenData)
		});
		
	}
	/* istanbul ignore next */
	componentDidMount() {
		this.props.fetchUserManagementDataAction().then((screenData) => {
			this.setInitialState(screenData)
		});
	}

	componentWillUnmount() {
	}

	render() {
		const { json, classes, storedata } = this.props;
		const { firstNameEmpty, lastNameEmpty, invalidEmail, btnDisabled, loading, formDataSet } = this.state;
		/* istanbul ignore next */
		return (
			<div>
				<Header jsonHeader={json && json.data && json.data.header} />
				<Banner
					config={json && json.data && json.data.content.banner.config}
					content={json && json.data && json.data.content.banner.content} />
				<div className="custom-usermanagment">
					<div className="dashboard-container dashboard theme-background-light-grey">
						<div className="customBreadcrumb">
							<Breadcrumb>
								<Breadcrumb.Item href={json && json.data && json.data.content.banner.content.breadCrumbUrl}>
									{json && json.data && json.data.content.banner.content.breadCrumb}
								</Breadcrumb.Item>
							</Breadcrumb>
						</div>
						<div className="menu-container">
							<div className="card custom-card">
								<div className="main-panel mt-3">
									<div className="custom-container custom-userManagmentComponent">
										<div className="custom-admin-title">
											<h2>{json && json.data && json.data.content.welcomeText.mainText}</h2>
											{<p>{json && json.data && json.data.content.welcomeText.subText}</p>}
										</div>

										<div className="theme-background-light-grey card d-flex flex-column py-3 card-custom admin-card-custom scroll-admin-card-custom">
											<div className="custom-admin-dashboard-card-title">
												<p class="mb-0 ml-2 headline-enrolled">{json && json.data && json.data.content.form.title}</p>
											</div>

											{this.state.mandatoryFieldsEntered === false ? 
												<div className='mandatoryFieldMessage'>													
													<p>{json && json.data && json.data.content && json.data.content.mandatoryFieldMessage && json.data.content.mandatoryFieldMessage.mainText}</p>
												</div>
											: null}
											

											<div className="admin-search-conatiner">

												
												{json && json.data && json.data.content ?													
													<UserManagementSearchForm
														content={json && json.data && json.data.content}
														componentState={this.state}
														onClickSubmit={this.onClickSubmit}
														handleChange={this.handleChange}
														handleDateChange={this.handleDateChange}
														//handleCheckboxChange = {this.handleCheckboxChange}
														handleBlur={this.handleBlur}
														onMouseLeave={this.handleBlur}
														btnDisable={this.state.btnDisableState}
														onClear={this.onClear} />													: ""}
											</div>
										</div>

										{ loading ? <Loader /> :
													
											this.state.searchData && this.state.searchData.body && this.state.searchData.body.users ?
												<div className="theme-background-light-grey card d-flex flex-column py-3 card-custom admin-card-custom scroll-admin-card-custom">
													<div className="custom-admin-dashboard-card-title">
														<h2>{json && json.data && json.data.content.tableSectionText}</h2>													
													</div>													
													
													<div className="userData" id="userTableSection">													
															<UserManagementTable searchResult={this.state.searchData} json={this.props.json.data} />
													</div>

													<div className='centered' id="paginationDIV">
														<Pagination color="primary"count={this.state.searchData.body.totalPageCount}
															onChange={(event, value) => this.handlePage(value)}
															page={this.state.page}
															size="large"
														></Pagination>
													</div>
													
												</div>
											:	null
										}
										
										{this.state.noUsers ?
											<div className="theme-background-light-grey card d-flex flex-column py-3 card-custom admin-card-custom ">
												<div className="userData" id="userTableSection" >
													<h4 style={{ textAlign: "center", fontWeight: "bold", marginBottom: "50px", marginTop: "50px" }}>{json && json.data && json.data.content.sectionText}</h4>
											</div></div> 
										: null}
									</div>


								</div>
							</div>
						</div>
					</div></div>

				{<Footer />}
			</div>

		);
	}
}


const mapStateToProps = state => ({
	usersSearchData: state.userManagementReducer.searchUserData,
	userSearchCriteria: state.userManagementReducer.storeSearchUserCriteria,
	userManagementJsonData: state.userManagementReducer.userManagementData,
	storedata: state.userManagementReducer.storedata,



});

const mapDispatchToProps = dispatch =>
	bindActionCreators(
		{
			searchUserManagementAction,
			fetchUserManagementDataAction,
			getStoreSearchForm,
			getClearSearchForm


		},
		dispatch
	);

const withRouter = (Component) => {
	const ComponentWithRouter = (props) => {
		const router = useRouter();
		return <Component {...props} router={router} />;
	};

	// Adding display name for better debugging
	ComponentWithRouter.displayName = `withRouter(${Component.displayName || Component.name || 'Component'})`;

	return ComponentWithRouter;
}
export default compose(
	connect(
		mapStateToProps,
		mapDispatchToProps,
	),
	withStyles(styles),
)(withRouter(userManagementComponent));