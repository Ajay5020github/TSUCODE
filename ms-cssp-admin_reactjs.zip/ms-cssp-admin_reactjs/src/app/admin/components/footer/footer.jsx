"use client"
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Infinite 2022.
 */
import React ,{Component} from 'react';
import { Row, Col } from 'react-bootstrap';
import PropTypes from 'prop-types';
import Storage from '../../utils/storage';
import CONFIG from '../../config/index';
import { fetchFooterPageData } from "../../actions/footer/footerActions";


import { bindActionCreators } from 'redux';
// import { , withRouter } from 'react-router-dom';

import { connect } from 'react-redux';
import parse from 'html-react-parser';

import './footer.scss';
import classnames from 'classnames';

export class Footer extends Component {

	constructor(props) {
		super(props);
	}

	componentDidMount() {
		this.setStickyFooter();
		window.addEventListener('resize', /* istanbul ignore next */() => {
			this.setStickyFooter();
		});
		/*
	*Author: Rahul
	*Purpose: UC-CP-PHP-09 - Action Call to fetch footer page json data from blob
	*Date: 01/07/2022
	*/
	if (Storage.getItem("defaultLangCode")) {
		/*
		*Author: Mounika
		*purpose: Add condition chech if data already there service call will be 
					restricted otherwise service call will happens
		*Date: 03/02/2022
		*/

		if(this.props.footerPageData && this.props.footerPageData.footerPageData && this.props.footerPageData.footerPageData.languageId === Storage.getItem("defaultLangCode")){
			return;
		}else{
		this.props.fetchFooterPageData(Storage.getItem("defaultLangCode"));
		}
	  } else {
		if(this.props.footerPageData && this.props.footerPageData.footerPageData){
			return;
		}else{
		this.props.fetchFooterPageData();
		}
	  }

	}

	/*
		*Author: Rahul
		*Purpose: UC-CP-PHP-09 - Function definition of fetchFooterPageData
		*Date: 01/07/2022
		*/

	fetchFooterPageData = languageOption => {
		this.props.fetchFooterPageData(languageOption.value);
	  };

	setStickyFooter = () => {
		if (document.querySelector('.footer-container')) {
			const height = document.querySelector('.footer-container').offsetHeight;
			document.querySelector('body').style.paddingBottom = `${height}px`;
		}
	}
	/*
	*Author: Rahul
	*Purpose: UC-CP-PHP-09 - Below function named as renderContactLinks, renderMdhsLinks, renderLinks, renderExtraLinks, renderLogo to fetch differenct section in footer
	*Date: 01/07/2022
	*/
	renderContactLinks() {
		/*
		*Author: Basha
		*Purpose: UC-CP-PHP-09 - Removed as this is not required
		*Date: 02/01/2022
		*/
		
		if (this.props && this.props.footerPageData && this.props.footerPageData.footerPageData?.content && 
			this.props.footerPageData.footerPageData.content.footer && this.props.footerPageData.footerPageData.content.footer.content &&
			this.props.footerPageData.footerPageData.content.footer.content.contactDetails
			&& this.props.footerPageData.footerPageData.content.footer.content.contactDetails.items
			&& this.props.footerPageData.footerPageData.content.footer.content.contactDetails.items.length > 0) {
			return this.props.footerPageData.footerPageData.content.footer.content.contactDetails.items.map((item, i) => {
				return (item.id && item.text && item.id !== "9100") ? (
					<li className="list-group-item customFooterList">
						{/*
						*Author: Rahul
						*Purpose: UC-CP-PHP-09 - removed Link on address field using extra parameter in json disableLink
						*Date: 01/28/2022
						*/}
						{/*
						*Author: Basha
						*Purpose: UC-CP-PHP-09 -added style property to className for icon
						*Date: 02/01/2022
						*/}
						{!item.disableLink ?
						<a
						key={`contact-${i}-${(item.id || '')}`}
						href={item.href || ''} target={item.target || '_blank'}
						className={`mx-lg-4 mt-lg-0 contact-links ms-contact-links ` + (item.styleClass ? item.styleClass : '')}>
						{(item.iconDetails && item.iconDetails.url) ? <img
							src={item.iconDetails.url || ''}
							alt={item.iconDetails.altText || ''}
							title={item.iconDetails.title || ''}
							className={`pr-1 mr-1 contact-icon ` + (item.style ? item.style : '')} rel="noopener noreferrer"/> : ''}
						{item.text || ''}
					</a>
					/*
					*Author: Rahul
					*Purpose: UC-CP-PHP-09 - Added new class ms-contact-address for keeping address text in same line in footer
					*Date: 02/01/2022
					*/
					: <div className="mx-lg-4 mt-lg-0 contact-links ms-contact-links ms-contat-address"> {parse(item.text)} </div> }
					</li>
				) : '';
			});
		} else {
			return null;
		}
	}

	renderMdhsLinks() {
			
		
		if (this.props && this.props.footerPageData && this.props.footerPageData.footerPageData && this.props.footerPageData.footerPageData.content && 
			this.props.footerPageData.footerPageData.content.footer.content.mdhs
			&& this.props.footerPageData.footerPageData.content.footer.content.mdhs.items
			&& this.props.footerPageData.footerPageData.content.footer.content.mdhs.items.length > 0) {
			return this.props.footerPageData.footerPageData.content.footer.content.mdhs.items.map((item, i) => {
				return (item.id && item.text && item.id !== "9100") ? (
					<li className="list-group-item customFooterList">
						{/*
						*Author: Rahul
						*Purpose: UC-CP-PHP-09 - removed Link on address field using extra parameter in json disableLink
						*Date: 01/28/2022
						*/}
						{/*
						*Author: Basha
						*Purpose: UC-CP-PHP-09 -added style property to className for icon
						*Date: 02/01/2022
						*/}
						{!item.disableLink ?
						<>
						{item.noLink ?
						<div className={`mx-lg-4 mt-lg-0 contact-links ms-contact-links ` + (item.styleClass ? item.styleClass : '')}>
							{(item.iconDetails && item.iconDetails.url) ? <img
							src={item.iconDetails.url || ''}
							alt={item.iconDetails.altText || ''}
							title={item.iconDetails.title || ''}
							className={`pr-1 mr-1 contact-icon ` + (item.style ? item.style : '')}/> : ''}
							{item.text || ''}

						</div> :
						<a href={item.href} target="_blank"
						key={`contact-${i}-${(item.id || '')}`}
						className={`mx-lg-4 mt-lg-0 contact-links ms-contact-links ` + (item.styleClass ? item.styleClass : '')}>
						{(item.iconDetails && item.iconDetails.url) ? <img
							src={item.iconDetails.url || ''}
							alt={item.iconDetails.altText || ''}
							title={item.iconDetails.title || ''}
							className={`pr-1 mr-1 contact-icon ` + (item.style ? item.style : '')}/> : ''}
						{parse(item.text) || ''}
						</a>}</>
					: <div className="mx-lg-4 mt-lg-0 contact-links ms-contact-links"> {item.text} </div> }
					</li>
				) : '';
			});
		} else {
			return null;
		}
	}
	renderLinks() {
		
		if (this.props && this.props.footerPageData && this.props.footerPageData.footerPageData && this.props.footerPageData.footerPageData.content && 
			this.props.footerPageData.footerPageData.content.footer.content.links
			&& this.props.footerPageData.footerPageData.content.footer.content.links.items
			&& this.props.footerPageData.footerPageData.content.footer.content.links.items.length > 0) {
			return this.props.footerPageData.footerPageData.content.footer.content.links.items.map((item, i) => {
				return (item.id && item.text && item.id !== "9100") ? (
					/*
					*Author: Rahul
					*Purpose: UC-CP-PHP-09 - removed <ins> tag and text-capitalize class to remove the underline and capitilization on links in footer
					*Date: 01/12/2022
					*/
					(<li className="list-group-item customFooterList">
                        <a
                            key={`contact-${i}-${(item.id || '')}`}
                            href={CONFIG.api.nodeUrl.replace('adminbackend','')+item.href || ''} target={item.target || '_blank'}
                            className=" mx-lg-4 mt-lg-0 contact-links ms-contact-links">
                            {(item.iconDetails && item.iconDetails.url) ? <img
                                src={item.iconDetails.url || ''}
                                alt={item.iconDetails.altText || ''}
                                title={item.iconDetails.title || ''}
                                className="pr-1 mr-1 contact-icon"/> : ''}
                            {item.text || ''}
                        </a>
                    </li>)
				) : '';
			});
		} else {
			return null;
		}
	}
	renderExtraLinks() {
		
		if (this.props && this.props.footerPageData && this.props.footerPageData.footerPageData && this.props.footerPageData.footerPageData.content && 
			this.props.footerPageData.footerPageData.content.footer.content.extraLinks
			&& this.props.footerPageData.footerPageData.content.footer.content.extraLinks.items
			&& this.props.footerPageData.footerPageData.content.footer.content.extraLinks.items.length > 0) {
			return this.props.footerPageData.footerPageData.content.footer.content.extraLinks.items.map((item, i) => {
				return (item.id && item.text && item.id !== "9100") ? (
					/*
					*Author: Rahul
					*Purpose: UC-CP-PHP-09 - removed <ins> tag and text-capitalize class to remove the underline and capitilization on links in footer
					*Date: 01/12/2022
					*/
					(<li className="list-group-item customFooterList">
                        {/*
                        *Author: Basha
                        *Purpose: UC-CP-PHP-09 - Applied disabled link changes
                        *Date: 02/02/2022
                        */}
                        {!item.disableLink ?
                        
                            <a
                                key={`contact-${i}-${(item.id || '')}`}
                                href={item.type=="external"? CONFIG.api.nodeUrl.replace('adminbackend','')+item.href : (item.type=="blob" ? CONFIG.blobUrl+item.href : item.href || '')}
                                target={item.target || '_blank'}
                                className="text-underline
                                mx-lg-4 mt-lg-0 contact-links ms-contact-links">
                                {(item.iconDetails && item.iconDetails.url) ? <img
                                    src={item.iconDetails.url || ''}
                                    alt={item.iconDetails.altText || ''}
                                    title={item.iconDetails.title || ''}
                                    className="pr-1 mr-1 contact-icon"/> : ''}
                                {item.text || ''}
                            </a> 
                        : <div className="mx-lg-4 mt-lg-0 contact-links ms-contact-links"> {item.text} </div> }
                    </li>)
				) : '';
			});
		} else {
			return null;
		}
	}
	renderorgLogo() {
		
		if (this.props && this.props.footerPageData && this.props.footerPageData.footerPageData && this.props.footerPageData.footerPageData.content && 
			this.props.footerPageData.footerPageData.content.footer.content.orgLogo
			&& this.props.footerPageData.footerPageData.content.footer.content.orgLogo.items
			&& this.props.footerPageData.footerPageData.content.footer.content.orgLogo.items.length > 0) {
			return this.props.footerPageData.footerPageData.content.footer.content.orgLogo.items.map((item, i) => {
				return (item.id && item.id !== "9100") ? (
					<li className="list-group-item customFooterList"><a
						key={`contact-${i}-${(item.id || '')}`}
						href={item.href || ''} target={item.target || '_blank'}
						className="mx-lg-4 mt-lg-0 contact-links ms-contact-links">
						{(item.iconDetails && item.iconDetails.url) ? <img
							src={item.iconDetails.url || ''}
							alt={item.iconDetails.altText || ''}
							title={item.iconDetails.title || ''}
							className="pr-1 mr-1 contact-icon" width="150"/> : ''}
						{item.text || ''}
					</a></li>
				) : '';
			});
		} else {
			return null;
		}
	}

	

	render() {
		return (
			<div>
				<div className={classnames( this.props.config.theme || 'theme-background-dark-grey', 'footer-container ms-footer-container', this.props.className )} id={this.props.config.id || ''} >
					<div className="footer-content-center ms-footer-content-center">
						<Row className="border-white">
							{this.props && this.props.footerPageData && this.props.footerPageData.footerPageData && this.props.footerPageData.footerPageData.content &&
							this.props.footerPageData.footerPageData.content.footer && this.props.footerPageData.footerPageData.content.footer.content && 
							this.props.footerPageData.footerPageData.content.footer.content.mainContent &&
							this.props.footerPageData.footerPageData.content.footer.content.mainContent.headline &&
									this.props.footerPageData.footerPageData.content.footer.content.mainContent.headline.text &&
										<p className="footer-headline font-300">
											{this.props.footerPageData.footerPageData.content.footer
												.content.mainContent.headline.text}
										</p>
									}
						</Row>
						<Row className="order-white py-4">
							<Col className="flex-lg-row flex-column justify-content-lg-end justify-content-center align-items-center px-0 medicaid-group" lg={2}>
								{ this.props && this.props.footerPageData && this.props.footerPageData.footerPageData?.content &&
								this.props.footerPageData.footerPageData.content.footer.content?.contactDetails &&
									this.props.footerPageData.footerPageData.content.footer.content.contactDetails.text &&
										<p className="footer-headline">
											{this.props.footerPageData.footerPageData.content.footer
												.content.contactDetails.text}
										</p>
									}
								<ul className="list-group address-group">
								{this.renderContactLinks()}
								</ul>
							</Col>
							<Col className="flex-lg-row
							flex-column justify-content-lg-end
							justify-content-center align-items-center px-0 mdhs-group" lg={2}>
								{this.props && this.props.footerPageData && this.props.footerPageData.footerPageData?.content &&
								 this.props.footerPageData.footerPageData.content.footer.content.mdhs &&
									this.props.footerPageData.footerPageData.content.footer.content.mdhs.text &&
										<p className="footer-headline">
											{this.props.footerPageData.footerPageData.content.footer
												.content.mdhs.text}
										</p>
									}
								<ul className="list-group address-group">
								{this.renderMdhsLinks()}
								</ul>
							</Col>
							<Col className="d-flex flex-lg-row flex-column justify-content-lg-end justify-content-center align-items-center px-0 customVerticalRightBorder" lg={1}></Col>
							<Col className="d-flex flex-lg-row flex-column justify-content-lg-end justify-content-center align-items-center px-0 customVerticalLeftBorder" lg={1}></Col>
							<Col className="flex-lg-row flex-column justify-content-lg-end justify-content-center align-items-center px-0" lg={2}>
								{this.props && this.props.footerPageData && this.props.footerPageData.footerPageData && this.props.footerPageData.footerPageData.content &&
								this.props.footerPageData.footerPageData.content.footer.content.links &&
									this.props.footerPageData.footerPageData.content.footer.content.links.text &&
										<p className="footer-headline font-300">
											{this.props.footerPageData.footerPageData.content.footer
												.content.links.text}
										</p>
									}
								<ul className="list-group">
								{this.renderLinks()}
								</ul>
							</Col>
							<Col className="d-flex flex-lg-row flex-column align-items-center px-0 footer-last-col" lg={2}>
								<ul className="list-group extraLinksStyle">
								{this.renderExtraLinks()}
								</ul>
							</Col>
							<Col className="flex-lg-row flex-column justify-content-lg-end justify-content-center align-items-center px-0 deviceStyleLogo">
								<ul className="list-group ">
								{this.renderorgLogo()}
								</ul>
							</Col>
						</Row>
						<Row className="py-4">
							<Col className="d-flex flex-lg-row flex-column justify-content-center align-items-center">
								
							</Col>
						</Row>
						
					</div>
					{CONFIG.buildVersion ? (<div className="pb-2 pr-2 buildversion">
							<div className="d-flex flex-row justify-content-center justify-content-md-end align-items-center">
								<label style={{ fontFamily: "'Source Sans Pro', sans-serif" }}>Build Version: {CONFIG.buildVersion}</label>
							</div>
						</div>)
						: null
					}
				</div>
				<div id="chat-bot"></div>
			</div>
		);
	}
}

Footer.propTypes = {
	config: PropTypes.shape({
		id: PropTypes.string,
		align: PropTypes.string,
		theme: PropTypes.oneOf([
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		])
	}).isRequired,
	content: PropTypes.shape({
		mainContent: PropTypes.shape({
			textAlign: PropTypes.string,
			headline: PropTypes.shape({
				text: PropTypes.string.isRequired
			}).isRequired,
			text: PropTypes.string.isRequired
		}).isRequired,
		contactDetails: PropTypes.shape({
			textAlign: PropTypes.string,
			items: PropTypes.arrayOf(PropTypes.shape({
				id: PropTypes.string.isRequired,
				text: PropTypes.string.isRequired,
				iconDetails: PropTypes.shape({
					url: PropTypes.string.isRequired,
					altText: PropTypes.string,
					title: PropTypes.string
				}),
				target: PropTypes.string,
				href: PropTypes.string.isRequired
			})).isRequired
		}).isRequired,
		policyLinks: PropTypes.shape({
			textAlign: PropTypes.string,
			items: PropTypes.arrayOf(PropTypes.shape({
				id: PropTypes.string.isRequired,
				text: PropTypes.string.isRequired,
				href: PropTypes.string.isRequired,
				target: PropTypes.string
			})).isRequired
		}).isRequired,
		copyright: PropTypes.shape({
			textAlign: PropTypes.string,
			text: PropTypes.string.isRequired
		}).isRequired
	}).isRequired,
	className: PropTypes.string
};
Footer.defaultProps = {
	config: {
		id: '1',
		align: 'center',
		theme: 'theme-background-dark-grey'
	},
	content: {
		mainContent: {
			textAlign: 'left',
			headline: {
				text: 'State Information'
			},
			text: 'The department of Social and Family Services helps children and families succeed as adults and helps the elderly and disabled live with dignity and respect. Our goal is to promote healthier families and safer, more prosperous communities.'
		},
		contactDetails: {
			textAlign: 'right',
			items: [
				{
					"id": "2",
					"text": "Voter's Registration",
					"iconDetails": {
						"url": "/src/resources/images/notes.png"
					},
					"altText": "Voter's Registration",
					"title": "",
					"href": "https://www.google.com/"
				  },
				  {
					"id": "3",
					"text": "Chat with Us",
					"iconDetails": {
					  "url": "/src/resources/images/chat_icon.png"
					},
					"altText": "Chat with Us",
					"title": "",
					"href": "https://kog.chfs.ky.gov/public/contact/"
				  },
				  {
					"id": "4",
					"text": "Call Us",
					"iconDetails": {
					  "url": "/src/resources/images/phone_icon.png"
					},
					"altText": "Call Us",
					"title": "",
					"href": "https://kog.chfs.ky.gov/public/contact/"
				  },
				  {
					"id": "5",
					"text": "Email Us",
					"iconDetails": {
					  "url": "/src/resources/images/email_icon.png"
					},
					"altText": "Email Us",
					"title": "",
					"href": "https://kog.chfs.ky.gov/public/contact/"
				  }
			]
		},
		policyLinks: {
			textAlign: 'centre',
			items: [
				{
					"id": "6",
					"text": "Privacy Policy",
					"href": "http://www.nebraska.gov/policies/",
					"target": "_blank"
				},
				{
					"id": "7",
					"text": "Accessibility Policy",
					"href": "http://www.nebraska.gov/policies/",
					"target": "_blank"
				},
				{
					"id": "8",
					"text": "Non-discrimination Policy",
					"href": "http://dhhs.ne.gov/Pages/Non-Discrimination-Notice.aspx",
					"target": "_blank"
				}
			]
		},
		copyright: {
			textAlign: 'centre',
			text: '&copy; 2012-2019. All Rights Reserved.'
		}
	},
	className: 'footer'
};
const mapStateToProps = state => ({
	footerPageData: state.footerReducer.footerPageData
	
});

const mapDispatchToProps = (dispatch) => bindActionCreators(
	{
		fetchFooterPageData
	},
	dispatch
);

export default connect(mapStateToProps, mapDispatchToProps)(Footer);
