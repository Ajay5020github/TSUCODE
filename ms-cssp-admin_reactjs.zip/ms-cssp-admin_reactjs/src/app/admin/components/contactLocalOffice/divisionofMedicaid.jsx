/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Infinite 2022.
 */
/**
 * Auther:- Vishal Sabnis
 * Purpose:- UC-MS-PHP-11
 * Date:-01/07/2022
 */
import React, { useState } from 'react';
import {
	Col, Card
} from 'react-bootstrap';
import Storage from '../../utils/storage';

const DivisionOfMedicaidComponent = (props) => {

	let defaultLangId = Storage.getItem('defaultLangCode');
	defaultLangId = defaultLangId ? defaultLangId : 'en';

	const [loading, setLoading] = useState(false);


	return (

		<Col md={{ span: 12 }} className="ms-DivisionOfMedicaidComponent-section ">
			<Card className="ms-DivisionOfMedicaidComponent-card-wrap  theme-background-light-grey">
				<Card.Header className="border-0">
					<Card.Title className="mb-0 d-flex ms-DivisionOfMedicaidComponent-main-title"
					>{props.content.headline.contentText.dom}</Card.Title>
				</Card.Header>
				<Card.Body>
					<div className="container-div">
						{/* Akshay, office location hyperlink added for contact Regional office */}
						{props?.content?.dom.map((item, index) => (
							<ul key={index}>
								<li className="contactlinks">
									{item && item?.href ? (
										<a
											href={item?.href}
											target={item?.target || '_blank'}
											className={`mx-lg-4 mt-lg-0 contact-links ms-contact-links ${item?.styleClass ? item?.styleClass : ''}`}
										>
											{item?.text || ''}
										</a>
									) : ""}

								</li>
							</ul>
						))}
					</div>
				</Card.Body>
			</Card>
		</Col>
	);
};

export default DivisionOfMedicaidComponent;