/**
 * Auther:- Vishal Sabnis
 * Purpose:- UC-MS-PHP-11
 * Date:-01/07/2022
 */
import React, { useState, useEffect, useLayoutEffect } from 'react';
import {
	Row, Col, Button, Form, Card, Container
} from 'react-bootstrap';
import Storage from '../../utils/storage';

const MississippiDepartmentofHuman = (props) => {

	let defaultLangId = Storage.getItem('defaultLangCode');
	defaultLangId = defaultLangId ? defaultLangId : 'en';

	const [loading, setLoading] = useState(false);

	return (

		<Col md={{ span: 12 }} className="ms-DivisionOfMedicaidComponent-section ">
			<Card className="ms-DivisionOfMedicaidComponent-card-wrap  theme-background-light-grey">
				<Card.Header className="border-0">
					<Card.Title className="mb-0 d-flex ms-DivisionOfMedicaidComponent-main-title"
					>{props.content.headline.contentText.mdhs}</Card.Title>
				</Card.Header>
				<Card.Body>
					<div className="flex-container">
						<div className="flex-child">{props.content.mdhs.map((item, index) =>
							index <= props.sizeOfarray ?
								<ul key={index}><li className="strong-font">{item.city}</li>
									<li>{item.address1}</li>
									<li>{item.address2}</li>
									<li className="strong-font">{props.content.headline.contentText.servicingCounties}</li>
									<li>{item.counties}</li>
									<li><span className="strong-font">{props.content.headline.contentText.phone}</span>:{item.phone}</li>
									<li><span className="strong-font">{props.content.headline.contentText.fax}</span>:{item.fax}</li></ul>
								: null
						)}</div>

						<div className="flex-child">
							{props.content.mdhs.map((item, index) =>
								index > props.sizeOfarray ?
									<ul key={index}><li className="strong-font">{item.city}</li>
										<li>{item.address1}</li>
										<li>{item.address2}</li>
										<li className="strong-font">{props.content.headline.contentText.servicingCounties}</li>
										<li>{item.counties}</li>
										<li><span className="strong-font">{props.content.headline.contentText.phone}</span>:{item.phone}</li>
										<li><span className="strong-font">{props.content.headline.contentText.fax}</span>:{item.fax}</li></ul>
									: null
							)}
						</div>
					</div>
					<Col />
				</Card.Body>
			</Card>
		</Col>
	);
};

export default MississippiDepartmentofHuman;