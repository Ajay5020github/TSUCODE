/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Infinite 2022.
 */
/**
 * Auther:- Vishal Sabnis
 * Purpose:- UC-MS-PHP-11
 * Date:-01/07/2022
 */
import React, { useState } from 'react';
import {
	Row, Col, Button, Form, Card, Container
} from 'react-bootstrap';
import './contactLocalOffice.scss';
import Storage from '../../utils/storage';
import DivisionOfMedicaidComponent from './divisionofMedicaid';
import MississippiDepartmentofHuman from './mississippiDepartmentofHuman'

const ContactLocalOfficeComponent = (props) => {

	const {
		content,
		config
	} = props;

	

	let defaultLangId = Storage.getItem('defaultLangCode');
	defaultLangId = defaultLangId ? defaultLangId : 'en';

	const [loading, setLoading] = useState(false);

	return (
		<section className={`${config.theme ||
			'theme-background-light-grey'} py-3 py-md-5
                `}
		>
			<Container
				className="pb-3"
				id={config.id || ''}
			>
				<Row className="mb-3 justify-content-center no-gutters">
					<Col md={{ span: 12 }} >
						<Card className="ms-ContactLocalOfficeComponent-card-wrap section-style">
							<Card.Header className="border-0 bg-white">
								<Card.Title
									className="mb-0 d-flex justify-content-left ms-item-left"
								> {content.headline.text}
								</Card.Title>
							</Card.Header>
							<Card.Body>
								<Row className="mb-3 justify-content-center no-gutters">
									<Col md={4} className="mb-3">
										<DivisionOfMedicaidComponent content={content} />
									</Col>
									<Col md={8} className="mb-3">
										<MississippiDepartmentofHuman content={content} sizeOfarray={props && props.content && props.content.mdhs && props.content.mdhs.length} />
									</Col>
								</Row>
							</Card.Body>
						</Card>
					</Col>
				</Row>
			</Container>
		</section>
	);
};

export default ContactLocalOfficeComponent;
