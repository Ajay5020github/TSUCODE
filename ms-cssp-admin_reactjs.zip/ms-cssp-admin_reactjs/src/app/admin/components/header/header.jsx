

""
import React, { Component } from 'react';
import {
	Navbar,
	Nav,
	NavDropdown,
	Accordion,
	Card
} from 'react-bootstrap';
// import { NavLink, withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import './header.scss';
import "../../components/componentStyle.css"

import Storage from '../../utils/storage';
import CONFIG from '../../config/index.js';
import { isAuthenticated } from '../../utils/authenticate';
import { cpus } from 'os';
import {
	fetchAuthIdleTimeoutData
} from '../../actions/authIdleTimeout/authIdleTimeoutActions';
import createSetTimeoutPolyFill from "../../createSetTimeoutPolyFill"

export class Header extends Component {

	state = {
		isMobileView: false,
		accordians: null		
	}

	componentDidMount() {


		this.setMobileView();
		window.addEventListener('resize',/* istanbul ignore next */() => {
			this.setMobileView();
		});
		/* const { history } = this.props;
		history.listen(() => {
			history.go(1);
		}); */

	}

	setMobileView = () => {
		const innerWidth = window.innerWidth;
		if (innerWidth < 992) {
			/* istanbul ignore next */
			this.setState({ isMobileView: true });
		} else {
			this.setState({ isMobileView: false });
		}
	}
	render() {
		return (
			<div>
					<nav id="43" className="theme-ms-header-container header-container header navbar navbar-expand-lg navbar-light fixed-top">
						<div className="d-flex header-content-center">
						
							<span className="navbar-brand">
								<a href={this.props.jsonHeader && this.props.jsonHeader.config && this.props.jsonHeader.config.href} target="">
									<img src={this.props.jsonHeader && this.props.jsonHeader.config && this.props.jsonHeader.config.ImageWithLink} className="d-inline-block align-top header-logo" alt="State logo" title="" />
								</a>
							</span>
							
							<div className="ml-3 navbar-collapse collapse">
								<div className="ml-auto navbar-nav">
								{
										isAuthenticated() ? 									
										<div className="custom-welcom-user">
											<p><span> {this.props.jsonHeader && this.props.jsonHeader.config && this.props.jsonHeader.config.welcomeHeaderText} </span>{Storage.getItem('firstName') && Storage.getItem('firstName').charAt(0) && Storage.getItem('firstName').charAt(0).toUpperCase() + Storage.getItem('firstName').slice(1)} </p>
											<a className="text-uppercase font-weight-bold nav-link" target="_self" role="button" href="/admin/logout">{this.props.jsonHeader && this.props.jsonHeader.config && this.props.jsonHeader.config.logOutButton}</a> 
										</div> 
										: 
										null
									
								}
							</div>
						</div>
					</div>
				</nav>
			</div>
		);
	}
}

const mapStateToProps = state => ({
	authIdleTimeoutData: state.authIdleTimeoutReducer
		.authIdleTimeoutData,
	loading: state.authIdleTimeoutReducer.loading,
	error: state.authIdleTimeoutReducer.error
});

const mapDispatchToProps = (dispatch) => bindActionCreators(
	{
		fetchAuthIdleTimeoutData
	},
	dispatch
);

export default connect(mapStateToProps, mapDispatchToProps)(Header);
// export default Header;
