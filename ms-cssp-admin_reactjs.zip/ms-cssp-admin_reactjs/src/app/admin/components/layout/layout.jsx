import React from "react";
import Header from "../header";
// import './layout.scss';

const Layout = ({ children }) => {
    return (
        <div >
            <div >
                <Header /> {/* Including the Header component */}
                <div >{children}</div>
                {/* <footer>React admin template</footer> */}
            </div>
        </div>
    );
};

export default Layout;
