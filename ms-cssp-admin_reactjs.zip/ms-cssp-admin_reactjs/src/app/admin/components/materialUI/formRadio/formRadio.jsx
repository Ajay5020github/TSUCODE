/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
import React from 'react';
import PropTypes from 'prop-types';
import FormControl from '@mui/material/FormControl';
import { FormControlLabel, Radio, RadioGroup, FormLabel } from '@mui/material';
import './formRadio.module.scss';

const FormRadio = (props) => {
	const { field, fieldError, errorMessage, formData, handleChange, isRequired } = props;
	return (
		<FormControl required={isRequired == 1 ? true : false}>
			{field.fieldLabel ? <FormLabel>{field.fieldLabel}</FormLabel> : <FormLabel><span className="d-none">{field.name}</span></FormLabel>}
			<RadioGroup aria-label={field.name} name={field.name} value={formData} onChange={handleChange}>
				{field.options.map((option, optionIndex) => (
					<FormControlLabel
						key={`${field.name}-${optionIndex}`}
						value={option.value}
						control={<Radio color="primary" />}
						label={option.title}
					/>
				))}
			</RadioGroup>
		</FormControl>
	);
};
FormRadio.propTypes = {
	handleChange: PropTypes.func,
	fieldError: PropTypes.bool,
	formData: PropTypes.any,
	showPassword: PropTypes.any,
	field: PropTypes.shape({
		fieldType: PropTypes.string,
		dataType: PropTypes.string,
		fieldLabel: PropTypes.string,
		placeHolder: PropTypes.string,
		validations: PropTypes.arrayOf(
			PropTypes.shape({
				type: PropTypes.string,
				validationRule: PropTypes.string,
				errorMessage: PropTypes.string
			})
		),
		defaultValue: PropTypes.string,
		textAlign: PropTypes.string,
		hint: PropTypes.string,
		name: PropTypes.string,
		isRequired: PropTypes.number.isRequired,
		prefix: PropTypes.string,
		suffix: PropTypes.string,
		options: PropTypes.arrayOf(
			PropTypes.shape({
				value: PropTypes.string.isRequired,
				title: PropTypes.string.isRequired
			})
		),
		minLength: PropTypes.string,
		maxLength: PropTypes.string,
		minValue: PropTypes.string,
		maxValue: PropTypes.string
	}),
	errorMessage: PropTypes.string
};
export default FormRadio;
