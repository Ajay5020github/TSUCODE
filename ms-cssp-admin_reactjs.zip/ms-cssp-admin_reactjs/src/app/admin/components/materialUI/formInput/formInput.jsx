/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
import React from 'react';
import PropTypes from 'prop-types';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import Input from '@mui/material/Input';


const FormInput = props => {
	const {
		field, fieldError, errorMessage, formData, showPassword, handleChange, handleBlur
	} = props;
	const getInputType = (dataType, name) => {
		let type = dataType;
		switch (dataType) {
		case 'password':
			if (name === 'password' || name === 'newPassword') {
				if (showPassword) {
					type = 'text';
				} else {
					type = dataType;
				}
			}
			if (name === 'confirmPassword' || name === 'confirmNewPassword') {
				if (showPassword) {
					type = 'text';
				} else {
					type = dataType;
				}
			}
			break;
		default:
			type;
		}
		return type;
	};

	return (
		<FormControl
			fullWidth
			required={field.isRequired ? true : false}
			error={fieldError}
			className={`formInputadmin ${field?.name?field.name:""}`}
		>
			<InputLabel 
			required= {false} 
			htmlFor={field.name}
		// shrink=	{getInputType(field.dataType, field.name)!=="" && formData?true:true}
			>
				{field.fieldLabel}
				{field.isRequired && field.isAstrickRequired ? 
				<span className={'MuiFormLabel-asterisk'}>&nbsp;*</span> 
				: ''}
			</InputLabel>
			<Input
				autoComplete="off"
				name={field.name}
				type={
					getInputType(field.dataType, field.name)
				}
				id={field.name}
				value={formData}
				onChange={handleChange}
				onPaste={field.name ==='password' ? (e)=>{e.preventDefault();return false;} : ''}
				onBlur={handleBlur}
			/>
			{
				fieldError ? (
					<FormHelperText className="d-flex justify-content-between">
						<span>
							{errorMessage}
						</span>
						{/* <span>
							<img src="/src/resources/images/error_icon.png" alt={''} />
						</span> */}
					</FormHelperText>
				)
					: ''
			}
		</FormControl>
	);
};
FormInput.propTypes = {
	handleChange: PropTypes.func,
	handleBlur: PropTypes.func,
	fieldError: PropTypes.bool,
	formData: PropTypes.any,
	showPassword: PropTypes.any,
	field: PropTypes.shape({
		fieldType: PropTypes.string,
		dataType: PropTypes.string,
		fieldLabel: PropTypes.string,
		placeHolder: PropTypes.string,
		validations: PropTypes.arrayOf(
			PropTypes.shape({
				type: PropTypes.string,
				validationRule: PropTypes.string,
				errorMessage: PropTypes.string
			})
		),
		defaultValue: PropTypes.string,
		textAlign: PropTypes.string,
		hint: PropTypes.string,
		name: PropTypes.string,
		isRequired: PropTypes.number.isRequired,
		prefix: PropTypes.string,
		suffix: PropTypes.string,
		options: PropTypes.arrayOf(
			PropTypes.shape({
				value: PropTypes
					.string.isRequired,
				title: PropTypes
					.string.isRequired
			})
		),
		minLength: PropTypes.string,
		maxLength: PropTypes.string,
		minValue: PropTypes.string,
		maxValue: PropTypes.string
	}),
	errorMessage: PropTypes.string
};
export default FormInput;
