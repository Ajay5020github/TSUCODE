
"use client";
import React from 'react';
import PropTypes from 'prop-types';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import TextField from '@mui/material/TextField';
import dayjs, { format } from 'dayjs';

const FormDatePicker = (props) => {
  const {
    field,
    fieldError,
    errorMessage,
    formData,
    handleDateChange,
    handleBlur,
    pickerShowType,
    pickerShowTypeExists,
    format,
    isClearable,
    disabled,
  } = props;

  const [selectedDate, setSelectedDate] = React.useState(
    formData ? dayjs(formData) : null
  );

  const dateChange = (newValue) => {
    setSelectedDate(newValue);
    handleDateChange(newValue ? newValue.toDate() : null);
  };

  let maxDateValidation = dayjs('2100-01-01');
  if (field.validations.some((o) => o['validationRule'] === 'disableFuture')) {
    maxDateValidation = dayjs();
  }

  let minDateValidation = dayjs('1900-01-01');
  if (field.validations.some((o) => o['validationRule'] === 'disablePast')) {
    minDateValidation = dayjs();
  }

  let fData = isClearable ? formData : selectedDate;

  return (
    <FormControl fullWidth required={field.isRequired} error={fieldError} className={`adminDatePicker ${field?.name?field.name:""}`}>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
        className="customOutline"
          label={
            field.isRequired && field.isAstrickRequired ? (
              <span>
                {field.fieldLabel.trim()}
                <span className={'MuiFormLabel-asterisk'}>&nbsp;*</span>
              </span>
            ) : (
              field.fieldLabel.trim()
            )
          }
          value={fData ? dayjs(fData) : null} // Ensure value is Dayjs or null
          onChange={dateChange} // Handle date change
          onBlur={handleBlur}
          format={format || 'MM/DD/YYYY'}
          disabled={disabled || false}
          minDate={minDateValidation}
          maxDate={maxDateValidation}
          renderInput={(params) => <TextField {...params} />}
        />
      </LocalizationProvider>
      {fieldError && (
        <FormHelperText className="d-flex justify-content-between">
          <span>{errorMessage}</span>
        </FormHelperText>
      )}
    </FormControl>
  );
};

FormDatePicker.propTypes = {
  handleChange: PropTypes.func,
  handleBlur: PropTypes.func,
  fieldError: PropTypes.bool,
  formData: PropTypes.any,
  field: PropTypes.shape({
    fieldType: PropTypes.string,
    dataType: PropTypes.string,
    fieldLabel: PropTypes.string,
    placeHolder: PropTypes.string,
    validations: PropTypes.arrayOf(
      PropTypes.shape({
        type: PropTypes.string,
        validationRule: PropTypes.string,
        errorMessage: PropTypes.string,
      })
    ),
    defaultValue: PropTypes.string,
    textAlign: PropTypes.string,
    hint: PropTypes.string,
    name: PropTypes.string,
    isRequired: PropTypes.number.isRequired,
    prefix: PropTypes.string,
    suffix: PropTypes.string,
    options: PropTypes.arrayOf(
      PropTypes.shape({
        value: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
      })
    ),
    minLength: PropTypes.string,
    maxLength: PropTypes.string,
    minValue: PropTypes.string,
    maxValue: PropTypes.string,
  }),
  errorMessage: PropTypes.string,
};

export default FormDatePicker;

