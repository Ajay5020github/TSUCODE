/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
import React from 'react';
import PropTypes from 'prop-types';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';

const FormSelect = props => {
    const { field, fieldError, errorMessage, formData, handleChange } = props;

    return (
        <FormControl fullWidth required={!!field.isRequired} error={fieldError} className={`formSelectAdmin ${field?.name?field?.name:""}`}>
            {field.fieldLabel && <InputLabel htmlFor={field.name}>{field.fieldLabel}</InputLabel>}
            <Select
                value={formData}
                onChange={handleChange}
                name={field.name}
                id={field.name}
                inputProps={{ name: field.name, id: field.name }}
                className="customOutline"
            >
                {field.options.map((option, optionIndex) => (
                    <MenuItem
                        value={option.value}
                        key={`${field.name}-option-${optionIndex}`}
                    >
                        {option.title}
                    </MenuItem>
                ))}
            </Select>
            {fieldError && (
                <FormHelperText className="d-flex justify-content-between">
                    <span>{errorMessage}</span>
                </FormHelperText>
            )}
        </FormControl>
    );
};

// FormSelect.propTypes = {
//     handleChange: PropTypes.func.isRequired,
//     fieldError: PropTypes.bool,
//     formData: PropTypes.any,
//     field: PropTypes.shape({
//         fieldType: PropTypes.string,
//         dataType: PropTypes.string,
//         fieldLabel: PropTypes.string,
//         placeHolder: PropTypes.string,
//         validations: PropTypes.arrayOf(
//             PropTypes.shape({
//                 type: PropTypes.string,
//                 validationRule: PropTypes.string,
//                 errorMessage: PropTypes.string
//             })
//         ),
//         defaultValue: PropTypes.string,
//         textAlign: PropTypes.string,
//         hint: PropTypes.string,
//         name: PropTypes.string,
//         isRequired: PropTypes.number,
//         prefix: PropTypes.string,
//         suffix: PropTypes.string,
//         options: PropTypes.arrayOf(
//             PropTypes.shape({
//                 value: PropTypes.string.isRequired,
//                 title: PropTypes.string.isRequired
//             })
//         ),
//         minLength: PropTypes.string,
//         maxLength: PropTypes.string,
//         minValue: PropTypes.string,
//         maxValue: PropTypes.string
//     }).isRequired,
//     errorMessage: PropTypes.string
// };

export default FormSelect;
