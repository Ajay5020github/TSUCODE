/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
// import FormControl from '@mui/material/FormControl';
import FormControl from '@mui/material/FormControl';
import { FormControlLabel, Checkbox } from '@mui/material';
// import { FormControlLabel, Checkbox } from '@mui/material';



const FormCheckbox = (props) => {

    const {field, formData, handleChange } = props;
    const [isChecked, setIsChecked] = useState(!!formData);
    // Update the isChecked state when formData prop changes
    useEffect(() => {
        setIsChecked(!!formData);
    }, [formData]);

    // Handle the checkbox change
    const handleCheckboxChange = (event) => {
        setIsChecked(event.target.checked);
        handleChange(event); // Propagate the change to the parent component
    };

    return (
        <FormControl>
            <FormControlLabel
                className="mb-0 mr-0"
                control={
                    <Checkbox
                    className='customOutline'
                        required={field.isRequired ? true : false}
                        checked={isChecked}
                        color="primary"
                        name={field.name}
                        value={formData}
                        onChange={handleCheckboxChange}
                    />
                }
                label={field.fieldLabel}
            />
        </FormControl>
    );
};
FormCheckbox.propTypes = {
	handleChange: PropTypes.func,
	handleBlur: PropTypes.func,
    fieldError: PropTypes.bool,
    formData: PropTypes.any,
    showPassword: PropTypes.any,
    field: PropTypes.shape({
        fieldType: PropTypes.string,
        dataType: PropTypes.string,
        fieldLabel: PropTypes.string,
        placeHolder: PropTypes.string,
        validations: PropTypes.arrayOf(
            PropTypes.shape({
                type: PropTypes.string,
                validationRule: PropTypes.string,
                errorMessage: PropTypes.string
            })
        ),
        defaultValue: PropTypes.string,
        textAlign: PropTypes.string,
        hint: PropTypes.string,
        name: PropTypes.string,
        isRequired: PropTypes.number.isRequired,
        prefix: PropTypes.string,
        suffix: PropTypes.string,
        options: PropTypes.arrayOf(
            PropTypes.shape({
                value: PropTypes
                    .string.isRequired,
                title: PropTypes
                    .string.isRequired
            })
        ),
        minLength: PropTypes.string,
        maxLength: PropTypes.string,
        minValue: PropTypes.string,
        maxValue: PropTypes.string
    }),
    errorMessage: PropTypes.string
};
export default FormCheckbox;
