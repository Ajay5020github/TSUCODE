import React from "react";
import { FormLabel } from "react-bootstrap";
import getValidationState from "./getValidationState";
import FormGroup from '@mui/material/FormGroup';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import InputLabel from '@mui/material/InputLabel';
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import Input from '@mui/material/Input';
import DateFnsUtils from '@date-io/date-fns';
import Tooltip from '@mui/material/Tooltip';
import InputAdornment from '@mui/material/InputAdornment';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import "../componentStyle.css";
import { renderReactParser } from "../../containers/wizard/customControl";
import Grid2 from '@mui/material/Grid2';
import debounce from 'lodash/debounce';
import { getSteps, isFieldType, getField, setField, getSubField, setSubField, getFieldValue,getFieldFromSub } from "../../containers/wizard/helper"
import { validateDate, validateInput, validateRadio, validateSelect, checkDateValidation } from "../../containers/wizard/validations"
 import createSetIntervalPolyFill from "../../createSetIntervalPolyFill"
export default class TextBox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: "",
      showAppUpdateStatus: false,
      selectedDate: this.props.ivalue ? this.props.ivalue : null,
      text: ""
    }
    this.value = "";
  }

  onChange = (e, id) => {
    if (e.currentTarget.type === "text" || e.currentTarget.type === "number" || e.currentTarget.type === "currency") {

       this.setState({ text: e.target.value });

      if (event && event.target) {
        var steps = getSteps();
        var field = getFieldFromSub(id, this.props.currentStepIndex);
        var subField = setSubField(field.id, id, e.target.value, this.props.currentStepIndex);

        if(subField != null) {

          var { error, errorType, stripval, stripvallen, currencyval, policyval } = validateInput(e.target, this.props.validations);
          if (stripval || stripval === "") {
            subField.currentValue = stripval;
            subField.value = stripval;
            this.setState({ text: stripval });
            error = stripval && stripval.length.toString() === stripvallen ? null : error
          }
          if (currencyval || currencyval === "") {
            subField.currentValue = currencyval;
            subField.value = currencyval;
            this.setState({ text: currencyval });
          }
          if (policyval || policyval === "") {
            subField.currentValue = policyval;
            subField.value = policyval;
            this.setState({ text: policyval });
          }

          if (e.currentTarget && e.currentTarget.type === "checkbox") {
            val = e.currentTarget.checked === true ? 'YES' : 'NO'
          }
         
          var obj = subField.validations && subField.validations.filter(v => v.validation === errorType)[0]


          if (typeof obj !== 'undefined' && error != null) {
            subField.errorMessage = obj.message; //current errorMessagehave to the empty on value change
            subField.errorType = errorType;
          }
          else {
            subField.errorMessage = "";
            subField.errorType = "";
          }

          this.setState({
            steps: steps,
          });


        }
        else {


          var steps = getSteps();
          var field = setField(id, e.target.value, this.props.currentStepIndex);

          var { error, errorType, stripval, stripvallen, currencyval } = validateInput(e.target, this.props.validations);
          if (stripval || stripval === "") {
            field.currentValue = stripval;
            field.value = stripval;
            this.setState({ text: stripval });
            error = stripval && stripval.length.toString() === stripvallen ? null : error
          }

          if (currencyval || currencyval === "") {
            field.currentValue = currencyval;
            field.value = currencyval;
            this.setState({ text: currencyval });
          }

          var obj =  field.validations && field.validations.filter(v=> v.validation === errorType)[0]


          if(typeof obj !== 'undefined' && error != null){
              field.errorMessage = obj.message; //current errorMessagehave to the empty on value change
              field.errorType = errorType;
          }
          else {
              field.errorMessage = "";
              field.errorType = "";
          }

          this.setState({
          steps: steps,
          });
        }

      }



      if(e.target.value === "" || e.target.value.length ==  this.maxlength)
          this.props.input.onChange(e, id);
      else
          this.sendOnChange(e, id);
    }
    else
      this.props.input.onChange(e, id);
  };

  sendOnChange = (e, id) => {
    this.props.input.onChange(e, id);
  };

  componentDidMount() {
    const {setIntervalPolyFill, clearIntervalPolyFill} = createSetIntervalPolyFill();
    if (this.props.type === "" || this.props.type === "text" ) {
      this.sendOnChange = debounce(this.sendOnChange, 1000);

      var interval = setIntervalPolyFill(() => {
        if (this.props.ivalue) {
          this.setState({ text: this.props.ivalue });
          clearIntervalPolyFill(interval);
        }
      }, 1000)

    }


   if(this.props.type === "currency" || this.props.type === "number") {

      this.sendOnChange = debounce(this.sendOnChange, 1000);

      var interval = setIntervalPolyFill(() => {
        if(this.props.ivalue !== "") {  
          this.setState({ text: this.props.ivalue });
          clearIntervalPolyFill(interval);
        }
      }, 1000);

   }


    if(this.props && this.props.validations &&
    this.props.validations.filter(x => x.validation == "StripChar").length > 0)
    this.maxlength = this.props.validations.filter(x => x.validation == "StripChar")[0].striplength

  }


  handleOnBlur = (e, id) => {

   
    var steps = getSteps();
    var field = getFieldFromSub(id, this.props.currentStepIndex);
    var subField = setSubField(field.id, id, e.target.value, this.props.currentStepIndex);


    if(subField && subField.dollarSymbolRequired){
      var dotIndex = e.currentTarget.value && e.currentTarget.value.indexOf('.');
      if(dotIndex === 0 && subField.currentValue !== 0 && subField.currentValue != "."){
        subField.currentValue= `0${e.currentTarget.value}`;
        e.currentTarget.value=`0${e.currentTarget.value}`;
      }
      subField.currentValue = parseFloat(subField.currentValue).toFixed(2);
      if(subField.currentValue === "NaN"){
        subField.currentValue = "";
      }
      this.setState({ text: subField.currentValue });
      this.setState({
        steps: steps,
      });
      this.props.input.onBlur(e, id);
    }
    else 
      this.props.input.onBlur(e, id);

    // Melissa API Validation
    this.props && this.props.validations && this.props.validations.forEach((validateRule) => {
      if (validateRule.validation === 'IsAddressValid') {
        this.props.addressValidation(e, id);
      }

    });
  }


  UNSAFE_componentWillReceiveProps(nextProps){

    if (this.props.type === "" || this.props.type === "text" || this.props.type === "number" || this.props.type === "currency" ) {

     if (this.state.text != nextProps.ivalue) {
          this.setState({ text: nextProps.ivalue });
     
        }
    }

  }


  // code to  validate maxlength of input have type as number
  handleMaxlengthOfNumberType = (e, id) => {
    /**
     * Added only to prevent the characters in the defined array
     */
    const symbolsArr = ["e", "E", "+", "-", "."];
  if (e.type === "keydown" && e.target.type && e.target.type === "number") {
    if (symbolsArr.includes(e.key)) {
      e.preventDefault();
    }
  } else {
    if ((e.type === "paste" && e.target.type && e.target.type === "number") || (e.type === "drop" && e.target.type && e.target.type === "number")) {
      var textContent = (e.type === "paste" ? e.clipboardData : e.dataTransfer).getData('text');
      if (isNaN(textContent) || (textContent.indexOf(".") > -1)) {
        e.preventDefault();
      }
    }
  }

  }

  handleOnKeyUp = (e, id) => {
    var charCode = (e.which) ? e.which : e.keyCode;
    if (this.props.type && this.props.type === "number") {
      /**
       * Allowing only numbers and remainig preventing for the type of "number"
       */
      if (!(charCode >= 48 && charCode <= 57)) {
        e.preventDefault();
      }
    }
    if (this.props.type && this.props.type === "currency") {
      var number = e.target.value.split('.');
      /**
       * Allowing only numbers and remainig alphabets preventing for the type of "currency"
       */
      if (!(charCode >= 48 && charCode <= 57)) {
        e.preventDefault();
      }
      /**
       * Preventing dot
       */
      if (number.length > 1 && charCode == 46) {
        e.preventDefault();
      }

      e.target.value = e.target.value
        .replace(/[^\d.]/g, '')
        .replace(new RegExp("(^[\\d]{7})[\\d]", "g"), '$1')
        .replace(/(\..*)\./g, '$1')
        .replace(new RegExp("(\\.[\\d]{2}).", "g"), '$1');

      this.props.input.onChange(e, id);
    }
  }


  handleDateChange = (e, id) => {
    this.setState({ selectedDate: e });
    this.props.input.onChange(e, id);
  };

  render() {
    const {
      input,
      type,
      meta,
      label,
      style,
      onClick,
      placeholder,
      ivalue,
      disabled,
      onChange,
      waterMark,
      id,
      required,
      validations,
      tooltipRequired,
      currentStepIndex,
      addressValidation,
      maxlength,
      errorMessage,
      dollarSymbolRequired
    } = this.props;
    if (ivalue != "") input.value = ivalue;
    let checkBoxValue = false;
    this.type = type;

    var minimumDate = new Date();
    minimumDate.setDate(minimumDate.getDate() - new Date().getDate() + 1);
    var maximumDate = new Date();

    let maxDateValidation = validations ? validations.filter((v) => v.validation === "maxDate")[0] : null;
    let isMaxDateExist = maxDateValidation ? maxDateValidation.daysToBeAdded && maxDateValidation.maxDate ? maximumDate.setDate(minimumDate && minimumDate.getDate() + maxDateValidation.daysToBeAdded) : maxDateValidation.maxDate : new Date("2100-01-01");

    let minDateValidation = validations ? validations.filter((v) => v.validation === "minDate")[0] : null;
    let isMinDateExist = minDateValidation && minDateValidation.isMinDateToday ? minDateValidation.minDate : minDateValidation ? minimumDate : new Date("1900-01-01");

    if (type == "checkbox") {
      if (typeof ivalue == "boolean") {
        checkBoxValue = ivalue
      }
      else if (typeof ivalue == 'string' && ivalue.toLowerCase() == "YES".toLowerCase()) {
        checkBoxValue = true;
      }
    }

    let onlyYears = validations ? validations.filter((v) => v.validation === "showMode")[0] : null;
    let pickerShowType = onlyYears && onlyYears.minYear === "1901";
    var maxYear = (new Date().getFullYear() + 1).toString();

    return (
      (<FormGroup validationState={getValidationState(meta)}>
        {type == "checkbox" ? (
          // <div className="checkbox-text form-group">
          //   <input
          //     type="checkbox"
          //     className="custom-checkbox"
          //     onChange={e => this.onChange(e, id).bind(this)}
          //   />{" "}
          //   <span className="checkbox-text-value">{label}</span>
          // </div>

          (<FormGroup aria-label={label} >
            <FormControlLabel
              control={<Checkbox color="primary" />}
              label={label}
              labelPlacement={label}
              type="checkbox"
              id={id}
              checked={checkBoxValue}
              onChange={e => this.onChange(e, id)}
              disabled={disabled ? disabled : false}
            />
          </FormGroup>)
        ) : type == "button" ? (
          <Button variant="contained" onClick={onClick}>{label}</Button>
        ) : (
              <div>
                {typeof label !== "undefined" ? (
                  <span className="">{}</span>
                ) : null}

                {typeof type !== "undefined" &&
                  typeof input !== "undefined" &&
                  typeof style !== "undefined" &&
                  typeof placeholder !== "undefined" ? (
                    <div class="">
                      {type == 'date' ?
                        <div className="cstmdateStyle">
                          <FormControl fullwidth >
                            {label !== "" ? (<FormLabel for={label} className="date-label-design">{label}</FormLabel>) : null}
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                              <KeyboardDatePicker
                                variant="inline"
                                views={pickerShowType ? ["year"] : ["year", "month", "date"]}
                                openToYearSelection={true}
                                format={pickerShowType ? 'yyyy' : 'MM/dd/yyyy'}
                                margin="normal"
                                placeholder={renderReactParser(waterMark)}
                                minDate={pickerShowType ? '1901' : isMinDateExist}
                                id={id}
                                autoOk={true}
                                maxDate={pickerShowType ? maxYear : isMaxDateExist}
                                label={required ? <span>{placeholder.replace(/\s+$/, '')}<span style={{ color: "#c92500" }}>&nbsp;*</span></span> : placeholder.replace(/\s+$/, '')}
                                value={this.props.ivalue ? this.props.ivalue : null}
                                onChange={e => this.handleDateChange(e, id)}
                                onBlur={e => this.handleOnBlur(e, id)}
                                KeyboardButtonProps={{
                                  'aria-label': { placeholder },
                                }}
                                InputProps={{ readOnly: true }}
                                invalidDateMessage={false}
                                maxDateMessage={false}
                                minDateMessage={false}
                                disabled={disabled ? disabled : false}
                              />
                            </MuiPickersUtilsProvider>
                          </FormControl>
                        </div>
                        :
                        <div>
                          {/* {dollarSymbolRequired ? <div style={{marginBottom:"-82px",marginLeft:"-11px"}}>$</div> : null } */}

                          {label !== "" ? (<FormLabel for={label} className={this.props.style === "dynamic-cust-cap-mrgn-lg-txt" ? "label-design-lg" : "label-design"}>{renderReactParser(label)} {tooltipRequired && tooltipRequired.required === true && tooltipRequired.tooltipDisplayNextToCaption === true ? (<Tooltip title={tooltipRequired.message} placement="bottom" enterTouchDelay={0}><img src="/src/resources/images/info_icon.png" alt="info" /></Tooltip>) : null}</FormLabel>) : null}
                          {dollarSymbolRequired ?
                          <Grid2 container alignItems="flex-end"  style={{marginLeft:"2%"}}>
                          <Grid2 item className="dollarAlignment">
                            $
                          </Grid2>
                        <Grid2 item style={{width:"98%"}}>
                        <FormControl fullWidth >
                            <InputLabel error={errorMessage ? true : null} htmlFor={this.props.id} className={label !== "" ? "inner_label_style control-input-cap-mrgn" : ""}>{placeholder.replace(/\s+$/, '')}{required ? <span style={{ color: "#c92500" }}>&nbsp;*</span> : null}</InputLabel>
                            <Input
                              type={type}
                              name={name}
                              disabled={disabled ? disabled : false}
                              id={id}
                              error={errorMessage ? true : null}
                              autoComplete="off"
                              value={this.state.text}
                              className={this.props.style == 'cursive-text-field' ? 'cursive-text-field' : null}
                              inputProps={{ maxLength: maxlength }}
                              endAdornment={
                                tooltipRequired && tooltipRequired.required === true && tooltipRequired.tooltipDisplayOnInputEnd === true ? (<InputAdornment position="end">
                                  <Tooltip title={tooltipRequired.message} placement="bottom" enterTouchDelay={0}><img src="/src/resources/images/info_icon.png" alt="info" /></Tooltip>
                                </InputAdornment>) : null
                              }
                              //startAdornment={dollarSymbolRequired ? (<InputAdornment position="start">$</InputAdornment>) : null}
                              //maxLength={maxlength}
                              onBlur={e => this.handleOnBlur(e, id)}
                              //onMouseOut={e => this.handleMouseOut(e, id)}
                              onChange={(e) => { e.persist(); this.onChange(e, id); }}
                              // onKeyUp={e =>this.handleOnKeyUp(e, id) }
                              onKeyDown={e => this.handleMaxlengthOfNumberType(e, id)}
                            />
                          </FormControl>
                          </Grid2>
                          </Grid2>
                        :
                          <FormControl fullWidth >
                            <InputLabel error={errorMessage ? true : null} htmlFor={this.props.id} className={label !== "" ? "inner_label_style control-input-cap-mrgn" : ""}>{placeholder.replace(/\s+$/, '')}{required ? <span style={{ color: "#c92500" }}>&nbsp;*</span> : null}</InputLabel>
                            <Input
                              type={type}
                              name={name}
                              disabled={disabled ? disabled : false}
                              id={id}
                              error={errorMessage ? true : null}
                              autoComplete="off"
                              value={this.state.text}
                              className={this.props.style == 'cursive-text-field' ? 'cursive-text-field' : null}
                              inputProps={{ maxLength: maxlength }}
                              endAdornment={
                                tooltipRequired && tooltipRequired.required === true && tooltipRequired.tooltipDisplayOnInputEnd === true ? (<InputAdornment position="end">
                                  <Tooltip title={tooltipRequired.message} placement="bottom" enterTouchDelay={0}><img src="/src/resources/images/info_icon.png" alt="info" /></Tooltip>
                                </InputAdornment>) : null
                              }
                              //startAdornment={dollarSymbolRequired ? (<Inpuvalue={this.state.text}tAdornment position="start">$</InputAdornment>) : null}
                              //maxLength={maxlength}
                              onBlur={e => this.handleOnBlur(e, id)}
                              //onMouseOut={e => this.handleMouseOut(e, id)}
                              onChange={(e) => { e.persist(); this.onChange(e, id); }}
                              // onKeyUp={e =>this.handleOnKeyUp(e, id) }
                              onKeyDown={e => this.handleMaxlengthOfNumberType(e, id)}
                              onPaste={e => this.handleMaxlengthOfNumberType(e, id)}
                              onDrop={e => this.handleMaxlengthOfNumberType(e, id)}
                            />
                          </FormControl>
                        }
                        </div>
                      }
                      {required ? (
                        <span className="">

                        </span>
                      ) : null}
                    </div>
                  ) : null}
              </div>
            )}
        {errorMessage ?
          <div className={dollarSymbolRequired ? "errormessageclass dollaramt" : "errormessageclass"}>

            <span className="error-text">
              {errorMessage}
            </span>
            {/* <span className="error-icon">
              <img src="/src/resources/images/error_icon.png" alt={''} />
            </span> */}
          </div>
          : null}
      </FormGroup>)
    );
  }
}
