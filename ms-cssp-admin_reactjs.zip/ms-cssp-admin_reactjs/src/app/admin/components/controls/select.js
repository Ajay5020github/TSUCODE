import React from "react";
import { FormLabel } from "react-bootstrap";
import FormGroup from '@mui/material/FormGroup';
import getValidationState from "./getValidationState";
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import { Select, MenuItem } from '@mui/material';

import "../componentStyle.css";
import { tsPropertySignature } from "@babel/types";

export default class Input extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: "",
      selectedVal:props.ivalue
    }
    this.props.input.value = this.props && this.props.ivalue;
  }

    handleOnBlur = (e, id) => {
      this.props.input.onBlur(e, id);
  }

  
    onChange = (e) => {
      this.props.input.onChange(e);
    };

    static getDerivedStateFromProps(props, state) {      
     if(props.ivalue){
      return {selectedVal:props.ivalue}
     }else{
       return {selectedVal:""}
     }
  }
render() {
  const { input, meta, label, disabled,options, placeholder, id, name, ivalue, style,required,validations,currentStepIndex,errorMessage } = this.props;
  return (
    (<FormGroup validationState={getValidationState(meta)}>
      {label !== "" ? (<FormLabel for={label} className="label-design cust-caption">{label}</FormLabel>): null}
      <FormControl fullWidth >
      <InputLabel id={this.props.id} htmlFor={this.props.id}>{placeholder.replace(/\s+$/, '')}{required? <span style={{ color: "#c92500" }}>&nbsp;*</span> : null}</InputLabel>
      {options && options.length>0 ? <Select inputProps={{
            name: this.props.id,
            id: this.props.id,
          }} 
          error={errorMessage? true : null} 
		  disabled={disabled ? disabled : false}
          value={this.state.selectedVal} 
          onChange={e => this.onChange(e,this.props.id)}
          onBlur={e => this.handleOnBlur(e, id)}>
        
        {options.map(({ value, title }, index) => (
          <MenuItem value={value} key={`${value}_${index}`}>{title}</MenuItem>
        ))}
      </Select>:<Select
                    inputProps={{
                      name: this.props.id,
                      id: this.props.id ,
                    }}
                    error={errorMessage? true : null} 
                    onChange={e => this.onChange(e)}
                    value={this.props.ivalue}
                  >
                    {this.props &&
                      this.props.members &&
                      this.props.members.map((member,i) => (
                        <MenuItem key={i} value={member.value} >{member.value}</MenuItem>
                      ))}
                  </Select>}
      </FormControl>
      {errorMessage ? 
      <div error={errorMessage ? true : null} className="errormessageForSelectclass">
          <span className="error-text">
          {this.state.error === "" ?  errorMessage : this.state.error}
          </span>
          {/* <span className="error-icon">
            <img src="/src/resources/images/error_icon.png" alt={''} />
          </span> */}
        </div> 
        :  null }
    </FormGroup>)
  );
}
}

