import React from "react";
//import { FormLabel, ToggleButton, FormGroup } from "react-bootstrap";
import getValidationState from "./getValidationState";
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import Tooltip from '@mui/material/Tooltip';
import "../componentStyle.css";
import { renderReactParser } from "../../containers/wizard/customControl";

export default class Input extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: ""
    }
  }
  
  onChange = (value, id) => {
    this.props.input.onChange(value, id);
    var error = null;
    this.props && this.props.validations && this.props.validations.forEach((validateRule) => {

      if (validateRule.validation === 'IsMandatory') {
        if (value === "") {
          error = validateRule.message;
        }
      }
    });
    this.setState({
      error: error
    })
  };
  onBlur = (e, id) => {
    this.props.input.onBlur(e, id);
    var error = null;
    this.props && this.props.validations && this.props.validations.forEach((validateRule) => {

      if (validateRule.validation === 'IsMandatory') {
        if (e.target.value === "") {
          error = validateRule.message;
        }
      }
    });
    this.setState({
      error: error
    })
  };
  
  render() {
    const { input, meta, label, options, id, ivalue, style, required, validations, currentStepIndex,tooltipRequired, errorMessage,disabled } = this.props;
    return (
      (<FormControl>
        <FormLabel for={label.replace(/\s+$/, '')} className="label-design cust-caption">
          {renderReactParser(label.replace(/\s+$/, ''))}
          {required ? <span style={{ color: "#c92500" }}> *</span> : ""}
          {tooltipRequired && tooltipRequired.required ? (<Tooltip title={tooltipRequired.message} placement="bottom" enterTouchDelay={0}><img src="/src/resources/images/info_icon.png" alt="info"  style={{marginLeft: "10px"}}/></Tooltip>): null}
        </FormLabel>
        <RadioGroup row aria-label={label.replace(/\s+$/, '')} name={label} validationState={getValidationState(meta)} >
          {
            options && options.map(({ value, title }, index) => (
              <FormControlLabel
                value={this.props.ivalue}
                control={<Radio color="primary" />}
                label={title}
                checked={value.toLowerCase() === (ivalue?ivalue.toLowerCase():null)}
                onChange={() => this.onChange(value, id)}
                //onBlur={(e) => this.onBlur(e, id)}
                key={`${value}_${index}`}
                disabled={disabled ? disabled:false}
              />
            ))
          }
          {errorMessage ?
          <div className="errormessage-radio-class">
            <span className="error-text">
              {this.state.error === "" || this.state.error === null ? errorMessage : this.state.error}
            </span>
            {/* <span className="error-icon">
              <img src="/src/resources/images/error_icon.png" alt={''} />
            </span> */}
          </div>
          : null }
        </RadioGroup>
      </FormControl>)
    );
  };
}
