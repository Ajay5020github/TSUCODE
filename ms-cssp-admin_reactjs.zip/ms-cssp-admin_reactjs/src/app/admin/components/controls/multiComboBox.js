import React from "react";
import { FormGroup } from "react-bootstrap";
import Table from '@mui/material/Table';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import "../componentStyle.css";

export default class MultiCombBOX extends React.Component {
    constructor(props) {
        super(props);
        this.errors = "";
        this.state = {
            memberList: [
                {
                    label: "one l",
                    value: "one l",
                    personNameIndex: 1
                },
                {
                    label: "Two l",
                    value: "Two l",
                    personNameIndex: 2
                },
                {
                    label: "three l",
                    value: "three l",
                    personNameIndex: 3
                },
            ]
        };
    }



    render() {
        return (
            <FormGroup>
                <div class="section-fields">
                    <div class="field field-type-table field-name-householdmemberprogram">
                        <div class="table-responsive">
                            <TableContainer className="">
                                <Table aria-label="simple table">
                                    <TableHead className="">
                                        <TableRow>
                                        <Checkbox color="primary"> {'Selelct all'}</Checkbox>
                                            {this.state.memberList &&
                                                this.state.memberList.map((f,index) => (                                                  
                                                    <TableCell key={index} className="tableHeadCellStyle" align="left">
                                                          <Checkbox color="primary" />
                                                        {f.label}</TableCell>
                                                ))}
                                        </TableRow>
                                    </TableHead>
                                </Table>
                            </TableContainer>
                        </div>
                    </div>
                </div>
            </FormGroup>
        );
    }
}


