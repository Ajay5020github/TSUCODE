import React from "react";
import { FormLabel } from "react-bootstrap";
import FormGroup from '@mui/material/FormGroup';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import "../componentStyle.css";

export default class CheckboxList extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        error: "",
        selectedVal: this.props.options,
      }
    }

    formingInput = (e,id) =>{
        let options = this.state.selectedVal
        options[id].checked = e.target.checked
        let reasons = []
        options.forEach(opt=>{
            if(opt.checked) reasons.push(opt.label)
        })
        this.setState({selectedVal:options});
        return reasons;
    }
    onChange = (e,id) =>{
        let reasons = []
        reasons = this.formingInput(e,id)
        this.props.input.onChange(reasons,this.props.id)
    }

    static getDerivedStateFromProps(props, state) {
        if(props.ivalue){
            props.ivalue.forEach(val=>{
                state.selectedVal.forEach(opt=>{
                    if(opt.lable===val){
                        opt.checked = true;
                    }
                })
            })
            return {selectedVal:state.selectedVal}
        }
    }

    handleOnBlur = (e, id) => {
        let reasons = []
        reasons = this.formingInput(e,id)
        this.props.input.onBlur(reasons, this.props.id);
    }
    
    render(){
        return (
            <FormControl>
            <FormLabel>{this.props.caption}</FormLabel>
            <FormGroup>
                {this.state.selectedVal && this.state.selectedVal.map((opt,id)=>{                   
                  return(<FormControlLabel
              control={<Checkbox color="primary" />}
              key={id}
              label={opt.label}
              labelPlacement={opt.label}
              type="checkbox"
              id={this.props.id}
              checked={opt.checked}
              onChange={e => this.onChange(e, id)}
             // onBlur={e => this.handleOnBlur(e, id)}
            />)
                })}
              
            </FormGroup>
            {this.props.errorMessage ?
          <div className="errormessageclass">

            <span style={{ color: "#c92500", fontSize: "0.75rem" }}>
              {this.props.errorMessage}
            </span>
            <span style={{ float: "right", marginRight: "5px" }}>
              <img src="/src/resources/images/error_icon.png" alt={''} />
            </span>
          </div>
          : null}
          </FormControl>
        )
    }
}