/*
 * This component is used to render
 * the user dashboard after login where other primary
 * components are rendered.
 */

import React from 'react';
import PropTypes from 'prop-types';
import './adminReport.scss';
// import { useHistory } from "react-router";
import { useRouter } from 'next/navigation';
import Button from '@mui/material/Button';
import Storage from '../../utils/storage';

const AdminReportComponent = (props) => {
    const { replace } = props; 
    // const history = useHistory();
    const router = useRouter();

    /* istanbul ignore next */
    const redirectJSONEditor = () => {
        // router.push({
        //     pathname: "/jsoneditor",
        //     state: {
        //         response: ''
        //     }
        // });
        replace("/admin/jsoneditor")
    }

    
    const redirectReportDetail = (reportID, WorkspaceID) => {
        // router.push({
        //     pathname: "/reportDetail",
        //     query:{
        //     reportId: reportID,
        //     workspaceId: WorkspaceID
        //     }
        // });
        Storage.setItem('reportId',reportID)
        Storage.setItem('workspaceId',WorkspaceID)
 
        replace("/admin/reportDetail")
    }
    const enterKeyPress = (event, reportId, workspaceId) => {       
        if(event.keyCode === 13){
            redirectReportDetail(reportId, workspaceId);
        }
    }

    return (
        <div>

            <div id="468" className="banner theme-ms-background-dark short right container reportitle">
                <div className="row">
                    <div className="col-lg-9 col-md-12 col-sm-12">
                        <div className="text-center text-lg-left banner-content">
                            <h1 className="banner-headline-report">Summary Reports</h1>
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid-container">                

                {props.adminReportLabelData && props.adminReportLabelData.reportData && props.adminReportLabelData.reportData.map((item, index) => (   
                  
                    item.environment === props.environment ? 
                    item.summaryReports && item.summaryReports.length > 0  ? 
                    item.summaryReports.map((reportData, reportIndex) => (  
                  
                        <div key={reportIndex} className="item1 col-lg-12" tabIndex= '0' onKeyDown = {(e) => (enterKeyPress(e, reportData.reportId, reportData.workspaceId))} onClick={() => redirectReportDetail(reportData.reportId, reportData.workspaceId)}>
                            <div className="col-lg-3"><img src={props.adminReportLabelData && props.adminReportLabelData.content && props.adminReportLabelData.content.labels.config.reportImage } alt="reportIcon"></img>
                            </div>
                            <div className="col-lg-9"><span>{reportData.report}</span></div>                            
                        </div>
                    )) : <h4>No Summary reports are available. Please contact administrator.</h4>
                    :  ""
                ))}
            </div>

            <br/><br/>           

            <div id="468" className="banner theme-ms-background-dark short right container">
                <div className="row">
                    <div className="col-lg-9 col-md-12 col-sm-12">
                        <div className="text-center text-lg-left banner-content">
                            <h1 className="banner-headline-report">Analytical Reports</h1>
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid-container">                

                {props.adminReportLabelData && props.adminReportLabelData.reportData && props.adminReportLabelData.reportData.map((item, index) => (   
                  
                    item.environment === props.environment ? 
                    item.analyticalReports && item.analyticalReports.length > 0  ? 
                    item.analyticalReports.map((reportData, reportIndex) => (  
                  
                        <div key={reportIndex} className="item1 col-lg-12" tabIndex= '0' onKeyDown = {(e) => (enterKeyPress(e, reportData.reportId, reportData.workspaceId))} onClick={() => redirectReportDetail(reportData.reportId, reportData.workspaceId)}>
                            <div className="col-lg-3"><img src={props.adminReportLabelData && props.adminReportLabelData.content && props.adminReportLabelData.content.labels.config.reportImage } alt="reportIcon"></img>
                            </div>
                            <div className="col-lg-9"><span>{reportData.report}</span></div>
                        </div>
                    )) : <h4>No Analytical reports are available. Please contact administrator.</h4>
                    :  ""
                ))}
            </div>

        </div>
    );
};

// AdminReportComponent.displayName = "Admin Report";

function AdminReportWithRouter(props) {
    const { replace } = useRouter();
    return <AdminReportComponent {...props} replace={replace} />;
}
export default AdminReportWithRouter;
