/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
import React from 'react';
import {
	Row, Col, Button, Form, Card, Container
} from 'react-bootstrap';
import PropTypes from 'prop-types';

import './loginForm.scss';
import "../../containers/custom.css"
import CustomModal from '../modal/customModal';
// import { Link } from 'react-router-dom';
import Link from 'next/link';
import FormInput from '../materialUI/formInput/formInput';
import FormCheckbox from '../materialUI/formCheckbox/formCheckbox';
import { ERROR_MESSAGES } from '../../resources/data/errorMessages';
import Storage from '../../utils/storage';
import FormSelect from '../materialUI/formSelect/formSelect';
import { Grid2 } from '@mui/material';

const LoginForm = (props) => {

	const {
		className,
		config,
		content,
		componentState,
		handleChange,
		loginappBlur,
		invalidData,
		validData,
		onClickSubmit,
		showSubmitModal,
		onShowSubmitModal,
		onShowChangePasswordModal,
		onClickGoBackToHome,
		onSubmitModalButtonClick,
		handleBlur
	} = props;

	const {
		headline,
		userLoginDetails,
		primaryButton,
		forgotLinks,
		backToSignupLink,
		modal
	} = content;

	const apps =[ 'Internal', 'DOM' , 'MDHS' ]

	let defaultLangId = Storage.getItem('defaultLangCode');
	const options = [
		{ label: 'DOM', value: 'DOM' },
	
	  ];
	defaultLangId = defaultLangId ? defaultLangId : 'en';

	const getUserLoginDetails = (userLoginDetails) => {
		const { formErrors, isFormSubmited, 		formDataSet } = componentState;
		
		return userLoginDetails.map((elem, index) => {
			if (elem.fieldType.toLowerCase() === 'select') {
				return (

					<Form.Group
						key={index}
						as={Col}
						className={'input-root form-group'}
						md={12}
					>
					<FormSelect
						field={elem}
						formData={formDataSet && formDataSet[elem.name] ? formDataSet[elem.name] : elem.defaultValue ? elem.defaultValue : ''}
						fieldError={
							formErrors
							&& !formErrors[elem.name]?.isValid
							&& (
								formErrors[elem.name]?.isTouched
								|| isFormSubmited
								)
							}
							errorMessage={
							formErrors
							&& formErrors[elem.name]
							?.activeValidator
							.errorMessage
							}
							handleChange={/* istanbul ignore next */(e)=>loginappBlur(e,elem)}
						/>
						</Form.Group>
					);


			}
				else if (elem.fieldType.toLowerCase() === 'input') {
		
					return (
						<Form.Group
							key={index}
							as={Col}
							className={'input-root form-group'}
							md={12}
						>
							{/* */}
				
							<FormInput
								field={elem}
								fieldError={
									formErrors
									&& !formErrors[elem.name]?.isValid
									&& (
										formErrors[elem.name]?.isTouched
										|| isFormSubmited
									)
								}
								errorMessage={
									formErrors
									&& formErrors[elem.name]
										?.activeValidator
										.errorMessage
								}
								formData={componentState[elem.name] ? componentState[elem.name] : ''}
								showPassword={elem.name === 'password' ? componentState.showPassword : false}
								handleChange={/* istanbul ignore next */(e) => handleChange(e, elem)}
								handleBlur={handleBlur}
							/>

						</Form.Group>
								
					);
			} else if (elem.fieldType.toLowerCase() === 'checkbox') {
				return (
					<Form.Group
						key={index}
						as={Col}
						className={'checkbox-root mb-0 d-flex justify-content-end'}
						md={12}
					>
						<FormCheckbox
							field={elem}
							fieldError={formErrors ? formErrors[elem.name] : false}
							isFormSubmited={isFormSubmited}
							formData={componentState[elem.name] ? componentState[elem.name] : false}
							handleChange={handleChange}
						/>

				

			
				
					</Form.Group>
					  
						 
			
					
				);
			}
		});
	};

	const getPrimaryButton = (primaryButton, modal) => {
		return (
			<Form.Group
				as={Col}
				md={12}
				className="mt-3"
			>
				<Button variant="dark"
					type="submit"
					onClick={/* istanbul ignore next */(e) =>
						onClickSubmit(e)}>
					{primaryButton[0]
						.text.toUpperCase()}
				</Button>
				{modal.length ? modalSelection(modal) : ''}
			</Form.Group>
		);
	};
	const modalSelection = (modal) => {
		if (modal) {
			if (invalidData !== null) {
				if (+invalidData.statusCode === 401 && modal[4].invalidUser) {
					/* istanbul ignore next */
					return renderSubmitModal(modal[4].invalidUser, '', handleClose, handleClose);
				} else if (+invalidData.statusCode === 460 && modal[0].invalidCredential) {
					/* istanbul ignore next */
					return renderSubmitModal(modal[0].invalidCredential, invalidData.data.loginAttemptsRemaining, handleClose, handleClose);
				} else if (+invalidData.statusCode === 150 && modal[2].passwordExpired) {
					/* istanbul ignore next */
					return renderSubmitModal(modal[2].passwordExpired, '', onExpiryModalButtonClick, handleClose);
				} else if (+invalidData.statusCode === 4044 && modal[5].accountLocked4044) {
					return renderSubmitModal(modal[5].accountLocked4044, '', onClickGoBack, handleClose);
				} else if (+invalidData.statusCode === 419 && modal[3].accountLocked) {
					/* istanbul ignore next */
					return renderSubmitModal(modal[3].accountLocked, '', onClickGoBack, handleClose);
				} else {
					const error = {
						...modal[0].invalidCredential,
						paragraph: ERROR_MESSAGES[defaultLangId]
					};
					return renderSubmitModal(error, '', onModalButtonClick, handleClose);
				}
			}
			/* istanbul ignore next */
			if (validData !== null) {
				/* if (+validData.statusCode === 200 && modal[1].passwordExpiry && validData.data.passwordExpirationDate && validData.data.passwordExpirationDate !== '') {
					const passwordExpirationDate = validData.data.passwordExpirationDate.split(' ');
					return renderSubmitModal(modal[1].passwordExpiry, passwordExpirationDate[0], onExpiryModalButtonClick, onModalButtonClick, true, true);
				} */
			}
		}
	};

	const renderSubmitModal = (modal, resData, primaryButtonAction, secondaryButtonAction, extraLarge = false, buttonColumn = false) => {
		let paragraph = modal.paragraph;
		if (resData) {
			/* istanbul ignore next */
			const invalidAttemptMsgs = paragraph.split('***');
			paragraph = (invalidAttemptMsgs.length > 0) ? ((invalidAttemptMsgs.length === 1) ? invalidAttemptMsgs[0] : invalidAttemptMsgs[resData - 1]) : '';
			paragraph = paragraph.split('*#').length > 1 ?
				`${paragraph.split('*#')[0]}${resData}${paragraph.split('*#')[1]}` : paragraph;
		}
		return (
			<CustomModal
				{...modal}
				paragraph={paragraph}
				size="lg"
				show={showSubmitModal}
				onHide={secondaryButtonAction}
				onModalButtonClick={primaryButtonAction}
				extraLarge={extraLarge}
				buttonColumn={buttonColumn}
			/>
		);
	};
	/* istanbul ignore next */
	const handleClose = () => {
		onShowSubmitModal(false);
	};
	/* istanbul ignore next */
	const onModalButtonClick = () => {
		handleClose();
		onSubmitModalButtonClick();
	};
	/* istanbul ignore next */
	const onExpiryModalButtonClick = () => {
		onShowSubmitModal(false);
		onShowChangePasswordModal();
	};
	/* istanbul ignore next */
	const onClickGoBack = () => {
		onShowSubmitModal(false);
		onClickGoBackToHome();
	};
	const getForgotLinks = (forgotLinks) => {
		return (
			<div className="d-flex justify-content-between col-12 my-3">
				{forgotLinks.map((elem, index) => {
					return (
						<Form.Label
							key={`${elem.name}-${index}`}
							className="px-0"
						>
							<Link className={`forgot-link-${index} custom-link `} to={elem.href}>{elem.text}</Link>
						</Form.Label>
					);
				})}
			</div>
		);
	};
	const getBackToSignupLink = (backToSignupLink) => {
		const textArr = backToSignupLink[0].text.split('*#');
		return (
			<Form.Group
				as={Col}
				md={12}
				className="text-center my-2 link-text"
			>
				{textArr[0]}<Link className="custom-link" to={backToSignupLink[0].href}>{textArr[1]}</Link>
			</Form.Group>
		);
	};

	return (
		<section className={`${config.theme ||
			'theme-background-light-grey'} py-3 py-md-5
                ${className || ''}`}
		>
			<Container
				className="pb-3"
				id={config.id || ''}
			>
				<Row className="mb-3 justify-content-center">
					<Col md={{ span: 8 }}>
					<Card className="login-card-wrap section-style">
							<Card.Header>
								<Card.Title
									className="mb-0 pl-md-5 d-flex justify-content-center"
								>
									<figure>
										<img
											src={headline.iconDetails.url}
											alt={headline.iconDetails.altText}
										/>
									</figure>
									<span className="custom-login-title">
										{headline.text}
									</span>
								</Card.Title>
							</Card.Header>
							<Card.Body>
								<Grid2
									className="px-md-0 px-lg-5"
									onSubmit={/* istanbul ignore next */(e) =>
										onClickSubmit(e)}
										noValidate>
									
										<Row className='form-row'>
										{userLoginDetails &&
											getUserLoginDetails(
												userLoginDetails
											)
										}
										{primaryButton ?
											getPrimaryButton(
												primaryButton, modal
											) : ''}
											</Row>
									
								</Grid2>
							</Card.Body>
						</Card>
					</Col>
				</Row>
			</Container>
		</section>
	);
};

LoginForm.propTypes = {
	componentState: PropTypes.object.isRequired,
	onClickSubmit: PropTypes.func.isRequired,
	handleChange: PropTypes.func.isRequired,
	handleBlur: PropTypes.func,
	onSubmitModalButtonClick: PropTypes.func.isRequired,
	onShowSubmitModal: PropTypes.func.isRequired,
	onShowChangePasswordModal: PropTypes.func,
	onClickGoBackToHome: PropTypes.func,
	showSubmitModal: PropTypes.bool.isRequired,
	invalidData: PropTypes.any,
	validData: PropTypes.any,
	viewport: PropTypes.string,
	config: PropTypes.shape({
		id: PropTypes.string,
		theme: PropTypes.oneOf([
			'theme-background-dark',
			'theme-background-light',
			'theme-background-light-grey',
			'theme-background-grey',
			'theme-background-dark-grey'
		]),
		icon: PropTypes.shape({
			url: PropTypes.string,
			alt: PropTypes.string,
			title: PropTypes.string
		}),
		height: PropTypes.oneOf(['short', 'tall']),
		align: PropTypes.oneOf(['right', 'left', 'center'])
	}),
	content: PropTypes.shape({
		headline: PropTypes.shape({
			text: PropTypes.string.isRequired,
			iconDetails: PropTypes.shape({
				url: PropTypes.string,
				altText: PropTypes.string
			})
		}).isRequired,
		userLoginDetails: PropTypes.arrayOf(
			PropTypes.shape({
				fieldType: PropTypes.string,
				dataType: PropTypes.string,
				fieldLabel: PropTypes.string,
				placeHolder: PropTypes.string,
				validations: PropTypes.arrayOf(
					PropTypes.shape({
						type: PropTypes.string.isRequired,
						validationRule: PropTypes.string,
						errorMessage: PropTypes.string.isRequired
					})
				),
				defaultValue: PropTypes.string,
				textAlign: PropTypes.string,
				hint: PropTypes.string,
				name: PropTypes.string,
				isRequired: PropTypes.number.isRequired,
				prefix: PropTypes.string,
				suffix: PropTypes.string,
				options: PropTypes.arrayOf(
					PropTypes.shape({
						value: PropTypes
							.string,
						name: PropTypes
							.string
					})
				),
				minLength: PropTypes.string,
				maxLength: PropTypes.string,
				minValue: PropTypes.string,
				maxValue: PropTypes.string
			})
		),
		primaryButton: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string,
				name: PropTypes.string,
				href: PropTypes.string,
				text: PropTypes.string.isRequired,
				target: PropTypes.string
			}).isRequired
		),
		forgotLinks: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string,
				name: PropTypes.string,
				href: PropTypes.string,
				text: PropTypes.string.isRequired,
				target: PropTypes.string
			})
		).isRequired,
		backToSignupLink: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string,
				name: PropTypes.string,
				href: PropTypes.string,
				text: PropTypes.string.isRequired,
				target: PropTypes.string
			}).isRequired
		),
		modal: PropTypes.arrayOf(
			PropTypes.shape({
				submitModal: PropTypes.shape({
					id: PropTypes.string,
					title: PropTypes.string.isRequired,
					paragraph: PropTypes.string.isRequired,
					primaryButton: PropTypes.shape({
						href: PropTypes.string.isRequired,
						text: PropTypes.string.isRequired,
						id: PropTypes.string,
						target: PropTypes.oneOf(['_self', '_blank', ''])
					}),
					closeLink: PropTypes.shape({
						image_url: PropTypes.string,
						altText: PropTypes.string,
						title: PropTypes.string
					}),
					guidelineInfo: PropTypes.shape({
						config: PropTypes.shape({
							theme: PropTypes.string,
							id: PropTypes.string,
							align: PropTypes.string
						}),
						content: PropTypes.shape({
							id: PropTypes.string,
							title: PropTypes.string.isRequired,
							iconDetails: PropTypes.shape({
								url: PropTypes.string,
								altText: PropTypes.string
							}),
							guidelines: PropTypes.arrayOf(
								PropTypes.string
							)
						})
					})
				})
			})
		)
	}),
	className: PropTypes.string
};

export default LoginForm;
