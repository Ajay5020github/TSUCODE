
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * This is a higher order component.
 * It is used to wrap components if no
 * common parent wrapper is available
 */

const ReactAux = props => props.children;

export default ReactAux;
