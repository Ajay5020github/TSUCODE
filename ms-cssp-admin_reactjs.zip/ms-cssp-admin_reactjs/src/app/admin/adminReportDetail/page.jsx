'use client';

import React, { useEffect, useState } from 'react';
import RootLayout from '../layout';
import dynamic from 'next/dynamic';

const AdminReportDetailComponent = dynamic(() => import('../components/adminReportDetail/adminReportDetailComponent'), {
  ssr: false
});

const LoginComponent = (props) => {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  return (
    <div className='login-container'>
      <RootLayout>
        {isClient && <AdminReportDetailComponent />}
      </RootLayout>
    </div>
  );
};

export default LoginComponent;
