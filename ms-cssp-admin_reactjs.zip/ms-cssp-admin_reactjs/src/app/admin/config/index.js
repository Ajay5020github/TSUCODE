
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/*
 * Configuration entry point.
 */

import DEV_CONFIG from './config.dev';
import PROD_CONFIG from './config.prod';

// Exports the configuration based on
// environment. Default is development.
const env = 'devevelopment';
let CONFIG = DEV_CONFIG;
if (env === 'production') {
	CONFIG = PROD_CONFIG;
}

export default CONFIG;
