/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
/**
 * This the configuration for development.
 */

export default {
	api: {
		nodeUrl: 'https://test.cssp.portal.conduent.com/adminbackend', 
		attemptAllowed: 5,
		// In milliseconds.
		attemptInterval: 3000,
		autoSaveAttemptInterval: 300000
	},
	defaultLang: 'en',
	defaultState: 'GA',
	fakeToken: '', // d37fd25d-5388-4c55-898e-bad9b8844883
	calendarMinDate: '1900-01-01T00:00:01',
	calendarMaxDate: '2070-01-01T00:00:01',
	pregnantMaxDueDate: '2020-12-31T00:00:01',
	uploadDocument: {
		fileSize: 5120, // 5mb file size
		fileAllowed: ['afp', 'bmp', 'doc', 'docx', 'gif', 'jpg', 'jpeg', 'pdf', 'png', 'tif', 'tiff', 'txt', 'xls', 'xlsx']
	},
	idleTimeout: 1000 * 300 * 1,
	idleDebounce: 1000 * 60 * 1,
	idleTimeoutElement: 'document',

	buildVersion: "0.0.12.06", // for DEV Release
	mailEncryptionSecret: "COnduenT*MaiL123"

};
