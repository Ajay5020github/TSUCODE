"use client";
import axios from "axios";
import https from "https";
import Storage from "./utils/storage";
import configDev from "./config/config.dev";

const GetBuildVersion = () => {
    const agent = new https.Agent({
        rejectUnauthorized: false,
    });

    const headers = {
        contentType: "application/json",
        authToken: Storage.getItem("token"),
    };


    const endpoint = `${configDev.api.nodeUrl}/adminService/getBuildVersion`;

    axios.get(endpoint, { httpsAgent: agent, headers })
        .then((response) => {
            if (response?.data?.version !== configDev.buildVersion) {
                window.location.reload();
            }
        })
        .catch((error) => {
        });

    return null; 
};

export default GetBuildVersion;
