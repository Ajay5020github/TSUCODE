import React from 'react';
import RootLayout from '../layout';
import Layout from '../components/layout';
import AdminReportDetailContainer from '../containers/adminReportDetail/adminReportDetailContainer';

const AdminReportDetailContainerComponent = (props) => {
 
  return (
    <div className='login-container'>

      <RootLayout>
        <AdminReportDetailContainer />
      </RootLayout>
    </div>
  );
};

export default AdminReportDetailContainerComponent;
