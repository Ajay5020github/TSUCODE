import {thunk}from 'redux-thunk'; 
import { configureStore as createToolkitStore } from '@reduxjs/toolkit';
import { persistReducer, persistStore } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import reduxImmutableStateInvariant from 'redux-immutable-state-invariant';
import monitorReducersEnhancer from '../enhancers/monitorReducer';
import loggerMiddleware from '../middleware/logger';
import { loaderMiddleware } from '../middleware/loaderMiddleware';
import rootReducer from '../reducers/rootReducer';

const persistConfig = {
  key: 'root',
  storage,
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

export function configureAppStore(preloadedState) {
  const middlewares = [
    loggerMiddleware,
    thunk, // Ensure thunk is included here
    loaderMiddleware,
    process.env.NODE_ENV !== 'production' && reduxImmutableStateInvariant(),
  ].filter(Boolean);

  const enhancers = [monitorReducersEnhancer];

  const store = createToolkitStore({
    reducer: persistedReducer,
    middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware({
        thunk: true,
        immutableCheck: {
          warnAfter: 32,
        },
        serializableCheck: {
          ignoredActions: [],
        },
      }).concat(middlewares),
    preloadedState,
    enhancers: (defaultEnhancers) => [...defaultEnhancers(), ...enhancers],
  });

  const persistor = persistStore(store);

  return { store, persistor };
}
