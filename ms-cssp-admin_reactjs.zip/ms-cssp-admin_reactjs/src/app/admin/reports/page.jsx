import React from 'react';
import RootLayout from '../layout';
import Login from '../components/login/login';
import Layout from '../components/layout';
import AdminReportContainer from '../containers/adminReport/adminReportContainer';
import '../components/userManagementComponents/userManagement.scss'

const AdminReportContainerComponent = (props) => {
 
  return (
    <div className='login-container'>

      <RootLayout>
        <AdminReportContainer />
      </RootLayout>
    </div>
  );
};

export default AdminReportContainerComponent;
