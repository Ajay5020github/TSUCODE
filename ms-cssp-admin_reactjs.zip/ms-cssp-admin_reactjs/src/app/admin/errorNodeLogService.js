import https from 'https';
import axios from 'axios';
import CONFIG from './config/index';

export const logErrorService = (err) => {
	const agent = new https.Agent({
		rejectUnauthorized: true
	});

    const params = {
        error: err ? err.toString() : ""
    }
    const endpoint = `${CONFIG.api.nodeUrl}/logErrors`;
    
	return axios
		.post(endpoint , params,
			{ httpsAgent: agent }
		)
		.then(response => response.data);
};