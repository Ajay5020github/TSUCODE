import React, { Component } from 'react';
import { connect } from 'react-redux';
//import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import htmlToReact from 'html-to-react';
import Banner from '../../components/banner/banner';
import Header from '../../components/header/header';
import Footer from '../../components/footer/footer';
import ReactAux from '../../reactAux/reactAux';
import Loader from '../../components/loader/loader';
import { fetchPrintableApplicationData } from '../../actions/printableApplication/printableApplicationActions';
import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';
import PrintableApplicationComponent from '../../components/printableApplication/printableApplication';

class printableApplicationContainer extends Component {
    constructor(props) {
        super(props);
    }

    state = {
        printableApplicationLabelData: {},
        environment: '',
        loading: true
    };
    componentDidMount() {
        
        this.props.fetchPrintableApplicationData().then(() => {            
            this.setInitialState();
        });
    }

    setInitialState = () => {
        //receive original data        
        this.setState({ printableApplicationLabelData: this.props.printableApplicationData && this.props.printableApplicationData.data, loading: false });
    };   

    render() {
        const {
            printableApplicationLabelData,
            loading,
            error
        } = this.state; 
        
        return (
            <ReactAux>
                
                    <div>
                        {/* {error ? <ErrorMessage text={error} /> : */}
                            <div>

                                <Header jsonHeader={printableApplicationLabelData && printableApplicationLabelData.header} />
                                <Banner
                                    config={printableApplicationLabelData && printableApplicationLabelData.content && printableApplicationLabelData.content.banner && printableApplicationLabelData.content.banner.config}
                                    content={printableApplicationLabelData && printableApplicationLabelData.content && printableApplicationLabelData.content.banner && printableApplicationLabelData.content.banner.content && printableApplicationLabelData.content.banner.content.headline} />

                                {/*  */}

                                <div className="dashboard-container dashboard theme-background-light-grey" id="dashboard">
                                    
                                    {loading ? <Loader /> : 
                                        <div className="menu-container">
                                            {/* <div className="card"> */}
                                                <div className="main-panel mt-3">
                                                    <div className="dashboard-home-content-container">
                                                        <div className="custom-jsoneditor">
                                                            <PrintableApplicationComponent content={printableApplicationLabelData && printableApplicationLabelData.content && printableApplicationLabelData.content.printableApplication && printableApplicationLabelData.content.printableApplication.content} config={printableApplicationLabelData && printableApplicationLabelData.content && printableApplicationLabelData.content.printableApplication && printableApplicationLabelData.content.printableApplication.config} />
                                                        </div>
                                                    </div>
                                                </div>
                                            {/* </div> */}
                                        </div>
                                    }
                                </div>
                                <Footer content={printableApplicationLabelData.footer && printableApplicationLabelData.footer.content} />
                            </div>
                        {/* } */}
                    </div>
                
            </ReactAux>
        );
    }
}
const mapStateToProps = state => ({
    printableApplicationData: state.printableApplicationReducer.printableApplicationData,
    loading: state.printableApplicationReducer.loading,
    error: state.printableApplicationReducer.error
});

const mapDispatchToProps = dispatch =>
    bindActionCreators(
        {
            fetchPrintableApplicationData
        },
        dispatch
    );

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(printableApplicationContainer);
