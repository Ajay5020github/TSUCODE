"use client";
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import htmlToReact from 'html-to-react';
import Banner from '../../components/banner/banner';
import Header from '../../components/header/header';
import Footer from '../../components/footer/footer';
import ReactAux from '../../reactAux/reactAux';
import Loader from '../../components/loader/loader';
import Dashboard from '../../components/dashboard/dashboard';
import { resetUserDetails } from '../../actions/userDetails/userDetailsActions';
import { resetSearchDetails } from '../../actions/userManagement/userManagementActions';
import { fetchUserDashboardData, fetchRoleManagementAction, fetchAuthDataManagementAction } from '../../actions/userDashboard/userDashboardActions';
import Storage from '../../utils/storage';
import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';
import { getToken } from '../../actions/login/loginActions';
import CONFIG from '../../../admin/config/index';
import CryptoJS from "crypto-js";
import { getTokenValue } from '../../../admin/utils/authenticate';

class UserDashboard extends Component {
    constructor(props) {
        super(props);
        this.htmlToReactParser = new htmlToReact.Parser();
    }

    state = {
        userDashboardLabelData: {},
        rolematrix: {},
        isFetching: true,
        initError: null
    };

    async componentDidMount() {
        this.props.resetUserDetails();
        this.props.resetSearchDetails();

        if (typeof window === "undefined") return;

        try {
            await this.initializeDashboard();
        } catch (err) {
            console.error("Dashboard initialization failed:", err);
            this.setState({ isFetching: false, initError: err.message });
        }
    }

    initializeDashboard = async () => {
        const loginType = Storage.getItem('loginType');
        let email = Storage.getItem('email');

        console.log("initializeDashboard - loginType:", loginType);
        console.log("initializeDashboard - email from storage:", email);

        const isExternalLogin =
            !loginType ||
            loginType === 'undefined' ||
            loginType === 'MDHS' ||
            loginType === 'DOM';

        console.log("initializeDashboard - isExternalLogin:", isExternalLogin);

        // ─── STEP 1: External login — decrypt params and call getTokenValue ───
        if (isExternalLogin) {
            // ✅ Read from sessionStorage — saved by DashboardPage before navigation
            const dEmail = sessionStorage.getItem('externalMail');
            const dId    = sessionStorage.getItem('externalId');

            console.log("External - dEmail from sessionStorage:", dEmail);
            console.log("External - dId from sessionStorage:", dId);

            // ✅ Clear immediately after reading
            sessionStorage.removeItem('externalMail');
            sessionStorage.removeItem('externalId');

            let emailID = "";
            let id      = "";

            if (dEmail) {
                try {
                    const bytes = CryptoJS.AES.decrypt(dEmail, CONFIG.mailEncryptionSecret);
                    emailID = bytes.toString(CryptoJS.enc.Utf8);
                    console.log("Decrypted emailID:", emailID);
                } catch (e) {
                    console.error("Failed to decrypt email:", e);
                }
            }

            if (dId) {
                try {
                    const bytes = CryptoJS.AES.decrypt(dId, CONFIG.mailEncryptionSecret);
                    id = bytes.toString(CryptoJS.enc.Utf8);
                    console.log("Decrypted id:", id);
                } catch (e) {
                    console.error("Failed to decrypt id:", e);
                }
            }

            if (emailID && id) {
                console.log("Calling getTokenValue with:", emailID, id);
                // ✅ AWAIT — this sets Storage 'email', which getToken needs
                await getTokenValue(emailID, id);
                console.log("getTokenValue completed. email in storage:", Storage.getItem('email'));
            } else {
                console.warn("Could not decrypt email/id from sessionStorage params");
            }

            // ✅ Read email AFTER getTokenValue has finished setting it
            email = Storage.getItem('email');
        }

        // ─── STEP 2: Guard — cannot proceed without email ───
        if (!email) {
            console.error("No email found in storage. Cannot call getToken.");
            this.setState({ isFetching: false });
            return;
        }

        console.log("Calling getToken with email:", email);

        // ─── STEP 3: Call getToken with valid email ───
        const res = await this.props.getToken(email);

        console.log("getToken response:", res);

        if (!res) {
            console.error("getToken returned empty response");
            this.setState({ isFetching: false });
            return;
        }

        // ─── STEP 4: Store token data for external users ───
        if (isExternalLogin) {
            Storage.setItem('authToken',   res.token);
            Storage.setItem('adminUserId', res.name);
            Storage.setItem('loginType',   res.loginType);
            Storage.setItem('firstName',   res.name);
            Storage.setItem('redirect',    res.logout);
            Storage.setItem('sid',         res.id);

            console.log("Stored external user data - loginType:", res.loginType);
        }

        // ─── STEP 5: Build role map and fetch role matrix ───
        if (res.role && res.role.length > 0) {
            const strroles = Array.isArray(res.role)
                ? res.role.join(',')
                : res.role;

            const roleMap = {
                userRoles: strroles,
                userId:    res.name
            };

            console.log("Fetching role matrix with roleMap:", roleMap);

            const data = await this.props.fetchRoleManagementAction(roleMap);

            console.log("fetchRoleManagementAction response:", data);

            if (data && data.rolesMatrix != null) {
                Storage.setItem('Authenticate',   data.rolesMatrix.Authenticate);
                Storage.setItem('UserManagement', data.rolesMatrix.UserManagement);
                Storage.setItem('Reports',        data.rolesMatrix.Reports);
                Storage.setItem('JsonEditor',     data.rolesMatrix.JsonEditor);

                console.log("Role matrix stored successfully");
            }
        } else {
            console.warn("No roles found in getToken response");
        }

        // ─── STEP 6: Fetch dashboard data ───
        console.log("Fetching dashboard data...");
        await this.props.fetchUserDashboardData();
        this.setInitialState();

        // ─── STEP 7: Done ───
        this.setState({ isFetching: false });
        console.log("Dashboard initialization complete");
    }

    setInitialState = () => {
        this.setState({
            userDashboardLabelData: this.props.userDashboardData.userDashboardData
        });
    };

    render() {
        const {
            userDashboardLabelData,
            isFetching,
            initError
        } = this.state;

        const { loading, error } = this.props;

        // Show loader while fetching
        if (loading || isFetching) {
            return <Loader />;
        }

        // Show error if init failed
        if (initError || error) {
            return <ErrorMessage text={initError || error} />;
        }

        // Show empty if no data yet
        if (!userDashboardLabelData || !userDashboardLabelData.content) {
            return null;
        }

        return (
            <ReactAux>
                <div>
                    <Header
                        jsonHeader={userDashboardLabelData.header}
                    />
                    <Banner
                        config={userDashboardLabelData.content.banner.config}
                        content={userDashboardLabelData.content.banner.content}
                    />
                    <Dashboard
                        buttons={userDashboardLabelData.content.buttons.config}
                        labels={userDashboardLabelData.content.labels.config}
                        welcomeText={userDashboardLabelData.content.welcomeText}
                    />
                    <Footer
                        content={userDashboardLabelData.footer && userDashboardLabelData.footer.content}
                    />
                </div>
            </ReactAux>
        );
    }
}

const mapStateToProps = state => ({
    userDashboardData: state.userDashboardReducer.userDashboardData,
    loading:           state.userDashboardReducer.loading,
    error:             state.userDashboardReducer.error
});

const mapDispatchToProps = dispatch =>
    bindActionCreators(
        {
            fetchUserDashboardData,
            resetUserDetails,
            resetSearchDetails,
            fetchRoleManagementAction,
            fetchAuthDataManagementAction,
            getToken
        },
        dispatch
    );

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(UserDashboard);
