"use client"
import React, { Component } from 'react';
import User from '../../components/userManagementComponents/user'
import Banner from '../../components/banner/banner';
import Header from '../../components/header/header';
import Footer from '../../components/footer/footer';
import { isAuthenticated } from '../../utils/authenticate';
import Storage from '../../utils/storage'; 
import { fetchUserDetailsData } from '../../actions/userDetails/userDetailsActions';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { formatSSN } from '../../components/userManagementComponents/myBenefitUtil';
import '../userManagement/userManagement.scss';
import '../../components/userManagementComponents/userdetails.css'
import "../../containers/custom.css"
import Loader from '../../components/loader/loader';

class UserDetailContainer extends Component {
	constructor(props) {
        super(props);
		this.handleChange = this.handleChange.bind(this);
		this.handleBlur = this.handleBlur.bind(this);
        this.handleDateChange = this.handleDateChange.bind(this);

		this.state = {
			userDetailsData: {},
			formErrors: null,
			formDataSet: null,
			formDate: null,
			formValid: false,
			isFormSubmited: false,
			singleUserData: null
	
		};
	}	

	handleUserDetails = (singleUserDetail) => {
		const updatedSingleUserDetail = {
			...singleUserDetail,
			socialSecurityNumber: (singleUserDetail.socialSecurityNumber && singleUserDetail.socialSecurityNumber.length > 4) ? 
			formatSSN(singleUserDetail.socialSecurityNumber) : ("XXX-XX-" + singleUserDetail.socialSecurityNumber)
		}
		this.setState({
			singleUserData: updatedSingleUserDetail,
			formDataSet: updatedSingleUserDetail
		}, () => {
			this.setInitialState(this.props.userDetailsData.data, updatedSingleUserDetail);
		})
	}
	componentDidMount() {
		const {singleUserData} = this.state
       	this.props.fetchUserDetailsData().then((res) => {
			this.setInitialState(res, singleUserData);
		});
	}

	getFormErrorRules = (item) => {
		return {
			isValid: item.isRequired ? false : true,
			isTouched: false,
			activeValidator: {},
			validations: item.validations,
			isRequired: item.isRequired,
			minValue: item.minValue,
			maxValue: item.maxValue,
			minLength: item.minLength,
			maxLength: item.maxLength
		};
	}

	setPrevActiveValidator = (curFormErrors, item) => {
		const { formErrors } = this.state;
		if (formErrors) {
			curFormErrors[item.name].isValid = formErrors[item.name].isValid;
			curFormErrors[item.name].isTouched = formErrors[item.name].isTouched;
			if (formErrors[item.name]?.activeValidator && formErrors[item.name].activeValidator.type) {
				const activeValidator = curFormErrors[item.name].validations.filter((elem) => elem.type === formErrors[item.name].activeValidator.type);
				if (activeValidator.length) {
					curFormErrors[item.name].activeValidator = activeValidator[0];
				}
			}
		}
		return curFormErrors;
	}

	setInitialState = (contentData, userData) => {

		const flds = {};
		const formData = {};
		let formErrors = {};
		const content = contentData && contentData.content;
		const { formDataSet } = this.state;

		if (this.props.storedata !== undefined && Object.keys(this.props.storedata).length > 0) {
			this.setState({
				formDataSet: this.props.storedata.storedata
			})

			const {
				fields
			} = content;
			const fieldTypeArr = ['input', 'checkbox', 'select', 'progessbar', 'multiselect'];
			const fieldsForEach = (item) => {
				if (fieldTypeArr.includes(item.fieldType.toLowerCase())) {
					formData[item.name] = formDataSet && formDataSet[item.name] ? formDataSet[item.name] : item.defaultValue;
					formErrors[item.name] = this.getFormErrorRules(item);
					formErrors = { ...this.setPrevActiveValidator(formErrors, item) };
				}
			}
			fields.forEach((item) => {
				fieldsForEach(item);
			});

			flds.formErrors = formErrors;
			flds.formDataSet = this.props.storedata.storedata;
			flds.benifitToggle = true;

			this.setState(flds);		

			if (this.state.formDataSet && flds) {
				this.onClickSubmit();
			}
		}
		else {
			if(userData && Object.keys(userData).length > 0) this.setState({formDataSet: userData})
			const {fields} = content;
			const fieldTypeArr = ['input', 'checkbox', 'select', 'progessbar', 'multiselect'];
			const fieldsForEach = (item) => {
				if (fieldTypeArr.includes(item.fieldType.toLowerCase())) {
					formData[item.name] = formDataSet && formDataSet[item.name] ? formDataSet[item.name] : item.defaultValue;
					formErrors[item.name] = this.getFormErrorRules(item);
					formErrors = { ...this.setPrevActiveValidator(formErrors, item) };
				}
			}
			fields && fields.length && fields.forEach((item) => {
				fieldsForEach(item);
			});

			flds.formErrors = formErrors;
			flds.formDataSet = formData;
			flds.benifitToggle = true;

			this.setState(flds);
		}
		//receive original data        
		this.setState({ userDetailsData: this.props.userDetailsData.data });
	}

	onClickAuthenticateBtn = () => {
		
		const { formDataSet, formValid, formErrors } = this.state;	
		
		this.setState({showTable:true})
		this.setState({ isFormSubmited: true });
		const fieldValidationErrors = {
			...formErrors
		};	

		Object.keys(fieldValidationErrors).forEach((fieldName, index) => {
			this.validateField(
				fieldName,
				formDataSet[fieldName],
				{ [fieldName]: formDataSet[fieldName] },
				index
			);
		});
	}

	validateField(fieldName, value, fields, subIndex, isTouched, checkDate) {
		const fieldValidationErrors = {
			...this.state.formErrors
		};
		let fieldValidationError = null;
		const fieldKey = Object.keys(fields)[0];

		fieldValidationError = fieldValidationErrors[fieldName];

		if (isTouched !== undefined) {
			fieldValidationError.isTouched = isTouched;
		}
		let validationObj = {};
		validationObj =
			this.getFieldIsValid(
				value,
				fieldValidationError,
				fieldName,
				checkDate
			);


		if (typeof fields[fieldKey] === 'object' && fields[fieldKey] !== null) {
			fieldValidationErrors[fieldKey][subIndex][fieldName] = {
				...validationObj.fieldValidationError
			};
		} else {
			fieldValidationErrors[fieldName] = {
				...validationObj.fieldValidationError
			};
		}

		this.customValidation(fieldName, value, validationObj, fieldKey, subIndex);

		return validationObj.currvalue
		
	}

	customValidation = (fieldName, value, validationObj, fieldKey, subIndex) => {
		const { formErrors, formDataSet } = this.state;
		const fieldValidationErrors = {
			...formErrors
		};
		let errcount = validationObj.errcount;

		if (!errcount) {
			fieldValidationErrors[fieldName].isValid = true;
			fieldValidationErrors[fieldName].activeValidator = {};
		} else {
			fieldValidationErrors[fieldName].isValid = false;
		}


		this.setState({
			formErrors: fieldValidationErrors
		}, this.validateForm);
	}

	validateForm() {
		let formValid = true;
		const { formErrors, formDataSet } = this.state;
		const formErrorKeys = Object.keys(formErrors);
		for (let i = 0; i < formErrorKeys.length; i++) {
			const fieldName = formErrorKeys[i];
			//skiping state validation as it has default value
			if (!formErrors[fieldName].isValid && fieldName !== "state") {
				formValid = formErrors[fieldName].isValid;
				break;
			}
		}

		if (!formValid) {
			this.setState({ formValid: false })
		}
		this.setState({
			formValid: formValid
		});
	}

	getFieldIsValid = (value, fieldValidationError, fieldName, checkDate) => {
		let validationObj = {
			fieldValidationError: fieldValidationError,
			errcount: 0
		};
		if (+fieldValidationError?.isRequired === 1) {
			validationObj = this.checkValidationByValidationTypes(value, fieldValidationError, fieldName, checkDate);
		} else {
			if (value!=null && value!=undefined) {
				validationObj = this.checkValidationByValidationTypes(value, fieldValidationError, fieldName, checkDate);
			}
		}
		return validationObj;
	}

	checkValidationByValidationTypes = (value, fieldValidationError, fieldName, checkDate) => {

		const validationTypes = ['empty', "CheckSSN", 'DateRange', 'validDate', 'IsMaxDate','IsMinDate'];
		let errcount = 0;
		let activeValidator = null;
		let formData = this.state.formDataSet;
		formData[fieldName] = value
		validationTypes.forEach(validationType => {

			activeValidator = fieldValidationError.validations && fieldValidationError.validations
				.filter(valid => valid.validation === validationType);


			if (activeValidator && activeValidator.length) {
				if (validationType === 'empty') {
					if (fieldName === 'userId' && value.length !== 0) {
						const userId = value;
						const newUserId = userId.replace(/\s+/g, ' ').trim();
						if (newUserId.length === 0) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					} else {
						if (!value) {
							errcount++;
							fieldValidationError
								.activeValidator = activeValidator[0];
						}
					}
				}
				if (validationType === 'validDate' && value) {
					const enterDate = new Date(value); //Convert provided data to proper date format
					if (enterDate.toString().toLowerCase() === 'invalid date' ) {
						errcount++;
						fieldValidationError.activeValidator = activeValidator[0];
					}
				}

				if (validationType === 'IsMaxDate' && value) {
					let enterDate = new Date(value);
					enterDate = new Date(new Date(enterDate.toString().substr(0, 16))) //Convert provided data to proper date format
					let currDate = null
					//Murali:- VSTS 279775 fix. max date validation in futur years
					if(!isNaN(enterDate)){
						if(activeValidator.yearsInFutur){
							let currentyear = new Date().getFullYear()
							currDate = new Date(currentyear+activeValidator.yearsInFutur,11,31)
						}else{
							currDate = activeValidator[0].maxDate === "newDate" ? new Date() : new Date(activeValidator[0].maxDate);
							currDate = new Date(new Date(currDate.toString().substr(0, 16)))
						}
						if (value && value.toString().toLowerCase() === 'invalid date' || enterDate > currDate) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
						/**@Murali: added validation to not accept current date(VSTS 286749) */
						if(activeValidator.noPresentDate){
							if (value && value.toString().toLowerCase() === 'invalid date' || enterDate >= currDate) {
								count = this.setErrorMessage(sfield, activeValidator, count, isPrg)
							}
						}
					}	
				}
				
				if (validationType === 'IsMinDate' && value) {
					const enterDate = new Date(value); //Convert provided data to proper date format
					let currDate = activeValidator[0].minDate === 'newDate' ? new Date() : new Date(activeValidator[0].minDate);
					currDate = new Date(new Date(currDate.toString().substr(0, 16)))
					if(!isNaN(enterDate)){
						if (value && value.toString().toLowerCase() === 'invalid date' || (enterDate < currDate)) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					}
        		}
				
				if (!errcount) {
					if (validationType === 'integer') {
						if (!new RegExp(activeValidator[0].validationRule)
							.test(value)) {
							errcount++;
							fieldValidationError
								.activeValidator = activeValidator[0];
						} else if (fieldValidationError.minValue &&
							+value <=
							fieldValidationError.minValue) {
							errcount++;
							fieldValidationError
								.activeValidator = activeValidator[0];
						}
					} else if(validationType === 'CheckSSN'){
						
						let usSSNVal = value.replace(/\D/g, '')   
							.replace(/^(\d{3})/, '$1-')
							.replace(/-(\d{2})/, '-$1-')
							.replace(/(\d)-(\d{4}).*/, '$1-$2');  
													
					   if(usSSNVal[usSSNVal.length-1] === '-'){
						   usSSNVal = usSSNVal.slice(0, -1);
					   }
					   formData[fieldName] = usSSNVal;
					   var reg = new RegExp("^(?!123-45-6789$)(?!666|000|9\\d{2})\\d{3}-(?!00)\\d{2}-(?!0{4})\\d{4}$");
					   if (!reg.test(usSSNVal)) {
						   errcount++;
						   fieldValidationError.activeValidator = activeValidator[0];
					   }
					} else {
						if (!new RegExp(activeValidator[0].validationRule).test(value) && validationType !== 'validDate') {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					}
				}
			}
		});
		return {
			fieldValidationError: fieldValidationError,
			errcount: errcount,
			currvalue: formData[fieldName]
		};
	}

	handleBlur = (e, subIndex) => {
		const fields = {};
		const target = e.target;

		this.setState({ btnDisableState: false })
		let value = '';
		fields[target.name] = target.value;
		value = target.value;
		this.validateField(target.name, value, fields, subIndex, true);
	}

	handleDateChange = (e, subIndex, field) => {
		let dob = '';
		if(e === null){
			dob = ''
		}else{
			var date = new Date(e);
			dob = ((date.getMonth() > 8) ? (date.getMonth() + 1) : ('0' + (date.getMonth() + 1))) + '/' + ((date.getDate() > 9) ? date.getDate() : ('0' + date.getDate())) + '/' + date.getFullYear();
		}
		let formDataSet = {};
		const fields = {};
		if (field.type === 'date') {
			fields[field.name] = dob;
			this.setState({ isBlocking: false, btnDisableState: false })
			//return
		}
		
		this.validateField(field.name, dob, fields, subIndex, true);

		formDataSet = {
			...this.state.formDataSet,
			...fields
		};

		this.setState({
			formDataSet: formDataSet
		});

	}

	handleChange = (e, subIndex, field) => {
		let formDataSet = { ...this.state.formDataSet };
		const fields = { ...formDataSet };
		let target = e.target;

		/**
		 * Prevent typing if allowed field length is reached.
		 */
		let maxLength = 0;
		if (field && field.maxLength) {
			maxLength = parseInt(field.maxLength);
		}
		if (maxLength > 0 && e.target.value.length > maxLength) {
			e.target.value = e.target.value.substring(0, maxLength);
			return;
		}
		if(e.target.name === 'socialSecurityNumber'){ 
			const currVal = target.value.replace(/[^\d]/g, '');
			if (maxLength > 0 && currVal.length > maxLength) {
				return;
			}
			fields[target.name] = currVal;
		}else {
			fields[target.name] = target.value;

		}

		let currvalue = this.validateField(
			target.name, target.value, fields, subIndex, true
		);
		if (typeof currvalue !== 'undefined') {
			fields[target.name] = currvalue
		}
		// Save the current cursor position and adjust for formatting characters
		let selectionStart = target.selectionStart;
		let selectionEnd = target.selectionEnd;
		const formattedValue = target.value.replace(/[^\d]/g, ''); // Remove formatting characters
		const formattedCursorPosition = selectionStart - (target.value.length - formattedValue.length);
		// Update the formDataSet
		formDataSet = {
			...formDataSet,
			...fields
		};

		this.setState({
			formDataSet: formDataSet
		}, () => {
			// Restore the cursor position after re-rendering and adjust for formatting characters
			const updatedCursorPosition = formattedCursorPosition + (target.value.length - formattedValue.length);
			target.selectionStart = updatedCursorPosition;
			target.selectionEnd = updatedCursorPosition;
		});

	}

	
	render() {

		const {
			userDetailsData

		} = this.state;
		
		return (
			this.props.loading?<Loader />: 
			<div>
				<div>
					{/*header */}
					{userDetailsData && userDetailsData.header &&
					<Header jsonHeader={userDetailsData && userDetailsData.header} />}
					{userDetailsData && userDetailsData.content && userDetailsData.content &&
					<Banner
						config={userDetailsData && userDetailsData.content && userDetailsData.content.banner.config}
					content={userDetailsData && userDetailsData.content && userDetailsData.content.banner.content} /> }

					{userDetailsData && userDetailsData.content &&
					<User
						componentState={this.state}
						handleChange={this.handleChange}
						handleDateChange={this.handleDateChange}	
						onClickAuthenticateBtn={this.onClickAuthenticateBtn}
						handleBlur={this.handleBlur}
						handleUserDetails={this.handleUserDetails}
						fields={userDetailsData && userDetailsData.content && userDetailsData.content.fields}
						buttons={userDetailsData && userDetailsData.content && userDetailsData.content.buttons.config}
						labels={userDetailsData && userDetailsData.content  && userDetailsData.content.labels.config}
						toolTipMessages={userDetailsData && userDetailsData.content  && userDetailsData.content.toolTipMessages.config}
						breadcrumb={userDetailsData && userDetailsData.content  && userDetailsData.content.banner.content.breadCrumb}
						breadcrumbUrl={userDetailsData && userDetailsData.content  && userDetailsData.content.banner.content.breadCrumbUrl}

					/>}
					{userDetailsData && userDetailsData.content && userDetailsData.content &&
					<Footer content={userDetailsData && userDetailsData.footer && userDetailsData.footer.content} />}
				</div>
			</div>
		)
	}


}

const mapStateToProps = state => ({
	userDetailsData: state.userDetailsReducer.userDetailsData,
	loading: state.userDetailsReducer.loading,
	error: state.userDetailsReducer.error
});

const mapDispatchToProps = dispatch =>
	bindActionCreators(
		{
			fetchUserDetailsData
		},
		dispatch
	);

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(UserDetailContainer);
