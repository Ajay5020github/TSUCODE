"use client"
import React, { Component } from 'react';
import UserAuth from '../../components/userManagementComponents/userAuth'
import Banner from '../../components/banner/banner';
import Header from '../../components/header/header';
import Footer from '../../components/footer/footer';
/* import { isAuthenticated } from '../../utils/authenticate';
import Storage from '../../utils/storage'; */
import { fetchUserAuthData } from '../../actions/userAuth/userAuthActions';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
//import './userManagement.scss';
import '../../components/userManagementComponents/userdetails.css';

class UserAuthenticationContainer extends Component {
	constructor(props) {
        super(props);
        
	}
	state = {
		userDetailsData: {},
	};

	componentDidMount() {
		this.props && this.props.fetchUserAuthData().then(() => {
			this.setInitialState();
		});
	}

	setInitialState = () => {
		//receive original data        
		this.setState({ userDetailsData: this.props.userDetailsData.data });
	}
	render() {

		const {
			userDetailsData
		} = this.state;
		
		return (
			<div>

				<div className='userauth_page'>
					{/*header */}
					<Header jsonHeader={userDetailsData && userDetailsData.header} />
					<Banner
						config={userDetailsData && userDetailsData.content && userDetailsData.content.banner.config}
						content={userDetailsData && userDetailsData.content && userDetailsData.content.banner.content} />
					{userDetailsData && userDetailsData.content &&
					<UserAuth
						buttons={userDetailsData && userDetailsData.content && userDetailsData.content.buttons.config}
						labels={userDetailsData && userDetailsData.content && userDetailsData.content.labels.config}
						breadcrumb={userDetailsData && userDetailsData.content && userDetailsData.content.banner.content.breadCrumb}
						breadcrumbUrl={userDetailsData && userDetailsData.content && userDetailsData.content.banner.content.breadCrumbUrl}
					/>}

					<Footer content={userDetailsData && userDetailsData.footer && userDetailsData.footer.content} />
				</div>
			</div>
		)
	}


}

const mapStateToProps = state => ({
	userDetailsData: state.userAuthReducer.userAuthData,
	loading: state.userAuthReducer.loading,
	error: state.userAuthReducer.error
});

const mapDispatchToProps = dispatch =>
	bindActionCreators(
		{
			fetchUserAuthData
		},
		dispatch
	);

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(UserAuthenticationContainer);
