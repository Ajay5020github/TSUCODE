/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import Storage from '../../utils/storage';
import { fetchLoginData, getAuthUrl } from '../../actions/login/loginActions';
import Loader from '../../components/loader/loader';
import Header from '../../components/header/header';
import Banner from '../../components/banner/banner';
import Footer from '../../components/footer/footer';
import LoginForm from '../../components/loginForm/loginForm';
import { validateLoginData } from '../../actions/login/loginActions';
import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';
import { fetchUserDashboardData, fetchRoleManagementAction, fetchAuthDataManagementAction } from '../../actions/userDashboard/userDashboardActions';
import { v4 as uuidv4 } from 'uuid';

export class Login extends Component {
	constructor(props) {
		super(props);
		this.onShowSubmitModal = this.onShowSubmitModal.bind(this);
		this.onShowChangePasswordModal = this.onShowChangePasswordModal.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.loginappBlur = this.loginappBlur.bind(this);
		this.handleBlur = this.handleBlur.bind(this);
		this.onClickSubmit = this.onClickSubmit.bind(this);
	}
	state = {
		formErrors: null,
		formValid: false,
		isFormSubmited: false,
		showSubmitModal: false,
		showChangePasswordModal: false
	};
	componentDidMount() {
		const defaultLangObj = Storage.getItem('defaultLangCode');
		if (Storage.getItem("authToken"))
		{
			Storage.removeItem('token');
		}

		if (defaultLangObj) {
			this.props.fetchLoginData(defaultLangObj).then(() => {
				setTimeout(function () {
					this.setInitialState();
				}.bind(this), 500)
			});
		} else {
			this.props.fetchLoginData().then(() => {
				setTimeout(function () {
					this.setInitialState();
				}.bind(this), 500)
			});
		}
		window.scroll({
			top: 0,
			left: 0,
			behavior: 'smooth'
		});
	}

	onChangeFetchLoginData = languageOption => {
		this.props.fetchLoginData(languageOption.value).then(() => {
			this.setInitialState();
		});
	};

	onSubmitModalButtonClick = () => {
		this.props.history.push('/userDashboard/userDashboard.js');
	}

	onClickGoBackToHome = () => {
		this.props.history.push('/home');
	}

	onShowChangePasswordModal = () => {
		Storage.removeItem('authToken');
		this.props.history.push({
			pathname: '/user/update-password', state: {
				fromLoginScreen: true,
				// eslint-disable-next-line max-len
				showLoggedInHeader: ((this.props.invalidData && this.props.invalidData.statusCode === 150) || (this.props.validData && this.props.validData.statusCode === 200)) ? false : true
			}
		});
	}
	onShowSubmitModal = (showSubmitModal) => {
		this.setState({ showSubmitModal: showSubmitModal });
	};

	onSuccessfulLogin = response => {		
		//Clean if there is any person list from previous session
		///window.appInsights.trackEvent('User successfully logged in', { 'userid': response.data.userId });
		Storage.setItem('authToken', response.authToken);
		// Storage.setItem('token', response.authToken);
		Storage.setItem('firstName', response.body.firstName);
		Storage.setItem('lastName', response.body.lastName);
		/*Storage.setItem('userId', response.data.userId); */
		Storage.setItem('adminUserId', response.body.userId);
		Storage.setItem('roleCodes', response.body.roles);
		Storage.setItem('loginType', response.loginType);
		Storage.setItem('email', response.body.userId + "@ms.com")
		Storage.setItem('sid', response.id)


		let roleDataMapping = {};
		let roleData = [];
		let roleUserId = '';
		let roleMatrixData;

		if (Storage.getItem("roleCodes") != null) {
			roleData = Storage.getItem('roleCodes');
			roleUserId = Storage.getItem('adminUserId');
		}

		roleDataMapping = {
			"userRoles": roleData,
			"userId": roleUserId
		}

		this.props.fetchRoleManagementAction(roleDataMapping)
			.then(data => {
				if (data.rolesMatrix !== null) {					
					Storage.setItem('Authenticate', data.rolesMatrix.Authenticate);
					Storage.setItem('UserManagement', data.rolesMatrix.UserManagement);
					Storage.setItem('Reports', data.rolesMatrix.Reports);
					Storage.setItem('JsonEditor', data.rolesMatrix.JsonEditor);

					// this.props.history.push('/admin/dashboard');

				}
			})

		//Clean if there is any Doc to upload data from previous session
		//this.onShowSubmitModal(true)

	};

	getFormErrorRules = item => {
		return {
			isValid: item.isRequired ? false : true,
			isTouched: false,
			activeValidator: {},
			validations: item.validations,
			isRequired: item.isRequired,
			minValue: item.minValue,
			maxValue: item.maxValue,
			minLength: item.minLength,
			maxLength: item.maxLength
		};
	};
	setPrevActiveValidator = (curFormErrors, item) => {
		const { formErrors } = this.state;
		if (formErrors) {
			curFormErrors[item.name].isValid = formErrors[item.name].isValid;
			curFormErrors[item.name].isTouched = formErrors[item.name].isTouched;
			if (
				formErrors[item.name].activeValidator &&
				formErrors[item.name].activeValidator.type
			) {
				const activeValidator = curFormErrors[item.name].validations.filter(
					elem => elem.type === formErrors[item.name].activeValidator.type
				);
				if (activeValidator?.length) {
					curFormErrors[item.name].activeValidator = activeValidator[0];
				}
			}
		}
		return curFormErrors;
	};
	//set initial state dynamically
	setInitialState() {
		const fields = {};
		let formErrors = {};

		const { content } = this.props.loginData && this.props.loginData.content && this.props.loginData.content.login;
		const { userLoginDetails } = content;
		const fieldTypeArr = ['input', 'checkbox', 'select'];
		userLoginDetails && userLoginDetails.length && userLoginDetails.forEach(item => {
			if (fieldTypeArr.includes(item.fieldType.toLowerCase())) {
				if (this.state[item.name]) {
					fields[item.name] = this.state[item.name];
				} else {
					fields[item.name] = item.defaultValue;
				}
				if (item.name !== 'showPassword') {
					formErrors[item.name] = this.getFormErrorRules(item);
					formErrors = { ...this.setPrevActiveValidator(formErrors, item) };
				}
			}
		});
		fields.formErrors = formErrors;
		this.setState(fields);
	}

	loginappBlur = (e) => {


		let domurl;


		if (e.target.value != "Internal") {

			this.props.getAuthUrl(e.target.value).then(res => {

				if (res.statusCode === 200) {
					//	this.onSuccessfulLogin(res);
					domurl = res.url;
					window.location.href = domurl;
				} else {

					//	domurl = "https://login.microsoftonline.com/657f0c85-1824-433c-983b-7743863f2ff2/oauth2/v2.0/authorize?client_id=8d46d5d7-8ce8-4a7c-b6b8-ab4ef5bd86da&response_type=token&redirect_uri=http://localhost:3000/auth/openid/return&response_mode=form_post&scope=openid+profile+User.Read&state=12345";
				}
			});

		}


	}

	handleChange = (e, field) => {
		const fields = {};
		const currTarget = e.currentTarget;
		const target = e.target;

		/**
		 * Prevent typing if allowed field length is reached.
		 */
		let maxLength = 0;
		if (field && field.maxLength) {
			maxLength = parseInt(field.maxLength);
		}
		if (maxLength > 0 && e.target.value.length > maxLength) {
			return;
		}
		/**
		 * End of maxLength checking
		 */

		if (currTarget.type === 'checkbox') {
			fields[target.name] = currTarget.checked;
		} else {
			fields[target.name] = target.value;
		}

		this.setState(fields);
	};

	handleBlur = e => {
		this.validateField(e.target.name, e.target.value, true);
	};

	validateField(fieldName, value, isTouched) {
		const fieldValidationErrors = {
			...this.state.formErrors
		};
		if (isTouched !== undefined) {
			if(fieldValidationErrors[fieldName]){
				fieldValidationErrors[fieldName].isTouched = isTouched;
			}		
		}
		let validationObj = {};
		validationObj = this.getFieldIsValid(
			value,
			fieldValidationErrors[fieldName],
			fieldName
		);
		const errcount = validationObj.errcount;
		fieldValidationErrors[fieldName] = {
			...validationObj.fieldValidationError
		};

		switch (fieldName) {
			case 'password':
				if (!errcount) {
					fieldValidationErrors[fieldName].isValid = true;
					fieldValidationErrors[fieldName].activeValidator = {};
				} else {
					fieldValidationErrors[fieldName].isValid = false;
				}
				break;
			default:
				if (!errcount) {
					fieldValidationErrors[fieldName].isValid = true;
					fieldValidationErrors[fieldName].activeValidator = {};
				} else {
					fieldValidationErrors[fieldName].isValid = false;
				}
		}
		this.setState(
			{
				formErrors: fieldValidationErrors
			},
			this.validateForm
		);
	}

	validateForm = () => {
		let isValid = true;
		Object.keys(this.state.formErrors).forEach(fieldName => {
			if (!this.state.formErrors[fieldName].isValid && isValid) {
				isValid = false;
			}
		});
		this.setState({
			formValid: isValid
		});
	};

	getFieldIsValid = (value, fieldValidationError, fieldName) => {
		let validationObj = {
			fieldValidationError: fieldValidationError,
			errcount: 0
		};
		if (+fieldValidationError?.isRequired === 1) {
			validationObj = this.checkValidationByValidationTypes(
				value,
				fieldValidationError,
				fieldName
			);
		} else {
			if (value) {
				validationObj = this.checkValidationByValidationTypes(
					value,
					fieldValidationError,
					fieldName
				);
			}
		}
		return validationObj;
	};

	checkValidationByValidationTypes = (
		value,
		fieldValidationError,
		fieldName
	) => {
		const validationTypes = [
			'empty',
			'email',
			'password',
			'integer',
			'characterMismatch'
		];
		let errcount = 0;
		let activeValidator = null;
		validationTypes && validationTypes.length && validationTypes.forEach(validationType => {
			activeValidator = fieldValidationError?.validations?.filter(
				validation => validation.type === validationType
			);
			if (activeValidator?.length) {
				if (validationType === 'empty') {
					if (fieldName === 'userId' && value.length !== 0) {
						const userId = value;
						const newUserId = userId.replace(/\s+/g, ' ').trim();
						if (newUserId.length === 0) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					} else {
						if (!value) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					}
				}
				if (!errcount) {
					if (validationType === 'integer') {
						if (!new RegExp(activeValidator[0].validationRule).test(value)) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						} else if (
							fieldValidationError.minValue &&
							+value <= fieldValidationError.minValue
						) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					} else {
						if (!new RegExp(activeValidator[0].validationRule).test(value)) {
							errcount++;
							fieldValidationError.activeValidator = activeValidator[0];
						}
					}
				}
			}
		});
		return {
			fieldValidationError: fieldValidationError,
			errcount: errcount
		};
	};

	onClickSubmit = e => {
		e.preventDefault();
		this.setState({ isFormSubmited: true });
		const fieldValidationErrors = {
			...this.state.formErrors
		};
		Object.keys(fieldValidationErrors).forEach(fieldName => {
			this.validateField(fieldName, this.state[fieldName]);
		});
		this.createValidateJSON();
	};

	createValidateJSON = () => {
		const { userId, password, formValid } = this.state;
		const saveJSON = {};
		const defaultLangObj = Storage.getItem('defaultLangCode');
		// Storage.setItem('oldPassword', password);
		if (formValid) {
			saveJSON.userId = userId;
			saveJSON.password = password;
			this.props.validateLoginData(defaultLangObj, saveJSON).then(res => {
				if (res.statusCode === 200) {
					this.onSuccessfulLogin(res);
				} else {
					this.onShowSubmitModal(true);
				}
			});
		}
	};

	render() {
		const { loginData, loading, error } = this.props;

		return (

			<React.Fragment>

				{loading ? (
					<Loader />
				) : (
						<React.Fragment>
							{error ? (
								<ErrorMessage text={error} />
							) : (
									<React.Fragment>

										{loginData && loginData.content && loginData.content.header ? (
											<Header
												jsonHeader={loginData.content.header}
												onLanguageChange={this.onChangeFetchLoginData}
											/>
										) : (
												''
											)}

										{loginData && loginData.content && loginData.content.banner ? (
											<Banner
												config={loginData.content.banner.config}
												content={loginData.content.banner.content}
											/>
										) : (
												''
											)}
										{/*page content here*/}
										{loginData && loginData.content && loginData.content ? (
											<LoginForm
												{...loginData.content.login}
												onSubmitModalButtonClick={
													this.onSubmitModalButtonClick
												}
												onShowSubmitModal={
													this.onShowSubmitModal
												}
												showSubmitModal={
													this.state.showSubmitModal
												}
												onShowChangePasswordModal={
													this.onShowChangePasswordModal
												}
												showChangePasswordModal={
													this.state.showChangePasswordModal
												}
												componentState={this.state}
												handleChange={this.handleChange}
												loginappBlur={this.loginappBlur}
												onClickSubmit={this.onClickSubmit}
												onClickGoBackToHome={this.onClickGoBackToHome}
												invalidData={this.props.invalidData}
												validData={this.props.validData}
												handleBlur={this.handleBlur}
											/>
										) : (
												''
											)}


										<Footer />
									</React.Fragment>
								)}
						</React.Fragment>
					)}
			</React.Fragment>
		);
	}
}
const mapStateToProps = state => ({
	loginData: state.loginReducer.loginData.data,
	invalidData: state.loginReducer.invalidData,
	validData: state.loginReducer.validData,
	loading: state.loginReducer.loading,
	error: state.loginReducer.error
});

const mapDispatchToProps = dispatch =>
	bindActionCreators(
		{
			fetchLoginData,
			getAuthUrl,
			validateLoginData,
			fetchRoleManagementAction
		},
		dispatch
	);

Login.propTypes = {
	fetchLoginData: PropTypes.func.isRequired,
	validateLoginData: PropTypes.func.isRequired,
	history: PropTypes.shape({
		push: PropTypes.func
	}),
	error: PropTypes.any,
	invalidData: PropTypes.any,
	validData: PropTypes.any,
	loading: PropTypes.bool,
	loginData: PropTypes.shape({
		stateCode: PropTypes.string,
		langCode: PropTypes.string,
		pageId: PropTypes.string,
		pageName: PropTypes.string,
		options: PropTypes.arrayOf(
			PropTypes.shape({
				value: PropTypes.string.isRequired,
				title: PropTypes.string.isRequired
			})
		).isRequired,
		config: PropTypes.shape({
			id: PropTypes.string,
			align: PropTypes.string,
			backgroundImage: PropTypes.shape({
				url: PropTypes.string,
				size: PropTypes.string,
				alt: PropTypes.string,
				position: PropTypes.string
			})
		}),
		content: PropTypes.shape({
			header: PropTypes.shape({
				config: PropTypes.shape({
					id: PropTypes.string,
					align: PropTypes.string,
					theme: PropTypes.oneOf([
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					])
				}).isRequired,
				content: PropTypes.shape({
					logoDetails: PropTypes.shape({
						items: PropTypes.arrayOf(
							PropTypes.shape({
								id: PropTypes.string.isRequired,
								url: PropTypes.string.isRequired,
								altText: PropTypes.string,
								title: PropTypes.string,
								textAlign: PropTypes.string,
								href: PropTypes.string.isRequired,
								target: PropTypes.string
							})
						).isRequired
					}).isRequired,
					navigationDetails: PropTypes.shape({
						textAlign: PropTypes.string,
						items: PropTypes.arrayOf(
							PropTypes.shape({
								id: PropTypes.string.isRequired,
								text: PropTypes.string.isRequired,
								href: PropTypes.string.isRequired,
								target: PropTypes.string
							})
						).isRequired
					}).isRequired,
					languageDetails: PropTypes.shape({
						textAlign: PropTypes.string,
						defaultLang: PropTypes.shape({
							value: PropTypes.string.isRequired,
							title: PropTypes.string.isRequired
						}).isRequired,
						options: PropTypes.arrayOf(
							PropTypes.shape({
								value: PropTypes.string.isRequired,
								title: PropTypes.string.isRequired
							})
						).isRequired
					}).isRequired
				}).isRequired,
				onLanguageChange: PropTypes.func,
				className: PropTypes.string
			}),
			banner: PropTypes.shape({
				config: PropTypes.shape({
					id: PropTypes.string,
					bannerImage: PropTypes.shape({
						url: PropTypes.string.isRequired,
						alt: PropTypes.string.isRequired,
						title: PropTypes.string.isRequired
					}).isRequired,
					theme: PropTypes.oneOf([
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					height: PropTypes.oneOf(['short', 'tall']),
					align: PropTypes.oneOf(['right', 'left']).isRequired
				}),
				content: PropTypes.shape({
					headline: PropTypes.shape({
						text: PropTypes.string
					}),
					paragraph: PropTypes.shape({
						text: PropTypes.string.isRequired
					}),
					primaryButton: PropTypes.shape({
						href: PropTypes.string.isRequired,
						text: PropTypes.string.isRequired,
						id: PropTypes.string,
						target: PropTypes.oneOf(['_self', '_blank', ''])
					}),
					hatchText: PropTypes.shape({
						text: PropTypes.string
					}),
					modal: PropTypes.shape({
						id: PropTypes.string,
						title: PropTypes.string.isRequired,
						paragraph: PropTypes.string.isRequired,
						primaryButton: PropTypes.shape({
							href: PropTypes.string.isRequired,
							text: PropTypes.string.isRequired,
							id: PropTypes.string,
							target: PropTypes.oneOf(['_self', '_blank', ''])
						}),
						closeLink: PropTypes.shape({
							url: PropTypes.string.isRequired,
							altText: PropTypes.string,
							title: PropTypes.string
						})
					})
				}),
				className: PropTypes.string,
				onModalButtonClick: PropTypes.func
			}),
			footer: PropTypes.shape({
				config: PropTypes.shape({
					id: PropTypes.string,
					align: PropTypes.string,
					theme: PropTypes.oneOf([
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					])
				}).isRequired,
				content: PropTypes.shape({
					mainContent: PropTypes.shape({
						textAlign: PropTypes.string,
						headline: PropTypes.shape({
							text: PropTypes.string.isRequired
						}).isRequired,
						text: PropTypes.string.isRequired
					}).isRequired,
					contactDetails: PropTypes.shape({
						textAlign: PropTypes.string,
						items: PropTypes.arrayOf(
							PropTypes.shape({
								id: PropTypes.string.isRequired,
								text: PropTypes.string.isRequired,
								iconDetails: PropTypes.shape({
									url: PropTypes.string.isRequired,
									altText: PropTypes.string,
									title: PropTypes.string
								}),
								target: PropTypes.string,
								href: PropTypes.string.isRequired
							})
						).isRequired
					}).isRequired,
					policyLinks: PropTypes.shape({
						textAlign: PropTypes.string,
						items: PropTypes.arrayOf(
							PropTypes.shape({
								id: PropTypes.string.isRequired,
								text: PropTypes.string.isRequired,
								href: PropTypes.string.isRequired,
								target: PropTypes.string
							})
						).isRequired
					}).isRequired,
					copyright: PropTypes.shape({
						textAlign: PropTypes.string,
						text: PropTypes.string.isRequired
					}).isRequired
				}).isRequired,
				className: PropTypes.string
			}),
			login: PropTypes.shape({
				config: PropTypes.shape({
					id: PropTypes.string,
					theme: PropTypes.oneOf([
						'theme-background-dark',
						'theme-background-light',
						'theme-background-light-grey',
						'theme-background-grey',
						'theme-background-dark-grey'
					]),
					icon: PropTypes.shape({
						url: PropTypes.string,
						alt: PropTypes.string,
						title: PropTypes.string
					}),
					height: PropTypes.oneOf(['short', 'tall']),
					align: PropTypes.oneOf(['right', 'left', 'center'])
				}),
				content: PropTypes.shape({
					headline: PropTypes.shape({
						text: PropTypes.string.isRequired
					}).isRequired,
					userLoginDetails: PropTypes.arrayOf(
						PropTypes.shape({
							fieldType: PropTypes.string,
							dataType: PropTypes.string,
							fieldLabel: PropTypes.string,
							placeHolder: PropTypes.string,
							validations: PropTypes.arrayOf(
								PropTypes.shape({
									type: PropTypes.string.isRequired,
									validationRule: PropTypes.string,
									errorMessage: PropTypes.string.isRequired
								})
							),
							defaultValue: PropTypes.string,
							textAlign: PropTypes.string,
							hint: PropTypes.string,
							name: PropTypes.string,
							isRequired: PropTypes.number.isRequired,
							prefix: PropTypes.string,
							suffix: PropTypes.string,
							options: PropTypes.arrayOf(
								PropTypes.shape({
									value: PropTypes.string.isRequired,
									title: PropTypes.string.isRequired
								})
							),
							minLength: PropTypes.string,
							maxLength: PropTypes.string,
							minValue: PropTypes.string,
							maxValue: PropTypes.string
						})
					),
					primaryButton: PropTypes.arrayOf(
						PropTypes.shape({
							id: PropTypes.string,
							name: PropTypes.string,
							href: PropTypes.string,
							text: PropTypes.string.isRequired,
							target: PropTypes.string
						}).isRequired
					),
					forgotLinks: PropTypes.arrayOf(
						PropTypes.shape({
							id: PropTypes.string,
							name: PropTypes.string,
							href: PropTypes.string,
							text: PropTypes.string.isRequired,
							target: PropTypes.string
						})
					).isRequired,
					backToSignupLink: PropTypes.arrayOf(
						PropTypes.shape({
							id: PropTypes.string,
							name: PropTypes.string,
							href: PropTypes.string,
							text: PropTypes.string.isRequired,
							target: PropTypes.string
						}).isRequired
					)
				})
			})
		})
	})
};
export default connect(
	mapStateToProps,
	mapDispatchToProps
)(Login);
