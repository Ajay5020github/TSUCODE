import React, { Component } from 'react';
import { connect } from 'react-redux';
//import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import htmlToReact from 'html-to-react';
import Banner from '../../components/banner/banner';
import Header from '../../components/header/header';
import Footer from '../../components/footer/footer';
import ReactAux from '../../reactAux/reactAux';
import Loader from '../../components/loader/loader';
import { fetchContactLocalOfficeData } from '../../actions/contactLocalOffice/contactLocalOfficeActions';
import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';
import ContactLocalOfficeComponent from '../../components/contactLocalOffice/contactLocalOffice';

class contactLocalOfficeContainer extends Component {
    constructor(props) {
        super(props);
    }

    state = {
        contactLocalOfficeLabelData: {},
        environment: '',
        loading: true
    };
    componentDidMount() {
        
        this.props.fetchContactLocalOfficeData().then(() => {            
            this.setInitialState();
        });
    }

    setInitialState = () => {
        //receive original data        
        this.setState({ contactLocalOfficeLabelData: this.props.contactLocalOfficeData && this.props.contactLocalOfficeData.data, loading: false });
    };   

    render() {
        const {
            contactLocalOfficeLabelData,
            loading,
            error
        } = this.state; 
        
        return (
            <ReactAux>
                
                    <div>
                        {/* {error ? <ErrorMessage text={error} /> : */}
                            <div>

                                <Header jsonHeader={contactLocalOfficeLabelData && contactLocalOfficeLabelData.header} />
                                <Banner
                                    config={contactLocalOfficeLabelData && contactLocalOfficeLabelData.content && contactLocalOfficeLabelData.content.banner && contactLocalOfficeLabelData.content.banner.config}
                                    content={contactLocalOfficeLabelData && contactLocalOfficeLabelData.content && contactLocalOfficeLabelData.content.banner && contactLocalOfficeLabelData.content.banner.content && contactLocalOfficeLabelData.content.banner.content.headline} />

                                {/*  */}

                                <div className="dashboard-container dashboard theme-background-light-grey" id="dashboard">
                                    
                                    {loading ? <Loader /> : 
                                        <div className="menu-container">
                                            {/* <div className="card"> */}
                                                <div className="main-panel mt-3">
                                                    <div className="dashboard-home-content-container">
                                                        <div className="custom-jsoneditor">
                                                            <ContactLocalOfficeComponent content={contactLocalOfficeLabelData && contactLocalOfficeLabelData.content && contactLocalOfficeLabelData.content.contactLocalOffice && contactLocalOfficeLabelData.content.contactLocalOffice.content} config={contactLocalOfficeLabelData && contactLocalOfficeLabelData.content && contactLocalOfficeLabelData.content.contactLocalOffice && contactLocalOfficeLabelData.content.contactLocalOffice.config} />
                                                        </div>
                                                    </div>
                                                </div>
                                            {/* </div> */}
                                        </div>
                                    }
                                </div>
                                <Footer content={contactLocalOfficeLabelData.footer && contactLocalOfficeLabelData.footer.content} />
                            </div>
                        {/* } */}
                    </div>
                
            </ReactAux>
        );
    }
}
const mapStateToProps = state => ({
    contactLocalOfficeData: state.contactLocalOfficeReducer.contactLocalOfficeData,
    loading: state.contactLocalOfficeReducer.loading,
    error: state.contactLocalOfficeReducer.error
});

const mapDispatchToProps = dispatch =>
    bindActionCreators(
        {
            fetchContactLocalOfficeData
        },
        dispatch
    );

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(contactLocalOfficeContainer);
