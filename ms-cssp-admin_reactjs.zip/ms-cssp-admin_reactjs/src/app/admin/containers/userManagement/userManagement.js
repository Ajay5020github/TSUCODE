"use client"
/* Copyright (C) Conduent Inc. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Storage from '../../utils/storage';
import { fetchUserManagementDataAction } from '../../actions/userManagement/userManagementActions';
import UserManagementComponent from '../../components/userManagementComponents/userManagementComponents';
 import './userManagement.scss';
import '../../components/dashboard/dashboard.scss';
import withAuth from '../../components/withAuth';
export class UserManagement extends Component {
	constructor(props) {
		super(props);
		this.state = {
			userManagementJson: {}
		};
	}

	// componentDidMount() {
	// 	this.props.fetchUserManagementDataAction().then((screenData) => {
	// 					this.setState({userManagementJson: screenData  })
	// 	});
	// }

	componentDidMount() {
	 
		if (typeof this.props.fetchUserManagementDataAction === 'function') {
		   this.props.fetchUserManagementDataAction().then((screenData) => {
			  this.setState({ userManagementJson: screenData });
		   })
		} 
	 }
	 

	render() { 
		

		const { userManagementJson } = this.state;
		const { userManagementJsonData } = this.props;
		return (
			
			<div>
				
				{userManagementJson  && userManagementJson  ? <UserManagementComponent json={userManagementJson} /> : null}


				
			</div>
			);
	}
}


const mapDispatchToProps = dispatch =>
	bindActionCreators(
	   {
		  fetchUserManagementDataAction
	   },
	   dispatch
	);
 
const mapStateToProps = state => ({
	userManagementJsonData: state.userManagementReducer.userManagementData
});



export default connect(
	mapStateToProps,
	mapDispatchToProps
)(withAuth(UserManagement))
