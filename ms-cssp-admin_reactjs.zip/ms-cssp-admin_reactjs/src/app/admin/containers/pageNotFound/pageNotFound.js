import React, { Component } from 'react';
import PageNotFound from '../../components/pageNotFound/pageNotFound';

class pageNotFoundContainer extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<>				
					<div>
						<div>
							<PageNotFound />							
						</div>
					</div>				
			</>
		);
	}
}

export default pageNotFoundContainer;
