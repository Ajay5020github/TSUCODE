import React, { Component } from 'react';
import { connect } from 'react-redux';
//import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import htmlToReact from 'html-to-react';
import Banner from '../../components/banner/banner';
import Header from '../../components/header/header';
import Footer from '../../components/footer/footer';
import ReactAux from '../../reactAux/reactAux';
import Loader from '../../components/loader/loader';
import { fetchContactUsData } from '../../actions/contactUs/contactUsActions';
import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';
import { ContactUs } from '../../components/contactUs/contactUs';

class contactUsContainer extends Component {
    constructor(props) {
        super(props);
    }

    state = {
        contactUsLabelData: {},
        environment: '',
        loading: true
    };
    componentDidMount() {
        
        this.props.fetchContactUsData().then(() => {            
            this.setInitialState();
        });
    }

    setInitialState = () => {
        //receive original data        
        this.setState({ contactUsLabelData: this.props.contactUsData && this.props.contactUsData.data, loading: false });
    };   

    render() {
        const {
            contactUsLabelData,
            loading,
            error
        } = this.state;        
        
        return (
            <ReactAux>
                
                    <div>
                        {/* {error ? <ErrorMessage text={error} /> : */}
                            <div>

                                <Header jsonHeader={contactUsLabelData.header} />
                                <Banner
                                    config={contactUsLabelData.content && contactUsLabelData.content.contactUs && contactUsLabelData.content.contactUs.content && contactUsLabelData.content.contactUs.content.banner && contactUsLabelData.content.contactUs.content.banner.config}
                                    content={contactUsLabelData.content && contactUsLabelData.content.contactUs && contactUsLabelData.content.contactUs.content && contactUsLabelData.content.contactUs.content.banner && contactUsLabelData.content.contactUs.content.banner.content && contactUsLabelData.content.contactUs.content.banner.content.headline} />

                                {/*  */}

                                <div className="dashboard-container dashboard theme-background-light-grey-one" id="dashboard">
                                    
                                    {loading ? <Loader /> : 
                                        <div className="menu-container">
                                            {/* <div className="card"> */}
                                                <div className="main-panel mt-3">
                                                    <div className="dashboard-home-content-container">
                                                        <div className="custom-jsoneditor">
                                                            <ContactUs contactUsLabelData={contactUsLabelData} />
                                                        </div>
                                                    </div>
                                                </div>
                                            {/* </div> */}
                                        </div>
                                    }
                                </div>
                                <Footer content={contactUsLabelData.footer && contactUsLabelData.footer.content} />
                            </div>
                        {/* } */}
                    </div>
                
            </ReactAux>
        );
    }
}
const mapStateToProps = state => ({
    contactUsData: state.contactUsReducer.contactUsData,
    loading: state.contactUsReducer.loading,
    error: state.contactUsReducer.error
});

const mapDispatchToProps = dispatch =>
    bindActionCreators(
        {
            fetchContactUsData
        },
        dispatch
    );

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(contactUsContainer);
