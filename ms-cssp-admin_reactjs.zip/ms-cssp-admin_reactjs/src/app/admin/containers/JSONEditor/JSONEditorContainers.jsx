"use client"
import React, { Component } from 'react';
import ReactJsonBuilder from '../../jsoneditor/ReactJsonBuilder';
import Banner from '../../components/banner/banner';
import Header from '../../components/header/header';
import Footer from '../../components/footer/footer';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import '../custom.css';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { fetchConfigPublishData } from '../../actions/configurationPublisher/configurationsPublisherActions';
import { resetUserDetails } from '../../actions/userDetails/userDetailsActions';
import { resetSearchDetails } from '../../actions/userManagement/userManagementActions';
import Storage from '../../utils/storage';
import withAuth from '../../components/withAuth';
import '../JSONEditor/JSONEditorContainers.scss'

class JSONEditorContainers extends Component {

    constructor(props) {
        super(props);
        this.clearFileName = this.clearFileName.bind(this);
    }
    state = {
        publishLabelData: {},

    };

    componentDidMount() {
        this.props.resetUserDetails();
        this.props.resetSearchDetails();
        this.props.fetchConfigPublishData().then(() => {
            this.setInitialState();
        });
    }

    setInitialState = () => {
        //receive original data
        this.setState({ publishLabelData: this.props.configPublishData && this.props.configPublishData.data })
    }

    clearFileName = () => {
        Storage.removeItem('fileName');
        Storage.removeItem('languageId');
        Storage.removeItem('screenName');
    }

    render() {

        const {
            publishLabelData

        } = this.state;

        return (
            <div className='jsonEditor_module'>
                <Header jsonHeader={publishLabelData && publishLabelData.header} />
                <Banner
                    config={publishLabelData?.content && publishLabelData.content.banner.config}
                    content={publishLabelData?.content && publishLabelData.content.banner.content} />

                <div className="dashboard-container dashboard theme-background-light-grey" id="dashboard">
                    <div className="customBreadcrumb">
                        <Breadcrumb>
                            <Breadcrumb.Item href={publishLabelData && publishLabelData.content && publishLabelData.content.banner.content.breadCrumbUrl} onClick={this.clearFileName}>
                                {publishLabelData && publishLabelData.content && publishLabelData.content.banner.content.breadCrumb}
                            </Breadcrumb.Item>

                        </Breadcrumb>
                    </div>
                    <div className="menu-container ms-json-edit-container">
                        <div className="card">
                            <div className="main-panel mt-3">
                                <div className="dashboard-home-content-container">
                                    <div className="custom-jsoneditor">
                                        <div className="custom-jsoneditor-title">
                                            <p className="headline">{publishLabelData && publishLabelData.content && publishLabelData.content.welcomeText.mainText}</p>
                                            <p className="welcomSubtitle">{publishLabelData && publishLabelData.content && publishLabelData.content.welcomeText.subText}</p>
                                        </div>
                                        <div className="custom-jsoneditor-builder">
                                            <ReactJsonBuilder publishLabelData={publishLabelData} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <Footer content={publishLabelData?.footer && publishLabelData.footer.content} />
            </div>

        );
    }
}

const mapStateToProps = state => ({

    configPublishData: state.configurationPublisherReducer.configPublishData,
    loading: state.configurationPublisherReducer.loading,
    error: state.configurationPublisherReducer.error
});

const mapDispatchToProps = dispatch =>
    bindActionCreators(
        {
            fetchConfigPublishData,
            resetUserDetails,
            resetSearchDetails
        },
        dispatch
    );

/*.propTypes = {
    fetchConfigPublishData: PropTypes.func.isRequired,
    configPublishData: PropTypes.any,
}*/
export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withAuth(JSONEditorContainers));
