"use client";
import React, { Component } from 'react';

import { connect } from 'react-redux';
//import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import htmlToReact from 'html-to-react';
import Banner from '../../components/banner/banner';
import Header from '../../components/header/header';
import Footer from '../../components/footer/footer';
import ReactAux from '../../reactAux/reactAux';
import Loader from '../../components/loader/loader';
import AdminReportComponent from '../../components/adminReport/adminReportComponent';

/* import { getAuthRepData } from '../../actions/userDashboard/authRepService';;
import Storage from '../../utils/storage';  */
import { fetchAdminReportListData } from '../../actions/reportList/adminReportListAction';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import Storage from '../../utils/storage';
import { getEnvironment } from '../../services/ConfigurePublisherService';
import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';

import https  from 'https';

class adminReportContainer extends Component {
    
    constructor(props) {
        super(props);
    }

    state = {
        adminReportLabelData: {},
        environment: '',
        loading: true
    };
    componentDidMount() {
       
        this.props.fetchAdminReportListData().then(() => {            
            this.setInitialState();

            // try { window.appInsights.trackEvent('Report List', { 'pageName': "Reports and Analytics" }, { 'adminUserId': Storage.getItem('adminUserId')  }); }
            // catch { }
        });
        
        Storage.setItem('reportId', "");
        Storage.setItem('embedUrl', "");
        Storage.setItem('accessToken', "");
        Storage.setItem('Message', "");
        
        this.getWorkingEnvironment();

    }

    setInitialState = () => {
        //receive original data
        this.setState({ adminReportLabelData: this.props.adminReportData && this.props.adminReportData.data });
    };

    getWorkingEnvironment = () => {

        const agent = new https.Agent({
            rejectUnauthorized: false
        });

        const headers = {
            'Content-Type': "application/json",
            authToken: Storage.getItem('authToken')
        };

		const thisObj = this;
        const adminReports = {  "userId":  Storage.getItem("loginType") === "internal" ? Storage.getItem("adminUserId") : Storage.getItem("email"),
                                "authToken": Storage.getItem('authToken'),
                                "department": Storage.getItem("loginType"),
                                "screenName": "getEnvironment"
                            };

        getEnvironment(adminReports, { httpsAgent: agent, headers })
            .then(function (response) {	                
                thisObj.setState({environment: response.env, loading: false});                
            })
            .catch(function (error) {                
                thisObj.setState({environment: '', loading: true});
             });
    }

    render() {
        const {
            adminReportLabelData,
            loading,
            error,
            environment
        } = this.state;

        return (
            <ReactAux>
                
                    <div className='admin_report_page'>
                        {error ? <ErrorMessage text={error} /> :
                            <div>

                                <Header jsonHeader={adminReportLabelData?.header} />
                                <Banner
                                    config={adminReportLabelData?.content && adminReportLabelData.content.banner.config}
                                    content={adminReportLabelData?.content && adminReportLabelData.content.banner.content} />
                                <div className="dashboard-container dashboard theme-background-light-grey" id="dashboard">
                                    <div className="customBreadcrumb">
                                        <Breadcrumb>
                                            <Breadcrumb.Item href={adminReportLabelData && adminReportLabelData.content && adminReportLabelData.content.banner.content.breadCrumbUrl} onClick={this.clearFileName}>
                                                {adminReportLabelData && adminReportLabelData.content && adminReportLabelData.content.banner.content.breadCrumb}
                                            </Breadcrumb.Item>

                                        </Breadcrumb>
                                    </div>
                                    {loading ? <Loader /> :
                                        <div className="menu-container">
                                            <div className="card">
                                                <div className="main-panel mt-3">
                                                    <div className="dashboard-home-content-container">
                                                        <div className="custom-jsoneditor">
                                                        <p className="headline">{adminReportLabelData && adminReportLabelData.content && adminReportLabelData.content.labels.config.reportList && environment !== ''}</p>
                                                            <AdminReportComponent adminReportLabelData={adminReportLabelData} environment={environment} />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>                                           
                                        </div>
                                    }
                                </div>
                                <Footer content={adminReportLabelData?.footer && adminReportLabelData.footer.content} />
                            </div>
                        }
                    </div>
                
            </ReactAux>
        );
    }
}
const mapStateToProps = state => ({
    adminReportData: state.adminReportReducer.adminReportData,
    loading: state.adminReportReducer.loading,
    error: state.adminReportReducer.error
});

const mapDispatchToProps = dispatch =>
    bindActionCreators(
        {
            fetchAdminReportListData,
            //resetUserDetails,
            //resetSearchDetails
        },
        dispatch
    );

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(adminReportContainer);
