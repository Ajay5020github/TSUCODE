"use client"
import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import htmlToReact from 'html-to-react';
import Banner from '../../components/banner/banner';
import Header from '../../components/header/header';
import Footer from '../../components/footer/footer';
import ReactAux from '../../reactAux/reactAux';
import Loader from '../../components/loader/loader';
import AdminReportDetailComponent from '../../components/adminReportDetail/adminReportDetailComponent';
import { fetchAdminReportDetailData } from '../../actions/reportsDetail/adminReportDetailAction';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import { getEmbedToken } from '../../services/ConfigurePublisherService';
import Storage from '../../utils/storage';
import { ErrorMessage } from '../../jsoneditor/components/helper/ErrorMessage';
import '../adminReportDetail/adminReportDetailContainer.scss';
import '../../containers/custom.css'

class AdminReportDetailContainer extends Component {
    constructor(props) {
        super(props);

        this.state = {
            adminReportDetailLabelData: {},
            accessToken: "", 
            embedUrl: "", 
            errorToken: [], 
            embedToken: "", 
            reportId: "", 
            loading: undefined
        };
    }

    reportRef = React.createRef();
    
    componentDidMount() {
        this.props.fetchAdminReportDetailData().then(() => {
            this.setInitialState();
        });
        this.getAccessTokenFromNode();
    }

    getAccessTokenFromNode = () => {
        const adminReports = {
            reportId: this.props?.location?.reportId || Storage.getItem('reportId'), 
            workspaceId: this.props?.location?.workspaceId || Storage.getItem('workspaceId')
        };
        
        getEmbedToken(adminReports)
            .then(response => {
                if (response.status === 200) {
                    Storage.setItem('accessToken', response.accessToken);
                    Storage.setItem('embedUrl', response.embedUrl[0].embedUrl);
                    Storage.setItem('reportId', response.embedUrl[0].reportId);
                    Storage.setItem('Message', '');

                    if (this.props.location.workspaceId.length > 0) {
                        Storage.setItem('workspaceId', this.props.location.workspaceId);
                    }

                    this.setState({
                        accessToken: response.accessToken, 
                        embedUrl: response.embedUrl[0].embedUrl, 
                        reportId: response.embedUrl[0].reportId, 
                        loading: false
                    });
                } else {
                    Storage.setItem('accessToken', '');
                    Storage.setItem('embedUrl', '');
                    Storage.setItem('reportId', '');
                    Storage.setItem('Message', 'Report is not available. Please contact system administrator.');
                    this.setState({loading: false});
                }
            })
            .catch(error => {
                this.setState({loading: false});
            });
    }

    setInitialState = () => {
        this.setState({ 
            adminReportDetailLabelData: this.props.adminReportDetailData && this.props.adminReportDetailData.data, 
            loading: true 
        });
    };

    render() {
        const { adminReportDetailLabelData, loading, error } = this.state;

        return (
            <ReactAux>
                <div>
                    {error ? <ErrorMessage text={error} /> : (
                        <div className='report_Details'>
                            <Header jsonHeader={adminReportDetailLabelData?.header} />
                            <Banner
                                config={adminReportDetailLabelData?.content?.banner?.config}
                                content={adminReportDetailLabelData?.content?.banner?.content} 
                            />
                            <div className="dashboard-container dashboard theme-background-light-grey" id="dashboard">
                                <div className="customBreadcrumb">
                                    <Breadcrumb>
                                        <Breadcrumb.Item href={adminReportDetailLabelData.content?.banner.content.breadCrumbUrl} onClick={this.clearFileName}>
                                            {adminReportDetailLabelData.content?.banner.content.breadCrumb}
                                        </Breadcrumb.Item>
                                    </Breadcrumb>
                                </div>
                                {loading ? <Loader /> : (
                                    <div className="menu-container">
                                        <div className="card">
                                            <div className="main-panel mt-3">
                                                <div className="dashboard-home-content-container">
                                                    <div className="custom-jsoneditor">
                                                        {Storage.getItem('accessToken') && Storage.getItem('accessToken').length > 0 && 
                                                            <AdminReportDetailComponent adminReportDetailLabelData={adminReportDetailLabelData} />
                                                        }
                                                        {Storage.getItem('Message') && Storage.getItem('Message').length > 0 && (
                                                            <center><h4>{Storage.getItem('Message')}</h4></center>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                            <Footer content={adminReportDetailLabelData.footer?.content} />
                        </div>
                    )}
                </div>
            </ReactAux>
        );
    }
}

AdminReportDetailContainer.propTypes = {
    fetchAdminReportDetailData: PropTypes.func.isRequired,
    adminReportDetailData: PropTypes.object,
    location: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
    adminReportDetailData: state.adminReportDetailReducer.adminReportDetailData,
    loading: state.adminReportDetailReducer.loading,
    error: state.adminReportDetailReducer.error
});

const mapDispatchToProps = dispatch =>
    bindActionCreators({ fetchAdminReportDetailData }, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(AdminReportDetailContainer);
