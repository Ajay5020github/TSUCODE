"use client"
import React, { Component } from 'react';
import { useRouter } from 'next/navigation';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import Loader from '../../components/loader/loader'; // Correct import
import Storage from '../../utils/storage';
import { logoutService } from '../../actions/logout/logoutService';
import { resetUserDetails } from '../../actions/userDetails/userDetailsActions';
import { resetSearchDetails } from '../../actions/userManagement/userManagementActions';
import { setUserApplicationTrackingId } from '../../actions/userDashboard/userDashboardActions';
import { bindActionCreators } from 'redux';

class Logout extends Component {
    constructor(props) {
        super(props);
        this.state = {
            hasLoggedOut: false
        };
    }

    componentDidMount() {
        logoutService().then(() => {
            //Clean if there is any Doc to upload data
				//window.appInsights.trackEvent('User successfully logged out', { 'userid': Storage.getItem('userId') });
				//this.props.resetDocumentUploadData();
				//JSONSteps.reset();
            [
                'authToken', 'consumerUserId', 'fileName', 'firstName', 'roleCodes',
                'languageId', 'screenName', 'rolematrix', 'Authenticate',
                'UserManagement', 'Reports', 'JsonEditor', 'email', 'roleName', 'lastName', 'loginType',
                'adminUserId', 'sid', 'authTimer'
            ].forEach(item => Storage.removeItem(item));

            this.props.resetSearchDetails();
            this.props.resetUserDetails();
            this.props.setUserApplicationTrackingId('');

            // Handle redirect
            const { replace, location, refresh } = this.props;
            if (location && location.state && location.state.fromChangePasswordScreen) {
                replace('/admin/login');
                // refresh();
            } else {
                replace('/admin/login');
                // refresh();
            }

            this.setState({ hasLoggedOut: true });
        });

        if (Storage.getItem('loginType') !== 'internal') {
            const url = Storage.getItem('redirect');
            Storage.removeItem('loginType');
            Storage.removeItem('token');
            window.location.href = url;
        }
    }

    render() {
        return (
            <React.Fragment>
                {!this.state.hasLoggedOut ? <Loader /> : <div></div>}
            </React.Fragment>
        );
    }
}

Logout.propTypes = {
    setUserApplicationTrackingId: PropTypes.func.isRequired,
    resetUserDetails: PropTypes.func.isRequired,
    resetSearchDetails: PropTypes.func.isRequired,
    location: PropTypes.object,
    push: PropTypes.func.isRequired
};

const mapDispatchToProps = dispatch =>
    bindActionCreators(
        {
            setUserApplicationTrackingId,
            resetUserDetails,
            resetSearchDetails
        },
        dispatch
    );

// Dashboard navigation using props
function LogoutWithRoute(props) {
    const router = useRouter();
    return <Logout {...props} replace={router.replace} location={router.location} />;
}

export default connect(null, mapDispatchToProps)(LogoutWithRoute);
