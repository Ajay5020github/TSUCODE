"use client";
import React, { useEffect } from 'react';
import { useRouter } from 'next/navigation';

import 'bootstrap/dist/css/bootstrap.min.css'; // Importing global styles if needed
// import '../../src/app/styles/global.scss'; // Importing additional global styles
import AppHome from './components/home';

const HomePage = () => {

  const router = useRouter();
  console.log("Admin Home Page" ,window.location);

 if(window?.location?.pathname ==="/admin/"|| window?.location?.pathname ==="/admin"  || window?.location?.pathname ==="/admin/home"){
  router.replace('/admin/login');
 }

  return (
    <div>      
      <AppHome
       />
    </div>
  );
};

export default HomePage;
