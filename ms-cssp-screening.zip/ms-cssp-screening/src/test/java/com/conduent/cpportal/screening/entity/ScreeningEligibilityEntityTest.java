package com.conduent.cpportal.screening.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.conduent.cpportal.screening.exception.ScreeningServiceException;

@RunWith(SpringRunner.class)

public class ScreeningEligibilityEntityTest {
	@Test
	void test() {
	 Long screeningId=1L;
	 String tanfEligibilityInd="Yes";
	 String snapEligibilityInd="Yes";
	 String healthCoverageInd="Yes";
	 String energyAssistanceCoverageInd="Yes";
	 String anonymousUserInd="Yes";
	 Date screeningDateTime= new Timestamp(Instant.now().toEpochMilli());
	 
	 ScreeningEligibilityEntity eligibilityEntity = new ScreeningEligibilityEntity();
	 eligibilityEntity.setAnonymousUserInd(anonymousUserInd);
	 eligibilityEntity.setEnergyAssistanceCoverageInd(energyAssistanceCoverageInd);
	 eligibilityEntity.setHealthCoverageInd(healthCoverageInd);
	 eligibilityEntity.setScreeningDateTime(screeningDateTime);
	 eligibilityEntity.setScreeningId(screeningId);
	 eligibilityEntity.setSnapEligibilityInd(snapEligibilityInd);
	 eligibilityEntity.setTanfEligibilityInd(tanfEligibilityInd);
	 
	 assertEquals(eligibilityEntity.getAnonymousUserInd(), anonymousUserInd);
	 assertEquals(eligibilityEntity.getEnergyAssistanceCoverageInd(), energyAssistanceCoverageInd);
	 assertEquals(eligibilityEntity.getHealthCoverageInd(), healthCoverageInd);
	 assertEquals(eligibilityEntity.getScreeningDateTime(), screeningDateTime);
	 assertEquals(eligibilityEntity.getScreeningId(), screeningId);
	 assertEquals(eligibilityEntity.getSnapEligibilityInd(), snapEligibilityInd);
	 assertEquals(eligibilityEntity.getTanfEligibilityInd(), tanfEligibilityInd);


	 
	 
	}
	@Test
	void testScreeningServiceException() {
		Throwable throwable = mock(Throwable.class);
		ScreeningServiceException exception = new ScreeningServiceException(0, null, null, null, throwable);
		exception.getAction();
		exception.getConsumerId();
		exception.getErrorCode();
	}

}
