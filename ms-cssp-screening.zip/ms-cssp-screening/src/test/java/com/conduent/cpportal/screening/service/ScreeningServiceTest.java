/**
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 * 
 * Licensed under the CONDUENT License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * 
 * Software is the copyrighted work of Conduent and/or its licensors. Copying or reproducing  
 * the Software to any other server or location for further reproduction or redistribution is 
 * prohibited,  unless such reproduction or redistribution is permitted by a license agreement
 * accompanying  such Software. You may not create derivative works of the Software, or attempt to 
 * decompile or reverse-engineer the Software unless otherwise permitted by law. Use of the Software
 * is subject to the license terms of any license agreement that may accompany or is provided 
 * with the Software.
 */

package com.conduent.cpportal.screening.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;


import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.conduent.cpportal.screening.constants.ScreeningConstants;
import com.conduent.cpportal.screening.dao.ScreeningServiceDaoImpl;
import com.conduent.cpportal.screening.entity.ScreeningEligibilityEntity;
import com.conduent.cpportal.screening.exception.ScreeningServiceException;
import com.conduent.cpportal.screening.model.Screening;
import com.conduent.cpportal.screening.model.ScreeningEligibilityResponse;
import com.conduent.cpportal.screening.utility.ScreeningServiceTestConstants;

@RunWith(SpringRunner.class)
class ScreeningServiceTest {

	@MockBean
	private KieContainer kieContainer;

	@Test
	void testScreeningEligibilityCheck1() throws ScreeningServiceException {

		Screening product = populateScreening();
		ScreeningServiceImpl service = getScreeningServiceImpl();
		ScreeningEligibilityResponse asd = service.screeningEligibilityCheck(product);
		assertEquals(ScreeningConstants.YES_IND, asd.getMedicaidProgramEligibilityInd());
	}

	@Test
	void testScreeningEligibilityCheck2() throws ScreeningServiceException {

		Screening product = populateScreening();
		product.setTanfEligibility("NO");
		ScreeningServiceImpl service = getScreeningServiceImpl();
		ScreeningEligibilityResponse asd = service.screeningEligibilityCheck(product);
		assertEquals(ScreeningConstants.NO_IND, asd.getTanfProgramEligibilityInd());

	}

	@Test
	void testScreeningEligibilityCheck3() throws ScreeningServiceException {

		Screening product = populateScreening();
		product.setSnapEligibility("YES");
		product.setEnergyAssistanceProgramEligibility("YES");
		ScreeningServiceImpl service = getScreeningServiceImpl();
		ScreeningEligibilityResponse asd = service.screeningEligibilityCheck(product);
		assertEquals(ScreeningConstants.YES_IND, asd.getSnapProgramEligibilityInd());
		assertEquals(ScreeningConstants.YES_IND, asd.getEnergyAssistanceProgramEligibilityInd());

	}

	@Test
	void testScreeningEligibilityCheck4() throws ScreeningServiceException {

		Screening product = populateScreening();
		ScreeningServiceImpl service = getScreeningServiceImpl();
		ScreeningEligibilityResponse asd = service.screeningEligibilityCheck(product);
		assertNotNull(asd);
	}

	@Test
	void testScreeningEligibilityCheck5() throws ScreeningServiceException {
		Screening product = new Screening();
		ScreeningServiceImpl service = getScreeningServiceImpl();
		ScreeningEligibilityResponse asd = service.screeningEligibilityCheck(product);
		assertNotNull(asd);

	}

	@Test
	void testScreeningEligibilityCheck6() throws ScreeningServiceException {

		Screening product = populateScreening();
		ScreeningServiceImpl service = getScreeningServiceImpl();
		ScreeningEligibilityResponse asd = service.screeningEligibilityCheck(product);
		assertNotNull(asd);

	}

	@Test
	void testScreeningEligibilityCheckElse() throws ScreeningServiceException {

		Screening product = populateScreening();
		product.setUserId(null);
		ScreeningServiceImpl service = getScreeningServiceImpl();
		ScreeningEligibilityResponse asd = service.screeningEligibilityCheck(product);
		assertNotNull(asd);

	}

	@Test
	void testScreeningEligibilityCheck() throws ScreeningServiceException {

		Screening product = populateScreening();
		ScreeningServiceImpl service = getScreeningServiceImpl();
		ScreeningEligibilityResponse asd = service.screeningEligibilityCheck(product);
		assertNotNull(asd);

	}

	@Test
	void testScreeningEligibilityCheckException() throws ScreeningServiceException {

		Screening product = populateScreening();
		ScreeningServiceImpl service = new ScreeningServiceImpl();
		try {

			ScreeningEligibilityResponse asd = service.screeningEligibilityCheck(product);
			assertNotNull(asd);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}





	@Test
	void testConstructor() {
		ScreeningServiceDaoImpl mockDao = Mockito.mock(ScreeningServiceDaoImpl.class);
		KieContainer keyContainer = Mockito.mock(KieContainer.class);
        ReferenceDataBean databean = Mockito.mock(ReferenceDataBean.class);
		ScreeningServiceImpl service = new ScreeningServiceImpl(mockDao, keyContainer,databean);
		assertNotNull(service);
	}
	
	

	private ScreeningServiceImpl getScreeningServiceImpl() {
		Screening product = populateScreening();

		ScreeningEligibilityEntity screeningEligibility = new ScreeningEligibilityEntity();
		screeningEligibility.setHealthCoverageInd(product.getMedicaidEligibility());
		screeningEligibility.setSnapEligibilityInd(product.getSnapEligibility());
		screeningEligibility.setTanfEligibilityInd(product.getTanfEligibility());

		ScreeningServiceImpl service = new ScreeningServiceImpl();
		ScreeningServiceDaoImpl mockDao = Mockito.mock(ScreeningServiceDaoImpl.class);
		service.setScreeningCheckEligibilityDAO(mockDao);
		ReflectionTestUtils.setField(service, ScreeningServiceTestConstants.REFERENCE_DATA, getReferenceData());

		KieSession kieSession = mock(KieSession.class);
		KieContainer kieContainer = mock(KieContainer.class);
		ReflectionTestUtils.setField(service, "kieContainer", kieContainer);
		when(kieContainer.newKieSession()).thenReturn(kieSession);

		when(mockDao.findAllSNAPIncomeAmount()).thenReturn(getSnapIncome());
		when(mockDao.findAllStandardDeductions()).thenReturn(getDeductions());
		when(mockDao.findAllTANFIncomeAmount()).thenReturn(getTanfIncome());
		when(mockDao.screeningEligibilityCheck(Mockito.any())).thenReturn(screeningEligibility);
		return service;

	}

	private Screening populateScreening() {
		Screening product = new Screening();

		product.setAdultOrChildCareExpenses(0d);
		product.setCitizenOrLegalResidentInd("YES");
		product.setHeatingOrCoolingExpenses(0);
		product.setHouseholdAssetsDollar(11);
		product.setHouseholdDisabledInd("YES");
		product.setHouseholdGrossIncome(100);
		product.setHouseholdMedicalExpensesInd("YES");
		product.setHouseholdOtherSourceIncome(1000);
		product.setMigrantORSeasonalWorkerInd("YES");
		product.setHouseholdLiveInMississippiInd("YES");
		product.setNumberOfAdults22through59(1);
		product.setNumberOfChildrenUnderAge18(1);
		product.setNumberOfAdults60orAbove(0);
		product.setNumberOfChildren18through21(0);
		product.setPlanToLiveInMississippiInd("YES");
		product.setRentIncludesHeatOrCoolingExpensesInd("YES");
		product.setRentOrMortgageExpenses(0);
		product.setSupplementalSecurityIncome(13);
		product.setTotalNumberOfHouseHolds(1);
		return product;

	}

	private Map<Integer, Double> getSnapIncome() {
		Map<Integer, Double> snapIncome = new HashMap<>();
		snapIncome.put(1, (double) 1064);
		snapIncome.put(2, (double) 1437);
		snapIncome.put(3, (double) 1810);
		snapIncome.put(4, (double) 2184);
		snapIncome.put(5, (double) 2557);
		snapIncome.put(6, (double) 2930);
		snapIncome.put(7, (double) 3304);
		snapIncome.put(8, (double) 3677);
		snapIncome.put(9, (double) 4051);
		snapIncome.put(10, (double) 4425);
		snapIncome.put(11, (double) 4799);
		snapIncome.put(12, (double) 5173);
		snapIncome.put(13, (double) 5547);
		snapIncome.put(14, (double) 5921);
		snapIncome.put(15, (double) 6295);
		snapIncome.put(16, (double) 6669);
		snapIncome.put(17, (double) 7043);
		snapIncome.put(18, (double) 7417);
		snapIncome.put(19, (double) 7791);
		snapIncome.put(20, (double) 8165);
		snapIncome.put(21, (double) 9539);
		snapIncome.put(22, (double) 8913);
		snapIncome.put(23, (double) 9287);
		snapIncome.put(24, (double) 9661);
		snapIncome.put(25, (double) 10035);

		return snapIncome;
	}

	
	
	private ReferenceDataBean getReferenceData() {
		ScreeningServiceDaoImpl mockDao =new ScreeningServiceDaoImpl();
		ReferenceDataBean referenceData = new ReferenceDataBean();
		Map<String, Double> map = new HashMap<>();
		map.put("HEAT_COOL_EXPENSES", (double) 278);
		map.put("TANF_BUDGET_VAL", (double) 75);
		map.put("SNAP_BUDGET_VAL", (double) 379);
		map.put("HEAT_COOL_EXPENSES_DEFAULT", (double) 0);
		map.put("ANF_CHILD_LIMIT", (double) 0);
		referenceData.setReferenceData(map);
		referenceData.setDeductions(getDeductions());
		referenceData.setSnapIncome(getSnapIncome());
		referenceData.setTanfIncome(getTanfIncome());
		referenceData.setScreeningServiceDAO(mockDao);
		return referenceData;
	}

	private Map<String, Double> getDeductions() {
		Map<String, Double> deductions = new HashMap<>();
		deductions.put("<=3", (double) 164);
		deductions.put("==4", (double) 174);
		deductions.put("==5", (double) 204);
		deductions.put(">5", (double) 234);
		return deductions;
	}

	private Map<Integer, Double> getTanfIncome() {
		Map<Integer, Double> tanfIncome = new HashMap<>();
		tanfIncome.put(1, 403d);
		tanfIncome.put(2, 542d);
		tanfIncome.put(3, 680d);
		tanfIncome.put(4, 819d);
		tanfIncome.put(5, 958d);
		tanfIncome.put(6, 1097d);
		tanfIncome.put(7, 1235d);
		tanfIncome.put(8, 1374d);
		tanfIncome.put(9, 1513d);
		return tanfIncome;
	}
}