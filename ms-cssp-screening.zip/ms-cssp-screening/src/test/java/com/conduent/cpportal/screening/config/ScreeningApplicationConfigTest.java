package com.conduent.cpportal.screening.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.net.URISyntaxException;
import java.security.InvalidKeyException;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;

import io.swagger.v3.oas.models.OpenAPI;



@RunWith(MockitoJUnitRunner.class)
public class ScreeningApplicationConfigTest {

	String exception = "Exception Occured While Running Test Case ";

	private static final Logger log = LoggerFactory.getLogger(ScreeningApplicationConfig.class);

	@Test
	void testApi() {
		ScreeningApplicationConfig config = new ScreeningApplicationConfig();
		//Docket docket = config.api();
		//assertEquals(config.openApiInformation(), "default");
		OpenAPI openAPI = config.openApiInformation();
		assertNotNull(openAPI, "openApiInformation() should not return null");
		assertNotNull(openAPI.getInfo(), "OpenAPI.info should not be null");
		assertEquals("Benepath - SSP Screening Service", openAPI.getInfo().getTitle());
	}

	@Test
	void testContainer() throws InvalidKeyException, URISyntaxException {
		
		ScreeningApplicationConfig config = new ScreeningApplicationConfig();
		String accountName = "DefaultEndpointsProtocol=https;EndpointSuffix=core.windows.net;AccountName=snlcpdnpstg;AccountKey=FjZLcqu1gJjz2dAFLhNuyvC+TD9vyn3pO7igH";
		String containerName = "dev";
		
		ReflectionTestUtils.setField(config, "accountName", accountName);
		ReflectionTestUtils.setField(config, "containerName", containerName);
			config.getContainer();
	}

}
