package com.conduent.cpportal.screening.controller;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

@RunWith(SpringRunner.class)

class ErrorLogHandlerTest {
	String exception = "Exception Occured While Running Test Case ";

	private static final Logger log = LoggerFactory.getLogger(ErrorLogHandlerTest.class);

	
	@Mock
	RestTemplate restTemplate;

	@Test
	void testErrorLogHandler() {
	try {
		ErrorLogHandler handler = new ErrorLogHandler();
		handler.invokeExceptionLogging(null);
	} catch (Exception e) {
	log.error(exception);
	}
	}

}

