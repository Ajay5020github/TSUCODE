package com.conduent.cpportal.screening.utility;

public class ScreeningServiceTestConstants {

	private ScreeningServiceTestConstants() {
		super();
	}
	
	 public static final String  REFERENCE_DATA= "referenceData";
	 public static final String  SNAP_INCOME= "snapIncome";
	 public static final String  DEDUCTION= "deductions";
	 public static final String  TANF_INCOME= "tanfIncome";
	 public static final String  KIE_CONTAINER= "kieContainer";
	 public static final String  SCREENING_REPO_TXT = "screeningCheckEligibilityRepository";
	 public static final String  JDBC_TEMPLATE = "jdbcTemplate";

}
