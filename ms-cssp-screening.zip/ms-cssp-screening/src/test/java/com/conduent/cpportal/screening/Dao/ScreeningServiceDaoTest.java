/**
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 * 
 * Licensed under the CONDUENT License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * 
 * Software is the copyrighted work of Conduent and/or its licensors. Copying or reproducing  
 * the Software to any other server or location for further reproduction or redistribution is 
 * prohibited,  unless such reproduction or redistribution is permitted by a license agreement
 * accompanying  such Software. You may not create derivative works of the Software, or attempt to 
 * decompile or reverse-engineer the Software unless otherwise permitted by law. Use of the Software
 * is subject to the license terms of any license agreement that may accompany or is provided 
 * with the Software.
 */
package com.conduent.cpportal.screening.Dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.conduent.cpportal.screening.dao.ScreeningServiceDaoImpl;
import com.conduent.cpportal.screening.entity.ScreeningEligibilityEntity;
import com.conduent.cpportal.screening.exception.ScreeningServiceException;
import com.conduent.cpportal.screening.repository.ScreeningServiceRepository;
import com.conduent.cpportal.screening.utility.ScreeningServiceTestConstants;

@RunWith(SpringRunner.class)

class ScreeningServiceDaoTest {

	
	@Test
	void testScreeningEligibilityCheck1() throws ScreeningServiceException {
		ScreeningServiceDaoImpl dao = new ScreeningServiceDaoImpl();
		ScreeningServiceRepository repository = Mockito.mock(ScreeningServiceRepository.class);
		dao.setScreeningCheckEligibilityRepository(repository);

	}
	
	@Test
	void testScreeningEligibilityCheck() throws ScreeningServiceException {
		ScreeningServiceDaoImpl dao = new ScreeningServiceDaoImpl();
		ScreeningServiceRepository repository = Mockito.mock(ScreeningServiceRepository.class);
		ReflectionTestUtils.setField(dao, ScreeningServiceTestConstants.SCREENING_REPO_TXT, repository);
		ScreeningEligibilityEntity screeningEligibilityEntity = new ScreeningEligibilityEntity();
		dao.screeningEligibilityCheck(screeningEligibilityEntity);

	}
	
	@Test
	void testScreeningEligibilityCheckException() throws ScreeningServiceException {
		ScreeningServiceDaoImpl dao = new ScreeningServiceDaoImpl();
		ScreeningServiceRepository repository = Mockito.mock(ScreeningServiceRepository.class);
		ReflectionTestUtils.setField(dao, ScreeningServiceTestConstants.SCREENING_REPO_TXT, repository);
		when(repository.save(Mockito.any())).thenThrow(new DataAccessException("") {});
		ScreeningEligibilityEntity screeningEligibilityEntity = new ScreeningEligibilityEntity();
		assertNotNull(assertThrows(ScreeningServiceException.class, ()->dao.screeningEligibilityCheck(screeningEligibilityEntity)));

	}
	@Test
	void testfindAllTANFIncomeAmount() throws ScreeningServiceException {
		ScreeningServiceDaoImpl dao = new ScreeningServiceDaoImpl();
		JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
		ScreeningServiceRepository repository = Mockito.mock(ScreeningServiceRepository.class);
		ReflectionTestUtils.setField(dao, ScreeningServiceTestConstants.SCREENING_REPO_TXT, repository);
		ReflectionTestUtils.setField(dao, ScreeningServiceTestConstants.JDBC_TEMPLATE, jdbcTemplate);
		dao.findAllTANFIncomeAmount();

	}
	
	@Test
	void testfindAllStandardDeductions() throws ScreeningServiceException {
		ScreeningServiceDaoImpl dao = new ScreeningServiceDaoImpl();
		JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
		ScreeningServiceRepository repository = Mockito.mock(ScreeningServiceRepository.class);
		ReflectionTestUtils.setField(dao, ScreeningServiceTestConstants.SCREENING_REPO_TXT, repository);
		ReflectionTestUtils.setField(dao, ScreeningServiceTestConstants.JDBC_TEMPLATE, jdbcTemplate);
		dao.findAllStandardDeductions();

	}
	
	@Test
	void testfindReferenceData() throws ScreeningServiceException {
		ScreeningServiceDaoImpl dao = new ScreeningServiceDaoImpl();
		JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
		ScreeningServiceRepository repository = Mockito.mock(ScreeningServiceRepository.class);
		ReflectionTestUtils.setField(dao, ScreeningServiceTestConstants.SCREENING_REPO_TXT, repository);
		ReflectionTestUtils.setField(dao, ScreeningServiceTestConstants.JDBC_TEMPLATE, jdbcTemplate);
		Map<String,Double> map =dao.findReferenceData();
		assertEquals(map.get(map), null);
	}

	
	
	@Test
	void testfindAllSNAPIncomeAmount() throws ScreeningServiceException {
		ScreeningServiceDaoImpl dao = new ScreeningServiceDaoImpl();
		JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
		ScreeningServiceRepository repository = Mockito.mock(ScreeningServiceRepository.class);
		ReflectionTestUtils.setField(dao, ScreeningServiceTestConstants.SCREENING_REPO_TXT, repository);
		ReflectionTestUtils.setField(dao, ScreeningServiceTestConstants.JDBC_TEMPLATE, jdbcTemplate);
		dao.findAllSNAPIncomeAmount();

	}
	
}
