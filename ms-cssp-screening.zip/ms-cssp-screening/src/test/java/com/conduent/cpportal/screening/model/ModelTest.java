package com.conduent.cpportal.screening.model;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
@RunWith(SpringRunner.class)

public class ModelTest {
	@Test
	void testReferenceData() {
		int householdSize = 23;
		double dollarAmount = 56D;
		String key = "xYz";
		ReferenceData data1 = new ReferenceData(householdSize,dollarAmount);
		ReferenceData data2 = new ReferenceData(key,dollarAmount);
		ReferenceData data3 = new ReferenceData();
		assertNotNull(data1);
		assertNotNull(data2);
		assertNotNull(data3);
		data3.setDollarAmount(dollarAmount);
		data3.setHouseholdSize(householdSize);
		data3.setKey(key);
		assertEquals(data3.getDollarAmount(), dollarAmount);
		assertEquals(data3.getHouseholdSize(), householdSize);
		assertEquals(data3.getKey(), key);

		

	}
	@Test
	void testScreeningEligibilityResponse() {
		 int statusCode=3;
		 String message="Yes";
		 
		 ScreeningEligibilityResponse screeningEResponse=new ScreeningEligibilityResponse();
		 screeningEResponse.setEnergyAssistanceProgramEligibilityInd(message);
		 screeningEResponse.setMedicaidProgramEligibilityInd(message);
		 screeningEResponse.setMessage(message);
		 screeningEResponse.setSnapProgramEligibilityInd(message);
		 screeningEResponse.setStatusCode(statusCode);
		 screeningEResponse.setTanfProgramEligibilityInd(message);
		 
		 assertEquals(screeningEResponse.getEnergyAssistanceProgramEligibilityInd(), message);
		 assertEquals(screeningEResponse.getMedicaidProgramEligibilityInd(), message);
		 assertEquals(screeningEResponse.getMessage(), message);
		 assertEquals(screeningEResponse.getSnapProgramEligibilityInd(), message);
		 assertEquals(screeningEResponse.getStatusCode(), statusCode);
		 assertEquals(screeningEResponse.getTanfProgramEligibilityInd(), message);

	}
	@Test
	void testScreening() {
		String string="ABC";
		double d =34D;
		int i=1;
		
		Screening screening= new Screening();
		screening.setAdultOrChildCareExpenses(i);
		screening.setCitizenOrLegalResidentInd(string);
		screening.setEnergyAssistanceProgramEligibility(string);
		screening.setHeatingOrCoolingExpenses(i);
		screening.setHouseholdAssetsDollar(d);
		screening.setHouseholdDisabledInd(string);
		screening.setHouseholdGrossIncome(i);
		screening.setHouseholdLiveInMississippiInd(string);
		screening.setHouseholdMedicalExpensesInd(string);
		screening.setHouseholdOtherSourceIncome(i);
		screening.setMedicaidEligibility(string);
		screening.setMigrantORSeasonalWorkerInd(string);
		screening.setNumberOfAdults22through59(i);
		screening.setNumberOfAdults60orAbove(i);
		screening.setNumberOfChildren18through21(i);
		screening.setNumberOfChildrenUnderAge18(i);
		screening.setPlanToLiveInMississippiInd(string);
		screening.setRentIncludesHeatOrCoolingExpensesInd(string);
		screening.setRentOrMortgageExpenses(i);
		screening.setSnapEligibility(string);
		screening.setSnapExpenses(i);
		screening.setSnapIncome(i);
		screening.setSupplementalSecurityIncome(i);
		screening.setTanfEligibility(string);
		screening.setTanfExpenses(i);
		screening.setTanfIncome(i);
		screening.setTotalNumberOfHouseHolds(i);
		screening.setTanfIncome(i);
		screening.setUserId(string);
		
		
		
		screening.getAdultOrChildCareExpenses();
		screening.getCitizenOrLegalResidentInd();
		screening.getEnergyAssistanceProgramEligibility();
		screening.getHeatingOrCoolingExpenses();
		screening.getHouseholdAssetsDollar();
		screening.getHouseholdDisabledInd();
		screening.getHouseholdGrossIncome();
		screening.getHouseholdLiveInMississippiInd();
		screening.getHouseholdMedicalExpensesInd();
		screening.getHouseholdOtherSourceIncome();
		screening.getMedicaidEligibility();
		screening.getMigrantORSeasonalWorkerInd();
		screening.getNumberOfAdults22through59();
		screening.getNumberOfAdults60orAbove();
		screening.getNumberOfChildren18through21();
		screening.getNumberOfChildrenUnderAge18();
		screening.getPlanToLiveInMississippiInd();
		screening.getRentIncludesHeatOrCoolingExpensesInd();
		screening.getRentOrMortgageExpenses();
		screening.getSnapEligibility();
		screening.getSnapExpenses();
		screening.getSnapIncome();
		screening.getSupplementalSecurityIncome();
		screening.getTanfEligibility();
		screening.getTanfExpenses();
		screening.getTanfIncome();
		screening.getTotalNumberOfHouseHolds();
		screening.getUserId();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
