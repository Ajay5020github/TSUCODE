/**
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 * 
 * Licensed under the CONDUENT License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * 
 * Software is the copyrighted work of Conduent and/or its licensors. Copying or reproducing  
 * the Software to any other server or location for further reproduction or redistribution is 
 * prohibited,  unless such reproduction or redistribution is permitted by a license agreement
 * accompanying  such Software. You may not create derivative works of the Software, or attempt to 
 * decompile or reverse-engineer the Software unless otherwise permitted by law. Use of the Software
 * is subject to the license terms of any license agreement that may accompany or is provided 
 * with the Software.
 */
package com.conduent.cpportal.screening.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.conduent.cpportal.screening.model.Screening;
import com.conduent.cpportal.screening.model.ScreeningEligibilityResponse;
import com.conduent.cpportal.screening.service.ScreeningService;


@RunWith(MockitoJUnitRunner.class)
class ScreeningServiceControllerTest {


	@Test
	void testscreeningEligibilityCheckBadRequest() {
		Screening screening = new Screening();
		screening.setNumberOfChildrenUnderAge18(1);
		screening.setHouseholdDisabledInd("Yes");
		screening.setHouseholdOtherSourceIncome(1000);
		screening.setHouseholdGrossIncome(100);
		screening.setHeatingOrCoolingExpenses(500);
		screening.setRentOrMortgageExpenses(500);
		ScreeningServiceController controller = new ScreeningServiceController();
		ScreeningService screeningService = mock(ScreeningService.class);
		ReflectionTestUtils.setField(controller, "screeningService", screeningService);
		ResponseEntity<ScreeningEligibilityResponse> responcEntity = controller.screeningEligibilityCheck(screening);
		assertEquals(HttpStatus.BAD_REQUEST, responcEntity.getStatusCode());
	}
	
	@Test
	void testscreeningEligibilityCheckOk() {
		Screening screening = new Screening();
		ScreeningServiceController controller = new ScreeningServiceController();
		ScreeningService screeningService = mock(ScreeningService.class);
		ReflectionTestUtils.setField(controller, "screeningService", screeningService);
		ResponseEntity<ScreeningEligibilityResponse> responcEntity = controller.screeningEligibilityCheck(screening);
		assertEquals(HttpStatus.OK, responcEntity.getStatusCode());
	}
	


}
