package com.conduent.cpportal.screening.controller;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.conduent.cpportal.screening.exception.ScreeningServiceException;

@RunWith(SpringRunner.class)
public class ExceptionHandlerAdviceTest {
	
	String exception = "Exception Occured While Running Test Case ";

	private static final Logger log = LoggerFactory.getLogger(ExceptionHandlerAdviceTest.class);


	@Test
	void testHandleMethodArgumentNotValid() {
		BindingResult result = mock(BindingResult.class);
		
		MethodParameter methodParameter = mock(MethodParameter.class);
	
		MethodArgumentNotValidException ex = new MethodArgumentNotValidException(methodParameter, result);
		ErrorLogHandler errorHandler = mock(ErrorLogHandler.class);
		ExceptionHandlerAdvice exceptionHandler = new ExceptionHandlerAdvice();
		ReflectionTestUtils.setField(exceptionHandler, "errorHandler", errorHandler);
		try {
			
		
		exceptionHandler.handleMethodArgumentNotValid(ex);
		} catch (Exception e) {
			log.error(exception);
		}
	}
	
	@Test
	void testscreeningException() {
		ScreeningServiceException ex = mock(ScreeningServiceException.class);
	
		ErrorLogHandler errorHandler = mock(ErrorLogHandler.class);
		ExceptionHandlerAdvice exceptionHandler = new ExceptionHandlerAdvice();
		ReflectionTestUtils.setField(exceptionHandler, "errorHandler", errorHandler);
			
		
		exceptionHandler.screeningException(ex);
	}
	
}
