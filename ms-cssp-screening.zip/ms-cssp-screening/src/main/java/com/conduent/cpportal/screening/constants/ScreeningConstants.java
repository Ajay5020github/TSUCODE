/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */
package com.conduent.cpportal.screening.constants;

/** 
 * @author Conduent Inc
 * 
 * RulsConstants contains list of constants
 *
 */
public class ScreeningConstants {


	private ScreeningConstants(){
		
	}

	public static final String RADIO_OPTIONAL = "^(?i)(YES|NO)?$"; //allows empty string
	public static final String RADIO_MANDATORY = "^(?i)(YES|NO)+$"; //does not allow empty string

	public static final String PROGRAM_ONE = "P01";
	public static final String PROGRAM_TWO = "P02";
	public static final String PROGRAM_THREE = "P03";
	public static final String PROGRAM_FOUR = "P04";
	public static final String MEDICAID_PROGRAM = "Medicaid";
	public static final String TANF_PROGRAM = "TANF";
	public static final String SNAP_PROGRAM = "SNAP";
	public static final String LIHEAP_PROGRAM = "LIHEAP";
	
	public static final String Y_IND = "Y";
	public static final String N_IND = "N";
	
	public static final String YES_IND = "YES";
	public static final String NO_IND = "NO";
	
	public static final int SUCCEESS = 200;
	public static final String SUCCESS_MSG = "SUCCESS";
	
	public static final String ERROR_MESSAGE = "Exception while screening";
	public static final String BAD_REQUEST = "Bad Request";
	
	public static final int INTERNAL_SERVER = 500;
	public static final String INTERNAL_SERVER_MSG = "Internal Server Error";
	
	public static final String HOUSEHOLD_SIZE = "HOUSEHOLD_SIZE";

}
