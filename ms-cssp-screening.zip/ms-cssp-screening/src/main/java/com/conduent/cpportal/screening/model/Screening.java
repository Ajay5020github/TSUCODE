/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */
package com.conduent.cpportal.screening.model;

import java.io.Serializable;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

import com.conduent.cpportal.screening.constants.ScreeningConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author Conduent Inc
 * 
 *         Screening class is used as entity for screening input from UI
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class Screening implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String userId;

	// Screening question#1
	@Positive
	private int totalNumberOfHouseHolds;

	// Screening question#2
	@PositiveOrZero
	private int  numberOfChildrenUnderAge18;

	@PositiveOrZero
	private int numberOfChildren18through21;

	@PositiveOrZero
	private int numberOfAdults22through59;

	@PositiveOrZero
	private int numberOfAdults60orAbove;

	// Screening question#3
	@Pattern(regexp = ScreeningConstants.RADIO_MANDATORY)
	private String householdLiveInMississippiInd;

	@Pattern(regexp = ScreeningConstants.RADIO_OPTIONAL)
	private String migrantORSeasonalWorkerInd;

	@Pattern(regexp = ScreeningConstants.RADIO_OPTIONAL)
	private String planToLiveInMississippiInd;

	@Pattern(regexp = ScreeningConstants.RADIO_MANDATORY)
	private String citizenOrLegalResidentInd;

	@Pattern(regexp = ScreeningConstants.RADIO_MANDATORY)
	private String householdDisabledInd;

	@Pattern(regexp = ScreeningConstants.RADIO_MANDATORY)
	private String householdMedicalExpensesInd;

	// Screening question#4 - Income
	@PositiveOrZero
	private double householdGrossIncome;

	@PositiveOrZero
	private double householdOtherSourceIncome;

	@PositiveOrZero
	private double supplementalSecurityIncome;

	// Screening question#5 - Assets
	@PositiveOrZero
	private double householdAssetsDollar;


	// Screening question#6 - Expenses
	@PositiveOrZero
	private double rentOrMortgageExpenses;
	@PositiveOrZero
	private double heatingOrCoolingExpenses;


	@PositiveOrZero
	private double adultOrChildCareExpenses;

	@Pattern(regexp = ScreeningConstants.RADIO_MANDATORY)
	private String rentIncludesHeatOrCoolingExpensesInd;

	@JsonIgnore
	private String tanfEligibility;
	@JsonIgnore
	private String snapEligibility;
	@JsonIgnore
	private String medicaidEligibility;
	@JsonIgnore
	private String energyAssistanceProgramEligibility;

	@JsonIgnore
	private double snapIncome;

	@JsonIgnore
	private double tanfIncome;

	@JsonIgnore
	private double snapExpenses;

	@JsonIgnore
	private double tanfExpenses;
}
