/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */
package com.conduent.cpportal.screening.service;

import com.conduent.cpportal.screening.exception.ScreeningServiceException;
import com.conduent.cpportal.screening.model.Screening;
import com.conduent.cpportal.screening.model.ScreeningEligibilityResponse;

/**
 * @author Conduent Inc
 * 
 * ScreeningService interacts with the 
 * ScreeningServiceDAO which
 * extends the JPARepsoitory to
 * save the data and fetch the response
 * from the database
 *
 */

public interface ScreeningService {
	 ScreeningEligibilityResponse screeningEligibilityCheck(Screening screening)
			throws ScreeningServiceException;


}
