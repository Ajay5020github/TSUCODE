/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */

package com.conduent.cpportal.screening.exception;

/**
 * ScreeningServiceException class which is used to give meaningful information
 * to the user
 */

public class ScreeningServiceException extends RuntimeException {

	private static final long serialVersionUID = 1L;


	private final int errorCode;

	public String getAction() {
		return action;
	}

	private final String action;

	public Long getConsumerId() {
		return consumerId;
	}

	private final Long consumerId;



	public int getErrorCode() {
		return errorCode;
	}

	public ScreeningServiceException(int errorCode, String action,Long consumerId, String errorMsg, Throwable cause) {
		super(errorMsg, cause);
		this.errorCode = errorCode;
		this.action = action;
		this.consumerId = consumerId;
	}



}
