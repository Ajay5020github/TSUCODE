package com.conduent.cpportal.screening.service;

import com.conduent.cpportal.screening.dao.ScreeningServiceDAO;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;

import java.util.Map;

@Service
@SessionScope
@Setter
@Getter
@NoArgsConstructor
public class ReferenceDataBean {


    private static final Logger log = LoggerFactory.getLogger(ReferenceDataBean.class);

    Map<Integer, Double> snapIncome;
    Map<Integer, Double> tanfIncome;
    Map<String, Double> deductions;
    Map<String, Double> referenceData;

    private ScreeningServiceDAO screeningServiceDAO;

    @Autowired
    public ReferenceDataBean(ScreeningServiceDAO screeningServiceDAO){
        this.screeningServiceDAO = screeningServiceDAO;
        snapIncome = screeningServiceDAO.findAllSNAPIncomeAmount();
        tanfIncome = screeningServiceDAO.findAllTANFIncomeAmount();
        deductions = screeningServiceDAO.findAllStandardDeductions();
        referenceData = screeningServiceDAO.findReferenceData();
    }
}
