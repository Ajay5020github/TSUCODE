/**
 * 
 */
package com.conduent.cpportal.screening.helper;

import com.conduent.cpportal.screening.model.Screening;
import com.conduent.cpportal.screening.model.ScreeningEligibilityResponse;

/**
 * @author Conduent Inc
 *
 */
public class ScreeningHelper {

	/**
	 * 
	 * @param req
	 * @return
	 */
	public boolean validateScreening(Screening req) {

		return this.validateTotalAgesNumOfHousehold(req);
	}


	private boolean validateTotalAgesNumOfHousehold(Screening req) {
		int sizeofHousehold = 	req.getTotalNumberOfHouseHolds();

		int totalAgesNumberOfHousehold = (req.getNumberOfChildren18through21() +
				req.getNumberOfAdults22through59() +
				req.getNumberOfAdults60orAbove()+
				req.getNumberOfChildrenUnderAge18());

		return (sizeofHousehold == totalAgesNumberOfHousehold);
	}


	/**
	 *
	 * @param programEligibilityResponse
	 * @param statusCode
	 * @return
	 */
	public ScreeningEligibilityResponse  screeningExceptionRes(ScreeningEligibilityResponse	programEligibilityResponse, int statusCode) {
		programEligibilityResponse.setStatusCode(statusCode);

		return programEligibilityResponse;

	}
}