/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 CONDUENT. All Rights Reserved>
 *
 */
package com.conduent.cpportal.screening.service;


import java.sql.Timestamp;
import java.time.Instant;


import jakarta.transaction.Transactional;


import lombok.NoArgsConstructor;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conduent.cpportal.screening.constants.ScreeningConstants;
import com.conduent.cpportal.screening.dao.ScreeningServiceDAO;
import com.conduent.cpportal.screening.entity.ScreeningEligibilityEntity;
import com.conduent.cpportal.screening.exception.ScreeningServiceException;
import com.conduent.cpportal.screening.model.Screening;
import com.conduent.cpportal.screening.model.ScreeningEligibilityResponse;

/**
 * @author Conduent Inc
 * ScreeningServiceImpl class is used for screening based on rules defined in
 * drools file
 */
@Service
@NoArgsConstructor
public class ScreeningServiceImpl implements ScreeningService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScreeningServiceImpl.class);

	

	private ScreeningServiceDAO screeningServiceDAO;


	private KieContainer kieContainer;

	private ReferenceDataBean referenceData;


	@Autowired
	public ScreeningServiceImpl(ScreeningServiceDAO screeningServiceDAO, KieContainer kieContainer,ReferenceDataBean referenceData) {
		this.screeningServiceDAO = screeningServiceDAO;
		this.kieContainer = kieContainer;
        this.referenceData =  referenceData;
	}


	/*
	 * screeningEligibilityCheck() method deals with integration with drools file
	 * 
	 * @param screening
	 * 
	 * @return ProgramEligibilityResponse
	 * 
	 * @throws ScreeningServiceException and DroolsParserException
	 * 
	 */
	@Override
	@Transactional
	public ScreeningEligibilityResponse screeningEligibilityCheck(Screening screening)
			throws ScreeningServiceException {
		
		
		LOGGER.info("Start screeningEligibilityCheck in ScreeningServiceImpl");

		ScreeningEligibilityResponse programEligibilityResponse = new ScreeningEligibilityResponse();
		ScreeningEligibilityEntity screeningEligibility;

		try {

			KieSession kieSession = kieContainer.newKieSession();
			kieSession.setGlobal("screening", screening);
			kieSession.insert(screening);
			LOGGER.info("Start screeningEligibilityCheck in ScreeningServiceImpl55");
			kieSession.setGlobal("HEAT_COOL_EXPENSES",referenceData.getReferenceData().get("HEAT_COOL_EXPENSES"));
			kieSession.setGlobal("HEAT_COOL_EXPENSES_DEFAULT", referenceData.getReferenceData().get("HEAT_COOL_EXPENSES_DEFAULT"));
			kieSession.setGlobal("TANF_BUDGET_VAL", referenceData.getReferenceData().get("TANF_BUDGET_VAL"));
			kieSession.setGlobal("SNAP_BUDGET_VAL", referenceData.getReferenceData().get("SNAP_BUDGET_VAL"));
			kieSession.setGlobal("TANF_CHILD_LIMIT", referenceData.getReferenceData().get("TANF_CHILD_LIMIT"));
			kieSession.setGlobal("STANDARD_DEDUCTIONS", referenceData.getDeductions());
			kieSession.setGlobal("TANF_INCOME_LIMIT", referenceData.getTanfIncome());
			kieSession.setGlobal("SNAP_INCOME_LIMIT", referenceData.getSnapIncome());
			kieSession.fireAllRules();
			kieSession.dispose();

			programEligibilityResponse.setMedicaidProgramEligibilityInd(ScreeningConstants.YES_IND);

			programEligibilityResponse.setTanfProgramEligibilityInd(screening.getTanfEligibility());
			programEligibilityResponse.setSnapProgramEligibilityInd(screening.getSnapEligibility());
			programEligibilityResponse.setEnergyAssistanceProgramEligibilityInd(screening.getSnapEligibility());
			programEligibilityResponse.setStatusCode(ScreeningConstants.SUCCEESS);
			programEligibilityResponse.setMessage("Screening check completed");

			screeningEligibility = new ScreeningEligibilityEntity();
			if(screening.getUserId() == null ||  screening.getUserId().isEmpty()) {
				screeningEligibility.setAnonymousUserInd(ScreeningConstants.Y_IND);
			}else {
				screeningEligibility.setAnonymousUserInd(ScreeningConstants.N_IND);
			}
			screeningEligibility.setSnapEligibilityInd(screening.getSnapEligibility());
			screeningEligibility.setHealthCoverageInd(ScreeningConstants.YES_IND);
			screeningEligibility.setTanfEligibilityInd(screening.getTanfEligibility());
			screeningEligibility.setEnergyAssistanceCoverageInd(screening.getSnapEligibility());

			
			screeningEligibility.setScreeningDateTime(Timestamp.from(Instant.now()));
			screeningServiceDAO.screeningEligibilityCheck(screeningEligibility);

		} catch (Exception ex) {
			LOGGER.error("Exception while drools execution : {} {}", ex.getMessage(), ex);
			throw new ScreeningServiceException(500,"screeningEligibilityCheck",null,ex.getMessage(),ex.getCause());
		}
		LOGGER.info("End screeningEligibilityCheck in ScreeningServiceImpl");

		return programEligibilityResponse;
	}



	public void setScreeningCheckEligibilityDAO(ScreeningServiceDAO screeningCheckElibilityDAO) {
		this.screeningServiceDAO = screeningCheckElibilityDAO;
	}

}
