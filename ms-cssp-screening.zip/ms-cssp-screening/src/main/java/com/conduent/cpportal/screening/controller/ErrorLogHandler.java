package com.conduent.cpportal.screening.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.Map;

@Component
public class ErrorLogHandler {


    @Value("${logging.error.api}")
    private String errorAPI;

    /**
     *
     * @param errorObject
     */
    public void invokeExceptionLogging(Map<String, Object> errorObject) {


        // create an instance of RestTemplate
        RestTemplate restTemplate = new RestTemplate();

        // create headers
        HttpHeaders headers = new HttpHeaders();
        // set `content-type` header
        headers.setContentType(MediaType.APPLICATION_JSON);
        // set `accept` header
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        // request body parameters
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(errorObject, headers);
        restTemplate.postForEntity(errorAPI+"transactionLog", entity, String.class);
    }
}
