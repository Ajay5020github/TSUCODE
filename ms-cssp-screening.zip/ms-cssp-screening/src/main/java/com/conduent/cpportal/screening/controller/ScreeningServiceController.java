/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */
package com.conduent.cpportal.screening.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.conduent.cpportal.screening.constants.ScreeningConstants;
import com.conduent.cpportal.screening.exception.ScreeningServiceException;
import com.conduent.cpportal.screening.helper.ScreeningHelper;
import com.conduent.cpportal.screening.model.Screening;
import com.conduent.cpportal.screening.model.ScreeningEligibilityResponse;
import com.conduent.cpportal.screening.service.ScreeningService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;

/**
 * @author Conduent Inc
 * 
 *         ScreeningServiceController class is used for screening of consumer
 *         portal
 *
 */
@RestController
public class ScreeningServiceController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScreeningServiceController.class);

	@Autowired
	private ScreeningService screeningService;

	@Autowired
	private ErrorLogHandler handler;
	/**
	 * @param screening
	 * @return ProgramEligibilityResponse
	 * @throws ScreeningServiceException
	 *
	 */

	@Operation(summary = "This method is used to check screen eligibility")
	@ApiResponses(value = { @ApiResponse(responseCode  = "200", description  = "Screening check completed"),
			@ApiResponse(responseCode = "400", description = "Bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error") })
	@PostMapping(value = "/screeningEligibilityCheck")
	@ExceptionHandler(value = ScreeningServiceException.class)
	public ResponseEntity<ScreeningEligibilityResponse> screeningEligibilityCheck(
			@RequestBody(required = true) @Valid Screening screening) {
		LOGGER.info("Start screeningEligibilityCheck in ScreeningServiceController ");
		ScreeningEligibilityResponse programEligibilityResponse = null;


			if(!new ScreeningHelper().validateScreening(screening)) {
				
				
				
				
				programEligibilityResponse = new ScreeningEligibilityResponse();
				programEligibilityResponse = new ScreeningHelper().screeningExceptionRes(programEligibilityResponse, 400);
				programEligibilityResponse.setMessage(ScreeningConstants.BAD_REQUEST);
				return new ResponseEntity<>(programEligibilityResponse, HttpStatus.BAD_REQUEST);
			}

		LOGGER.info("End screeningEligibilityCheck in ScreeningServiceController ");
		return new ResponseEntity<>(screeningService.screeningEligibilityCheck(screening), HttpStatus.OK);
	}

	
}