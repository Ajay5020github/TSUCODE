/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 CONDUENT. All Rights Reserved>
 *
 */

package com.conduent.cpportal.screening.dao;

import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.conduent.cpportal.screening.entity.ScreeningEligibilityEntity;
import com.conduent.cpportal.screening.exception.ScreeningServiceException;
import com.conduent.cpportal.screening.model.ReferenceData;
import com.conduent.cpportal.screening.repository.ScreeningServiceRepository;

/**
 * ScreeningServiceDaoImpl class is used for screening based on rules defined in
 * drools file
 */
/**
 * @author Conduent Inc
 */
@Repository
public class ScreeningServiceDaoImpl implements ScreeningServiceDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScreeningServiceDaoImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ScreeningServiceRepository screeningCheckEligibilityRepository;



	/**
	 * screeningEligibilityCheck() method deals with screening based on rules
	 * defined in drools file and insert the data into database
	 * 
	 * @param screeningEligibility
	 */
	public ScreeningEligibilityEntity screeningEligibilityCheck(ScreeningEligibilityEntity screeningEligibility)
			throws ScreeningServiceException {
		LOGGER.info("Start screeningEligibilityCheck in ScreeningServiceDaoImpl");


		try {
		screeningCheckEligibilityRepository.save(screeningEligibility);

		} catch (DataAccessException e) {
			throw new ScreeningServiceException(500,"loadScreeningReferenceData",null,e.getMessage(),e.getCause());

		}
		LOGGER.info("End screeningEligibilityCheck in ScreeningServiceDaoImpl");
		return screeningEligibility;
	}



	private static final String SNAP_QUERY = "SELECT HOUSEHOLD_SIZE, NET_INCOME_LIMIT FROM SNAP_INCOME_TB";

	@Override
	public Map<Integer, Double> findAllSNAPIncomeAmount() {
		LOGGER.info("Entering into findAllSNAPIncomeAmount() :: ");
		return	this.jdbcTemplate.query(SNAP_QUERY, (rs, rownum)->
		new ReferenceData(rs.getInt("HOUSEHOLD_SIZE"), rs.getDouble("NET_INCOME_LIMIT"))
				).stream().collect(Collectors.toMap(ReferenceData :: getHouseholdSize, ReferenceData :: getDollarAmount));
	}

	private static final String TANF_QUERY = "SELECT HOUSEHOLD_SIZE, INCOME_LIMIT FROM TANF_INCOME_TB";

	@Override
	public Map<Integer, Double> findAllTANFIncomeAmount() {
		LOGGER.info("Entering into findAllTANFIncomeAmount() :: ");
		return	this.jdbcTemplate.query(TANF_QUERY, (rs, rownum)->
		new ReferenceData(rs.getInt("HOUSEHOLD_SIZE"), rs.getDouble("INCOME_LIMIT"))
				)
				.stream().collect(Collectors.toMap(ReferenceData :: getHouseholdSize, ReferenceData :: getDollarAmount));
	}

	private static final String STANDARD_DEDUCTIONS_QUERY = "SELECT FORMULA,EXPENSES FROM STANDARD_DEDUCTIONS_TB";

	@Override
	public Map<String,Double> findAllStandardDeductions(){
		LOGGER.info("Entering into findAllStandardDeductions() :: ");
		return this.jdbcTemplate.query(STANDARD_DEDUCTIONS_QUERY, (rs, rownum) ->
						new ReferenceData(rs.getString("FORMULA"), rs.getDouble("EXPENSES"))
				).stream().collect(Collectors.toMap(ReferenceData :: getKey, ReferenceData :: getDollarAmount));

	}

	public void setScreeningCheckEligibilityRepository(ScreeningServiceRepository repository) {
		this.screeningCheckEligibilityRepository = repository;
	}

	private static final String SCREENING_REF_QUERY = "SELECT REFERENCE_KEY, REFERENCE_VAL FROM SCREENING_REFERENCE_TB";
	@Override
	public Map<String, Double> findReferenceData() {
		LOGGER.info("Entering into findReferenceData() :: ");
		return	this.jdbcTemplate.query(SCREENING_REF_QUERY, (rs, rownum)->
						new ReferenceData(rs.getString("reference_key"), rs.getInt("reference_val"))
				)
				.stream().collect(Collectors.toMap(ReferenceData :: getKey, ReferenceData :: getDollarAmount));
	}

}
