package com.conduent.cpportal.screening.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.conduent.cpportal.screening.exception.ScreeningServiceException;
import com.conduent.cpportal.screening.model.ScreeningEligibilityResponse;

/**
 * 
 * @author Conduent Inc
 *
 */
@RestControllerAdvice
public class ExceptionHandlerAdvice {



	@ExceptionHandler(value = {ScreeningServiceException.class})
	public ResponseEntity<ScreeningEligibilityResponse> screeningException(ScreeningServiceException ex) {
		ScreeningEligibilityResponse response = new ScreeningEligibilityResponse();
		response.setStatusCode(ex.getErrorCode());
		response.setMessage(ex.getMessage());

		transactionLog( ex, ex.getErrorCode());
		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}


	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> handleMethodArgumentNotValid(	MethodArgumentNotValidException ex ){

		Map<String, Object> body = new LinkedHashMap<>();
		body.put("timestamp", new Date());
		body.put("statusCode", 400);
		body.put("message", "Bad Request");
		//Get all errors
		List<String> errors = ex.getBindingResult().getFieldErrors().stream()
				.map(x -> x.getField()).collect(Collectors.toList());
		body.put("errorFields", errors);

		transactionLog( ex, 400);

		return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
	}

	@Autowired
	private ErrorLogHandler errorHandler;


	private void transactionLog(Exception ex, int errorCode) {
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> childObj = new HashMap<>();

		if (ex instanceof MethodArgumentNotValidException) {
			MethodArgumentNotValidException methodEx = (MethodArgumentNotValidException) ex;
			map.put("actionName", methodEx.getParameter().getMethod() != null ?methodEx.getParameter().getMethod().getName():null);
			map.put("serviceId", methodEx.getParameter().getMethod() != null ?methodEx.getParameter().getMethod().getName():null);
			childObj.put("responseCode", errorCode);
			childObj.put("errorCode", errorCode);
		} else if (ex instanceof ScreeningServiceException) {
			ScreeningServiceException aex = (ScreeningServiceException) ex;
			map.put("actionName", aex.getAction());
			map.put("serviceId", aex.getAction());
			map.put("consumerId", aex.getConsumerId());
			childObj.put("responseCode", aex.getErrorCode());
			childObj.put("errorCode", aex.getErrorCode());
		}

		map.put("transactionId", null);
		map.put("serviceType", "Account");
		map.put("sourceLayer", "Service-SB");
		map.put("transactionStatus", "F");
		childObj.put("errorMessage", ex.getMessage());
		childObj.put("errorTrace", Arrays.toString(ex.getStackTrace()));
		map.put("message", childObj);
		errorHandler.invokeExceptionLogging(map);
	}

	}
