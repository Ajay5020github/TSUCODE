package com.conduent.cpportal.screening.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * @author Conduent Inc
 *
 */
@Setter
@Getter
@NoArgsConstructor
public class ReferenceData {

    private int householdSize;
    private double dollarAmount;
    private String key;


    public ReferenceData(int householdSize, double dollarAmount) {
        this.householdSize = householdSize;
        this.dollarAmount = dollarAmount;
    }


    public ReferenceData(String key, double dollarAmount) {
        this.key = key;
        this.dollarAmount = dollarAmount;
    }

}
