/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */
package com.conduent.cpportal.screening.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author Conduent Inc
 * 
 *         ScreeningEligibilityResponse class is used for Returning screening
 *         Response
 * 
 */

@Getter
@Setter
@NoArgsConstructor
public class ScreeningEligibilityResponse {

	private int statusCode;

	private String message;

	private String medicaidProgramEligibilityInd;
	private String tanfProgramEligibilityInd;
	private String snapProgramEligibilityInd;
	private String energyAssistanceProgramEligibilityInd;

}
