/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */

package com.conduent.cpportal.screening;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

/**
 * 
 * @author Conduent Inc 
 * Description: ScreeningServiceApplication is the class
 *         to invoke screening service by sending screening answers to
 *         ScreeningServiceDAOImpl class to
 *         fetch eligibility data as response
 *
 */

@SpringBootApplication
@EnableWebSecurity
public class ScreeningServiceApplication {

	
	/**
	 * @param args
	 */



	public static void main(String[] args) {

		SpringApplication.run(ScreeningServiceApplication.class, args);
	}
	


}
