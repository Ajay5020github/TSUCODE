/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */
package com.conduent.cpportal.screening.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author Conduent Inc
 * 
 *         ScreeningEligibilityEntity class is used as entity for screening
 *
 */

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "SCREENING_RESULTS")
public class ScreeningEligibilityEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SCREENING_ID", nullable = false)
	private Long screeningId;

	@Column(name = "TANF_ELG_IND", length = 3)
	private String tanfEligibilityInd;

	@Column(name = "SNAP_ELG_IND", length = 3)
	private String snapEligibilityInd;

	@Column(name = "HEALTH_COVERAGE_ELG_IND", length = 3)
	private String healthCoverageInd;

	@Column(name = "LIHEAP_ELG_IND", length = 3)
	private String energyAssistanceCoverageInd;
	
	@Column(name = "ANONYMOUS_USER_IND", length = 5)
	private String anonymousUserInd;

	@Column(name = "SCREENING_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	private Date screeningDateTime;

}
