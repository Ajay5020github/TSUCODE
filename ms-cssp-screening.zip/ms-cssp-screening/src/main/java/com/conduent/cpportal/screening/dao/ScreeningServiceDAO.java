/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */

package com.conduent.cpportal.screening.dao;

import java.util.Map;

import com.conduent.cpportal.screening.entity.ScreeningEligibilityEntity;
import com.conduent.cpportal.screening.exception.ScreeningServiceException;


/**
 * @author Conduent Inc
 * ScreeningSericeDAO interface returns programEligibilityResponse by taking screeningEligibility
 */
public interface ScreeningServiceDAO {
	public ScreeningEligibilityEntity screeningEligibilityCheck(ScreeningEligibilityEntity screeningEligibility)
			throws ScreeningServiceException;

	
	public Map<Integer, Double> findAllSNAPIncomeAmount();
	
	public Map<Integer, Double> findAllTANFIncomeAmount();
	
	public Map<String,Double>  findAllStandardDeductions();

	public Map<String, Double> findReferenceData() ;
}
