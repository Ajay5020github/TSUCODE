/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */
package com.conduent.cpportal.screening.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.conduent.cpportal.screening.entity.ScreeningEligibilityEntity;

/**
 * @author Conduent Inc
 * 
 *  Interface extends JpaRepository by taking ScreeningEligibilityEntity
 *         and sends the data to save it in the database
 *
 */

public interface ScreeningServiceRepository extends JpaRepository<ScreeningEligibilityEntity, Integer> {

}
