/*
 * 
 * screening 22-08-2019 service
 * <Copyright (c) 2019 Conduent. All Rights Reserved>
 *
 */

package com.conduent.cpportal.screening.config;

import java.net.URISyntaxException;
import java.security.InvalidKeyException;

import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.runtime.KieContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.XXssProtectionHeaderWriter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;




/**
 * @author Conduent Inc
 * It is a configuration file which contains configuration information
 * to connect to Swagger UI
 *
 */
@Configuration
@EnableWebMvc
public class ScreeningApplicationConfig {

	private static final Logger logger = LoggerFactory.getLogger(ScreeningApplicationConfig.class);
	/**
	 * This is a Docket api method which calls the apiinfo method by passing the
	 * controller's path.
	 */
	/*
	 * @Bean public Docket api() { return new
	 * Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select()
	 * .apis(RequestHandlerSelectors.basePackage("com.conduent.cpportal.screening"))
	 * .paths(PathSelectors.any()).build(); }
	 */

	/**
	 * apiinfo method is used to connect the swagger by calling the service url
	 * ,license and license url.
	 * 
	 * 
	 */
	/*
	 * private ApiInfo apiInfo() { return new
	 * ApiInfoBuilder().title("Benepath - SSP Screening Service")
	 * .description("Benepath - SSP Screening Service restAPI Info").build();
	 * 
	 * }
	 */
	@Bean
	public OpenAPI openApiInformation() {
	 
	  Info info = new Info()
	              .description("Benepath - SSP Screening Service restAPI Info")
	              .title("Benepath - SSP Screening Service")
	              .version("V1.0.0");
	  return new OpenAPI().info(info);
	 }




	@Value("${azure.storage.connection-string}")
	private String accountName;

	@Value("${azure.storage.container-name}")
	private String containerName;

	@Bean
	public KieContainer getContainer() {
		logger.info("Start of getContainer in ApplicationConfig");
		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container = null;
		KieContainer kieContainer = null;
		try {
			storageAccount = CloudStorageAccount.parse(accountName);
			blobClient = storageAccount.createCloudBlobClient();
			container = blobClient.getContainerReference(containerName);
			

			CloudBlockBlob azureBlob = container.getBlockBlobReference("csspdev/Screening/Rules/screeningRules.drl");
			KieServices kieServices = KieServices.Factory.get();
			KieFileSystem kfs = kieServices.newKieFileSystem();
			kfs.write("src/main/resources/rules/screeningRules.drl",
					kieServices.getResources().newInputStreamResource(azureBlob.openInputStream()));
			
			KieBuilder kb = kieServices.newKieBuilder(kfs);
			kb.buildAll();
			kieContainer = kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
			
		} catch (InvalidKeyException | StorageException | URISyntaxException io) {
			logger.error("error while getting container {}", io.getMessage());
		}
		logger.info("End of getContainer in ApplicationConfig");
		return kieContainer;
	}

	@Bean
	public WebSecurityCustomizer webSecurityCustomizer() {
		return (web) -> web.ignoring()
				.requestMatchers("/**");
	}

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.headers(headers -> headers
                .xssProtection(xss -> xss.headerValue(XXssProtectionHeaderWriter.HeaderValue.ENABLED_MODE_BLOCK))
                        .contentSecurityPolicy(csp -> csp
                            .policyDirectives("script-src 'self'")
                        ));
		return http.build();
	}

}
