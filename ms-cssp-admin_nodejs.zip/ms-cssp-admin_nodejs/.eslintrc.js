module.exports = {
    "env": {
        "browser": true,
        "commonjs": true,
        "es6": true,
        "jest": true,
        "node": true
    },
    "extends": "eslint:recommended",
    "globals": {
        "Atomics": "readonly",
        "SharedArrayBuffer": "readonly"
    },
    "parserOptions": {
        "ecmaFeatures": {
            "jsx": true
        },
        "ecmaVersion": 2018
    },
    "plugins": [
        "react"
    ],
    "rules": {
        "quotes": ["error", "single"],
        "eol-last": ["error", "always"],
        "indent": ["error", "tab"],
        "no-var": "error",
        "no-trailing-spaces": "error",
        "eqeqeq": "error",
        "object-shorthand": ["error", "always"],
        "max-len": ["error", { "code": 80, "tabWidth": 2 }],
        "prefer-const": "error",
        "complexity": ["error", 10],
        "prefer-template": "error",
        "comma-dangle": ["error", "never"],
        "arrow-body-style": ["error", "as-needed"],
        "curly": "error",
        "no-extra-parens": "error"
    }
};
