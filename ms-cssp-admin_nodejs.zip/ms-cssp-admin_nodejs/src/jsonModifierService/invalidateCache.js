
const config = require('./../../config/main')
const fetch = require('node-fetch')

module.exports.invalidateCache = async function (req, res) {
	const url = config.devUrlAdminPortalService

	try {

		var response = await fetch(`${url}language/invalidateCache`,
			{
				method: 'get',
				headers: { 'Content-Type': 'application/json' }
			})

		let body = await response.json();

		if (body) {

			const message = body && body.message;
			let statusCode = response && response.statusCode;

			res.json({
				statusCode, message
			})
		}

	} catch (error) {
		if (error) {
			return res.json({
				statusCode: 403,
				success: false,
				timestamp: new Date().getTime(),
				error
			})
		}
	}
}
