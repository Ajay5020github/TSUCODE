
const config = require('./../../config/main')
const fetch = require('node-fetch')

module.exports.fetchLog = async function (req, res) {
	const {
		authToken,
		userId,
		jsonScreenName,
		language
	} = req.body

	const url = config.devUrlAdminPortalService

	const reqOptions = {
		"authToken": authToken,
		"userId": userId,
		"jsonScreenName": jsonScreenName,
		"language": language
	}

	try {

		var response = await fetch(`${url}adminportal/fetchLog`,
			{
				method: 'post', body: JSON.stringify(reqOptions),
				headers: { 'Content-Type': 'application/json' }
			})

		let body = await response.json();

		if (body) {
			const message = body && body.message;

			res.json({
				statusCode: 200,
				success: true,
				timestamp: new Date().getTime(),
				message,
				body
			})

		}

	} catch (error) {
		return res.json({
			'statusCode': "500",
			'success': false,
			'timestamp': new Date().getTime(),
			'message': 'Issue in fetch Log',
			error: "Error in fetchLog - " + error
		})
	}
}
