
const config = require('./../../config/main')
const fetch = require('node-fetch')

module.exports.saveJson = async function (req, res) {
	const {
		authToken,
		userId,
		comments,
		json,
		jsonFileName,
		jsonScreenName,
		language
	} = req.body

	const url = config.devUrlAdminPortalService

	const reqOptions = {
		"authToken": authToken,
		"userId": userId,
		"comments": comments,
		"json": json,
		"jsonFileName": jsonFileName,
		"jsonScreenName": jsonScreenName,
		"language": language
	}

	try {
		var response = await fetch(`${url}adminportal/saveJson`,
			{
				method: 'post', body: JSON.stringify(reqOptions),
				headers: { 'Content-Type': 'application/json' }
			})

		let body = await response.json();

		const message = body && body.message;

		if (body) {

			res.json({
				statusCode: 200,
				success: true,
				timestamp: new Date().getTime(),
				message,
				body
			})
		}

	} catch (error) {

		return res.json({
			'statusCode': "500",
			'success': false,
			'timestamp': new Date().getTime(),
			'message': 'Issue in save JSON',
			error: "Error in saveJson - " + error
		})

	}
}
