
const config = require('./../../config/main')
const fetch = require('node-fetch')

module.exports.publishJson = async function (req, res) {
	const {
		authToken,
		userId,
		comments,
		json,
		jsonFileName,
		jsonScreenName,
		language
	} = req.body

	const url = config.devUrlAdminPortalService

	const reqOptions = {
		authToken,
		userId,
		comments,
		json,
		jsonFileName,
		jsonScreenName,
		language
	}

	try {

		var response = await fetch(`${url}adminportal/publishJson`,
			{
				method: 'post', body: JSON.stringify(reqOptions),
				headers: { 'Content-Type': 'application/json' }
			})

		let body = await response.json();

		if (body) {

			const message = body && body.message;

			res.json({
				statusCode: 200,
				success: true,
				timestamp: new Date().getTime(),
				message,
				body
			})

		}

	} catch (error) {

		return res.json({
			'statusCode': "500",
			'success': false,
			'timestamp': new Date().getTime(),
			'message': 'Issue in publish JSON',
			error: "Error in publishJSON - " + error
		})

	}



}
