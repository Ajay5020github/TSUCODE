
const config = require('../../config/main')
const fetch = require('node-fetch')

module.exports.readContentJSON = async function (req, res) {
	const { filename } = req.body
	const url = config.devUrlAdminPortalService

	var response = await fetch(`${url}adminportal/readContentJson/${encodeURIComponent(filename)}`,
		{
			method: 'get',
			headers: { 'Content-Type': 'application/json' }
		})

	let body = await response.json();

	const bodyJSON = JSON.parse(JSON.stringify(body));

	const message = bodyJSON && bodyJSON.message;
	const statusCode = bodyJSON && bodyJSON.statusCode;

	/* istanbul ignore if */
	if (statusCode !== 200) {
		req.app.settings.apiLogger.error({
			'message': 'Issue in reading Content JSON',
			error,
			bodyJSON
		})
		return res.json({
			'statusCode': statusCode || 500,
			'success': false,
			'timestamp': new Date().getTime(),
			'message': message || 'Issue in reading Content JSON',
			error: "Error in readContentJSON",
			bodyJSON
		})
	} else {
		res.json({
			statusCode,
			success: true,
			timestamp: new Date().getTime(),
			message,
			bodyJSON
		})
	}

}
