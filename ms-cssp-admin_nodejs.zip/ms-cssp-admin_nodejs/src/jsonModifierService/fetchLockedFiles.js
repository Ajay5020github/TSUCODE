
const config = require('./../../config/main')
const fetch = require('node-fetch')

module.exports.fetchLockedFiles = async function (req, res) {
	const {
		authToken,
		userId
	} = req.body

	const url = config.devUrlAdminPortalService

	const postOptions = {
		"authToken": authToken,
		"userId": userId
	}

	try {

		var response = await fetch(`${url}adminportal/fetchLockedFiles`,
			{
				method: 'post', body: JSON.stringify(postOptions),
				headers: { 'Content-Type': 'application/json' }
			})

		let body = await response.json();

		if (body) {
			/* istanbul ignore if */
			const message = body && body.message;

			res.json({
				'statusCode': 200,
				'success': true,
				'timestamp': new Date().getTime(),
				message,
				body
			})

		}

	} catch (error) {
		return res.json({
			'statusCode': "500",
			'success': false,
			'timestamp': new Date().getTime(),
			'message': 'Issue in fetch Locked Files',
			error: "Error in fetchLockedFiles - " + error
		})
	}
}
