
const express = require('express')
const router = express.Router()
const {
	body
} = require('express-validator')
const cusValid = require('../helper/custom_validators')
const vMsg = require('../helper/validation_message')

const fetchJsonFile = require('./fetchJson')
const fetchLogFile = require('./fetchLog')
const publishJsonFile = require('./publishJson')
const revertJsonFile = require('./revertJson')
const saveJsonFile = require('./saveJson')
const readContentJSONFile = require('./readContentJSON')
const invalidateCacheFile = require('./invalidateCache')
const fetchLockedFiles = require('./fetchLockedFiles')
const sanitizeFile = require('../../sanitize')

router.post('/fetchJson',
	cusValid.validate([
		body('jsonScreenName'),
		body('language'),
	]), cusValid.authTokenValidate,
	sanitizeFile.sanitize,
	fetchJsonFile.fetchJson)

router.post('/fetchLog',
	cusValid.validate([
		body('jsonScreenName'),
		body('language'),
	]), cusValid.authTokenValidate,
	sanitizeFile.sanitize,
	fetchLogFile.fetchLog)

router.post('/publishJson',
	cusValid.validate([
		body('comments'),
		body('json'),
		body('jsonFileName'),
		body('jsonScreenName'),
		body('language'),
	]), cusValid.authTokenValidate,
	sanitizeFile.sanitize,
	publishJsonFile.publishJson)

router.post('/revertJson',
	cusValid.validate([
		body('jsonScreenName'),
		body('language'),
	]), cusValid.authTokenValidate,
	sanitizeFile.sanitize,
	revertJsonFile.revertJson)

router.post('/saveJson',
	cusValid.validate([
		body('comments'),
		body('json'),
		body('jsonFileName'),
		body('jsonScreenName'),
		body('language'),
	]), cusValid.authTokenValidate,
	sanitizeFile.sanitize,
	saveJsonFile.saveJson)

router.post('/readContentJson', cusValid.authTokenValidate, sanitizeFile.sanitize, readContentJSONFile.readContentJSON)

router.get('/invalidateCache', sanitizeFile.sanitize, invalidateCacheFile.invalidateCache)

router.post('/fetchLockedFiles',
	cusValid.validate([
		body('userId')
	]), cusValid.authTokenValidate, sanitizeFile.sanitize, fetchLockedFiles.fetchLockedFiles)

	module.exports = router
