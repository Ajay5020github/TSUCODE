// "use strict"


const config = require('../../config/main')

const DOMApplicationType = ["DOMGetClientInfo","DOMUploadDocument","DOMGetDocument","DOMGetDocumentList" , "DOMVerifyCase", "DOMWithdrawAppeal","DOMUpdateCIC","DOMSubmitAppeal","DOMMessageToEligibility", "DOMGetApplicationInfo", "DOMSubmitApp","DOMMailDocument","DOMGetAppealInfo" ]
const MDHSApplicationType = ["MDHSGetClientInfo","MDHSUploadDocument","MDHSGetDocument","MDHSGetDocumentList","MDHSVerifyCase","MDHSWithdrawAppeal","MDHSUpdateCIC","MDHSSubmitAppeal" ,"MDHSMessageToEligibility", "MDHSGetApplicationInfo", "MDHSSubmitApp","MDHSGetAppealInfo"]

const getAccountMap = (accountInfo,application) => {
	//let benefit = getBenefitProgramInfo(accountInfo.benefitProgramIndInfo,application);
	return {
		"AccountInfo": {
			"CWPAcctID": config.mockAccountInfo ?  Math.floor(Math.random() * 100000) :accountInfo.CWPAcctID ,//accountInfo.cwpacctID,
			"CWPAcctUserName": accountInfo.CWPAcctUserName,
			"AccountActiveStatusInd": accountInfo && accountInfo.AccountActiveStatusInd ? accountInfo.AccountActiveStatusInd : false,
			"CWPAcctTrustedInd": accountInfo && accountInfo.CWPAcctTrustedInd ? accountInfo.CWPAcctTrustedInd : false,
			"CWPAcctAuthStatusCode": config.mockAccountInfo ? "Third-PartyAuthenticated" : (accountInfo && accountInfo.CWPAcctAuthStatusCode ? accountInfo.CWPAcctAuthStatusCode : null ),//accountInfo && accountInfo.cwpacctAuthStatusCode ? accountInfo.cwpacctAuthStatusCode : null,
			"BenefitProgramIndInfo": accountInfo && accountInfo.BenefitProgramIndInfo ? getBenefitProgramInfo(accountInfo.BenefitProgramIndInfo,application):null ,
			"AcctName": {
					"FirstName": accountInfo.AcctName.FirstName,//accountInfo.acctName.firstName,
					"MiddleName": accountInfo.AcctName.MiddleName,
					"LastName": accountInfo.AcctName.LastName ,//accountInfo.acctName.lastName,
					"SuffixName": accountInfo.AcctName.SuffixName,
					"MaidenName": accountInfo.AcctName.MaidenName,
			},
			"SSN": accountInfo.SSN,//"505989889",//accountInfo.ssn,
			...(accountInfo && accountInfo.DOB && {"DOB": accountInfo.DOB}),
			"AccountAddress": {
					"AddressCategoryType": accountInfo && accountInfo.AccountAddress && accountInfo.AccountAddress.AddressCategoryType ? accountInfo.AccountAddress.AddressCategoryType : "Account",
					"StreetAddress1": accountInfo && accountInfo.AccountAddress && accountInfo.AccountAddress.StreetAddress1 ? accountInfo.AccountAddress.StreetAddress1 : null,
					"StreetAddress2": accountInfo && accountInfo.AccountAddress && accountInfo.AccountAddress.StreetAddress2 ? accountInfo.AccountAddress.StreetAddress2 : null,
					"City": accountInfo && accountInfo.AccountAddress && accountInfo.AccountAddress.City ? accountInfo.AccountAddress.City :null,
					"State": accountInfo && accountInfo.AccountAddress && accountInfo.AccountAddress.State ? accountInfo.AccountAddress.State : null,
					"ZipCodeDesc": accountInfo && accountInfo.AccountAddress && accountInfo.AccountAddress.ZipCodeDesc ? accountInfo.AccountAddress.ZipCodeDesc : null,
					"ZipCodeExt": accountInfo && accountInfo.AccountAddress && accountInfo.AccountAddress.ZipCodeExt ? accountInfo.AccountAddress.ZipCodeExt : null,
					"County": accountInfo && accountInfo.AccountAddress && accountInfo.AccountAddress.County ? accountInfo.AccountAddress.County : null,
					...(accountInfo && accountInfo.AccountAddress && accountInfo.AccountAddress.VerificationDate && {"VerificationDate": accountInfo.AccountAddress.VerificationDate})
					//"VerificationDate": accountInfo && accountInfo.AccountAddress && accountInfo.AccountAddress.VerificationDate ? accountInfo.AccountAddress.VerificationDate : null,
			},
			"EmailID": accountInfo && accountInfo.EmailID ? accountInfo.EmailID : null,
			"PhoneNumber": accountInfo && accountInfo.PhoneNumber ? accountInfo.PhoneNumber : null,
			"CWPAcctHolderARInd":  accountInfo && accountInfo.CWPAcctHolderARInd ? accountInfo.CWPAcctHolderARInd : false,
		}
	}
}

const getBenefitProgramInfo = (benefitProgramIndInfo,application) => {
	let benefitProgramIndArr = [];
	let DOMPrograms = benefitProgramIndInfo && benefitProgramIndInfo.filter(prog => prog.ProgramType.toLowerCase() == "medicaid" || prog.ProgramType.toLowerCase() == "familyplanning"  || prog.ProgramType.toLowerCase() == "abd");
	let MDHSPrograms = benefitProgramIndInfo && benefitProgramIndInfo.filter(prog => prog.ProgramType.toLowerCase() == "snap" || prog.ProgramType.toLowerCase() == "tanf" || prog.ProgramType.toLowerCase() == "liheap");
	//if(application == "DOMGetClientInfo" || application == "DOMUploadDocument" || application == "DOMGetDocument" || application == "DOMGetDocumentList" || application == "DOMVerifyCase" ){
	if(DOMApplicationType.includes(application)){
			DOMPrograms.length > 0 &&
			DOMPrograms.forEach((elem) => {
				benefitProgramIndArr.push(getBenefitProgramInfoArr(elem))
			});
	//}else if(application == "MDHSGetClientInfo"  || application == "MDHSUploadDocument" || application == "MDHSGetDocument" || application == "MDHSGetDocumentList" || application == "MDHSVerifyCase"){
	}else if(MDHSApplicationType.includes(application)){
			MDHSPrograms.length > 0 &&
			MDHSPrograms.forEach((elem) => {
				benefitProgramIndArr.push(getBenefitProgramInfoArr(elem))
			});
	}
	return benefitProgramIndArr;
};

const getBenefitProgramInfoArr = elem => {
	//let benefitProgramIndArr = [];
	let obj = {
		ProgramType: elem.ProgramType ? elem.ProgramType : null,
		BenefitProgramIsEnabledInd: elem.BenefitProgramIsEnabledInd
				? elem.BenefitProgramIsEnabledInd
				: false
		};
		//benefitProgramIndArr.push(obj);
		return obj
}
module.exports = {getAccountMap};
