/**
 *  @Author - Vijay Sharma
 *  @AuthorEmail : vijaykumar.sharma@conduent.com
 *  @CreatedDate : 2019-06-14:02:38:00
 *  @ModifiedDate : 2019-06-14:02:38:00
 */


const config = require('../../config/main')
// const mycache = require('../cache/cache')
const { cacheConnection } = require('../cache/cache')
const logs = require("../helper/log_function");
// var { get, set } = require('../cache/cacheMethods');
// var sanitizer = require('sanitize')()
const constants = require("../../config/constants");
const axios = require('axios')

/**
 * @LOGIC : API TO FETCH JSON FILE FROM AZURE BLOB !
 * @REQUEST_PARAMS :  lang_code ,state_code, page, programId
 * @DESCRIPTION : CALL SPRINGBOOT API WITH REQUEST PARAMS
 * TO FETCH JSON FROM AZURE BLOB
 * @RESPONSE : RETURN JSON IN RESPONSE
 */


module.exports.fetchConfigJsonFromBlobStorageFromBlob = async function (req, res) {

	let langIDs = ["en"]
	const { screenName } = req.body

	let languageId = "en"

	if (languageId && req.body.screenName && langIDs.includes(languageId)) {
		if ((/^[A-Za-z0-9]+$/.test(languageId)) && (/^[A-Za-z0-9]+$/.test(screenName))) {
			var pageNameKey = languageId + screenName;
			let jsonReceived = null;


			let url = `${config.devUrlLanguageService}${config.language}/conversion/`
			url += `${languageId}/${screenName}`

			let value = null;
			if (cacheConnection) {
				value = await cacheConnection.get(`${config.env}${pageNameKey}`);
			}

			if (!value) {
				try {

					axios.get(url).then(async response => {

						try {

							try {
								jsonReceived = response && response.data && JSON.parse(JSON.stringify(response.data))
							} catch (error) {
								jsonReceived = response && response.data
							}

							if (jsonReceived.statusCode === 200) {
								cacheConnection && await cacheConnection.set(`${config.env}${pageNameKey}`, JSON.stringify(jsonReceived.data), { "EX": 24 * 60 * 60 })
								return res.status(200).send({
									'statusCode': 200,
									'success': true,
									'timestamp': jsonReceived.timestamp,
									'message': 'DATA FETCHED SUCCESSFULLY',
									'data': jsonReceived.data,
									'screenName': screenName
								})
							} else {
								return res.status(jsonReceived.statusCode || 500).send({
									'statusCode': jsonReceived.statusCode || 500,
									'success': false,
									'timestamp': jsonReceived.timestamp,
									'message': 'ERROR WHILE GETTING DATA',
									'errorMessage': jsonReceived.errorMessage
								})
							}
						} catch (err) {
							req.app.settings.apiLogger.error({
								'message': 'Logging Exception in get catch',
								err
							})
							logs.transactionLog(
								req,
								res,
								"",
								err,
								"Error in get.js",
								"FetchConfigJson",
								constants.service.LANG,
								constants.type.INT,
								"",
								url,
								req.body && req.body.consumerAccountId || null,
								"",
								""
							);
						}

					}).catch(excep => {

						/* istanbul ignore if */
						logs.transactionLog(
							req,
							res,
							"",
							"",
							"Error in get.js",
							"FetchConfigJson",
							constants.service.LANG,
							constants.type.INT,
							"",
							url,
							req.body && req.body.consumerAccountId || null,
							"",
							""
						);
						req.app.settings.apiLogger.error(excep && excep.response)
						return res.status(400).send({
							statusCode: 400,
							success: false,
							timestamp: new Date().getTime(),
							message: 'ERROR WHILE GETTING DATA',
							errorMessage: 'Data Not Found',
							path: url,
							error: excep && excep.response
						})
					})

				} catch (err) {
					req.app.settings.apiLogger.error({
						'message': 'Logging Exception in get',
						err
					})
					return res.send({
						error: err
					})
				}
			} else {
				const data = cacheConnection && await cacheConnection.get(`${config.env}${pageNameKey}`)
				return res.status(200).send({
					'statusCode': 200,
					'success': true,
					'timestamp': new Date().getTime(),
					'message': 'DATA FETCHED SUCCESSFULLY',
					'data': await JSON.parse(data)
				})
			}
		} else {
			res.json({
				statusCode: 400,
				message: 'PLEASE PROVIDE PROPER INPUTS',
				success: false
			})
		}

	} else {
		return res.status(400).send({
			success: false,
			statusCode: 400,
			timestamp: new Date().getTime(),
			message: 'PLEASE PROVIDE PROPER INPUTS',
			errorMessage: 'Please provide Required Inputs',
			'screenName': req.query.screenName,
			'languageId': req.query.languageId
		})
	}
}
