
const config = require('../../config/main')
const axios = require('axios');
const {cacheConnection} = require('../cache/cache')

/**
 * @LOGIC : API TO FETCH JSON FILE FROM AZURE BLOB !
 * @REQUEST_PARAMS :  lang_code ,state_code, page, programId
 * @DESCRIPTION : CALL SPRINGBOOT API WITH REQUEST PARAMS
 * TO FETCH JSON FROM AZURE BLOB
 * @RESPONSE : RETURN JSON IN RESPONSE
 */

module.exports.fetchConfigJsonBlobStorage = async function (req, res) {
	let langIDs = ["en"];
	if (req.query.languageId && req.query.screenName) {
		const { languageId, screenName, stateId } = req.query

		if (req.query.languageId && req.query.screenName && langIDs.includes(req.query.languageId)) {
			if ((/^[A-Za-z0-9]+$/.test(languageId)) && (/^[A-Za-z0-9]+$/.test(screenName)) && (/^[A-Za-z0-9]+$/.test(stateId))){
					var pageNameKey = languageId + screenName;
					let jsonReceived = null;

					let url = `${config.devUrlLanguageService}language/conversion/`
					url += `${languageId}/${screenName}`

					let value = null;
					if (cacheConnection){
						value = await cacheConnection.get(`${config.env}${pageNameKey}`);
					}

					if (!value){

						axios.get(url).then(async results => {

							jsonReceived = results & results.data && JSON.parse(results.data)
							if (jsonReceived.statusCode === 200) {

								cacheConnection && await cacheConnection.set(`${config.env}${pageNameKey}`,JSON.stringify(jsonReceived.data), {"EX": 24  * 60 * 60})

								return res.status(200).json({
									'statusCode': 200,
									'success': true,
									'timestamp': jsonReceived.timestamp,
									'message': 'DATA FETCHED SUCCESSFULLY',
									'data': jsonReceived.data,
									'screenName':screenName
								})
							} else {
								return res.status(jsonReceived.statusCode).json({
									'statusCode': jsonReceived.statusCode,
									'success': false,
									'timestamp': jsonReceived.timestamp,
									'message': 'ERROR WHILE GETTING DATA',
									'errorMessage': jsonReceived.errorMessage
								})
							}

						}).catch(excep => {
							req.app.settings.apiLogger.error(excep && excep.response)

							return res.status(400).json({
								statusCode: 400,
								success: false,
								timestamp: new Date().getTime(),
								message: 'ERROR WHILE GETTING DATA',
								errorMessage: 'Data Not Found',
								path: url,
								error: excep && excep.response
							})
						})
					}
					else {
						const data = cacheConnection && await cacheConnection.get(`${config.env}${pageNameKey}`)
						return res.status(200).send({
							'statusCode': 200,
							'success': true,
							'timestamp': new Date().getTime(),
							'message': 'DATA FETCHED SUCCESSFULLY',
							'data': await JSON.parse(data)
						})
					}
			}
		}
	}
	else {
		return res.status(400).json({
			success: false,
			statusCode: 400,
			timestamp: new Date().getTime(),
			message: 'PLEASE PROVIDE PROPER INPUTS',
			errorMessage: 'Please provide Required Inputs',
			'screenName': req.query.screenName,
			'languageId': req.query.languageId
		})
	}
}
