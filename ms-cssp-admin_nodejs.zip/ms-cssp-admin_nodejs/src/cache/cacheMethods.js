
var { cacheConnection } = require("./cache");

const set = (key, value) => {
	var ret = undefined;
	cacheConnection.set(key, value).then((resp) => {
		ret = resp;
	})
	while (ret === undefined) {
		require('deasync').runLoopOnce();
	}
	return ret;
}

const get = (key) => {
	var ret = undefined;
	cacheConnection.get(key).then((resp) => {
		ret = resp;
	})
	while (ret === undefined) {
		require('deasync').runLoopOnce();
	}
	return ret;
}

module.exports = { get, set };
