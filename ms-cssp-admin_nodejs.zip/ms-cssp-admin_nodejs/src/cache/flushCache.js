
const { cacheConnection } = require('./cache');
/*
 * Validate and Sanitize the json input
 *
 */
module.exports.flushCache = async function (req, res) {
	try {
		for await (const key of cacheConnection.scanIterator()) {
			var response = await cacheConnection.del(key);
		}

		await res.json({
			statusCode: 200,
			success: true,
			message: 'CACHE FLUSHED SUCCESSFULLY'
		})
	}
	catch (e) {
		return res.json({
			statusCode: 400,
			success: false,
			timestamp: new Date().getTime(),
			message: e.message
		})
	}
}

