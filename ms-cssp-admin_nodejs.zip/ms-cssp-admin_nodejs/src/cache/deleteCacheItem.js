
const config = require('./../../config/main')
const axios = require('axios');

module.exports.deleteCacheItem = function (req, res) {
	const url = config.devUrlNodebackendService
	const { cacheItem } = req.body
	const reqOptions = {
		url: `${url}cache/deleteCacheItem`,
		method: 'POST',
		data: {
			cacheItem
		}
	}
	axios(reqOptions).then(results => {


		const { statusCode, message } = results && results.data;

		res.json({
			statusCode, message
		})

	}).catch(excep => {

		/* istanbul ignore if */
		return res.json({
			statusCode: 403,
			success: false,
			timestamp: new Date().getTime(),
			error: excep &&
			excep.response,
			body: excep &&
			excep.response &&
			excep.response.data
		})

	})

}
