
const express = require('express')
const router = express.Router()
const deleteCacheItemFile = require('./deleteCacheItem')
const flushCacheFile = require('./flushCache')
const sanitizeFile = require('../../sanitize')

router.post('/deleteCacheItem',sanitizeFile.sanitize,
deleteCacheItemFile.deleteCacheItem)

router.post('/flushCache',sanitizeFile.sanitize,
flushCacheFile.flushCache)

module.exports = router;
