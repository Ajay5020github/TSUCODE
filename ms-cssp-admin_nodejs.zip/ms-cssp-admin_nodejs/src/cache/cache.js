
var redis = require("redis");
const config = require('./../../config/main')

var cacheConnection = null;
try {
	const mycache = async () => {
		var cacheHostName = config.cacheHostName;
		var cachePassword = config.cachePassword;
		cacheConnection = redis.createClient({
			// rediss for TLS
			url: "rediss://" + cacheHostName + ":" + config.cachePort,
			password: cachePassword,
			ssl: true,
			abortConnect: false
		});
		await cacheConnection.connect();

		// Flush the keys
		for await (const key of cacheConnection.scanIterator()) {
			// use the key!
			var response = await cacheConnection.del(key);
		}

		return cacheConnection;
	}


	mycache();
	/*
	cacheConnection.on("connect", function () {
			cacheConnection.stream.setKeepAlive(true, 50000);
	});
	*/
	cacheConnection.on('error', err => {
	});
	cacheConnection.on('connect', () => {
	});
	cacheConnection.on('reconnecting', () => {
	});
	cacheConnection.on('ready', () => {
	});
} catch (error) {
	cacheConnection = null
}


module.exports = { cacheConnection }
