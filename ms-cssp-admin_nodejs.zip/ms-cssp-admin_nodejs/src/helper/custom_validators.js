/**
 *  @Author - Sourav Thakur
 *  @CreatedDate : 2022-02-16:15:00:00
 *  @DESCRIPTION :  CREATING A NEW AUTHTOKEN IN EXCHANGE OF A VALID TOKEN
 */

const jwt = require("jsonwebtoken");
const config = require("./../../config/main");
const keyVault = require("../helper/keyVault_function");
// const mycache = require("../cache/cache");
const { cacheConnection } = require('../cache/cache')
var { get, set } = require('../cache/cacheMethods');
const { v4: uuidv4 } = require('uuid');
const logs = require("../helper/log_function");
const constants = require("./../../config/constants");
const commonFunc = require('./common')
const axios = require('axios')

const {
	validationResult
} = require('express-validator')

//validation error response function
module.exports.validate = validations => async (req, res, next) => {
	await Promise.all(validations.map(validation => validation.run(req)))
	const errors = validationResult(req)
	if (errors.isEmpty()) {
		return next();
	}
	req.app.settings.apiLogger.error({
		'message': 'INPUT VALIDATION FAILED'
		// errors: errors.array()
	})
	commonFunc.cleanUploadedFiles(req)
	return res.json({
		'statusCode': 400,
		'success': false,
		'timestamp': new Date().getTime(),
		'message': 'INPUT VALIDATION FAILED'
	})
}

module.exports.authTokenValidate = async function (req, res, next) {

	const url = config.devUrlAdminPortalService

	const email = req.body && req.body.email;
	const id = req.body && req.body.id;
	const authToken = req.headers && req.headers.authtoken;

	const department = req.body && req.body.department;
	const userId = req.body && req.body.userId;

	let isValidToken = undefined;

	try {
		if (authToken) {

			const userLoginData1 = cacheConnection && await cacheConnection.get(`${config.env}${userId}${id}`);
			const userLoginData = await JSON.parse(userLoginData1)

			keyVault
				.getValue()
				.then((jwtSecret) =>
					jwt.verify(authToken, jwtSecret, function (err, decoded) {


						if (err) {
							req.app.settings.apiLogger.error({
								message: "INVALID JWT TOKEN"
							});
							return res.json({
								statusCode: 401,
								success: false,
								message: "INVALID TOKEN"
							});
						} else {

							function checkValidTokenService(decodedValue) {

								return new Promise(async (resolve, reject) => {
									const userLoginData1 = cacheConnection && await cacheConnection.get(`${config.env}${decodedValue}${id}`);

									const userLoginData = JSON.parse(userLoginData1)

									if (!userLoginData) {

										isValidToken = false;
										reject();
									} else if (authToken === userLoginData.authToken) {
										isValidToken = true;
										resolve();
									}
								}).catch(error => {

								})
							} // End of checkValidTokenService

							if (department === "internal") {

								if (
									userId === decoded.userId &&
									authToken === userLoginData.authToken
								) {
									checkValidTokenService(decoded.userId)
										.then(() => {
											if (isValidToken) {
												next();
											} else {
												return res.send({
													statusCode: 401,
													message: "UNAUTHORIZED TOKEN",
												});
											}
										})
										.catch(error => {

											return res.send({
												statusCode: 401,
												message: "invalid",
												timestamp: new Date().getTime()
											});
										});
								} else {
									return res.send({
										statusCode: 401,
										message: "Invalid inputs",
										timestamp: new Date().getTime(),
									});
								}


							}
							else if (department === "MDHS" || department === "DOM") {

								if (
									userId === decoded.email
								) {
									const postOptions = {
										url: `${url}adminportal/authorizeUser`,
										method: 'POST',
										data: {
											authenticationStatus: true,
											authToken,
											userId: decoded.email,
											department: department
										}
									}


									axios(postOptions).then(results => {

										const message = results && results.data && results.data.message;
										const statusCode = results && results.data && results.data.statusCode;
										if (statusCode !== 200) {

											req.app.settings.apiLogger.error({
												'message': "Unable to authorize User"
											})
											return res.json({
												'statusCode': statusCode || 401,
												'timestamp': new Date().getTime(),
												'message': "Unable to authorize User"
											})
										} else {

											req.body.userId = decoded.email
											next()
										}

									}).catch(excep => {
										// Log exception here
									})

									// request(postOptions, function (error, response, body) {
									// 	/* istanbul ignore if */
									// 	const message = body && body.message;
									// 	const statusCode = body && body.statusCode;
									// 	if (statusCode !== 200) {

									// 		req.app.settings.apiLogger.error({
									// 			'message': "Unable to authorize User"
									// 		})
									// 		return res.json({
									// 			'statusCode': statusCode || 401,
									// 			'timestamp': new Date().getTime(),
									// 			'message': "Unable to authorize User"
									// 		})
									// 	} else {

									// 		req.body.userId = decoded.email
									// 		next()
									// 	}
									// })
								} else {
									return res.send({
										statusCode: 401,
										message: "Invalid inputs",
										timestamp: new Date().getTime(),
									});
								}
							}
						}
					})
				)
				.catch(
          /* istanbul ignore next */(error) => {



						req.app.settings.apiLogger.error({
							message: "AZURE KEY VAULT ERROR"
						});
						res.status(500).json({
							statusCode: 500,
							success: false,
							message: "AZURE KEY VAULT ERROR"
						});
					}
				);
		} else {

			logs.transactionLog(
				req,
				res,
				"",
				"",
				"Logging error in refreshToken.js",
				"Refresh Token",
				constants.service.APP,
				constants.type.INT,
				"",
				req.body
			);
			return res.json({
				statusCode: 401,
				success: false,
				timestamp: new Date().getTime(),
				message: "Invalid Parameters",
			});
		}
	} catch (err) {


		logs.transactionLog(
			req,
			res,
			"",
			err,
			"Logging error in Custom Validator",
			"Refresh Token",
			constants.service.APP,
			constants.type.INT,
			"",
			req.body
		);

		return res.send({
			message: "Logging error in DB for Custom Validator"
		});
	}
};
