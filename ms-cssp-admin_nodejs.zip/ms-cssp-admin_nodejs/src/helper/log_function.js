
const config = require("../../config/main");
const constants = require("../../config/constants");
const axios = require('axios')

module.exports.transactionLog = (
	req,
	res,
	error,
	action,
	service,
	type,
	responseBody,
	requestPayload,
	transactionId,
	requestPayloadXML,
	oxiErrorCode,
	oxiInternalTransactionId,
	spErrorCode,
	oxiErrorDescription,
	consumerAccountId,
	serviceId
) => {

	const url = config.devUrlAuditService;
	const transactionParams = {
		"actionName": action,
		"consumerId": consumerAccountId,
		"ipAddress": "",
		"message": {
			"errorMessage": error, //-- spErrorDescription
			"errorTrace": oxiErrorDescription, //-- oxiErrorDescription
			"requestPayload": requestPayload,
			"responseCode": spErrorCode, //-- spErrorCode
			"responsePayload": responseBody && responseBody, //-- soapFaultBody
			"requestPayloadXML": requestPayloadXML,
			"errorCode": oxiErrorCode, //-- oxiErrorCode
			"oxiInternalTransactionId": oxiInternalTransactionId, //- oxiInternalTransactionID
		},
		"screenName": "",
		"serviceId": serviceId,
		"serviceType": service,
		"sourceLayer": "INTEGRATION NODE",
		"transactionId": transactionId,
		"transactionStatus": type,
		"responsePayloadXML": ""
	}
	try {
		axios({
			method: 'POST',
			url: `${url}audit/transactionLog`,
			data: transactionParams,
			maxContentLength: Infinity,
			maxBodyLength: Infinity
		})
			.then((results) => {
			})
			.catch((e) => {
			})
	} catch (error) {
	}
};
