/**
 *  @Author - Rahul saha
 *  @AuthorEmail : rahul.saha@conduent.com
 *  @CreatedDate : 2019-08-16:15:00:00
 *  @ModifiedDate : 2019-08-16:15:00:00
 */


const messages = {}
messages.required = 'is required'
messages.string = 'must be a string'
messages.email = 'invalid email'
messages.numeric = 'must be a number'
messages.alpha = 'must be only alphabetical chars'
messages.postal = 'invalid postal code'
messages.valid = 'invalid input'
messages.boolean = 'must be a boolean'
module.exports = messages
