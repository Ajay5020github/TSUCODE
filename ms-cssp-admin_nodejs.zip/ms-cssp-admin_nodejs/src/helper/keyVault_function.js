/**
 *  @Author - Rahul saha
 *  @AuthorEmail : rahul.saha@conduent.com
 *  @CreatedDate : 2019-09-20:20:00:00
 *  @ModifiedDate : 2019-09-20:20:00:00
*/

const config = require('../../config/main')

const {
	clientId,
	clientSecret,
	directoryId,
	secretName,
	keyVaultName
} = config.azureKeyVault

let agent = false
const process = require('process')
require('dotenv').config()
/* istanbul ignore if */
if (process.env.PROXY) {
	const HttpsProxyAgent = require('https-proxy-agent')
	agent = new HttpsProxyAgent(process.env.PROXY)
}


/**
 * @LOGIC : FUNCTION TO AUTH AZURE
 * @RETURN : RETURN ACCESS TOKEN
 */
const authenticator = async function () {

	const formBody = new FormData();
	formBody.append("grant_type", "client_credentials")
	formBody.append("client_id", clientId)
	formBody.append("client_secret", clientSecret)
	formBody.append("scope", "https://vault.azure.net/.default")


	return new Promise(async (resolve, reject) => {
		try {
			const response = await fetch(`https://login.microsoftonline.com/${directoryId}/oauth2/v2.0/token`,
				{
					method: 'post', body: formBody,
					rejectUnauthorized: true, agent
				})

			let bodyJSON = await response.json();
			resolve(bodyJSON.access_token)
		} catch (error) {
			reject(error)
		}
	})
}

/**
 * @LOGIC : FUNCTION TO GET VALUE
 * @RETURN : RETURN VALUE
 */

const getSecretValue = async function (bearerToken) {


	return new Promise(async (resolve, reject) => {
		try {

			let url = `https://${keyVaultName}.vault.azure.net/secrets/`
			url += `${secretName}?api-version=2016-10-01`

			const response = await fetch(url,
				{
					method: 'GET',
					headers: {
						Authorization: `Bearer ${bearerToken}`
					},
					rejectUnauthorized: true,
					agent
				})

			let bodyJSON = await response.json();
			resolve(bodyJSON.value)

		} catch (error) {
			reject(error)
		}
	})

}

//GET KEY VALUE OPERATION

module.exports.getValue = async function () {
	const bearerToken = await authenticator()
	const result = await getSecretValue(bearerToken)
	return result
}
