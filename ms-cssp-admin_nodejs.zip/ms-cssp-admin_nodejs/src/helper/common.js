/**
 *  @Author - Rahul Saha
 *  @AuthorEmail : rahul.saha@conduent.com
 *  @CreatedDate : 2019-18-12:15:00:00
 *  @ModifiedDate : 2019-18-12:15:00:00
*/


const config = require('./../../config/main')
const fs = require('fs-extra')

//function to clean upload file from upload folder
module.exports.cleanUploadedFiles = (req) => {
	//clean temp files
	if (req.files && req.files.file) {
		const {
			file
		} = req.files
		for (const fileInfo of file) {
			fs.unlink(config.docUpload.tempDir + fileInfo.filename, err => {
				/* istanbul ignore if */
				if (err) { throw err }
			})
		}
	}
}
