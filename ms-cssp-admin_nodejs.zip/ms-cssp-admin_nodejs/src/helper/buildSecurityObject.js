// "use strict"


const { DefaultAzureCredential } = require("@azure/identity");
const { CertificateClient } = require("@azure/keyvault-certificates");
const { SecretClient } = require("@azure/keyvault-secrets");
var forge = require("node-forge");
var saml = require("saml").Saml20;
var xml2js = require("xml2js");

const config = require('../../config/main')

var { cacheConnection } = require("../cache/cache");

const buildSecurityObject = () => {

    return new Promise(async function (resolve, _reject) {

        process.env.AZURE_CLIENT_ID = config.azureClientId;
        process.env.AZURE_CLIENT_SECRET = config.azureClientSecret;
        process.env.AZURE_TENANT_ID = config.azureTenantId;

        let privateKeyPem;
        let certificate;
        const credential = new DefaultAzureCredential();
        const vaultName = config.vaultName;
        const url = `https://${vaultName}.vault.azure.net`;
        const client = new CertificateClient(url, credential);
        const certificateName = config.certificateName;
        const secretClient = new SecretClient(url, credential);
        const certificateSecret = await secretClient.getSecret(certificateName);
        const PKCS12Certificate = certificateSecret.value;
        var p12Der = forge.util.decode64(PKCS12Certificate);
        var p12Asn1 = forge.asn1.fromDer(p12Der);
        var p12 = forge.pkcs12.pkcs12FromAsn1(p12Asn1);
        var certBags = p12.getBags({ bagType: forge.pki.oids.certBag });
        var pkeyBags = p12.getBags({
            bagType: forge.pki.oids.pkcs8ShroudedKeyBag,
        });
        var certBag = certBags[forge.pki.oids.certBag][0];
        var keybag = pkeyBags[forge.pki.oids.pkcs8ShroudedKeyBag][0];
        privateKeyPem = forge.pki.privateKeyToPem(keybag.key);
        certificate = forge.pki.certificateToPem(certBag.cert);
        var header_2;
        var options = {
            cert: certificate,
            key: privateKeyPem,
            lifetimeInSeconds: 600,
            attributes: {
                "urn:oasis:names:tc:xspa:1.0:subject:organization-id":
                    "urn:oid:0SSP-001A-001A-0002",
            },
        };

        let signedAssertion = saml.create(options);

        var parseString = require("xml2js").parseString;
        parseString(signedAssertion, async function (error, secdata) {

            if (error){
            }

            secdata["saml:Assertion"].Signature[0].SignatureValue = "";
            let signObj = { Security: secdata };
            var securityobj = new xml2js.Builder({ headless: true });
            var secobj = securityobj.buildObject(signObj);


            await cacheConnection.set("securityXMl", secobj);

            resolve(secobj);

        });
    });
}

module.exports = buildSecurityObject;
