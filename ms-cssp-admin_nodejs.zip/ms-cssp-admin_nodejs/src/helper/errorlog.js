/**
 *  @Author - Sourav Thakur
 *  @CreatedDate : 2022-02-18:15:00:00
 *  @DESCRIPTION : CALL SPRING BOOT SERVICES AND RECORD THE LOGS IN DB
 */


 const config = require('../../config/main')
 const constants = require('../../config/constants')

 module.exports.errorLogs = function (req, res) {
	 try {
		 req.app.settings.apiLogger.error({
			 stackTrace: req.body,
			 error: req.body.error && req.body.error.message
		 });
		//  const url = config.devUrlAuditService;
		//  const transactionParams = {
		// 	 consumerAccountid: req.body.email,
		// 	 trackingid: req.body.trackingid,
		// 	 stacktrace: req.body.error,
		// 	 screenName: "",
		// 	 actionName: req.body.action,
		// 	 serviceName: req.body.service,
		// 	 layer: constants.layer.UI,
		// 	 APIM: "",
		// 	 errorBackendResponse: req.body.error && req.body.error.message,
		// 	 type: constants.type.INT,
		//  };
		//  const reqOptions = {
		// 	 url: `${url}audit/transactionLog`,
		// 	 method: "POST",
		// 	 json: transactionParams,
		//  };

		//  request(reqOptions, function (error, response, body) {
		// 	 if (error) {
		// 		 req.app.settings.apiLogger.error({
		// 			 message: "Logging error in transaction log for UI",
		// 			 error,
		// 		 });
		// 	 }
		// 	 /* istanbul ignore if */
		// 	 if (error || body.statusCode !== 200) {
		// 		 req.app.settings.apiLogger.error({
		// 			 message: "springboot_error",
		// 			 postDataObject: reqOptions,
		// 			 error,
		// 			 body,
		// 		 });
		// 	 }
		//  });
	 } catch (err) {
		 req.app.settings.apiLogger.error({
			 message: "Logging Exception in transactionLog",
			 err,
		 });
	 }
 }
