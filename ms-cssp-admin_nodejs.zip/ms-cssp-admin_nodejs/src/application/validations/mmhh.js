/**
 *  @Author - rahul Saha
 *  @AuthorEmail : rahul.saha@conduent.com
 *  @CreatedDate : 2020-01-16:15:00:00
 *  @ModifiedDate : 2020-01-16:15:00:00
 */


const {
	body
} = require('express-validator')
const cusValid = require('../../helper/custom_validators')
const vMsg = require('../../helper/validation_message')

/**
 * @LOGIC : FUNCTION TO FETCH RULES
 * @RESPONSE : RETURN RULES ARRAY IN RESPONSE
 */

module.exports = {

	/*Me and My Household Validation @Page1  */
	mmhhPage1: () => {
		const hdInfo = 'headOfhouseholdInfo'
		const hmAddr = 'homeAddress'
		const mailAddr = 'mailingAddress'
		return [
			body(`${hdInfo}.firstName`).not().isEmpty().withMessage(vMsg.required)
				.isLength({ max: 50 }),
			body(`${hdInfo}.middleName`).isLength({ max: 50 }),
			body(`${hdInfo}.lastName`).not().isEmpty().isLength({ max: 50 }),
			body(`${hdInfo}.suffix`).isLength({ max: 10 }),
			body(`${hdInfo}.otherNames`).optional().isArray().custom(
				(value) => value.every((currentValue) => currentValue.length <= 50)),
			body(`${hdInfo}.dateOfBirth`).custom(cusValid.validDateWithRange),
			body(`${hdInfo}.maritalStatus`).not().isEmpty().isLength({ max: 25 }),
			body(`${hdInfo}.gender`).not().isEmpty().isIn(['Male', 'Female']),
			body(`${hdInfo}.preferredWrittenLanguage`).isLength({ max: 30 }),
			body(`${hdInfo}.preferredSpokenLanguage`).isLength({ max: 30 }),
			body(`${hdInfo}.race`).isLength({ max: 60 }),
			body(`${hdInfo}.ethnicity`).isLength({ max: 60 }),
			body(`${hdInfo}.mobileNumber`).optional().isInt({ max: 9999999999 }),
			body(`${hdInfo}.homePhoneNumber`).optional().isInt({ max: 9999999999 }),
			body(`${hdInfo}.email`).not().isEmpty().isLength({ max: 50 }),
			body(`${hdInfo}.applicationStartDate`)
				.custom(cusValid.validDateWithCustomRange),
			body(`${hdInfo}.homelessStatus`).not().isEmpty().isIn(['Yes', 'No']),
			body(`${hmAddr}.addressLine1`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${hmAddr}.addressLine2`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).isLength({ max: 100 }),
			body(`${hmAddr}.city`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).not().isEmpty().isLength({ max: 50 }),
			body(`${hmAddr}.state`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).not().isEmpty().isLength({ max: 25 }),
			body(`${hmAddr}.zipCode`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).not().isEmpty().isLength({ max: 10 }),
			body(`${hmAddr}.county`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).isLength({ max: 50 }),
			body(`${mailAddr}.sameHomeAddressAndMailingAddress`).if(
				(value, { req }) => req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).not().isEmpty().isIn(['Yes', 'No']),
			body(`${mailAddr}.addressLine1`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${mailAddr}.addressLine2`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).isLength({ max: 100 }),
			body(`${mailAddr}.city`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).not().isEmpty().isLength({ max: 50 }),
			body(`${mailAddr}.state`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).not().isEmpty().isLength({ max: 25 }),
			body(`${mailAddr}.zipCode`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).not().isEmpty().isLength({ max: 10 }),
			body(`${mailAddr}.county`).if((value, { req }) =>
				req.body.headOfhouseholdInfo.homelessStatus === 'No'
			).isLength({ max: 50 })
		]
	},

	/*Me and My Household Validation @Page2  */
	mmhhPage2: () => {

		const SSI = 'socialSecurityInfo'
		const imigrtnStatus = 'eligibleImmigrationStatusInfo'
		return [
			body(`${SSI}.ssnStatus`).not().isEmpty().isIn(['Yes', 'No']),
			body(`${SSI}.ssn`).if((value, { req }) =>
				req.body.socialSecurityInfo.ssnStatus === 'Yes'
			).not().isEmpty().isInt({ max: 999999999 }),
			body(`${SSI}.reasonForNotProvideSSN`).if((value, { req }) =>
				req.body.socialSecurityInfo.ssnStatus === 'No'
			).not().isEmpty().isLength({ max: 50 }),
			body(`${SSI}.nameOnApplicationMatchNameOnSocialSecurityCard`)
				.if((value, { req }) => req.body.socialSecurityInfo.ssnStatus === 'Yes')
				.not().isEmpty().isIn(['Yes', 'No']),
			body(`${SSI}.nameOnSocialSecurityCard`)
				.if((value, { req }) =>
					req.body.socialSecurityInfo
						.nameOnApplicationMatchNameOnSocialSecurityCard === 'No'
				).not().isEmpty().isLength({ max: 170 }),

			body('unitedStatesCitizen').not().isEmpty().isIn(['Yes', 'No']),

			body(`${imigrtnStatus}.immigrationStatus`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${imigrtnStatus}.nonCitizenDocumentation`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${imigrtnStatus}.documentId`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No'
			).not().isEmpty().isLength({ max: 20 }),
			body(`${imigrtnStatus}.nameOnApplicationMatchNameOnImmigrationDocument`)
				.if((value, { req }) => req.body.unitedStatesCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${imigrtnStatus}.nameOnDocument`)
				.if((value, { req }) =>
					req.body.unitedStatesCitizen === 'No' &&
					req.body.eligibleImmigrationStatusInfo
						.nameOnApplicationMatchNameOnImmigrationDocument === 'No'
				).not().isEmpty().isLength({ max: 100 }),
			body(`${imigrtnStatus}.dateOfEntry`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No'
			).custom(cusValid.validDateWithRange),
			body(`${imigrtnStatus}.alienNumber`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No'
			).not().isEmpty().isLength({ max: 25 }),
			body(`${imigrtnStatus}.dateOfResidency`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No'
			).custom(cusValid.validDateWithRange),
			body(`${imigrtnStatus}.sponsorForYourImmigration`)
				.if((value, { req }) => req.body.unitedStatesCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${imigrtnStatus}.sponsorCompanyName`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No' &&
				req.body.eligibleImmigrationStatusInfo.sponsorForYourImmigration === 'Yes'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${imigrtnStatus}.sponsorPhoneNumber`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No' &&
				req.body.eligibleImmigrationStatusInfo.sponsorForYourImmigration === 'Yes'
			).optional().isInt({ max: 9999999999 }),
			body(`${imigrtnStatus}.addressLine1`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No' &&
				req.body.eligibleImmigrationStatusInfo.sponsorForYourImmigration === 'Yes'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${imigrtnStatus}.addressLine2`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No' &&
				req.body.eligibleImmigrationStatusInfo.sponsorForYourImmigration === 'Yes'
			).isLength({ max: 100 }),
			body(`${imigrtnStatus}.city`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No' &&
				req.body.eligibleImmigrationStatusInfo.sponsorForYourImmigration === 'Yes'
			).not().isEmpty().isLength({ max: 50 }),
			body(`${imigrtnStatus}.state`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No' &&
				req.body.eligibleImmigrationStatusInfo.sponsorForYourImmigration === 'Yes'
			).not().isEmpty().isLength({ max: 25 }),
			body(`${imigrtnStatus}.zipCode`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No' &&
				req.body.eligibleImmigrationStatusInfo.sponsorForYourImmigration === 'Yes'
			).not().isEmpty().isLength({ max: 10 }),
			body(`${imigrtnStatus}.county`).if((value, { req }) =>
				req.body.unitedStatesCitizen === 'No' &&
				req.body.eligibleImmigrationStatusInfo.sponsorForYourImmigration === 'Yes'
			).isLength({ max: 50 }),
			body(`${imigrtnStatus}.continuousResidentInUS`)
				.if((value, { req }) => req.body.unitedStatesCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${imigrtnStatus}.countryYouWereBorn`)
				.if((value, { req }) => req.body.unitedStatesCitizen === 'No'
				).not().isEmpty().isLength({ max: 50 }),
			body(`${imigrtnStatus}.currentImmigrationStatusForAtleast5Years`)
				.if((value, { req }) => req.body.unitedStatesCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${imigrtnStatus
				}.honorablyDischargedVeteranOrActiveDutyMemberOfTheMilitary`)
				.if((value, { req }) => req.body.unitedStatesCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${imigrtnStatus}.cubanOrHaitianEntrant`)
				.if((value, { req }) => req.body.unitedStatesCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${imigrtnStatus}.victimOfHumanTrafficking`)
				.if((value, { req }) => req.body.unitedStatesCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${imigrtnStatus}.violenceAgainstWomenAct`)
				.if((value, { req }) => req.body.unitedStatesCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No'])

		]
	},

	/*Me and My Household Validation @Page3  */
	mmhhPage3: () => {
		const eSnapApp = 'expeditedSnapAppInfo'
		return [
			body(`${eSnapApp}.householdIncomeLessThen150DollersPerMonth`)
				.not().isEmpty().isIn(['Yes', 'No']),
			body(`${eSnapApp}.householdHaveLessThen100DollersCash`)
				.not().isEmpty().isIn(['Yes', 'No']),
			body(`${eSnapApp}.householdMonthlyRentAndPaymentsMoreThenIncome`)
				.not().isEmpty().isIn(['Yes', 'No']),
			body(`${eSnapApp}.anyoneInHouseholdMigrantOrSeasonalFarmWorker`)
				.not().isEmpty().isIn(['Yes', 'No']),
			body(`${eSnapApp}.eSignature`).not().isEmpty().isLength({ max: 101 }),
			body(`${eSnapApp}.location`).not().isEmpty().isLength({ max: 50 })
		]
	},

	/*Me and My Household Validation @Page4  */
	mmhhPage4: () => {
		const hdOtherInfo = 'headOfHouseholdOtherInfo'
		return [
			body(`${hdOtherInfo}.someoneElseCompletingApplicationOnYourBehalf`)
				.not().isEmpty().isIn(['Yes', 'No']),

			body(`${hdOtherInfo}.typeOfPersonHelpingYouCompleteTheApplication`)
				.if((value, { req }) =>
					req.body.headOfHouseholdOtherInfo
						.someoneElseCompletingApplicationOnYourBehalf === 'Yes'
				).not().isEmpty().isLength({ max: 170 }),

			body(`${hdOtherInfo}.haveAnAuthorizedRepresentative`)
				.not().isEmpty().isIn(['Yes', 'No']),
			body(`${hdOtherInfo}.sizeOfHouseholdIncludingYou`)
				.not().isEmpty().isInt({ min: 1, max: 20 })

		]
	},

	/*Me and My Household Agent/Broker  */
	mmhhAgentBrokerValidation: () => {
		const agentBroker = 'agentsAndBrokersInfo'
		return [
			body(`${agentBroker}.firstName`).not().isEmpty().isLength({ max: 50 }),
			body(`${agentBroker}.middleName`).isLength({ max: 50 }),
			body(`${agentBroker}.lastName`).not().isEmpty().isLength({ max: 50 }),
			body(`${agentBroker}.addressLine1`).not().isEmpty().isLength({ max: 100 }),
			body(`${agentBroker}.addressLine2`).isLength({ max: 100 }),
			body(`${agentBroker}.city`).not().isEmpty().isLength({ max: 59 }),
			body(`${agentBroker}.state`).not().isEmpty().isLength({ max: 25 }),
			body(`${agentBroker}.zipCode`).not().isEmpty().isLength({ max: 10 }),
			body(`${agentBroker}.county`).isLength({ max: 50 }),
			body(`${agentBroker}.phoneNumber`).optional().isInt()
				.isLength({ max: 10 }),
			body(`${agentBroker}.email`).not().isEmpty().isLength({ max: 50 }),
			body(`${agentBroker}.organizationName`).not().isEmpty()
				.isLength({ max: 100 }),
			body(`${agentBroker}.licenseNumber`).not().isEmpty().isLength({ max: 20 })
		]
	},

	/*Me and My Household Assistant information  */
	mmhhAssistantInformationValidation: () => {
		const assist = 'assistantInfo'
		return [
			body(`${assist}.firstName`).not().isEmpty().isLength({ max: 50 }),
			body(`${assist}.middleName`).isLength({ max: 50 }),
			body(`${assist}.lastName`).not().isEmpty().isLength({ max: 50 }),
			body(`${assist}.phoneNumber`).optional().isInt({ max: 9999999999 }),
			body(`${assist}.email`).not().isEmpty().isLength({ max: 50 })
		]
	},

	/*Me and My Household Certified Application Counselors  */
	mmhhCertifiedAppValidation: () => {
		const certApp = 'certifiedAppCounsillorInfo'
		return [
			body(`${certApp}.firstName`).not().isEmpty().isLength({ max: 50 }),
			body(`${certApp}.middleName`).isLength({ max: 50 }),
			body(`${certApp}.lastName`).not().isEmpty().isLength({ max: 50 }),
			body(`${certApp}.addressLine1`).not().isEmpty().isLength({ max: 100 }),
			body(`${certApp}.addressLine2`).isLength({ max: 100 }),
			body(`${certApp}.city`).not().isEmpty().isLength({ max: 50 }),
			body(`${certApp}.state`).not().isEmpty().isLength({ max: 25 }),
			body(`${certApp}.zipCode`).not().isEmpty().isLength({ max: 10 }),
			body(`${certApp}.county`).isLength({ max: 50 }),
			body(`${certApp}.phoneNumber`).optional().isInt().isLength({ max: 10 }),
			body(`${certApp}.email`).not().isEmpty().isLength({ max: 50 }),
			body(`${certApp}.organizationName`).not().isEmpty().isLength({ max: 100 }),
			body(`${certApp}.certificationNumber`).isLength({ max: 20 })
		]
	},

	/*Me and My Household authorized representative  */
	mmhhAuthorizedRepValidation: () => {
		const authRep = 'authorizedRepresentative'
		return [
			body(`${authRep}.type`).not().isEmpty().isLength({ max: 50 }),
			body(`${authRep}.actionsTobeCompletedByAuthorizedRepresentative`)
				.isLength({ max: 170 }),
			body(`${authRep}.firstName`).not().isEmpty().isLength({ max: 50 }),
			body(`${authRep}.middleName`).isLength({ max: 50 }),
			body(`${authRep}.lastName`).not().isEmpty().isLength({ max: 50 }),
			body(`${authRep}.suffix`).isLength({ max: 10 }),
			body(`${authRep}.addressLine1`).not().isEmpty().isLength({ max: 100 }),
			body(`${authRep}.addressLine2`).isLength({ max: 100 }),
			body(`${authRep}.city`).not().isEmpty().isLength({ max: 50 }),
			body(`${authRep}.state`).not().isEmpty().isLength({ max: 25 }),
			body(`${authRep}.zipCode`).not().isEmpty().isLength({ max: 10 }),
			body(`${authRep}.county`).isLength({ max: 50 }),
			body(`${authRep}.organizationName`).not().isEmpty().isLength({ max: 100 }),
			body(`${authRep}.phoneNumber`).optional().isInt().isLength({ max: 10 }),
			body(`${authRep}.email`).not().isEmpty().isLength({ max: 50 }),
			body(`${authRep}.certificationNumber`).isLength({ max: 20 }),
			body(`${authRep}.eSignature`).not().isEmpty().isLength({ max: 101 }),
			body(`${authRep}.location`).isLength({ max: 50 })
		]
	},

	/*Me and My Household Member Information  */
	mmhhMemberInfoValidation: () => {
		const memInfo = 'householdMemberInfo'
		return [
			body(`${memInfo}.firstName`).not().isEmpty().isLength({ max: 50 }),
			body(`${memInfo}.middleName`).isLength({ max: 50 }),
			body(`${memInfo}.lastName`).not().isEmpty().isLength({ max: 50 }),
			body(`${memInfo}.suffix`).isLength({ max: 10 }),
			body(`${memInfo}.otherNames`).optional().isArray()
				.custom((value) => value.every((currentValue) => currentValue.length <= 50)),
			body(`${memInfo}.dateOfBirth`).custom(cusValid.validDateWithRange),
			body(`${memInfo}.maritalStatus`).not().isEmpty().isLength({ max: 25 }),
			body(`${memInfo}.gender`).not().isEmpty().isIn(['Male', 'Female']),
			body(`${memInfo}.livingArrangements`).not().isEmpty().isLength({ max: 59 }),
			body(`${memInfo}.race`).isLength({ max: 60 }),
			body(`${memInfo}.ethnicity`).isLength({ max: 60 }),
			body(`${memInfo}.haveSSN`).not().isEmpty().isIn(['Yes', 'No']),
			body(`${memInfo}.ssn`).if((value, { req }) =>
				req.body.householdMemberInfo.haveSSN === 'Yes'
			).not().isEmpty().isInt().isLength({ max: 9 }),
			body(`${memInfo}.whySSNnotProvided`).if((value, { req }) =>
				req.body.householdMemberInfo.haveSSN === 'No'
			).not().isEmpty().isLength({ max: 50 }),
			body(`${memInfo}.nameOnApplicationMatchNameOnSocialSecurityCard`)
				.if((value, { req }) => req.body.householdMemberInfo.haveSSN === 'Yes')
				.not().isEmpty().isIn(['Yes', 'No']),
			body(`${memInfo}.nameOnSocialSecurityCard`).if((value, { req }) =>
				req.body.householdMemberInfo.haveSSN === 'Yes' &&
				req.body.householdMemberInfo
					.nameOnApplicationMatchNameOnSocialSecurityCard === 'No'
			).not().isEmpty().isLength({ max: 170 }),
			body(`${memInfo}.naturalBornOrNaturalizedUsCitizen`).not().isEmpty()
				.isIn(['Yes', 'No']),
			body(`${memInfo}.immigrationStatus`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${memInfo}.immigrationNonCitizenDoc`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${memInfo}.immigrationDocId`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
			).not().isEmpty().isLength({ max: 20 }),
			body(`${memInfo}.nameOnAppMatchNameOnImmigrationDoc`)
				.if((value, { req }) =>
					req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${memInfo}.nameOnDoc`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				&&
				req.body.householdMemberInfo.nameOnAppMatchNameOnImmigrationDoc === 'No'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${memInfo}.dateOfEntry`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
			).custom(cusValid.validDateWithRange),
			body(`${memInfo}.alienNumber`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
			).not().isEmpty().isLength({ max: 25 }),
			body(`${memInfo}.dateOfResidency`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
			).custom(cusValid.validDateWithRange),
			body(`${memInfo}.sponsorForYourImmigration`)
				.if((value, { req }) =>
					req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${memInfo}.sponsorCompanyName`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				&&
				req.body.householdMemberInfo.sponsorForYourImmigration === 'Yes'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${memInfo}.sponsorPhoneNumber`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				&&
				req.body.householdMemberInfo.sponsorForYourImmigration === 'Yes'
			).optional().isInt().isLength({ max: 10 }),
			body(`${memInfo}.sponsorAddressLine1`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				&&
				req.body.householdMemberInfo.sponsorForYourImmigration === 'Yes'
			).not().isEmpty().isLength({ max: 100 }),
			body(`${memInfo}.sponsorAddressLine2`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				&&
				req.body.householdMemberInfo.sponsorForYourImmigration === 'Yes'
			).isLength({ max: 100 }),
			body(`${memInfo}.sponsorCity`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				&&
				req.body.householdMemberInfo.sponsorForYourImmigration === 'Yes'
			).not().isEmpty().isLength({ max: 50 }),
			body(`${memInfo}.sponsorState`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				&&
				req.body.householdMemberInfo.sponsorForYourImmigration === 'Yes'
			).not().isEmpty().isLength({ max: 25 }),
			body(`${memInfo}.sponsorZipCode`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				&&
				req.body.householdMemberInfo.sponsorForYourImmigration === 'Yes'
			).not().isEmpty().isLength({ max: 10 }),
			body(`${memInfo}.sponsorCounty`).if((value, { req }) =>
				req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				&&
				req.body.householdMemberInfo.sponsorForYourImmigration === 'Yes'
			).isLength({ max: 50 }),
			body(`${memInfo}.continuousResidentInUS`)
				.if((value, { req }) => req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${memInfo}.countryBornIn`)
				.if((value, { req }) => req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				).not().isEmpty().isLength({ max: 50 }),
			body(`${memInfo}.currentImmigrationStatusForAtleast5Years`)
				.if((value, { req }) => req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${memInfo}.honorblyDischargedVeteranOrActiveMemberOfMilitary`)
				.if((value, { req }) => req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${memInfo}.cubanOrHaitianEntrant`)
				.if((value, { req }) => req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${memInfo}.victimOfHumanTraffcking`)
				.if((value, { req }) => req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No']),
			body(`${memInfo}.violenceAgainstWomenAct`)
				.if((value, { req }) => req.body.householdMemberInfo.naturalBornOrNaturalizedUsCitizen === 'No'
				).not().isEmpty().isIn(['Yes', 'No'])
		]
	}

}
