/**
 *  @Author - rahul Saha
 *  @AuthorEmail : rahul.saha@conduent.com
 *  @CreatedDate : 2020-01-16:15:00:00
 *  @ModifiedDate : 2020-01-16:15:00:00
 */
// "use strict"


const {
	body
} = require('express-validator')
const cusValid = require('../../helper/custom_validators')
const vMsg = require('../../helper/validation_message')
const mmmh = require('./mmhh')

/**
 * @LOGIC : MIDDLEWARE TO VALIDATE APPLICATION
 */
module.exports.validate = function (req, res, next) {
	let { applicationState } = req.body
	try {
		applicationState = JSON.parse(applicationState)
		const { pageId } = applicationState
		if (!pageId) {
			throw Error(`pageId: ${pageId}`)
		}
		return cusValid.validate(generateRules(pageId))(req, res, next)
	} catch (error) {
		return res.json({
			'statusCode': 400,
			'success': false,
			'timestamp': new Date().getTime(),
			'message': 'pageId NOT FOUND',
			error: error.message
		})
	}
}

function commonRules() {
	return [
		body('consumerAccountId')
			.not().isEmpty().withMessage(vMsg.required),
		body([
			'healthcoverageProgram',
			'snapProgram',
			'tanfProgram',
			'expeditedSnapProgram'
		])
			.not().isEmpty().withMessage(vMsg.required)
	]
}

function generateRules(pageId) {
	const ruleList = [
		{
			pageId: 904,
			rules: mmmh.mmhhPage1()
		}
	]

	let rules = commonRules()
	for (let r = 0; r < ruleList.length; r++) {
		const ruleElement = ruleList[r]
		rules = rules.concat(ruleElement.rules)
		if (ruleElement.pageId === pageId) {
			break
		}
	}
	return rules
}
