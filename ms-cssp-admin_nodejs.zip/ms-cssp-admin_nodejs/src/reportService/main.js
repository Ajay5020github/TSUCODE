// "use strict"

const express = require("express");
const router = express.Router()
const getEmbedTokenFile = require('./getEmbedToken')
const cusValid = require('../helper/custom_validators')
const sanitizeFile = require('../../sanitize')

const {
	body
} = require('express-validator')

router.post('/getEmbedToken',
						cusValid.authTokenValidate,
						cusValid.validate([
							body('reportId'),
							body('workspaceId'),
					]),
					sanitizeFile.sanitize,
					getEmbedTokenFile.getEmbedToken)


module.exports = router
