// "use strict"
/**
 *  @Author - Vijay Sharma
 *  @AuthorEmail : vijaykumar.sharma@conduent.com
 *  @CreatedDate : 2019-06-14:02:38:00
 *  @ModifiedDate : 2019-06-14:02:38:00
 */
// "use strict"

const process = require("process");

let env = process.env.ENVIRONMENT; // "DEV"; //DEV|QA|UAT
let authenticationMode,
  authorityUri,
  scope,
  apiUrl,
  clientId,
  workspaceId,
  reportId,
  pbiUsername,
  pbiPassword,
  clientSecret,
  tenantId;

switch (env) {
  case "DEV":
      authenticationMode = process.env.reports_authenticationMode;
      authorityUri = process.env.reports_authorityUri;
      scope = process.env.reports_scope;
      apiUrl = process.env.reports_apiUrl;
      clientId = process.env.reports_clientId;
      clientSecret = process.env.reports_clientSecret;
      tenantId = process.env.reports_tenantId;
      break;
  case "SIT":
      authenticationMode = process.env.reports_authenticationMode;
      authorityUri = process.env.reports_authorityUri;
      scope = process.env.reports_scope;
      apiUrl = process.env.reports_apiUrl;
      clientId = process.env.reports_clientId;
      clientSecret = process.env.reports_clientSecret;
      tenantId = process.env.reports_tenantId;
      break;
  case "QA":
      authenticationMode = process.env.reports_authenticationMode;
      authorityUri = process.env.reports_authorityUri;
      scope = process.env.reports_scope;
      apiUrl = process.env.reports_apiUrl;
      clientId = process.env.reports_clientId;
      clientSecret = process.env.reports_clientSecret;
      tenantId = process.env.reports_tenantId;
      break;
  case "UAT":
      authenticationMode = process.env.reports_authenticationMode;
      authorityUri = process.env.reports_authorityUri;
      scope = process.env.reports_scope;
      apiUrl = process.env.reports_apiUrl;
      clientId = process.env.reports_clientId;
      clientSecret = process.env.reports_clientSecret;
      tenantId = process.env.reports_tenantId;
      break;
  default:
    break;
}

const config = {
  authenticationMode,
  authorityUri,
  scope,
  apiUrl,
  clientId,
  workspaceId,
  reportId,
  pbiUsername,
  pbiPassword,
  clientSecret,
  tenantId
};
module.exports = config;
