//const config = require('./../../config/main')
let embedToken = require('./embedConfigService.js');
let utils = require("./utils");

module.exports.getEmbedToken = async function (req, res) {
    try {
        if (req.body.reportId && req.body.workspaceId) {

            const { reportId, workspaceId } = req.body;

            try {
                // Validate whether all the required configurations are provided in config.json
                configCheckResult = utils.validateConfig();
                if (configCheckResult) {
                    return res.status(400).send({
                        "error": configCheckResult
                    });
                }
                // Get the details like Embed URL, Access token and Expiry
                let result = await embedToken.getEmbedInfo(workspaceId, reportId);


                // result.status specified the statusCode that will be sent along with the result object
                return res.status(result.status).send(result);
            }
            catch (error) {

                req.app.settings.apiLogger.error({
                    'message': 'Logging Exception in getEmbedToken',
                    error
                })
                return res.json({
                    error
                })
            }
        }
        else {
            return res.json({
                error: "Workspace ID and Report ID  is mandatory"
            })
        }
    } catch (excep) {
    }

}
