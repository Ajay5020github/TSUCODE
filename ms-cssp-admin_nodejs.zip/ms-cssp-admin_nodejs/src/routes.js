
const express = require('express')
const router = express.Router()
const config = require('../config/main')
const cusValid = require('./helper/custom_validators')
const { cacheConnection } = require('./cache/cache')
const sanitizeFile = require('../sanitize')

// const logs = require('./helper/errorLog')

router.use((req, res, next) => {
	if (req.method === 'POST'
		&& (!req.headers['content-type']
			|| req.headers['content-type'].indexOf('multipart') === -1
			&& req.headers['content-type'].indexOf('application/json') === -1)) {
		res.status(400).send('Node Server requires application/json')
	} else {
		res.status(200)
		next()
	}
})
/**
 * API TO CHECK SERVER IS RUNNING OR NOT !
 *
 */
router.get('/', function (req, res) {
	const { prod, uat, sit, dev } = config.version
	const version = `${prod}.${uat}.${sit}.${dev}`
	res.status(200).send({
		statusCode: 200,
		success: true,
		timestamp: new Date().getTime(),
		message: 'Server Running',
		version
	})
})

const validateBodyParams = function(req ,res ,next) {

	const { screenName } = req.body



	if (screenName === 'AdminLogin' || screenName === 'AdminFooter' || screenName === 'AdminContactUs' || screenName === 'AdminContactLocalOffice' || screenName === 'AdminPrintableApplication') {

		next();
	}
	else {

		cusValid.authTokenValidate(req,res,next);
	}

}

const languageFile = require('./language/getJSON')
router.post('/fetchConfigJson', validateBodyParams, sanitizeFile.sanitize, languageFile.fetchConfigJsonFromBlobStorageFromBlob)

const adminService = require('./adminService/main')
router.use('/adminService', adminService)

const jsonModifierService = require('./jsonModifierService/main')
router.use('/jsonModifierService', jsonModifierService)

const reportService = require('./reportService/main')
router.use('/reportService',reportService)

const azureService = require('./azureService/main')
router.use('/externalAuth', azureService)

const cacheFile = require('./cache/main')
// const mycache = require('./cache/cache')

router.use('/cache', cacheFile)

router.post('/getEnvironment', cusValid.authTokenValidate, sanitizeFile.sanitize, (req, res) =>{
	res.json({ "env" : config.env})
})

router.post('/logErrors', (req, res, next) => {
	const {error} = req.body;

	// This is to  capture Transaction Logs in Audit Table
	// logs.errorLogs(req, res);
	if(error){
	req.app.settings.apiLogger.error({
		'message': 'Error log sent from frontend',
		error
	})
	return res.send({
		'msg': "Error Logged"
	})
	}
})

router.get('/checkRedirect', (req, res, next) => {
	const cacheValue = cacheConnection && cacheConnection.get('dataValue');
	const checkRedirect = cacheValue.checkRedirect;
	res.send({
		checkRedirect
	})
})

module.exports = router
