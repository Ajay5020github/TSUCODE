const jwt = require('jsonwebtoken');
const config = require('./../../config/main');
const keyVault = require('../helper/keyVault_function');
const { cacheConnection } = require('../cache/cache');
const { v4: uuidv4 } = require('uuid');


const DANGEROUS_OPERATORS = new Set([
	'$where', '$gt', '$gte', '$lt', '$lte', '$ne', '$in', '$nin',
	'$or', '$and', '$not', '$nor', '$exists', '$type', '$mod',
	'$regex', '$text', '$search', '$elemMatch', '$size', '$all',
	'$slice', '$expr', '$jsonSchema', '$function', '$accumulator'
]);

const GLOBALLY_BLOCKED_FIELDS_NORMALIZED = new Set([
	'isadmin',
	'issso',
	'role',
	'passwordhash',
	'createdat',
	'updatedat',
	'deletedat',
]);

const GLOBALLY_BLOCKED_EXACT = new Set(['__v', '_id']);

module.exports.getToken = async function (req, res, next) {
	const { email, id, department, firstName, adminUserId } = req.body;

	let validPayload = await verifyPayload(req, res, next);
	let resultFoundBlockedKeys = await checkBlockedFields(req, res, next);

	if (validPayload === false || resultFoundBlockedKeys === false) {
		return res.status(400).send({
			message: 'Please provide Proper Inputs',
			ResponseCode: "400",
			ResponseDescription: "Bad Request",
			ResponseTimeStamp: new Date()
		});
	}



	const cacheKey = department === "internal"
		? `${config.env}${adminUserId}${id}`
		: `${config.env}${email}${id}`;

	if (!cacheConnection) {
		return res.status(500).json({
			statusCode: 500,
			success: false,
			message: "Cache connection not initialized",
		});
	}


	let authDataString = await cacheConnection.get(cacheKey);


	if (!authDataString) {
		console.warn(`No cache found for key: ${cacheKey}`);
		return res.json({
			statusCode: 404,
			success: false,
			message: "No cache found"
		});
	}

	let authData;
	try {
		authData = JSON.parse(authDataString);

	} catch (error) {
		console.error("Error parsing authDataString:", error);
		return res.json({
			statusCode: 500,
			success: false,
			message: "Invalid Cache Data"
		});
	}

	if (!authData || (!authData.email && !authData.userId)) {
		return res.json({
			statusCode: 404,
			success: false,
			message: "Incomplete auth data"
		});
	}

	const newId = uuidv4();
	const loginType = authData.loginType || department;
	const loggedInUserName = authData.name || firstName;


	try {
		const jwtSecret = await keyVault.getValue();
		const authToken = jwt.sign({ email }, jwtSecret, config.jwtOptions);

		const dataValue = {
			name: loggedInUserName,
			availableName: authData.availableName,
			email: authData.email,
			role: authData.role,
			authToken,
			loginType,
			id // newId
		};

		return res.json({
			statusCode: 200,
			name: loggedInUserName,
			availableName: authData.availableName,
			role: authData.role,
			token: authToken,
			authToken,
			email: authData.email,
			loginType,
			logout: config.destroySessionUrl,
			success: true,
			id // : newId
		});
	} catch (err) {
		return res.status(500).json({
			statusCode: 500,
			success: false,
			message: "Token generation failed"
		});
	}
};


async function verifyPayload(req, res, next) {

	try {
		let filteredPayload = JSON.parse(JSON.stringify(req.body));

		// SAST MongoDB Check
		let resultMongoDBKeys = await validateForMongoDBJSONKeys(filteredPayload);
		return resultMongoDBKeys;

	} catch (error) {
		req.app.settings.apiLogger.error({
			message: constants.errorLogMsg.errInputPayload
		});
		return false;
	}

}

async function validateForMongoDBJSONKeys(body, res, next) {
	let aborted = false;
	const dangerousKeys = [];

	loopThroughObjRecurse(body, (key, value) => {
		if (aborted) return;

		if (key.startsWith('$')) {
			dangerousKeys.push(key);
			aborted = true;
			return;
		}

		if (typeof value === 'string' && DANGEROUS_OPERATORS.has(value.trim())) {
			dangerousKeys.push(`value:${value}`);
			aborted = true;
			return;
		}

		if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
			dangerousKeys.push(key);
			aborted = true;
			return;
		}
	});

	if (dangerousKeys.length > 0) {
		return false;
	}

	return true;
}

function checkBlockedFields(req, res, next) {

	let parsedJSON = JSON.parse(JSON.stringify(req.body));

	const dangerousKeys = [];

	loopThroughObjRecurse(parsedJSON, function (prop, jsonValue) {
		// Exact match for fields with underscores that matter
		if (GLOBALLY_BLOCKED_EXACT.has(prop)) {
			dangerousKeys.push(`blockedkey:${prop}`);
		}

		// Normalized match for everything else
		const normalizedProp = prop.toLowerCase().replace(/[_\-]/g, '');
		if (GLOBALLY_BLOCKED_FIELDS_NORMALIZED.has(normalizedProp)) {
			dangerousKeys.push(`normalizedProp:${normalizedProp}`);
		}
	});

	if (dangerousKeys.length > 0) {
		return false;
	}

	return true;
}

function loopThroughObjRecurse(obj, propExec) {
	for (var k in obj) {
		if (obj.hasOwnProperty(k)) {
			if (typeof obj[k] === 'object' && obj[k] !== null) {
				propExec(k, obj[k]);
				loopThroughObjRecurse(obj[k], propExec);
			} else {
				propExec(k, obj[k]);
			}
		}
	}
}
