
const express = require('express')
const router = express.Router()
const {
	body
} = require('express-validator')
const cusValid = require('../helper/custom_validators')
const vMsg = require('../helper/validation_message')
const azureLoginFile = require('./azureLogin')
const getTokenFile = require('./getToken')
const sanitizeFile = require('../../sanitize')

router.post('/extLogin',
	cusValid.validate([
		body('loginData')
			.not().isEmpty().withMessage(vMsg.required),
	]), sanitizeFile.sanitize, azureLoginFile.azureLogin)


	//router.post('/getToken', getTokenFile.getToken)

	router.post('/getToken',
	cusValid.validate([
		body('email')
			.not().isEmpty().withMessage(vMsg.required),
	]), sanitizeFile.sanitize, getTokenFile.getToken)

module.exports = router
