
const config = require('./../../config/main')

module.exports.azureLogin = function (req, res) {
  if (req.body.loginData && req.body.loginData) {
    const selectedAuth = req.body.loginData
    // const { selectedAuth } = req.body;
    let url;
    if (selectedAuth.toLowerCase() == "dom") {
      url = config.identityMetadataDOM +
        "?" +
        "client_id=" +
        config.clientID_dom +
        "&response_type=" +
        config.responseType +
        "&redirect_uri=" +
        config.redirect_uri +
        "&response_mode=" +
        config.response_mode +
        "&scope=" +
        config.scope +
        "&state=" +
        config.state;
    } else if (selectedAuth.toLowerCase() == "mdhs") {
      url =
        config.identityMetadataMDHS +
        "?" +
        "client_id=" +
        config.clientID_mdhs +
        "&response_type=" +
        config.responseType +
        "&redirect_uri=" +
        config.redirect_uri +
        "&response_mode=" +
        config.response_mode +
        "&scope=" +
        config.scope +
        "&state=" +
        config.state;
    }
    return res.send({
      statusCode: 200,
      url
    })
  } else {
    res.send({
      statusCode: 400,
      message: 'REQUIRED PARAMETERS MISSING'
    })
  }
}








