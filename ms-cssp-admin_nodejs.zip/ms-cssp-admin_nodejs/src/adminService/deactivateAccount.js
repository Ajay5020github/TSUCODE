
const config = require('./../../config/main')
const axios = require('axios');

module.exports.deactivateAccount = function (req, res) {

	const db = "database" === config.apiMode;

	const deactivateAccountService = function (userId, email, consumerAccountId, department, adStatus, req, res) {
		const url = config.devUrlAccountService
		const reqOptions = {
			url: `${url}account/admin/changeAccountStatus`,
			method: 'POST',
			data: {
				adStatus,
				consumerAccountId,
				requestType: "DEACTIVATE-ACCOUNT",
				userId,
				department,
				email
			}
		}


		axios(reqOptions).then(results => {

			const { statusCode, message } = results && results.data;

			/* istanbul ignore if */

			if (statusCode !== 200) {
				req.app.settings.apiLogger.error({
					'message': 'Issue in performing Account Deactivation process',
					'postDataObject': reqOptions,
					error,
					body: results && results.data
				})
				return res.json({
					'statusCode': statusCode || 500,
					'success': false,
					'timestamp': new Date().getTime(),
					'message': message || 'Issue in performing Account Deactivation process',
					error,
					body: results && results.data
				})
			} else {
				res.json({
					statusCode,
					success: true,
					timestamp: new Date().getTime(),
					message,
					body: results && results.data
				})
			}

		}).catch(excep => {
			/* istanbul ignore if */
			req.app.settings.apiLogger.error({
				'message': 'Issue in performing Account Deactivation process',
				'postDataObject': reqOptions,
				error: excep &&
					excep.response,
				body: excep &&
					excep.response &&
					excep.response.data
			})
			return res.json({
				'statusCode': statusCode || 500,
				'success': false,
				'timestamp': new Date().getTime(),
				'message': message || 'Issue in performing Account Deactivation process',
				error: excep &&
					excep.response,
				body: excep &&
					excep.response &&
					excep.response.data
			})
		})

	}

	function deactivateAccountAD(req, res) {
		const {
			consumerAccountId,
			userId,
			email,
			department
		} = req.body

		axios({
			method: 'GET',
			url: `${config.devUrlAccountService}account/fetchUserId/${email}/${config.env}`,
		}).then(results => {

			if (results.data && results.data.userName) {

				// Get AD Status
				const {
					userName,
					statusCode
				} = results.data;

				let adStatus = false;

				if (statusCode === 200) {
					adFunc.existsCheckUserId(userName).then(exist => {
						if (!exist) {
							return res.json({
								exist,
								statusCode,
								success: true,
								timestamp: new Date(),
								message: 'User does not exists',
								consumerAccountId
							})
						} else {
							adStatus = true;
							deactivateAccountService(userId, email, consumerAccountId, department, adStatus, req, res)
						}
					}).catch(err => {
						return res.json({
							err,
							consumerAccountId
						})
					})
				}
				else {
					return res.json({
						'statusCode': statusCode,
						'success': false,
						'timestamp': new Date().getTime(),
						'message': message || 'User does not exist',
					})
				}
			}
		})
	}

	function deactivateAccountDB(req, res) {
		const {
			consumerAccountId,
			userId,
			email,
			department
		} = req.body
		const adStatus = true;
		deactivateAccountService(userId, email, consumerAccountId, department, adStatus, req, res)
	}

	if (db) {
		deactivateAccountDB(req, res)
	} else {
		deactivateAccountAD(req, res)
	}


}

