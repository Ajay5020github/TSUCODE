
const config = require('./../../config/main')
const axios = require('axios');

module.exports.searchUserMS = function (req, res) {
	const {
		arInd,
		emailAddress,
		firstName,
		lastName,
		fromDate,
		toDate,
		programName,
		userId,
		department,
		page,
		size
	} = req.body
	const url = config.devUrlAccountService

	const reqOptions = {
		url: `${url}account/admin/searchUser`,
		method: 'POST',
		data: {
			arInd,
			emailAddress,
			firstName,
			lastName,
			fromDate,
			toDate,
			programName,
			userId,
			department,
			page,
			size
		}
	}

	axios(reqOptions).then(results => {

		const { message, users, statusCode } = results && results.data

		res.json({
			statusCode: 200,
			success: true,
			timestamp: new Date().getTime(),
			message,
			body: results && results.data
		})

	}).catch(excep => {

		/* istanbul ignore if */
		req.app.settings.apiLogger.error({
			'message': 'User Details Not Found',
			'postDataObject': reqOptions,
			error: excep &&
			excep.response,
			body: excep &&
			excep.response &&
			excep.response.data
		})
		return res.status(500).json({
			'statusCode': 500,
			'success': false,
			'timestamp': new Date().getTime(),
			'message': 'Issue in performing User Search process',
			error: excep &&
			excep.response,
			body: excep &&
			excep.response &&
			excep.response.data
		})

	})
}
