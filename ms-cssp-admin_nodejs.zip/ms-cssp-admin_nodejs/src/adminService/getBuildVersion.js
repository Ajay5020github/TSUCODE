const config = require('../../config/main');

const getBuildVersion = (req, res) => {

	res.header('Cache-Control', 'no-store');
	res.header('Pragma', 'no-cache');

	res.send({
		version: config.version,
		env: config.env
	})
}

module.exports = getBuildVersion;
