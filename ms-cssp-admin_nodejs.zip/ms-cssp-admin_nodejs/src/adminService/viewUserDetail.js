
const config = require('./../../config/main')
const axios = require('axios');

module.exports.viewUserDetail = function (req, res) {
	const db = "database" === config.apiMode;

	const viewUserDetailService = function (userId, email, consumerUserID, adStatus, req, res) {
		const url = config.devUrlAccountService
		const reqOptions = {
			url: `${url}account/admin/viewUser`,   /// 	Modified from url: `${url}adminportal/viewUser`,
			method: 'POST',
			data: {
				userId,
				consumerUserID,
				email
			}
		}

		axios(reqOptions).then(results => {

			const { statusCode, message } = results && results.data

			res.json({
				statusCode,
				success: true,
				timestamp: new Date().getTime(),
				message,
				body: results && results.data,
				userExits: true
			})

		}).catch(excep => {

			/* istanbul ignore if */
			req.app.settings.apiLogger.error({
				'message': 'Issue in performing view User details process',
				'postDataObject': reqOptions,
				error: excep &&
				excep.response,
				body: excep &&
				excep.response &&
				excep.response.data
			})
			return res.json({
				'statusCode': 500,
				'success': false,
				'timestamp': new Date().getTime(),
				'message': message || 'Issue in performing view User details process',
				error: excep &&
				excep.response,
				body: excep &&
				excep.response &&
				excep.response.data
			})

		})
	}

	function viewUserDetailAD(req, res) {
		const {
			userId,
			consumerUserID,
			email
		} = req.body

		axios({
			method: 'GET',
			url: `${config.devUrlAccountService}account/fetchUserId/${email}/${config.env}`,
		}).then(results => {
			if (results.data && results.data.userName) {

				// Get AD Status
				const {
					userName,
					statusCode
				} = results.data;

				let adStatus = false;

				if (statusCode === 200) {
					adFunc.existsCheckUserId(userName).then(exist => {
						if (!exist) {
							return res.json({
								exist,
								statusCode,
								success: true,
								timestamp: new Date(),
								message: 'User does not exists',
								userExits: false
							})
						} else {
							adStatus = true;
							viewUserDetailService(userId, email, consumerUserID, adStatus, req, res)
						}
					}).catch(err => {
						req.app.settings.apiLogger.error({
							'message': 'Logging Exception in viewUserDetails',
							err
						})
						return res.json({
							err,
							error: "ConstraintViolationError",
							consumerUserID
						})
					})
				} else {
					return res.json({
						'statusCode': statusCode,
						'success': false,
						'timestamp': new Date().getTime(),
						'message': message || 'User does not exist',
					})
				}


			}
		});

	}

	function viewUserDetailDB(req, res) {
		const {
			userId,
			consumerUserID,
			email
		} = req.body
		const adStatus = true;
		viewUserDetailService(userId, email, consumerUserID, adStatus, req, res)
	}

	if(db){
		viewUserDetailDB(req,res)
	}else{
		viewUserDetailAD(req,res)
	}

}







