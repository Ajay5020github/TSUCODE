
const config = require('./../../config/main')
const axios = require('axios');

module.exports.fetchRoleMatrix = function (req, res) {
	const {
		userId,
		userRoles
	} = req.body
	const url = config.devUrlAdminPortalService
	const reqOptions = {
		url: `${url}adminportal/fetchRoleMatrix`,
		method: 'POST',
		data: {
			userId,
			userRoles
		}
	}

	/* Template */
	axios(reqOptions).then(results => {

		const message = results && results.data && results.data.message;
		const statusCode = results && results.data && results.data.statusCode;

		/* istanbul ignore if */
		if (statusCode !== 200) {
			req.app.settings.apiLogger.error({
				'message': 'Issue in performing Fetch Role Matrix process',
				'postDataObject': reqOptions,
				error,
				body: results && results.data
			})
			return res.json({
				'statusCode': 500,
				'success': false,
				'timestamp': new Date().getTime(),
				'message': 'Issue in performing Fetch Role Matrix process',
				error,
				body: results && results.data
			})
		}
		else {
			res.json({
				statusCode: 200,
				success: true,
				timestamp: new Date().getTime(),
				message,
				body: results && results.data
			})
		}

	}).catch(excep => {

		req.app.settings.apiLogger.error({
			'message': 'Issue in performing Fetch Role Matrix process',
			'postDataObject': reqOptions,
			error: excep &&
				excep.response,
			body: excep &&
				excep.response &&
				excep.response.data
		})
		return res.json({
			'statusCode': 500,
			'success': false,
			'timestamp': new Date().getTime(),
			'message': 'Issue in performing Fetch Role Matrix process',
			error: excep &&
				excep.response,
			body: excep &&
				excep.response &&
				excep.response.data
		})

	})

}
