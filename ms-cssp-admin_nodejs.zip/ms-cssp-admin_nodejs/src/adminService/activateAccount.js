
const config = require('./../../config/main')
const axios = require('axios');

module.exports.activateAccount = function (req, res) {

    const db = "database" === config.apiMode;

    const activateAccountService = async function (userId, email, consumerAccountId, department, adStatus, req, res) {
        const url = config.devUrlAccountService
        const reqOptions = {
            url: `${url}account/admin/changeAccountStatus`,
            method: 'POST',
            data: {
                adStatus,
                consumerAccountId,
                requestType: "ACTIVATE-ACCOUNT",
                userId,
                department,
                email
            }
        }
        axios(reqOptions).then(results => {
            /* istanbul ignore if */
            const {statusCode, message} = results && results.data

            if (statusCode !== 200) {
                req.app.settings.apiLogger.error({
                    'message': 'Issue in performing Account Activation process',
                    'postDataObject': reqOptions,
                    error,
                    body: results && results.data
                })
                return res.json({
                    'statusCode': statusCode || 500,
                    'success': false,
                    'timestamp': new Date().getTime(),
                    'message': message || 'Issue in performing Account Activation process',
                    error,
                    body: results && results.data
                })
            }
            else {
                res.json({
                    statusCode,
                    success: true,
                    timestamp: new Date().getTime(),
                    message,
                    body: results && results.data
                })
            }

        }).catch(excep => {

            /* istanbul ignore if */
            req.app.settings.apiLogger.error({
                'message': 'Issue in performing Account Activation process',
                'postDataObject': reqOptions,
                error: excep.response,
                body: excep.response.data
            })
            return res.json({
                'statusCode': statusCode || 500,
                'success': false,
                'timestamp': new Date().getTime(),
                'message': 'Issue in performing Account Activation process',
                error: excep.response,
                body: excep.response.data
            })
        })
    }

    function activateAccountDB(req, res) {
        const {
            consumerAccountId,
            userId,
            email,
            department
        } = req.body
        const adStatus = true;
        activateAccountService(userId, email, consumerAccountId, department, adStatus, req, res)

    }

    function activateAccountAD(req, res) {
        const {
            consumerAccountId,
            userId,
            email,
            department
        } = req.body

        axios({
            method: 'GET',
            url: `${config.devUrlAccountService}account/fetchUserId/${email}/${config.env}`,
        }).then(results => {

            if (results.data && results.data.userName) {

                // Get AD Status
                const {
                    userName,
                    statusCode
                } = results.data;

                let adStatus = false;

                if (statusCode === 200) {
                    adFunc.existsCheckUserId(userName).then(exist => {
                        if (!exist) {
                            return res.json({
                                exist,
                                statusCode,
                                success: true,
                                timestamp: new Date(),
                                message: 'User does not exists',
                                consumerAccountId
                            })
                        } else {
                            adStatus = true;
                            activateAccountService(userId, email, consumerAccountId, department, adStatus, req, res)
                        }
                    }).catch(err => {
                        return res.json({
                            err,
                            consumerAccountId
                        })
                    })
                } else {
                    return res.json({
                        'statusCode': statusCode,
                        'success': false,
                        'timestamp': new Date().getTime(),
                        'message': message || 'User does not exist',
                    })
                }
            }
        })
    }

    if (db) {
        activateAccountDB(req, res);
    } else {
        activateAccountAD(req, res);
    }


}


