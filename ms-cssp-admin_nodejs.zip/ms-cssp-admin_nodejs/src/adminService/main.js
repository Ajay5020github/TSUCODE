
const express = require('express')
const router = express.Router()
const {
	body
} = require('express-validator')
const cusValid = require('../helper/custom_validators')
const vMsg = require('../helper/validation_message')

const adminLoginFile = require('./adminLogin')
const searchUserFile = require('./searchUser')
const logoutFile = require('./logout')

// MS related services

const searchUserMSFile = require('./searchUserMS')
const viewUserDetailFile = require('./viewUserDetail')
const getBuildVersion = require('./getBuildVersion')

const resetAccountPasswordFile = require('./resetAccountPassword')
const lockUserAccountFile = require('./lockUserAccount')
const unlockUserAccountFile = require('./unlockUserAccount')
const activateAccountFile = require('./activateAccount')
const deactivateAccountFile = require('./deactivateAccount')
const authenticateAccountFile = require('./authenticateAccount')
const verifyCaseFile = require('./verifyCase')
const telephoneAssistorFile = require('./telephoneAssistor')
const fetchRoleMatrixFile = require('./fetchRoleMatrix')
const refreshTokenFile = require('./refreshToken')
const sanitizeFile = require('../../sanitize')

router.post('/adminLogin',
	cusValid.validate([
		body('userId')
			.not().isEmpty().withMessage(vMsg.required),
		body('password')
			.not().isEmpty().withMessage(vMsg.required)
	]), sanitizeFile.sanitize, adminLoginFile.adminLogin)

router.post('/searchUser', cusValid.authTokenValidate,
	cusValid.validate([
		body('firstName'),
		body('lastName'),
		body('emailAddress'),
		body('consumerUserID'),
		body('phoneNumber'),
		body('zipCode'),
	]), sanitizeFile.sanitize, searchUserFile.searchUser)

// Updated viewUserDetail
router.post('/viewUserDetail', cusValid.authTokenValidate, sanitizeFile.sanitize, viewUserDetailFile.viewUserDetail)

router.post('/unlockAccount', cusValid.authTokenValidate, sanitizeFile.sanitize, unlockUserAccountFile.unlockUserAccount)

router.post('/resetAccountPassword', cusValid.authTokenValidate, sanitizeFile.sanitize, resetAccountPasswordFile.resetAccountPassword)

router.post('/logout', sanitizeFile.sanitize, logoutFile.logout)

router.post('/searchUserMS', cusValid.authTokenValidate, sanitizeFile.sanitize, searchUserMSFile.searchUserMS)

router.post('/lockAccount', cusValid.authTokenValidate, sanitizeFile.sanitize,  lockUserAccountFile.lockUserAccount)

router.post('/authenticateAccount', cusValid.authTokenValidate, sanitizeFile.sanitize,  authenticateAccountFile.authenticateAccount)

router.post('/activateAccount', cusValid.authTokenValidate, sanitizeFile.sanitize,  activateAccountFile.activateAccount)

router.post('/deactivateAccount', cusValid.authTokenValidate, sanitizeFile.sanitize,  deactivateAccountFile.deactivateAccount)

router.post('/fetchRoleMatrix', cusValid.authTokenValidate, sanitizeFile.sanitize, fetchRoleMatrixFile.fetchRoleMatrix)

router.post('/verifyCase', cusValid.authTokenValidate, sanitizeFile.sanitize,  verifyCaseFile.verifyCase)

router.post('/telephoneAssistor', cusValid.authTokenValidate, sanitizeFile.sanitize, telephoneAssistorFile.telephoneAssistor)

router.post('/refreshToken', cusValid.authTokenValidate, sanitizeFile.sanitize, refreshTokenFile.refreshToken)
router.get('/getBuildVersion', getBuildVersion);



module.exports = router
