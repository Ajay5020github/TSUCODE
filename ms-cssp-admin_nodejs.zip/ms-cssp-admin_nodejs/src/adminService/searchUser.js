
const config = require('./../../config/main')
const axios = require('axios');

module.exports.searchUser = function (req, res) {
	const {
		emailAddress,
		consumerUserID,
		firstName,
		lastName,
		phoneNumber,
		zipCode,
		authToken,
		userId
	} = req.body
	const url = config.devUrlAdminPortalService
	const reqOptions = {
		url: `${url}adminportal/searchUser`,
		method: 'POST',
		data: {
			authToken,
			userId,
			emailAddress,
			consumerUserID,
			firstName,
			lastName,
			phoneNumber,
			zipCode
		}
	}

	axios(reqOptions).then(results => {

		const message = results && results.data && results.data.message;
		const statusCode = results && results.data && results.data.statusCode;

		if (statusCode !== 200) {
			req.app.settings.apiLogger.error({
				'message': 'Issue in performing User Search process',
				'postDataObject': reqOptions,
				error,
				body
			})
			return res.json({
				'statusCode': statusCode || 500,
				'success': false,
				'timestamp': new Date().getTime(),
				'message': message || 'Issue in performing User Search process',
				error,
				body
			})
		}
		else {

			res.json({
				statusCode: 200,
				success: true,
				timestamp: new Date().getTime(),
				message,
				body: results && results.data
			})
		}

	}).catch(excep => {

		/* istanbul ignore if */
		req.app.settings.apiLogger.error({
			'message': 'Issue in performing User Search process',
			'postDataObject': reqOptions,
			error: excep &&
				excep.response,
			body: excep &&
				excep.response &&
				excep.response.data
		})
		return res.json({
			'statusCode': statusCode || 500,
			'success': false,
			'timestamp': new Date().getTime(),
			'message': message || 'Issue in performing User Search process',
			error: excep &&
				excep.response,
			body: excep &&
				excep.response &&
				excep.response.data
		})

	})
}
