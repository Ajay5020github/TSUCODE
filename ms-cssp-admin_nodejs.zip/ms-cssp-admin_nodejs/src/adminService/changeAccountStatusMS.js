
const config = require('./../../config/main')
const axios = require('axios');

module.exports.changeAccountStatusMS = function (req, res) {
	const {
		authToken,
		adStatus,
		consumerAccountId,
		requestType,
		userId
	} = req.body

	const url = config.devUrlAdminPortalService
	const reqOptions = {
		url: `${url}account/admin/changeAccountStatus`,
		method: 'POST',
		data: {
			authToken,
			adStatus,
			consumerAccountId,
			requestType,
			userId
		}
	}


	axios(reqOptions).then(results => {

		const { statusCode, message } = results && results.data;

		/* istanbul ignore if */

		if (statusCode !== 200) {
			req.app.settings.apiLogger.error({
				'message': 'Issue in performing Change Account Status process',
				'postDataObject': reqOptions,
				error,
				body: results && results.data
			})
			return res.json({
				'statusCode': statusCode || 500,
				'success': false,
				'timestamp': new Date().getTime(),
				'message': message || 'Issue in performing Change Account Status process',
				error,
				body: results && results.data
			})
		} else {
			res.json({
				statusCode,
				success: true,
				timestamp: new Date().getTime(),
				message,
				body: results && results.data,
				userExits: true
			})
		}

	}).catch(excep => {

		/* istanbul ignore if */
		req.app.settings.apiLogger.error({
			'message': 'Issue in performing Change Account Status process',
			'postDataObject': reqOptions,
			error: excep &&
				excep.response,
			body: excep &&
				excep.response &&
				excep.response.data
		})
		return res.json({
			'statusCode': statusCode || 500,
			'success': false,
			'timestamp': new Date().getTime(),
			'message': message || 'Issue in performing Change Account Status process',
			error: excep &&
				excep.response,
			body: excep &&
				excep.response &&
				excep.response.data
		})

	})

}
