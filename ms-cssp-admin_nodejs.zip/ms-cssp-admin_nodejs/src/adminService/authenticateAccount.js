
const config = require('./../../config/main')
const axios = require('axios');

module.exports.authenticateAccount = function (req, res) {

    const db = "database" === config.apiMode;


    const authenticateAccountService = function (userId, email, consumerAccountId, department, adStatus, dateOfBirth, socialSecurityNumber, req, res) {

        const url = config.devUrlAccountService

        // Sending DOB, Social Security Number

        const reqOptions = {
            url: `${url}account/admin/changeAccountStatus`,
            method: 'POST',
            data: {
                adStatus,
                consumerAccountId,
                requestType: "AUTHENTICATE-ACCOUNT",
                userId,
                department,
                dateOfBirth,
                socialSecurityNumber,
                email
            }
        }


        axios(reqOptions).then(results => {

            const { statusCode, message } = results && results.data;

            /* istanbul ignore if */
            if (statusCode !== 200) {
                req.app.settings.apiLogger.error({
                    'message': 'Issue in performing Account Authentication process',
                    'postDataObject': reqOptions,
                    error,
                    body: results && results.data
                })
                return res.json({
                    'statusCode': statusCode || 500,
                    'success': false,
                    'timestamp': new Date().getTime(),
                    'message': message || 'Issue in performing Account Authentication process',
                    error,
                    body: results && results.data
                })
            } else {
                res.json({
                    statusCode,
                    success: true,
                    timestamp: new Date().getTime(),
                    message,
                    body: results &&
                        results.data
                })
            }
        }).catch(excep => {
            /* istanbul ignore if */
            req.app.settings.apiLogger.error({
                'message': 'Issue in performing Account Authentication process',
                'postDataObject': reqOptions,
                error: excep,
                body: excep &&
                    excep.response &&
                    excep.response.data
            })
            return res.json({
                'statusCode': statusCode || 500,
                'success': false,
                'timestamp': new Date().getTime(),
                'message': message || 'Issue in performing Account Authentication process',
                error: excep &&
                    excep.response,
                body: excep &&
                    excep.response &&
                    excep.response.data
            })
        })

    }

    function authenticateAccountAD(req, res) {
        const {
            consumerAccountId,  // for whom authentication is required
            userId, // logged in userId - admin user id
            email, // consumer email id
            department,
            dateOfBirth,
            socialSecurityNumber
        } = req.body

        axios({
            method: 'GET',
            url: `${config.devUrlAccountService}account/fetchUserId/${email}/${config.env}`,
        }).then(results => {

            if (results.data && results.data.userName) {

                // Get AD Status
                const {
                    userName,
                    statusCode
                } = results.data;

                let adStatus = false;

                if (statusCode === 200) {

                    adFunc.existsCheckUserId(userName).then(exist => {

                        if (!exist) {
                            return res.json({
                                exist,
                                statusCode,
                                success: true,
                                timestamp: new Date(),
                                message: 'User does not exists',
                                consumerAccountId
                            })
                        } else {

                            adStatus = true;
                            authenticateAccountService(userId, email, consumerAccountId, department, adStatus, dateOfBirth, socialSecurityNumber, req, res)
                        }
                    }).catch(err => {
                        return res.json({
                            err,
                            consumerAccountId
                        })
                    })
                } else {
                    return res.json({
                        'statusCode': statusCode,
                        'success': false,
                        'timestamp': new Date().getTime(),
                        'message': message || 'User does not exist',
                    })
                }
            }
        })
    }

    function authenticateAccountDB(req, res) {
        const {
            consumerAccountId,
            userId,
            email,
            department,
            dateOfBirth,
            socialSecurityNumber
        } = req.body
        const adStatus = true;
        authenticateAccountService(userId, email, consumerAccountId, department, adStatus, dateOfBirth, socialSecurityNumber, req, res)
    }

    if (db) {
        authenticateAccountDB(req, res)
    } else {
        authenticateAccountAD(req, res)
    }


}

