
let xml2js = require("xml2js");
const config = require('../../config/main')
const logs = require("../helper/log_function");
const { cacheConnection } = require("../cache/cache");
const buildSecurityObject = require("../helper/buildSecurityObject");
const axios = require('axios')

function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
}

function replaceAll(str, find, replace) {
  return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
}


module.exports.verifyCaseIntegration = async function (req, res, application, merged, consumerAccountId, t_m_ID) {
  let args = merged;

  let newobj = { applicationRequest: args };

  if (args) {
    let builder = new xml2js.Builder();
    const prefix = 'ns'
    const prefixedObj = JSON.parse(
      JSON.stringify(newobj)
        .replace(/"([^"]+)":/g, `"${prefix}:$1":`))
    let xml = builder.buildObject(prefixedObj);

    let serviceTimeStamp = new Date();
    let receiver = "";
    let serviceDescription = "";

    if (application === 'MDHSVerifyCase') {
      receiver = 'MDHS';
      serviceDescription = 'Mississippi Department of Human Services (MDHS)';
    }

    xml = xml.replace("<ns:applicationRequest>", `
            <ver:VerifyCaseRequest>
              <ver:TXNHeader>
                <ns:ServiceID>`+ application + `</ns:ServiceID>
                <ns:ServiceDescription>`+ serviceDescription + `</ns:ServiceDescription>
                <ns:ServiceTimeStamp>`+ serviceTimeStamp.toISOString() + `</ns:ServiceTimeStamp>
                <ns:Sender>CWP</ns:Sender>
                <ns:Receiver>`+ receiver + `</ns:Receiver>
                <ns:IPAddress>`+ req.socket.remoteAddress + `</ns:IPAddress>
                <ns:TransactionID>`+ t_m_ID + `</ns:TransactionID>
              </ver:TXNHeader>`);

    xml = xml.replace("ns:applicationRequest", "ver:VerifyCaseRequest");
    xml = replaceAll(xml, "ns:applicationRequest", "ver:VerifyCaseRequest");
    xml = replaceAll(xml, "ns:ApplicationRequest", "ver:VerifyCaseRequest");
    xml = replaceAll(xml, "ns:AccountInfo", "ver:AccountInfo");
    xml = replaceAll(xml, "ns:KeyElementsInfo", "ver:KeyElementsInfo");
    xml = replaceAll(xml, "ver:KeyElementsInfoVer", "ns:KeyElementsInfo");
    xml = replaceAll(xml, "ns:VerifyCaseInfo", "ver:VerifyCaseInfo");
    xml = replaceAll(xml, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "");

    let security = await cacheConnection.get("securityXMl");
    if (!security) {
      security = await buildSecurityObject();
    }

    let body = "";
    let header = "";

    // build header
    let action = "<a:Action>" + application + "</a:Action>";
    let message = "<a:MessageID>" + t_m_ID + "</a:MessageID>";
    header = " <soap:Header>" + action + message + security + " </soap:Header>"

    //build body
    body = "<soap:Body>" + xml + "</soap:Body>";

    let final = `<?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
        xmlns:ver="http://hhstp.ms.gov/hhstp/VerifyCase"
        xmlns:ns="http://hhstp.ms.gov/hhstp/hhstp-core/1.0"
        xmlns:a="http://www.w3.org/2005/08/addressing"
        xmlns:o="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
        ` + header + body + `</soap:Envelope>`;

    final = replaceAll(final, "<Security", "<o:Security");
    final = replaceAll(final, "</Security", "</o:Security");

    let options = {
      method: 'POST',
      url: `${config.apimURL}${config.internalURL}`,
      headers: {
        'Content-Type': 'text/plain',
        'SOAPAction': "http://tempuri.org/ISampleService/TestMethod"
      },
      data: final
    };

    try {
      logs.transactionLog(
        req,
        res,
        null,
        "BEFORE INVOKING ESB",
        "VERIFY_CASE",
        "I",
        null,
        null,
        t_m_ID,
        final,
        null,
        null,
        null,
        null,
        consumerAccountId,
        application
      );
    } catch (error) {
    }

    axios(options)
      .then((response) => {

        if (response && response.headers && response.headers.oxistatus == 'SUCCESS') {

          try {
            logs.transactionLog(
              req,
              res,
              response && response.headers && response.headers.sperrordescription,
              "POST ESB INVOCATION",
              "VERIFY_CASE",
              "S",
              response && response.data,
              null,
              t_m_ID,
              null,
              response && response.headers && response.headers.oxierrorcode,
              response && response.headers && response.headers.oxiinternaltransactionid,
              response && response.headers && response.headers.sperrorcode || 'G500',
              response && response.headers && response.headers.oxierrordescription,
              consumerAccountId,
              application
            );
          } catch (error) {
          }

        } else {


          try {
            logs.transactionLog(
              req,
              res,
              response && response.headers && response.headers.sperrordescription,
              "POST ESB INVOCATION",
              "VERIFY_CASE",
              "F",
              response && response.data,
              null,
              t_m_ID,
              null,
              response && response.headers && response.headers.oxierrorcode,
              response && response.headers && response.headers.oxiinternaltransactionid,
              response && response.headers && response.headers.sperrorcode || 'G500',
              response && response.headers && response.headers.oxierrordescription,
              consumerAccountId,
              application
            );
          } catch (error) {
          }

        }
        res.send({
          "ResponseCode": "200",
          "ResponseDescription": "Request sent successfully",
          "ResponseTimeStamp": new Date()
        })

      })
      .catch((err) => {

      })

  } else {
    res.send("Error in processing");
  }
}

