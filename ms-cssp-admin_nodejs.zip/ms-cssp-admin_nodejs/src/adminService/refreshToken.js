/**
 *  @Author - Sourav Thakur
 *  @CreatedDate : 2022-02-16:15:00:00
 *  @DESCRIPTION :  CREATING A NEW AUTHTOKEN IN EXCHANGE OF A VALID TOKEN
 */
// "use strict"


const jwt = require("jsonwebtoken");
const config = require("./../../config/main");
const keyVault = require("../helper/keyVault_function");
// const mycache = require("../cache/cache");
const { cacheConnection } = require('../cache/cache')
var { get, set } = require('../cache/cacheMethods');
const { v4: uuidv4 } = require('uuid');
const logs = require("../helper/log_function");
const constants = require("./../../config/constants");

module.exports.refreshToken = async function (req, res) {
  const email = req.body && req.body.email;
  const id = req.body && req.body.id;
  const oldauthToken = req.headers && req.headers.authtoken;

  const department = req.body && req.body.department;
  const userId = req.body && req.body.userId;
  const authToken = req.body && req.body.authToken;

  try {
    if (oldauthToken) {

      const userLoginData1 = cacheConnection && await cacheConnection.get(`${config.env}${userId}${id}`);
      const userLoginData = await JSON.parse(userLoginData1)

      keyVault
        .getValue()
        .then((jwtSecret) =>
          jwt.verify(oldauthToken, jwtSecret, function (err, decoded) {


            if (err) {
              req.app.settings.apiLogger.error({
                message: "INVALID JWT TOKEN"
              });
              return res.json({
                statusCode: 401,
                success: false,
                message: "INVALID TOKEN"
              });
            } else {

              if (department === "internal") {

                if (
                  userId === decoded.userId &&
                  oldauthToken === userLoginData.authToken
                ) {
                  keyVault.getValue().then(async (jwtSecret) => {
                    const authToken = jwt.sign(
                      {
                        userId,
                      },
                      jwtSecret,
                      config.jwtOptions
                    );
                    const cacheUserData = {
                      userId: userId,
                      authToken: authToken,
                    };

                    // deleting old id in cache
                    // cacheConnection && await cacheConnection.del(`${config.env}${email}${id}`);
                    let newId = await uuidv4()
                    cacheConnection && cacheConnection.set(`${config.env}${userId}${newId}`, JSON.stringify(cacheUserData), {"EX": 2  * 60 * 60})

                    await res.json({
                      authToken,
                      message: "AuthToken validated succesfully",
                      statusCode: 200,
                      success: true,
                      id: newId
                    });
                  });
                } else {

                  res.json({
                    statusCode: 401,
                    success: false,
                    message: "INVALID TOKEN",
                  });
                }

              }
              else if (department === "MDHS" || department === "DOM") {

                if (
                  email === decoded.email &&
                  oldauthToken === authToken
                ) {

                  keyVault.getValue().then(async (jwtSecret) => {
                    const authToken = jwt.sign(
                      {
                        email,
                      },
                      jwtSecret,
                      config.jwtOptions
                    );

                    const cacheUserData = {
                      email: email,
                      authToken: authToken,
                    };

                    // deleting old id in cache
                    // cacheConnection && await cacheConnection.del(email);

                    let newId = await uuidv4()
                    cacheConnection && cacheConnection.set(`${config.env}${email}${newId}`, JSON.stringify(cacheUserData), {"EX": 2  * 60 * 60})

                    await res.json({
                      authToken,
                      message: "AuthToken validated succesfully",
                      statusCode: 200,
                      success: true,
                      id: newId
                    });
                  });
                } else {

                  res.json({
                    statusCode: 401,
                    success: false,
                    message: "INVALID TOKEN",
                  });
                }

              }

            }
          })
        )
        .catch(
          /* istanbul ignore next */(error) => {

            req.app.settings.apiLogger.error({
              message: "AZURE KEY VAULT ERROR"
            });
            res.status(500).json({
              statusCode: 500,
              success: false,
              message: "AZURE KEY VAULT ERROR"
            });
          }
        );
    } else {

      logs.transactionLog(
        req,
        res,
        "",
        "",
        "Logging error in refreshToken.js",
        "Refresh Token",
        constants.service.APP,
        constants.type.INT,
        "",
        req.body
      );
      return res.json({
        statusCode: 401,
        success: false,
        timestamp: new Date().getTime(),
        message: "Invalid Parameters",
      });
    }
  } catch (err) {


    logs.transactionLog(
      req,
      res,
      "",
      err,
      "Logging error in refreshToken.js",
      "Refresh Token",
      constants.service.APP,
      constants.type.INT,
      "",
      req.body
    );
    return res.send({
      "message": "Logging error in DB for refreshToken.js"
    });
  }
};
