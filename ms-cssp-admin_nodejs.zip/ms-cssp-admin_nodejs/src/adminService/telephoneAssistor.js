
const config = require('./../../config/main')
const axios = require('axios');

module.exports.telephoneAssistor = function (req, res) {

	const db = "database" === config.apiMode;


	const telephoneAssistorService = function (userId, email, consumerAccountId, department, adStatus, assistorInd, req, res) {

		const url = config.devUrlAccountService
		const reqOptions = {
			url: `${url}account/admin/changeAccountStatus`,
			method: 'POST',
			data: {
				adStatus,
				consumerAccountId,
				requestType: "TELEPHONE-ASSISTOR",
				userId,
				department,
				assistorInd,
				email
			}
		}


		axios(reqOptions).then(results => {

			const { statusCode, message } = results && results.data

			res.json({
				statusCode,
				success: true,
				timestamp: new Date().getTime(),
				message,
				body: results && results.data
			})


		}).catch(excep => {

			/* istanbul ignore if */
			req.app.settings.apiLogger.error({
				'message': 'Issue in performing role assignment in Telephone Asssitor process',
				'postDataObject': reqOptions,
				error: excep &&
				excep.response,
				body: excep &&
				excep.response &&
				excep.response.data
			})
			return res.json({
				'statusCode': statusCode || 500,
				'success': false,
				'timestamp': new Date().getTime(),
				'message': message || 'Issue in performing role assignment in Telephone Asssitor process',
				error: excep &&
				excep.response,
				body: excep &&
				excep.response &&
				excep.response.data
			})

		})
	}

	function telephoneAssistorDB(req, res) {
		const {
			consumerAccountId,
			userId,
			email,
			department,
			assistorInd
		} = req.body
		const adStatus = true;
		telephoneAssistorService(userId, email, consumerAccountId, department, adStatus, assistorInd, req, res)
	}

	function telephoneAssistorAD(req, res) {

		const {
			consumerAccountId,
			userId,
			email,
			department,
			assistorInd
		} = req.body

		axios({
			method: 'GET',
			url: `${config.devUrlAccountService}account/fetchUserId/${email}/${config.env}`,
		}).then(results => {

			if (results.data && results.data.userName) {

				// Get AD Status
				const {
					userName,
					statusCode
				} = results.data;

				let adStatus = false;

				if (statusCode === 200) {
					adFunc.existsCheckUserId(userName).then(exist => {
						if (!exist) {
							return res.json({
								exist,
								statusCode,
								success: true,
								timestamp: new Date(),
								message: 'User does not exists',
								consumerAccountId
							})
						} else {
							adStatus = true;
							telephoneAssistorService(userId, email, consumerAccountId, department, adStatus, assistorInd, req, res)
						}
					}).catch(err => {
						return res.json({
							err,
							consumerAccountId
						})
					})
				}
				else {

					return res.json({
						'statusCode': statusCode,
						'success': false,
						'timestamp': new Date().getTime(),
						'message': message || 'User does not exist',
					})
				}
			}
		})
	}

	if(db){
		telephoneAssistorDB(req,res)
	}else{
		telephoneAssistorAD(req,res)
	}

}

