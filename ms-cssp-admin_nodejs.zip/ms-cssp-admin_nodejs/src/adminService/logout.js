
const config = require('./../../config/main')
const axios = require('axios');

module.exports.logout = function (req, res) {
	const {
		authToken,
		userId,
		department
	} = req.body
	const url = config.devUrlAdminPortalService
	const postOptions = {
		url: `${url}adminportal/logout`,
		method: 'POST',
		data: {
			authToken,
			authenticationStatus: true,
			userId,
			department
		}
	}
	if (department === "internal") {


		axios(postOptions).then(results => {


				const message = results && results.data && results.data.message;
				const statusCode = results && results.data && results.data.statusCode;

				/* istanbul ignore if */
				res.redirect(config.destroySessionUrl);


		}).catch(excep => {

			/* istanbul ignore if */
			req.app.settings.apiLogger.error({
				'message': 'Issue in Logout process',
				'postDataObject': postOptions,
				error: excep &&
				excep.response,
				body: excep &&
				excep.response &&
				excep.response.data
			});

			res.redirect(config.destroySessionUrl);

		})
	}
	else {
		res.redirect(config.destroySessionUrl);
	}

}
