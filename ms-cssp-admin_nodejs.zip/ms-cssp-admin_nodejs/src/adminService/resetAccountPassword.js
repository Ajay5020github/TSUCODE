
const config = require('./../../config/main')
const generator = require('generate-password');
const fetch = require('node-fetch')

module.exports.resetAccountPassword = function (req, res) {

	const db = "database" === config.apiMode;

	const resetPasswordService = async function (userId, consumerAccountId, department, adStatus, req, res, generatedPassword, email) {
		const url = config.devUrlAccountService;
		const reqOptions = {
			"adStatus": adStatus,
			"consumerAccountId": consumerAccountId,
			"requestType": "RESET-PASSWORD",
			"userId": userId,
			"department": department,
			"email": email,
			"password": generatedPassword
		}

		try {

			var response = await fetch(`${url}account/admin/changeAccountStatus`,
				{
					method: 'post', body: JSON.stringify(reqOptions),
					headers: { 'Content-Type': 'application/json' }
				})

			let body = await response.json();
			let message = body && body.message;

			res.json({
				statusCode: 200,
				success: true,
				timestamp: new Date().getTime(),
				message,
				body,
				generatedPassword
			})


		} catch (error) {

			req.app.settings.apiLogger.error({
				'message': 'Issue in performing Reset Account process',
				'postDataObject': reqOptions,
				error
			})
			return res.json({
				'statusCode': 500,
				'success': false,
				'timestamp': new Date().getTime(),
				'message': 'Issue in performing Reset Account process',
				error
			})

		}
	}

	function resetAccountPasswordDB(req, res) {
		const {
			consumerAccountId,
			userId,
			email,
			department
		} = req.body
		const generatedPasswordString = generator.generate({
			length: 10,
			numbers: true, strict: false
		});
		const generatedPassword = `${generatedPasswordString}@`;
		const adStatus = true;
		resetPasswordService(userId, consumerAccountId, department, adStatus, req, res, generatedPassword, email);

	}

	if (db) {
		resetAccountPasswordDB(req, res)
	}

}

