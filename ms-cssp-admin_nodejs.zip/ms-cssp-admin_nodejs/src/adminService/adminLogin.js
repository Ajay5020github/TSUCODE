
const jwt = require('jsonwebtoken')
const config = require('./../../config/main')
const keyVault = require('../helper/keyVault_function')
const { cacheConnection } = require('../../src/cache/cache')
const { v4: uuidv4 } = require('uuid');
const axios = require('axios');
const constants = require('./../../config/constants')

const DANGEROUS_OPERATORS = new Set([
	'$where', '$gt', '$gte', '$lt', '$lte', '$ne', '$in', '$nin',
	'$or', '$and', '$not', '$nor', '$exists', '$type', '$mod',
	'$regex', '$text', '$search', '$elemMatch', '$size', '$all',
	'$slice', '$expr', '$jsonSchema', '$function', '$accumulator'
]);

const GLOBALLY_BLOCKED_FIELDS_NORMALIZED = new Set([
	'isadmin',
	'issso',
	'role',
	'passwordhash',
	'createdat',
	'updatedat',
	'deletedat',
]);

const GLOBALLY_BLOCKED_EXACT = new Set(['__v', '_id']);

module.exports.adminLogin = async function (req, res, next) {
	const {
		userId,
		password
	} = req.body;


	let id = uuidv4();

	try {

		let validPayload = await verifyPayload(req, res, next);
		let resultFoundBlockedKeys = await checkBlockedFields(req, res, next);

		if (validPayload === false || resultFoundBlockedKeys === false) {
			return res.status(400).send({
				message: 'Please provide Proper Inputs',
				ResponseCode: "400",
				ResponseDescription: "Bad Request",
				ResponseTimeStamp: new Date()
			});
		}

		keyVault.getValue().then(async jwtSecret => {
			const authToken = jwt.sign({
				userId
			}, jwtSecret, config.jwtOptions)

			try {
				const cacheUserData = {
					userId: userId,
					authToken: authToken
				}
				cacheConnection && cacheConnection.set(`${config.env}${userId}${id}`, JSON.stringify
					(cacheUserData), { "EX": 2 * 60 * 60 })

			} catch (err) {
				next()

			}

			const reqOptions = {
				url: `${config.devUrlAdminPortalService}adminportal/login`,
				method: 'POST',
				data: {
					authToken,
					authenticationStatus: false,
					userId,
					password
				}
			}

			axios(reqOptions).then(results => {

				const message = results && results.data && results.data.message;
				const data = results && results.data && results.data.statusCode;
				const statusCode = results && results.data && results.data.statusCode;

				if (statusCode !== 200) {
					req.app.settings.apiLogger.error({
						'message': 'Issue in performing Login process',
						'postDataObject': postOptions,
						error: "",
						body: results && results.data
					})
					const spring_response_code = [150, 401, 419, 460, 4044]
					/* istanbul ignore else */
					if (spring_response_code.includes(statusCode)) {
						return res.send({
							statusCode,
							'success': false,
							'timestamp': new Date().getTime(),
							message,
							// authToken,
							data: results && results.data
						})
					} else {

						return res.send({
							'statusCode': statusCode || 500,
							'success': false,
							'timestamp': new Date().getTime(),
							'message': message || 'Issue in performing Login process',
							error,
							// authToken,
							body: results && results.data
						})
					}
				} else {

					res.json({
						statusCode,
						'success': true,
						'timestamp': new Date().getTime(),
						message,
						authToken,
						body: results && results.data,
						loginType: 'internal',
						id
					})
				}

			}).catch(excep => {

				return res.send({
					statusCode: 401,
					'success': false,
					'timestamp': new Date().getTime(),
					message: "401 UNAUTHORIZED",
					data: 401
				})

			})

		}).catch(error => {
			/* istanbul ignore next */
			res.status(500).json({
				'statusCode': 500,
				'success': false,
				'message': 'AZURE KEY VAULT ERROR',
				'error': error.response
			})
		})

	} catch (excep) {

		req && req.app && req.app.settings &&
			req.app.settings.apiLogger && req.app.settings.apiLogger.error({
				'message': 'Not authorized',
				'error': excep
			})
		return res.json({
			'statusCode': 500,
			'success': false,
			'timestamp': new Date().getTime(),
			'message': 'Logging Exception in adminLogin',
			'error': excep
		})

	}
}

async function verifyPayload(req, res, next) {

	try {
		let filteredPayload = JSON.parse(JSON.stringify(req.body));

		// SAST MongoDB Check
		let resultMongoDBKeys = await validateForMongoDBJSONKeys(filteredPayload);
		return resultMongoDBKeys;

	} catch (error) {
		req.app.settings.apiLogger.error({
			message: constants.errorLogMsg.errInputPayload
		});
		return false;
	}

}


async function validateForMongoDBJSONKeys(body, res, next) {
	let aborted = false;
	const dangerousKeys = [];

	loopThroughObjRecurse(body, (key, value) => {
		if (aborted) return;

		if (key.startsWith('$')) {
			dangerousKeys.push(key);
			aborted = true;
			return;
		}

		if (typeof value === 'string' && DANGEROUS_OPERATORS.has(value.trim())) {
			dangerousKeys.push(`value:${value}`);
			aborted = true;
			return;
		}

		if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
			dangerousKeys.push(key);
			aborted = true;
			return;
		}
	});

	if (dangerousKeys.length > 0) {
		return false;
	}

	return true;
}

function checkBlockedFields(req, res, next) {

	let parsedJSON = JSON.parse(JSON.stringify(req.body));

	const dangerousKeys = [];

	loopThroughObjRecurse(parsedJSON, function (prop, jsonValue) {
		// Exact match for fields with underscores that matter
		if (GLOBALLY_BLOCKED_EXACT.has(prop)) {
			dangerousKeys.push(`blockedkey:${prop}`);
		}

		// Normalized match for everything else
		const normalizedProp = prop.toLowerCase().replace(/[_\-]/g, '');
		if (GLOBALLY_BLOCKED_FIELDS_NORMALIZED.has(normalizedProp)) {
			dangerousKeys.push(`normalizedProp:${normalizedProp}`);
		}
	});

	if (dangerousKeys.length > 0) {
		return false;
	}

	return true;
}

function loopThroughObjRecurse(obj, propExec) {
	for (var k in obj) {
		if (obj.hasOwnProperty(k)) {
			if (typeof obj[k] === 'object' && obj[k] !== null) {
				propExec(k, obj[k]);
				loopThroughObjRecurse(obj[k], propExec);
			} else {
				propExec(k, obj[k]);
			}
		}
	}
}
