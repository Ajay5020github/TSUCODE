
const axios = require('axios')
const logs = require("../helper/log_function");
const constants = require("./../../config/constants");
const config = require('../../config/main')
let getAccountMapFile = require('../mappers/getAccountMap')
const uuid = require('uuid');
const verifyCaseGainwellFile = require('./verifyCaseGainwell')

// Load the full build.
let _ = require('lodash');

function escapeRegExp(string) {
	return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
}

function replaceAll(str, find, replace) {
	return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
}

var dateConvert = (date) => {
	var d = new Date(date);
	var datestring = d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
	return datestring
}

module.exports.verifyCase = async function (req, res) {

	const payload = req.body.payload;
	const application = req.body.application;
	const consumerAccountId = req.body.payload.consumerAccountId && req.body.payload.consumerAccountId;
	let t_m_ID = "";

	let years = new Date().getFullYear().toString();
	let year = years.slice(2, 4);
	let months = new Date().getMonth() + 1;
	let month = months < 10 ? "0" + months.toString() : months;
	let days = new Date().getDate();
	let day = days < 10 ? "0" + days.toString() : days;
	let dates = year + month + day;

	let s_id = "";
	let merged = []

	if (application === 'MDHSVerifyCase') {
		s_id = 'M12';
	}

	t_m_ID = dates + '-' + config.env + '-CSSP-' + s_id + "-" + uuid.v4();

	try {

		// const url = "https://dev.cssp.portal.conduent.com/"
		const url = config.devUrlAccountService
		const reqOptions = {
			url: `${url}account/getAccountInfo`,
			method: 'POST',
			data: {
				"acctHolderName": {
					"firstName": "",
					"lastName": "",
					"maidenName": "",
					"middleName": "",
					"suffixName": ""
				},
				"CWPAcctID": consumerAccountId,
				"cwpacctUserName": "",
				"dob": "",
				"keyInfo": [
					{
						"keyIdentifier": "",
						"keyType": ""
					}
				],
				"programIdentificationInfo": [
					{
						"programCategoryDesc": "",
						"programIdentificationCode": ""
					}
				],
				"ssn": ""
			}
		}

		axios(reqOptions).then(response => {

			let accountInfo = response && response.data && response.data.AccountInfo && response.data.AccountInfo.length ? response.data.AccountInfo[0].AccountInfo : [];
			let AccountInfoReq = getAccountMapFile.getAccountMap(accountInfo, application);

			let ProgramInfo = [];
			let parent = [];
			let keyInfo = {};
			let KeyElementsInfo = [];
			let keyType = "";

			// Forming the Request Object
			if (payload) {

				if (payload && payload.programsRequested) {
					if (payload.programsRequested.length > 0) {
						payload.programsRequested.forEach(program => {
							let programIdentificationInfo = {
								"ProgramIdentificationCode": program,
								"ProgramCategoryDesc": program
							}
							ProgramInfo.push(programIdentificationInfo);
						});
					}
				}

				keyInfo = {
					"KeyType": "CWPAcctID",
					"KeyIdentifier": consumerAccountId
				}

				KeyElementsInfo.push(keyInfo);

				let adminPersonName = {};

				adminPersonName = {
					"FirstName": payload.AdminPersonFirstName,
					"LastName": payload.AdminPersonLastName
				}

				let VerifyCase = {}

				VerifyCase = {
					"VerifyCaseActionType": payload.actionType && payload.actionType,
					"ProgramIdentificationInfo": ProgramInfo,
					"PersonName": adminPersonName
				}

				parent.push(AccountInfoReq);
				parent.push({ "KeyElementsInfo": KeyElementsInfo });
				parent.push({ "VerifyCaseInfo": new Array(VerifyCase) })
				merged = _.merge(...parent);
			}

			const reqOption = { merged }

			try {
				logs.transactionLog(
					req,
					res,
					null,
					"BEFORE INVOKING INTGNODE",
					"VERIFY_CASE",
					"I",
					null,
					payload,
					t_m_ID,
					null,
					null,
					null,
					null,
					null,
					consumerAccountId,
					application
				);
			} catch (error) {
			}

			verifyCaseGainwellFile.verifyCaseIntegration(req, res, application, merged, consumerAccountId, t_m_ID)

		}).catch(excep => {
			req.app.settings.apiLogger.error({
				'message': 'Logging error in MDHSVerifyCase - getAccountInfo',
				error: excep
			})
			res.send({ error: excep })
		})
	}

	catch (exception) {
		req.app.settings.apiLogger.error({
			'message': 'Logging error in MDHSVerifyCase',
			error: exception
		})
		res.send({ error: exception })
	}
}
