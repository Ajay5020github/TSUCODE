/**
 *  @Author - Vijay Sharma
 *  @AuthorEmail : vijaykumar.sharma@conduent.com
 *  @CreatedDate : 2019-06-14:02:38:00
 *  @ModifiedDate : 2019-06-14:02:38:00
 */
const process = require("process");
require("dotenv").config();
let env = process.env.ENVIRONMENT; //DEV|QA|UAT
// env = process.env.SPRINGBOOT_API ? "local" : env;

let clientUrl = process.env.clientUrl; // "https://test.cssp.portal.conduent.com/admin"

let devUrlAdminPortalService,
  devUrlNodebackendService,
  devUrlLanguageService,
  ad;
devUrlAdminPortalService = process.env.devUrlAdminPortalService;
devUrlNodebackendService = process.env.devUrlNodebackendService;
devUrlLanguageService = process.env.devUrlLanguageService;
devUrlAccountService = process.env.devUrlAccountService;  /// to be informed to Vinoth
devUrlAuditService = process.env.devUrlAuditService; /// to be checked with Vinoth/Mukesh
apimURL = process.env.apimURL;
azureClientId =  process.env.reports_clientId;
azureClientSecret = process.env.reports_clientSecret;
azureTenantId = process.env.reports_tenantId;
vaultName = process.env.keyVaultName;
certificateName = process.env.certificateName;
ad = {
  url: process.env.url,
  user: process.env.user,
  pass: process.env.pass,
  baseDN: process.env.baseDN,
  baseDNTemp: "OU=Users,OU=MSCSSP-DEV,DC=mscsspdev,DC=com",
  location: process.env.location
};

const config = {
  env,
  clientUrl,
  devUrlAdminPortalService,
  devUrlNodebackendService,
  devUrlLanguageService,
  devUrlAccountService,
  devUrlAuditService,
  apimURL,
  azureClientId,
  azureClientSecret,
  azureTenantId,
  vaultName,
  certificateName,
  ad,
  localTestUrl: "", // http://localhost:3000/nodebackend/
  jwtOptions: { expiresIn: parseInt(process.env.expiresIn, 10) },
  destroySessionUrl: process.env.destroySessionUrl,
  port: 3000,
  azureKeyVault: {
    clientId: process.env.clientId,
    clientSecret: process.env.clientSecret,
    directoryId: process.env.directoryId,
    secretName: process.env.secretName,
    keyVaultName: process.env.keyVaultName,
    certificateName: process.env.certificateName
  },
  docUpload: {
    maxSize: parseInt(process.env.docUploadMaxSize, 10), //in MB
    maxCount: parseInt(process.env.docUploadmaxCount, 10),
    allowExt: [
      "afp",
      "bmp",
      "doc",
      "docx",
      "gif",
      "jpg",
      "jpeg",
      "pdf",
      "png",
      "tif",
      "tiff",
      "txt",
      "xls",
      "xlsx",
    ],
    tempDir: "uploads/",
  },
  // version: {
  //   prod: 0,
  //   uat: 1.04,
  //   sit: 1.04,
  //   dev: 1.04,
  // },
  version: "m.d.bid",
  tempPassword: process.env.tempPassword,
  localhost: process.env.localhost,
  httpsBslocalhost: process.env.httpsBslocalhost,
  httpBslocalhost: process.env.httpBslocalhost,


  identityMetadataDOM: process.env.identityMetadataDOM,

  identityMetadataMDHS: process.env.identityMetadataMDHS,

  clientID_dom: process.env.clientID_dom,

  clientID_mdhs: process.env.clientID_mdhs,

  responseType: process.env.responseType,

  response_mode: process.env.response_mode,

  redirect_uri: process.env.redirect_uri,

  state: process.env.state,

  scope: process.env.scope,

  client_app_name: process.env.client_app_name, // "CSSP-TEST",

  redirect_react: process.env.redirect_react,

  microsoft_graph_url: process.env.microsoft_graph_url,
  mailEncryptionSecret: process.env.mailEncryptionSecret,
  cacheHostName: process.env.cacheHostName,
  cachePassword: process.env.cachePassword,
  cachePort: process.env.cachePort,
  devUrlAdminbackendService: process.env.devUrlAdminbackendService,
  apiMode : process.env.loginApiMode,
  language: process.env.language,
  internalURL: process.env.internalURL,
  corsOptions: [process.env.clientDomainUrl, process.env.clientDomainUrl_wp, process.env.clientDomainUrlRedirect, process.env.clientDomainUrl_wp_Redirect],
};
module.exports = config;
