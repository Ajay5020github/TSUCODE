const { URL } = require('url');
const config = require('./main');

const origins = config.corsOptions;

const ALLOWED_REDIRECT_ORIGINS = String(config.corsOptions || '')
  .split(',')
  .map(o => (o || '').trim().toLowerCase())
  .filter(Boolean);

function validateRedirectUrl(fullUrl) {
  let parsed;
  try {
    parsed = new URL(fullUrl);
  } catch {
    // throw new Error(`Invalid redirect URL: ${fullUrl}`);
  }

  const origin = parsed.origin.toLowerCase();

  if (!ALLOWED_REDIRECT_ORIGINS.includes(origin)) {
    throw new Error(
      `Blocked redirect to untrusted origin: "${origin}". ` +
      `Allowed: ${ALLOWED_REDIRECT_ORIGINS.join(', ')}`
    );
  }

  return fullUrl;
}


function sanitiseRedirectParams(params) {
  if (!params || typeof params !== 'string') return '';

  const urlPattern = /^(https?:)?\/\//i;

  return params
    .split('&')
    .filter(pair => {
      const value = decodeURIComponent(pair.split('=')[1] || '');
      return !urlPattern.test(value);
    })
    .join('&');
}

module.exports = { validateRedirectUrl, sanitiseRedirectParams };
