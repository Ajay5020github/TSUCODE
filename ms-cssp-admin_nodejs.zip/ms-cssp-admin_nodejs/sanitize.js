const config = require('./config/main')

const sanitize = async (req, res, next) => {

	try {

		res.header('Cache-Control', 'no-cache, no-store, must-revalidate');
		res.header('Pragma', 'no-cache');

		/* Check for allowable Headers, Origin, Referrrer check */
		let allowedHeaders = config.corsOptions;
		let foundHeader = allowedHeaders.findIndex(o => o === req.headers.host);

		let isOriginAllowed = true;
		let isRefererAllowed = true;
		let isReferrerInValid = false;

		const requestOrigin = req.headers.origin;
		const requestReferer = req.headers.referer;

		if (requestOrigin !== undefined) {

			isOriginAllowed = allowedHeaders.some(allowed => requestOrigin && requestOrigin.includes(allowed));

			if (requestReferer !== undefined) {

				isRefererAllowed = allowedHeaders.some(allowed => requestReferer && requestReferer.includes(allowed));

				const referrerInvalidChars = ["*"];
				isReferrerInValid = referrerInvalidChars.some(invalidChar => requestReferer && requestReferer.includes(invalidChar));
			}
		}

		if (foundHeader === -1 || !isOriginAllowed || !isRefererAllowed || isReferrerInValid) {

			return res.status(400).send({
				error: "Bad Request",
				ResponseCode: "403",
				ResponseDescription: "Bad Request",
				ReqHost: req.headers.host,
				allowedHeaders: allowedHeaders,
				ResponseTimeStamp: new Date()
			});
		}
		/* Check for allowable Headers, Origin, Referrrer check */


		let sqlInjectionKeys = ["benchmark", "SLEEP", "waitfor", "INJECTX", "DELAY", "WAIT", "WAIT FOR DELAY", "RANDOMBLOB", "pg_SLEEP", "ORDER BY SLEEP", "--", "#", "eval", "ALTER", "CREATE", "DELETE", "DROP", "EXEC", "INSERT", "MERGE", "SELECT", "UPDATE", "UNION", "'OR", "AND", "'"];


		let foundInHost = undefined;
		let foundInHostKeyword = undefined;
		let foundInUserAgent = undefined;
		let foundInUserAgentKeyword = undefined;
		let foundInRequestURL = undefined;
		let foundInRequestURLKeyword = undefined;

		// SQL Injection
		try {

			const requestedUrl = req.protocol + '://' + req.get('host') + req.originalUrl;

			for (let index = 0; index <= sqlInjectionKeys.length - 1; index++) {
				if (req.headers.host && new RegExp(sqlInjectionKeys[index].toLowerCase()).test(req.headers.host.toString().toLowerCase())) {
					foundInHost = true;
					foundInHostKeyword = sqlInjectionKeys[index];
				}
				if (req.headers['user-agent'] && new RegExp(sqlInjectionKeys[index].toLowerCase()).test(req.headers['user-agent'].toString().toLowerCase())) {
					foundInUserAgent = true;
					foundInUserAgentKeyword = sqlInjectionKeys[index];
				}
				if (requestedUrl && new RegExp(sqlInjectionKeys[index].toLowerCase()).test(requestedUrl.toString().toLowerCase())) {
					foundInRequestURL = true;
					foundInRequestURLKeyword = sqlInjectionKeys[index];
				}
			}
		}
		catch (error) {
			// log error
		}

		if (foundInHost === true || foundInUserAgent === true || foundInRequestURL === true) {
			return res.status(400).send({
				error: "Bad Request",
				ResponseCode: "400",
				ResponseDescription: "Bad Request",
				ResponseTimeStamp: new Date(),
				foundInUserAgent,
				foundInHost,
				foundInRequestURL
			});
		}
		else {
			next();
		}

	}
	catch (err) {
		req.app.settings.apiLogger.error({
			'message': constants.errorLogMsg.errSanitize,
			err
		})
	}
}

module.exports = { sanitize };

