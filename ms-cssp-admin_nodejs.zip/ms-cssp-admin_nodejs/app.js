//This is starting point of invocation
const express = require('express')
const bodyParser = require('body-parser');
const cors = require('cors')
const morgan = require('morgan')
const helmet = require("helmet");
const config = require('./config/main')
const fs = require('fs-extra')
const indexRouter = require('./src/routes')
const app = express()
const path = require('path')
const axios = require('axios')
// const NodeCache = require( "node-cache" );
// const myCache = new NodeCache();
const { cacheConnection } = require('./src/cache/cache')
const { v4: uuidv4 } = require('uuid');
/* Comment if any issue comes after deployment */
/* Start */
const crypto = require('crypto');

// AFTER (safe)
const { validateRedirectUrl, sanitiseRedirectParams } = require('./config/security');

app.use(helmet())

var CryptoJS = require("crypto-js");

//impliment log4js logger
const log4js = require('log4js')
log4js.configure({
  appenders: {
    api: {
      type: 'file',
      filename: 'logs/api.log'
    }
  },
  categories: {
    default: {
      appenders: ['api'],
      level: 'trace'
    }
  }
})
const apiLogger = log4js.getLogger('api')
app.set('apiLogger', apiLogger)
apiLogger.trace('Server starting....')
// log functions: trace | debug | info | warn | error | fatal

// Security Header Changes
app.use((req, res, next) => {
  res.locals.nonce = crypto.randomBytes(16).toString('base64');
  next();
});

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        ...helmet.contentSecurityPolicy.getDefaultDirectives(),
        "script-src": [
          "'self'",
          "'unsafe-inline'",
          config.clientUrl,
          'https://maps.googleapis.com',
          'https://www.googletagmanager.com',
          'https://az416426.vo.msecnd.net',
          'https://www.google-analytics.com',
          'https://www.googletagmanager.com',
          'https://fonts.googleapis.com'
        ],
        "script-src-elem": [
          "'self'",
          "'unsafe-inline'",
          config.clientUrl,
          'https://maps.googleapis.com',
          'https://www.googletagmanager.com',
          'https://az416426.vo.msecnd.net',
          'https://www.google-analytics.com',
          'https://www.googletagmanager.com',
          'https://fonts.googleapis.com',
          'https://login.microsoftonline.com'
        ],
        "frame-src": [
          "'self'",
          "'unsafe-inline'",
          'https://app.powerbi.com',
          'https://www.google-analytics.com',
          'https://login.microsoftonline.com',
          'https://www.googletagmanager.com',
          'https://fonts.googleapis.com'
        ],
        "connect-src": [
          "'self'",
          "'unsafe-inline'",
          'https://login.microsoftonline.com',
          'https://www.google-analytics.com',
          'https://www.googletagmanager.com',
          'https://fonts.googleapis.com'
        ],
        'style-src': [
          "'self'",
          "'unsafe-inline'",
          'https://login.microsoftonline.com',
          'https://www.google-analytics.com',
          'https://fonts.googleapis.com',
          'https://www.googletagmanager.com',
          'https://fonts.googleapis.com'
        ],
        "style-src-elem": [
          "'self'",
          "'unsafe-inline'",
          'https://login.microsoftonline.com',
          'https://www.google-analytics.com',
          'https://fonts.googleapis.com',
          'https://www.googletagmanager.com',
          'https://fonts.googleapis.com'
        ],
        'img-src': [
          "'self'",
          "'unsafe-inline'",
          'https://login.microsoftonline.com',
          'https://www.google-analytics.com',
          'https://fonts.googleapis.com',
          'https://www.googletagmanager.com',
          'https://fonts.googleapis.com'
        ],
        "font-src": [
          "'self'",
          "'unsafe-inline'",
          'https://login.microsoftonline.com',
          'https://www.google-analytics.com',
          'https://www.googletagmanager.com',
          'https://fonts.googleapis.com',
          'https://fonts.gstatic.com'
        ],
        "script-src-attr": ["'self'", "'unsafe-inline'"],
        "frame-ancestors": ["'self'", "'unsafe-inline'", config.clientUrl],
        "object-src": ["'none'"],
        "base-uri": ["'self'"],
        "form-action": ["'self'"],
        "frame-ancestors": ["'none'"],
        "script-src-attr": ["'none'"]
      },

      crossOriginOpenerPolicy: { policy: "same-origin" },
      crossOriginEmbedderPolicy: { policy: "unsafe-none" },
      crossOriginResourcePolicy: { policy: "same-origin" },

      //  Fixed referrer policy (was unsafe-url before)
      referrerPolicy: { policy: "strict-origin-when-cross-origin" }
    },
  })
);

app.use((req, res, next) => {

  res.header('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.header('Pragma', 'no-cache');

  res.setHeader("X-XSS-Protection", "1; mode=block");
  next();
});

app.use(
  helmet.referrerPolicy({
    policy: ["origin", "unsafe-url"],
  })
);


app.use(helmet.noSniff());

app.use(helmet.ieNoOpen());


app.use(
  helmet.frameguard({
    action: "deny",
  })
);


app.use(
  helmet.dnsPrefetchControl({
    allow: true,
  })
);

// HSTS Header Configuration (add it manually if needed)
// app.use(helmet.hsts({
//   maxAge: 96400,
//   includeSubDomains: true, // Apply to all subdomains
//   preload: true // Enable preloading to browsers that support HSTS preload list
// }));

app.disable('x-powered-by'); // Removes the header

const corsOptions = {
  origin: [config.clientUrl, config.localhost, config.httpsBslocalhost,
  config.httpBslocalhost]
}
app.use(cors(corsOptions));
const dirLog = './logs'
/* istanbul ignore if */
if (!fs.existsSync(dirLog)) {
  fs.mkdirSync(dirLog)
}


/* Commented by Mahadesh - bodyParser is deprecated since express 4.16.0 */

app.use(bodyParser.json({ limit: "50mb" }))
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true, parameterLimit: 50000 }))

// Extended the size limit of request entity
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true, parameterLimit: 50000 }));


const accessLogStream = fs.createWriteStream('logs/morgan.log', { flags: 'a' })
app.use(morgan('combined', {
  stream: accessLogStream
}))
app.use(morgan('short'))

app.post("/admin/home", async function (req, res, next) {


  let respdata;
  let userdata;

  let givenName;
  let mailId;
  let uid;
  let client_app_name;
  let graphmicrosoft
  let roleInfo = [];
  let mid;
  let domName;
  let userName;
  let loginType = "";

  graphmicrosoft = config.microsoft_graph_url;

  try {

    const resp = await axios.get(graphmicrosoft + "me", {

      headers: {
        Authorization: `Bearer ${req.body.access_token}`,
        "Content-Type": "application/json",
      },
    });


    if (resp && resp.data) {

      userName = resp.data.displayName;
      givenName = resp.data.givenName;
      mailId = resp.data.mail;
      uid = resp.data.id;
      mid = resp.data.userPrincipalName;

      if (mid && mid.indexOf("medicaid.ms.gov") > -1) {
        loginType = "DOM";
      }
      else if (mid && mid.indexOf("mdhs.ms.gov") > -1) {
        loginType = "MDHS";
      }
    }
    else {
      next()
    }

  }
  catch (err) {
    apiLogger.error('Error in graph url process ....', err)
    next()
  }

  client_app_name = config.client_app_name;

  try {
    const roleDetails = await axios.get(
      graphmicrosoft + "users/" + uid + "/appRoleAssignments",
      { headers: { Authorization: `Bearer ${req.body.access_token}` } }
    )



    if (roleDetails != null) {
      for (var m = 0; m < roleDetails.data.value.length; m++) {
        if (
          roleDetails.data.value[m].resourceDisplayName ===
          client_app_name
        ) {

          roleInfo.push(roleDetails.data.value[m]);
        }
      }
    }

    if (roleDetails.data && roleDetails.data.value) {

      const roleMap = new Map();
      const availableRoles = [];
      const appRoleList = [];

      try {

        const roleInformation = await axios.get(
          graphmicrosoft + "/servicePrincipals/?$filter=startswith(displayName,'" +
          client_app_name +
          "')", {

          headers: {
            Authorization: `Bearer ${req.body.access_token}`,
            "Content-Type": "application/json",
          },
        });

        if (roleInformation.data.value) {
          for (m = 0; m < roleInformation.data.value.length; m++) {
            for (n = 0; n < roleInformation.data.value[m].appRoles.length; n++) {
              appRoleList.push(roleInformation.data.value[m].appRoles[n]);
            }
          }
        }

        if (roleInfo) {

          if (appRoleList) {
            for (j = 0; j < appRoleList.length; j++) {
              roleMap.set(appRoleList[j].id, appRoleList[j].value);
            }
          }
          if (roleMap) {
            for (i = 0; i < roleInfo.length; i++) {
              if (roleInfo[i].appRoleId) {
                for (let [k, v] of roleMap) {
                  if (k === roleInfo[i].appRoleId) {
                    availableRoles.push(v);
                  }
                }
              }
            }
          }
        }
      }
      catch (err) {
        apiLogger.error('Error in appRoleAssignments ....', err)
        next()
      }

      if (availableRoles && availableRoles.length > 0) {

        let id = uuidv4();

        const dataValue = {
          'name': userName,
          'availableName': givenName,
          'email': mailId,
          'role': availableRoles,
          'loginType': loginType,
          'redirect': 'OAuth',
          'id': id
        };

        // Encrypt
        let ciphertext = CryptoJS.AES.encrypt(mailId, config.mailEncryptionSecret).toString();

        let cipherIDtext = CryptoJS.AES.encrypt(id, config.mailEncryptionSecret).toString();

        const params = new URLSearchParams({
          'mail': ciphertext,
          'id': cipherIDtext
        });

        try {
          cacheConnection && cacheConnection.set(`${config.env}${dataValue.email}${id}`, JSON.stringify(dataValue), { "EX": 2 * 60 * 60 })
        } catch (err) {
          apiLogger.error('Error in cacheConnection ....', err)
          next()
        }

        const safeParams = sanitiseRedirectParams(params);
        const redirectUrl = validateRedirectUrl(
          `${config.redirect_react}admin/dashboard` + (safeParams ? `?${safeParams}` : '')
        );
        res.redirect(303, redirectUrl);

        // res.redirect(303, 'https://dev.cssp.portal.conduent.com/admin/dashboard');
        // res.redirect(303, `${config.redirect_react}admin/dashboard?` + params);

        // res.redirect(303, 'https://dev.cssp.portal.conduent.com/adminbackend/redirectDashboard');
      }
    }
  } catch (error) {
    apiLogger.error('Error in role assignments and routing to dashboard ....', error)
    next()
  }

})

//app.use('/nodebackend/', indexRouter)
app.use('/adminbackend/', indexRouter)
app.use('/reportsBackend/', indexRouter)
app.use('/jsonEditorBackend/', indexRouter)

// Have Node serve the files for our built React app
app.use('/admin/_next', express.static(path.resolve(__dirname, './public/_next')));

// All other GET requests not handled before will return our React app
app.get('*', (req, res) => {
  res.sendFile(path.resolve(__dirname, './public', 'admin.html'));
});

app.use((req, res) => {
  res.status(404).json({
    'statusCode': 404,
    'success': false,
    'message': 'URL not found'
  })
})

module.exports = app
