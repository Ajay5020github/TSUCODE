FROM snaazevsmsspacr.azurecr.io/nodealpine20:v1
LABEL maintainer="mukesh.tatanara@conduent.com"
RUN mkdir -p /home/node/app && chown -R node:node /home/node/app
WORKDIR /home/node/app
COPY package.json /home/node/app
RUN npm install
COPY --chown=node:node . /home/node/app
RUN rm package-lock.json
#USER node
EXPOSE 3000
CMD [ "npm", "run", "startHttps" ]

#Comment above line and Uncomment this only to run in Http mode
#CMD [ "npm", "start" ]